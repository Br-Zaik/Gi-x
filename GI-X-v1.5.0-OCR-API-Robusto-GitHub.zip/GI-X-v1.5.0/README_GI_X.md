# GI X v1.2

Aplicación Android personal para trabajar con una M5Stack Timer Camera X y también con imágenes elegidas manualmente desde el celular.

## Flujo principal

### Modo CÁMARA
1. Activa la Zona Wi‑Fi del celular y abre GI X.
2. Enciende la Timer Camera X con PWR.
3. El firmware preparado conecta solo a la red Wi‑Fi configurada, toma una foto, la envía a GI X y trata de apagarse automáticamente cuando trabaja con batería.
4. GI X hace OCR local mejorado, extrae la pregunta, consulta una API configurada, muestra la respuesta y la lee en voz alta.

También queda el botón **PEDIR FOTO A LA CÁMARA** para dejar una orden pendiente, útil si la cámara ya está activa o para pruebas.

### Modo IMAGEN MANUAL
1. Selecciona **IMAGEN MANUAL**.
2. Pulsa **ELEGIR IMAGEN DEL CELULAR**.
3. GI X corrige la orientación EXIF, prepara la imagen, hace OCR, consulta la API y lee la respuesta.

## OCR mejorado

GI X usa Google ML Kit Text Recognition v2 en el dispositivo. Para aumentar estabilidad con fotos reales:
- limita imágenes enormes para evitar bloqueos por memoria;
- amplía imágenes pequeñas cuando conviene;
- corrige la orientación de fotos de galería usando EXIF;
- hace una lectura sobre una versión normalizada;
- hace una segunda lectura sobre una versión en escala de grises y contraste reforzado;
- compara ambos resultados y conserva el texto más legible.

Ningún OCR puede garantizar 0 errores. La iluminación, enfoque, distancia, inclinación y tamaño de las letras siguen importando.

## APIs

Se conserva el sistema de varias APIs de la base anterior: Gemini, OpenRouter, Mistral y Cohere. Las claves se configuran desde el botón **API** y se guardan localmente en preferencias de Android.

## Cámara

Archivo preparado: `camera_firmware/TimerCameraX_GIX.ino`

Antes de grabarlo en la Timer Camera X hay que cambiar solo:
- `WIFI_NAME`
- `WIFI_PASSWORD`
- `GIX_TOKEN`

El token debe coincidir con **GI X > CÁMARA**.

La configuración de cámara está orientada a OCR: JPEG, UXGA 1600x1200 y varias tomas descartadas al inicio para estabilizar exposición/balance de blancos antes de enviar la foto útil.

## Compilar en GitHub

El ZIP incluye `.github/workflows/build-apk.yml`.

Al subir el contenido a un repositorio GitHub en `main` o `master`, GitHub Actions intentará compilar `app-debug.apk`. También puede ejecutarse manualmente desde **Actions > Build GI X APK > Run workflow**.

El APK generado queda como artefacto llamado `GI-X-debug-apk`.

## Versión

- applicationId: `com.gix.cameraai`
- versionCode: `20`
- versionName: `1.5.0`
- minSdk: 24
- targetSdk: 34

## Cheaper Inference / DeepSeek
GI X incluye un espacio dedicado para la API pagada de Cheaper Inference, que funciona como intermediario compatible con OpenAI. Acepta claves `ir_live_...` y `ci_live_...`, usa por defecto `deepseek-v4-flash`, prueba la conexión antes de marcarla como disponible y la deja como API principal cuando funciona. Las demás APIs quedan disponibles como respaldo. La clave se guarda localmente en las preferencias privadas de la app.

## v1.2.2
Corrección de compilación en `MainActivity.kt`: parámetros de layout del `ScrollView` corregidos para Android/Kotlin. Sin cambios en el funcionamiento previsto.


## Cheaper Inference / DeepSeek (v1.2.2)

GI X trata Cheaper Inference como un intermediario compatible con OpenAI, no como la API oficial de DeepSeek.
La conexion usa `https://api.cheaperinference.com/v1/chat/completions`, `Authorization: Bearer <clave>` y el modelo predeterminado `deepseek-v4-flash`.
Se admiten claves `ir_live_...` de cuentas anteriores y claves `ci_live_...` documentadas actualmente. Al pegar una clave, GI X elimina espacios, comillas envolventes y caracteres invisibles comunes antes de guardarla y probarla.
La clave real del usuario NO esta incluida en el proyecto ni en GitHub.


## v1.2.4
- Varias preguntas en una sola foto.
- Una llamada a la API para toda la hoja.
- Respuesta con formato pregunta + respuesta.


## v1.3.0
- Vista previa se puede abrir completa.
- Cuadros OCR y Respuesta con VER TODO / OCULTAR.
- Historial local con abrir, borrar y borrar todo.
- Velocidades de voz de 0.25x a 2.00x.

## v1.3.1
- Corregido error de compilación en MainActivity.kt.
- Corregida concatenación de pregunta + respuesta.
- Corregido patrón de validación de clave del intermediario.


## v1.4.0
- OCR y Respuesta quedan en cuadros de tamaño fijo con desplazamiento interno por dedo.
- API simplificada a una sola Cheaper Inference / DeepSeek de pago.
- La clave queda guardada y el estado se muestra permanentemente en la pantalla principal.
- Eliminado el bloqueo de "EN ESPERA" del flujo principal: los errores temporales no desactivan la API.
- Hasta 3 intentos automáticos por consulta ante fallos temporales/conexión/límite transitorio.
- Tiempos de espera de red ampliados para hojas con varias preguntas.
- Mejor separación OCR de alternativas A-E, títulos y subtítulos.
- Formatos mejorados para alternativas, verdadero/falso y completar frases.


## v1.4.1
- Consulta real a DeepSeek: una sola solicitud, sin 3 envíos repetidos.
- Timeout simple: 180 s; hojas múltiples/consultas complejas: 240 s.
- Conexión: hasta 20 s.
- Eliminados mensajes antiguos de "espera" y "cambiar a otra API" en errores de red.
- La API pagada permanece guardada aunque una consulta falle por tiempo o conexión.


## v1.4.2
- Corrección crítica del validador de respuestas múltiples.
- Hojas mixtas se validan como lote completo y no como un único ejercicio.


## v1.4.5
- Cheaper Inference sigue usando la misma API Key y el mismo endpoint.
- Modelo fijo cambiado de `deepseek-v4-pro` a `deepseek-v4-flash`.
- Las configuraciones anteriores guardadas con V4 Pro se migran automáticamente a V4 Flash.
- Se conserva OCR, respuestas múltiples, historial, voz, cámara y validadores de v1.4.4.


## v1.4.9
GI X añade reconstrucción conservadora de tablas usando la geometría del OCR de ML Kit. Puede conservar encabezados, filas, columnas y celdas vacías para tablas de 2 a 6 columnas y enviar esa estructura ordenada a la IA. La mejora es general y no está limitada a una tabla específica.


## v1.5.0
- OCR reconstruido por geometría real de ML Kit: ordena arriba→abajo y une números aislados con su enunciado.
- Los números de una sola cifra ya no se eliminan antes de formar preguntas.
- Acepta numeración donde ML Kit pierde el punto, por ejemplo `4 Cuales son...`.
- Preguntas de completar con `.....`/`____` se conservan como ejercicios.
- Símbolos y datos cortos como Fe, Pb, Ag, Au, Cu, Zn, fórmulas y unidades siguen protegidos.
- Las regiones de tablas reales se retiran del texto normal antes de extraer preguntas, evitando que palabras como NAVEGADOR o REDES SOCIALES se peguen a otra pregunta.
- Tablas reales permanecen estructuradas con encabezados, filas, columnas y celdas vacías.
- Verdadero/Falso reconoce también afirmaciones que terminan en `( )`.
- Lotes normales reducidos a 3 preguntas; V/F usa hasta 5; tablas se consultan por separado.
- Más margen de tokens de salida.
- Si un lote falla o alcanza el límite de salida, GI X lo recupera pregunta por pregunta y conserva todas las respuestas que sí consiga.
- Un bloque que llega a MAX_TOKENS ya no se reintenta idéntico dos veces: se divide inmediatamente.
