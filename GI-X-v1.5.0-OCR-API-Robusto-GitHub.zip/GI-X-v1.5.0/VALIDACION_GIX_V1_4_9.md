# GI X v1.4.9 - Robustez OCR + API por bloques

- versionCode: 19
- versionName: 1.4.9
- Conserva números de pregunta aunque ML Kit separe `1.` del enunciado.
- Conserva datos cortos relevantes dentro de preguntas: Fe, Pb, Ag, Au, fórmulas, unidades y abreviaturas.
- El detector de tablas exige evidencia fuerte para 2 columnas y ya no usa una mención casual de “función” como señal de tabla.
- Una tabla detectada solo se adjunta a una consigna de tabla explícita; no se pega automáticamente a la última pregunta.
- Consultas con más de 5 preguntas se dividen en bloques de 5 y las respuestas se vuelven a numerar globalmente.
- Los lotes de V/F se marcan y piden en formato compacto para reducir salida.
- Reintentos de API en errores temporales: 2 intentos.
- Timeouts de ejecución reducidos para evitar esperas excesivas: 60 s normal / 90 s compleja.
- Si falla un bloque después de responder anteriores, GI X conserva y muestra lo ya respondido en lugar de descartarlo.
