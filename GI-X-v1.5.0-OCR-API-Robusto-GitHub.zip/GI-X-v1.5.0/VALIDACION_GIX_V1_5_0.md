# GI X v1.5.0 - Reconstrucción OCR y recuperación API

- versionCode: 20
- versionName: 1.5.0

## Fallos corregidos
1. Números 1–9 aislados por ML Kit ya no se eliminan.
2. Se reconstruye el orden visual usando bounding boxes de ML Kit.
3. Numeración sin punto (`4 Cuales...`) se reconoce como pregunta.
4. Fe, Pb, Ag y otros símbolos/datos cortos se conservan.
5. La zona de una tabla detectada se elimina del texto lineal y se conserva aparte de forma estructurada.
6. Encabezados no deben convertirse en preguntas por tener un número OCR esperando.
7. V/F usa `( )` como señal adicional de ejercicio.
8. Lotes API: 3 normales, 5 V/F, tablas aisladas.
9. Más margen de tokens de salida.
10. Si un lote falla o se corta, se recupera automáticamente pregunta por pregunta.

## Regresiones de lógica ejecutadas
Se probaron entradas equivalentes al contenido de las tres hojas usadas como referencia:
- Fundamentos de Minería: 7/7 preguntas; Fe, Pb, Ag conservados.
- Aplicaciones en Internet: 9/9 ejercicios; preguntas 1–8 separadas y tabla 9 asociada correctamente.
- Verdadero/Falso: 20/20 afirmaciones, numeración 1–20 continua, encabezados fuera de las preguntas.

También se compiló y ejecutó en JVM el extractor con un stub de tablas y se compiló/ejecutó el formateador de geometría con stubs de Rect/Text para verificar la sintaxis y el ordenado de filas. El proyecto Android completo debe compilarse mediante el workflow incluido de GitHub Actions.
