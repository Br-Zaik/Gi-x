package com.gix.cameraai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.gix.cameraai.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.Executors
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener, CameraBridgeServer.Listener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: AppPrefs
    private lateinit var apiSettings: GeminiSettings
    private lateinit var onlineProvider: OnlineAnswerProvider
    private val cameraServer: CameraBridgeServer?
        get() = CameraLinkService.currentServer()
    private lateinit var cameraJournal: CameraPhotoJournal
    private val deferredCameraBatches = ArrayDeque<List<String>>()
    private var activeCameraPhotoIds: List<String> = emptyList()
    private val observedJournalIds = mutableSetOf<String>()
    private var lastSevereThermal = false
    private lateinit var historyRepository: HistoryRepository
    private lateinit var ocrProcessor: OcrProcessor
    private val ioExecutor = Executors.newSingleThreadExecutor()
    private val cameraIoExecutor = Executors.newSingleThreadExecutor()
    private val galleryExecutor = ThreadPoolExecutor(
        1,
        1,
        0L,
        TimeUnit.MILLISECONDS,
        ArrayBlockingQueue<Runnable>(4),
        ThreadPoolExecutor.DiscardOldestPolicy(),
    )
    private val recentPhotoDeduper = RecentPhotoDeduper()
    private val pendingCameraBatches = ArrayDeque<QueuedCameraBatch>()
    private val cameraBatchCollector = ArrayDeque<QueuedCameraPhoto>()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val processing = AtomicBoolean(false)

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsInitializing = false
    private var pendingSpeechText: String? = null
    private var activeSpeechText: String? = null
    private var activeSpeechFinalId: String? = null
    private var speechRetryCount = 0
    private var speechSessionId = 0L
    private var speechRecoveryInProgress = false
    private var isSpeakingAnswer = false
    private var autoMode = true
    private var stopped = false
    @Volatile private var destroyedForAsync = false
    private var inputMode = InputMode.CAMERA
    @Volatile private var activeCaptureRequestId: String? = null
    private var cameraStatusTicker: Runnable? = null
    private var lastExtractedQuestions: List<String> = emptyList()
    private var previewBitmap: Bitmap? = null
    private var batchPreviewBitmaps: List<Bitmap> = emptyList()
    private var lastDisplayedOcrText: String = ""
    private var lastSourceLabel: String = "desconocido"
    private var pendingOcrDisplayOverride: String? = null
    private var pendingBatchInfo: String? = null
    private var pendingMissingQuestionNumbers: List<Int> = emptyList()
    private var pendingCoverageNote: String? = null
    private var lockAppOnScreen = false
    private var touchGuard: View? = null
    private var unlockTapCount = 0
    private var lastUnlockTapAtMs = 0L
    private var backPressCount = 0
    private var lastBackPressAtMs = 0L
    private var cameraBatchFinalizeRunnable: Runnable? = null
    private var cameraBatchOpenedAtMs: Long = 0L

    private data class QueuedCameraPhoto(
        val jpeg: ByteArray,
        val source: String,
        val requestId: String? = null,
        val journalId: String? = null,
    )

    private data class QueuedCameraBatch(
        val photos: List<QueuedCameraPhoto>,
        val label: String,
    )

    private data class ManualBatchOcrItem(
        val rawText: String,
        val quality: OcrProcessor.ImageQualityReport,
    )

    private val openPhotosLauncher = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isEmpty()) return@registerForActivityResult
        loadPhotosFromUris(uris)
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* Si deniega, Android aún permite FGS, pero podría ocultar la notificación. */ }

    private val legacyGalleryPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (::binding.isInitialized && !granted) {
            binding.tvStatus.text = "GI X seguirá funcionando, pero Android no permitió guardar fotos en Galería."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = AppPrefs(this)
        cameraJournal = CameraPhotoJournal(this)
        apiSettings = GeminiSettings(this)
        onlineProvider = OnlineAnswerProvider(this)
        historyRepository = HistoryRepository(this)
        ocrProcessor = OcrProcessor(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            legacyGalleryPermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        ttsInitializing = true
        tts = TextToSpeech(this, this)

        // Limpia estados antiguos de "espera" de la API pagada sin borrar la clave.
        apiSettings.getApiConfigs()
            .filter { it.provider == NetProvider.CHEAPER_INFERENCE }
            .forEach { apiSettings.shouldSkip(it) }

        setupButtons()
        setupInternalScroll(binding.svOcr)
        setupInternalScroll(binding.svAnswer)
        renderHistory()
        updateApiChip()
        startCameraServer()
        startCameraStatusTicker()
        // Si Android recreó la UI, recuperar originales guardados por el servicio.
        mainHandler.postDelayed({ if (!stopped) restoreJournaledCameraPhotos() }, 1_000L)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun setupButtons() {
        binding.inputModeGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            when (checkedId) {
                R.id.btnModeCamera -> setInputMode(InputMode.CAMERA)
                R.id.btnModeImage -> setInputMode(InputMode.IMAGE)
            }
        }
        binding.inputModeGroup.check(R.id.btnModeCamera)

        // La TimerCamera-X sube su JPEG al encender, sin solicitarlo desde el móvil.
        // La app ya está escuchando desde startCameraServer(), incluso si está resolviendo
        // otra foto: los lotes nuevos se encolan de forma segura.
        binding.btnCapture.visibility = View.GONE
        binding.btnAuto.text = "BLOQUEAR TOQUES"
        binding.btnAuto.setOnClickListener { enableTouchGuard() }
        binding.btnStop.text = "SALIR"
        binding.btnStop.setOnClickListener { confirmExitApp() }

        binding.btnChooseImage.setOnClickListener {
            stopped = false
            openPhotosLauncher.launch(arrayOf("image/*"))
        }

        binding.btnApi.setOnClickListener { showApiDialog() }
        binding.btnVoice.setOnClickListener { showVoiceDialog() }
        binding.btnCameraSettings.setOnClickListener { showCameraDialog() }
        binding.btnOpenPreview.setOnClickListener { showPreviewDialog() }
        binding.btnClearHistory.setOnClickListener { confirmClearHistory() }

        // La protección nueva se activa desde BLOQUEAR TOQUES y cubre la pantalla.
        binding.cbLockApp.visibility = View.GONE
    }

    private fun setInputMode(mode: InputMode) {
        if (inputMode == mode && binding.cameraActions.visibility == if (mode == InputMode.CAMERA) View.VISIBLE else View.GONE) {
            return
        }
        inputMode = mode
        when (mode) {
            InputMode.CAMERA -> {
                binding.cameraActions.visibility = View.VISIBLE
                binding.btnChooseImage.visibility = View.GONE
                autoMode = true
                stopped = false
                // Espera automática de fotografías en cuanto el modo CÁMARA está activo.
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                binding.tvStatus.text = "Cámara automática: esperando foto. Activa tu Zona Wi-Fi y deja GI X abierto."
            }
            InputMode.IMAGE -> {
                autoMode = false
                releaseScreenAwakeIfAllowed()
                cameraServer?.cancelCapture()
                activeCaptureRequestId = null
                binding.cameraActions.visibility = View.GONE
                binding.btnChooseImage.visibility = View.VISIBLE
                binding.tvStatus.text = "Modo IMAGEN MANUAL. Puedes elegir de 1 a 4 imágenes del mismo documento. GI X las une, ordena y evita duplicados."
            }
        }
    }

    private fun startCameraServer() {
        CameraLinkService.attach(this)
        // Se inicia desde Activity visible (cumple restricciones de inicio en Android 12+).
        ContextCompat.startForegroundService(this, Intent(this, CameraLinkService::class.java))
    }

    private fun restoreJournaledCameraPhotos(): Boolean {
        // Leer solo 4 JPEG por ciclo: nunca cargar 150 MB al mismo tiempo en UI.
        val toRestore = cameraJournal.pendingIds()
            .filterNot { it in observedJournalIds }.take(MAX_CAMERA_BATCH_IMAGES)
        if (toRestore.isEmpty()) return false
        for (id in toRestore) {
            val entry = cameraJournal.read(id) ?: continue
            observedJournalIds.add(id)
            // La entrega puede haber ocurrido hace segundos antes de recrearse la UI.
            if (recentPhotoDeduper.isDuplicate(entry.jpeg)) continue
            enqueueCameraPhotoForBatch(QueuedCameraPhoto(entry.jpeg, "cámara recuperada", entry.requestId, entry.id))
        }
        return true
    }

    private fun isThermallySevere(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        val power = getSystemService(Context.POWER_SERVICE) as PowerManager
        return power.currentThermalStatus >= PowerManager.THERMAL_STATUS_SEVERE
    }

    private fun startCameraStatusTicker() {
        val ticker = object : Runnable {
            override fun run() {
                updateCameraChip()
                val severe = isThermallySevere()
                if (severe != lastSevereThermal) {
                    lastSevereThermal = severe
                    binding.tvStatus.text = if (severe) {
                        "Temperatura elevada: guardando fotos y pausando tareas nuevas hasta enfriarse."
                    } else "Temperatura normal. GI X continúa con fotos pendientes."
                    if (!severe) scheduleNextAutoIfNeeded()
                }
                mainHandler.postDelayed(this, 2_000L)
            }
        }
        cameraStatusTicker = ticker
        mainHandler.post(ticker)
    }

    private fun requestCameraCapture(manual: Boolean) {
        if (processing.get()) {
            binding.tvStatus.text = "Espera: GI X todavía está procesando la foto anterior."
            return
        }
        if (activeCaptureRequestId != null) {
            binding.tvStatus.text = "Ya hay una foto solicitada. Esperando a la cámara..."
            return
        }

        val server = cameraServer ?: run {
            binding.tvStatus.text = "Servidor reiniciando, espera unos segundos."
            return
        }
        val requestId = server.requestCapture()
        activeCaptureRequestId = requestId
        binding.tvStatus.text = if (cameraServer?.isCameraConnected() == true) {
            "Orden enviada. Esperando la foto de Timer Camera X..."
        } else {
            "Orden preparada. Enciende la cámara y verifica que esté conectada a tu Zona Wi-Fi."
        }

        mainHandler.postDelayed({
            if (activeCaptureRequestId == requestId) {
                cameraServer?.cancelCapture()
                activeCaptureRequestId = null
                if (!processing.get()) {
                    binding.tvStatus.text = if (manual) {
                        "La cámara no respondió. Revisa Zona Wi-Fi, cámara y clave de enlace."
                    } else {
                        "Auto: cámara sin respuesta. Reintentaré cuando vuelva a estar disponible."
                    }
                }
            }
        }, 25_000L)
    }

    private fun stopCurrentCycle() {
        stopped = true
        autoMode = false
        // La salida confirmada cancela el ciclo y permite descansar la pantalla.
        if (!lockAppOnScreen) window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        cameraServer?.cancelCapture()
        activeCaptureRequestId = null
        onlineProvider.cancelActiveRequest()
        tts?.stop()
        pendingSpeechText = null
        activeSpeechText = null
        activeSpeechFinalId = null
        isSpeakingAnswer = false
        speechRetryCount = 0
        speechRecoveryInProgress = false
        ttsInitializing = false
        processing.set(false)
        pendingOcrDisplayOverride = null
        pendingBatchInfo = null
        pendingMissingQuestionNumbers = emptyList()
        pendingCoverageNote = null
        pendingCameraBatches.clear()
        deferredCameraBatches.clear()
        activeCameraPhotoIds = emptyList()
        cameraBatchCollector.clear()
        cameraBatchFinalizeRunnable?.let { mainHandler.removeCallbacks(it) }
        cameraBatchFinalizeRunnable = null
        // Solo SALIR explícito termina el servicio: no hacerlo en onDestroy accidental.
        stopService(Intent(this, CameraLinkService::class.java))
        binding.tvStatus.text = if (inputMode == InputMode.CAMERA) {
            "Detenido. Vuelve a encender la cámara cuando quieras otra foto."
        } else {
            "Detenido. Pulsa ELEGIR 1–4 IMÁGENES cuando quieras continuar."
        }
    }

    override fun onServerStarted(port: Int) {
        runOnUiThread {
            if (inputMode == InputMode.CAMERA) {
                binding.tvStatus.text = "GI X listo. Activa tu Zona Wi-Fi y enciende la cámara; recibirá la foto por el puerto $port."
            }
        }
    }

    override fun onServerError(message: String) {
        runOnUiThread {
            binding.tvStatus.text = "Error del enlace con cámara: $message"
            binding.tvCameraChip.text = "Cámara: error"
        }
    }

    override fun onCameraSeen() {
        runOnUiThread { updateCameraChip() }
    }

    override fun onPhotoReceived(jpeg: ByteArray, requestId: String?) {
        activeCaptureRequestId = null

        // La cámara puede reenviar el MISMO JPEG si la red falla. Lo confirmamos,
        // pero no repetimos OCR/API/voz si el contenido es idéntico.
        if (recentPhotoDeduper.isDuplicate(jpeg)) {
            runOnUiThread {
                binding.tvStatus.text = "La cámara reenvió la misma foto. GI X evitó procesarla dos veces."
            }
            return
        }

        cameraIoExecutor.execute {
            // Validación de dimensiones SIN expandir el JPEG completo a memoria. La v1.6.8
            // hacía aquí una decodificación ARGB_8888 completa antes incluso de encolar.
            val info = CameraJpegDecoder.inspect(jpeg)
            if (info == null) {
                runOnUiThread {
                    binding.tvStatus.text = "La cámara envió una imagen JPEG inválida o demasiado grande."
                }
                return@execute
            }

            // El guardado en Galería ya no bloquea la recepción del siguiente JPEG ni el
            // inicio del OCR. El ByteArray recibido es propio de esta petición; no hace
            // falta duplicarlo con copyOf(), ahorrando memoria cuando llegan varias fotos.
            runCatching {
                galleryExecutor.execute {
                    CameraPhotoStore.save(this, jpeg)
                }
            }

            runOnUiThread {
                // Una foto física de la TimerCamera siempre tiene prioridad y activa el
                // modo CÁMARA aunque el usuario hubiera dejado la pantalla en MANUAL.
                if (inputMode != InputMode.CAMERA) {
                    binding.inputModeGroup.check(R.id.btnModeCamera)
                }

                val journalId = cameraJournal.idFor(jpeg)
                observedJournalIds.add(journalId)
                enqueueCameraPhotoForBatch(
                    QueuedCameraPhoto(jpeg, "cámara", requestId, journalId)
                )
            }
        }
    }

    private fun enqueueCameraPhotoForBatch(photo: QueuedCameraPhoto) {
        val incomingRequestId = photo.requestId?.trim().orEmpty()
        val currentRequestId = cameraBatchCollector.firstOrNull()?.requestId?.trim().orEmpty()

        // Si cambia el requestId, cerramos el lote anterior antes de mezclar capturas.
        if (cameraBatchCollector.isNotEmpty() &&
            (incomingRequestId.isNotBlank() || currentRequestId.isNotBlank()) &&
            incomingRequestId != currentRequestId) {
            finalizeCameraCollector()
        }

        if (cameraBatchCollector.isEmpty()) {
            cameraBatchOpenedAtMs = System.currentTimeMillis()
        }

        while (cameraBatchCollector.size >= MAX_CAMERA_BATCH_IMAGES) {
            finalizeCameraCollector()
        }

        cameraBatchCollector.addLast(photo)
        val received = cameraBatchCollector.size
        val waitingForMore = received < MAX_CAMERA_BATCH_IMAGES
        binding.tvStatus.text = if (waitingForMore) {
            "Cámara: recibí $received de $MAX_CAMERA_BATCH_IMAGES imágenes del mismo documento. Esperando más para formar el lote..."
        } else {
            "Cámara: recibí $received imágenes. Preparando el lote automático..."
        }

        cameraBatchFinalizeRunnable?.let { mainHandler.removeCallbacks(it) }
        cameraBatchFinalizeRunnable = Runnable {
            cameraBatchFinalizeRunnable = null
            finalizeCameraCollector()
        }

        if (received >= MAX_CAMERA_BATCH_IMAGES) {
            mainHandler.post(cameraBatchFinalizeRunnable!!)
        } else {
            // Firmware antiguo (sin id): 1 foto, respuesta rápida sin esperar 7 s.
            // Firmware de 4 fotos (mismo id): esperar a recibir el lote completo.
            val idleMs = if (incomingRequestId.isBlank()) 1_200L else
                if (received <= 1) CAMERA_BATCH_FIRST_IDLE_MS else CAMERA_BATCH_CONTINUATION_IDLE_MS
            mainHandler.postDelayed(cameraBatchFinalizeRunnable!!, idleMs)
        }
    }

    private fun finalizeCameraCollector() {
        cameraBatchFinalizeRunnable?.let { mainHandler.removeCallbacks(it) }
        cameraBatchFinalizeRunnable = null
        if (cameraBatchCollector.isEmpty()) return

        val photos = buildList {
            while (cameraBatchCollector.isNotEmpty()) {
                add(cameraBatchCollector.removeFirst())
            }
        }
        val label = if (photos.size > 1) {
            "lote cámara · ${photos.size} imágenes"
        } else {
            photos.first().source
        }
        val batch = QueuedCameraBatch(photos, label)
        cameraBatchOpenedAtMs = 0L

        if (stopped) return

        if (processing.get() || isSpeakingAnswer || !pendingSpeechText.isNullOrBlank()) {
            enqueuePendingCameraBatch(batch)
            binding.tvStatus.text = if (photos.size > 1) {
                "Recibí ${photos.size} imágenes de cámara. GI X las procesará juntas al terminar el trabajo actual."
            } else {
                "Foto recibida. GI X la procesará al terminar el trabajo actual."
            }
            return
        }

        processCameraBatch(batch)
    }

    private fun enqueuePendingCameraBatch(batch: QueuedCameraBatch) {
        val incomingBytes = batch.photos.sumOf { it.jpeg.size.toLong() }
        fun queuedBytes(): Long = pendingCameraBatches.sumOf { queued ->
            queued.photos.sumOf { it.jpeg.size.toLong() }
        }

        // No dejamos que una ráfaga/reintentos acumulen decenas de MB comprimidos mientras
        // OCR/API/voz siguen ocupados. Se conserva siempre el trabajo más reciente.
        while (pendingCameraBatches.isNotEmpty() &&
            (pendingCameraBatches.size >= MAX_PENDING_CAMERA_BATCHES ||
                queuedBytes() + incomingBytes > MAX_PENDING_CAMERA_BYTES)) {
            val old = pendingCameraBatches.pollFirst()
            if (old != null) deferredCameraBatches.addLast(old.photos.mapNotNull { it.journalId })
        }
        pendingCameraBatches.addLast(batch)
    }

    private fun processCameraBatch(batch: QueuedCameraBatch) {
        if (isThermallySevere()) {
            enqueuePendingCameraBatch(batch)
            binding.tvStatus.text = "Calor elevado: fotos guardadas, esperando temperatura segura."
            return
        }
        activeCameraPhotoIds = batch.photos.mapNotNull { it.journalId }
        // v1.6.22: visión IA es la ruta principal. Si no hay una API configurada,
        // el mismo lote entra directamente al OCR local en vez de quedar bloqueado.
        if (apiSettings.hasApiKey()) {
            processVisionCameraBatch(batch)
        } else {
            binding.tvStatus.text = "Sin API disponible para visión. Usando OCR local de respaldo..."
            processCameraImageBatch(batch)
        }
    }

    private fun processVisionCameraBatch(batch: QueuedCameraBatch) {
        if (!processing.compareAndSet(false, true)) {
            enqueuePendingCameraBatch(batch)
            binding.tvStatus.text = "GI X está ocupado. El lote de cámara quedó en espera."
            return
        }
        if (!apiSettings.hasApiKey()) {
            processing.set(false)
            binding.tvStatus.text = "Visión IA no disponible. Activando OCR local de respaldo..."
            processCameraImageBatch(batch)
            return
        }

        stopped = false
        lastExtractedQuestions = emptyList()
        lastDisplayedOcrText = ""
        lastSourceLabel = batch.label
        pendingOcrDisplayOverride = null
        pendingBatchInfo = null
        pendingMissingQuestionNumbers = emptyList()
        pendingCoverageNote = null
        clearAllPreviews()
        binding.tvOcr.text = "Enviando ${batch.photos.size} imagen(es) originales a la IA para compararlas..."
        binding.tvAnswer.text = "Esperando lectura visual..."
        binding.tvStatus.text = "Visión IA: comparando ${batch.photos.size} imagen(es) juntas y usando la toma más legible de cada parte."

        ioExecutor.execute {
            val payloads = batch.photos.take(MAX_MANUAL_BATCH_IMAGES).map { photo ->
                VisionImagePayload(photo.jpeg, "image/jpeg")
            }

            val previews = batch.photos.take(MAX_MANUAL_BATCH_IMAGES).mapNotNull { photo ->
                val decoded = CameraJpegDecoder.decodeForOcr(photo.jpeg) ?: return@mapNotNull null
                val thumb = makePreviewThumbnail(decoded)
                if (!decoded.isRecycled) decoded.recycle()
                thumb
            }

            if (!destroyedForAsync) runOnUiThread {
                batchPreviewBitmaps = previews
                previewBitmap = batchPreviewBitmaps.firstOrNull()
                previewBitmap?.let {
                    binding.ivPreview.setImageBitmap(it)
                    binding.tvPreviewPlaceholder.visibility = View.GONE
                }
            }

            val result = onlineProvider.extractQuestionsFromImages(payloads).trim()
            if (destroyedForAsync) {
                processing.set(false)
                return@execute
            }
            runOnUiThread {
                if (stopped) {
                    processing.set(false)
                    return@runOnUiThread
                }
                val visionQuestions = if (result.startsWith(OnlineAnswerProvider.API_ERROR_PREFIX)) {
                    emptyList()
                } else {
                    runCatching { OcrQuestionExtractor.extractQuestions(result) }.getOrDefault(emptyList())
                }
                if (result.startsWith(OnlineAnswerProvider.API_ERROR_PREFIX) || visionQuestions.isEmpty()) {
                    processing.set(false)
                    val detail = result.removePrefix(OnlineAnswerProvider.API_ERROR_PREFIX).trim()
                    binding.tvStatus.text = "Visión IA no pudo reconstruir preguntas. Activando OCR local de respaldo..."
                    binding.tvAnswer.text = if (detail.isBlank() || detail == result) {
                        "Usando OCR local de respaldo."
                    } else {
                        "Visión IA falló; GI X continuará con OCR local."
                    }
                    processCameraImageBatch(batch)
                    return@runOnUiThread
                }
                pendingBatchInfo = "Visión IA · ${payloads.size} imagen(es) comparadas"
                binding.tvStatus.text = "Visión IA terminó la lectura. Organizando preguntas..."
                handleOcrResult(result)
            }
        }
    }

    private fun processCameraImageBatch(batch: QueuedCameraBatch) {
        if (!processing.compareAndSet(false, true)) {
            enqueuePendingCameraBatch(batch)
            binding.tvStatus.text = "GI X está ocupado. El lote de cámara quedó en espera."
            return
        }
        stopped = false
        lastExtractedQuestions = emptyList()
        lastDisplayedOcrText = ""
        lastSourceLabel = batch.label
        pendingOcrDisplayOverride = null
        pendingBatchInfo = null
        pendingMissingQuestionNumbers = emptyList()
        pendingCoverageNote = null
        clearAllPreviews()
        binding.tvOcr.text = "Procesando lote de ${batch.photos.size} imágenes de cámara..."
        binding.tvAnswer.text = "Leyendo preguntas..."
        binding.tvStatus.text = "Lote cámara: preparando imagen 1 de ${batch.photos.size}."

        val items = mutableListOf<ManualBatchOcrItem>()
        val previews = mutableListOf<Bitmap>()
        var failedImages = 0
        var heavyPasses = 0

        fun finishBatch() {
            if (stopped) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                processing.set(false)
                return
            }
            val rawTexts = items.map { it.rawText }
            if (rawTexts.none { it.isNotBlank() }) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                processing.set(false)
                binding.tvStatus.text = "No pude identificar preguntas legibles en las imágenes de cámara."
                binding.tvOcr.text = "No se detectaron preguntas."
                binding.tvAnswer.text = "Acerca la cámara, mejora la luz y vuelve a intentarlo."
                scheduleNextAutoIfNeeded()
                return
            }

            batchPreviewBitmaps = previews.toList()
            previewBitmap = batchPreviewBitmaps.firstOrNull()
            previewBitmap?.let {
                binding.ivPreview.setImageBitmap(it)
                binding.tvPreviewPlaceholder.visibility = View.GONE
            }

            val merge = MultiImageDocumentMerger.merge(
                rawTexts,
                items.map { it.quality.selectionScore() }
            )
            pendingMissingQuestionNumbers = merge.missingQuestionNumbers
            pendingCoverageNote = merge.coverageNote.takeIf { it.isNotBlank() }
            pendingOcrDisplayOverride = merge.questions.joinToString("\n\n")

            pendingBatchInfo = null

            if (merge.combinedRaw.isBlank()) {
                processing.set(false)
                binding.tvStatus.text = "El lote de cámara llegó, pero no pude reconstruir texto útil."
                binding.tvOcr.text = pendingOcrDisplayOverride.orEmpty()
                binding.tvAnswer.text = "Vuelve a tomar la hoja con mejor luz o mayor solapamiento."
                pendingOcrDisplayOverride = null
                pendingBatchInfo = null
                pendingMissingQuestionNumbers = emptyList()
        pendingCoverageNote = null
                scheduleNextAutoIfNeeded()
                return
            }

            handleOcrResult(merge.combinedRaw)
        }

        fun rescueAt(order: List<Int>, position: Int) {
            if (position >= order.size) {
                finishBatch()
                return
            }
            if (stopped) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                processing.set(false)
                return
            }

            // Para máxima precisión hacemos rescate fuerte sobre TODAS las imágenes
            // del lote, de forma secuencial y controlada. Es algo más lento que
            // cortar antes, pero mejora la recuperación de preguntas finales borrosas
            // y reduce casos donde una foto buena tapa una pregunta que otra sí aporta.

            val imageIndex = order[position]
            binding.tvStatus.text = "Analizando imagen ${position + 1} de ${order.size}..."
            ioExecutor.execute {
                val photo = batch.photos[imageIndex]
                val bitmap = CameraJpegDecoder.decodeForOcr(photo.jpeg)
                if (bitmap == null) {
                    if (!destroyedForAsync) runOnUiThread { rescueAt(order, position + 1) }
                    return@execute
                }
                ocrProcessor.process(
                    bitmap,
                    onSuccess = { raw ->
                        heavyPasses++
                        if (raw.isNotBlank()) {
                            val better = chooseBetterBatchOcr(items[imageIndex].rawText, raw.trim())
                            items[imageIndex] = ManualBatchOcrItem(better, items[imageIndex].quality)
                        } else {
                            failedImages++
                        }
                        if (!bitmap.isRecycled) bitmap.recycle()
                        if (!destroyedForAsync) runOnUiThread { rescueAt(order, position + 1) }
                    },
                    onError = {
                        failedImages++
                        if (!bitmap.isRecycled) bitmap.recycle()
                        if (!destroyedForAsync) runOnUiThread { rescueAt(order, position + 1) }
                    }
                )
            }
        }

        fun startAdaptiveRescue() {
            val order = buildAdaptiveRescueOrder(items)
            if (order.isEmpty()) {
                finishBatch()
                return
            }
            rescueAt(order, 0)
        }

        fun processAt(index: Int) {
            if (index >= batch.photos.size) {
                startAdaptiveRescue()
                return
            }
            if (stopped) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                processing.set(false)
                return
            }

            binding.tvStatus.text = "Preparando imagen ${index + 1} de ${batch.photos.size}..."
            ioExecutor.execute {
                val photo = batch.photos[index]
                val bitmap = CameraJpegDecoder.decodeForOcr(photo.jpeg)
                if (bitmap == null) {
                    failedImages++
                    items += ManualBatchOcrItem(
                        "",
                        OcrProcessor.ImageQualityReport(128.0, 64.0, 0.0, false, false, true)
                    )
                    if (!destroyedForAsync) runOnUiThread { processAt(index + 1) }
                    return@execute
                }

                val quality = runCatching { ocrProcessor.assessQuality(bitmap) }
                    .getOrElse { OcrProcessor.ImageQualityReport(128.0, 64.0, 100.0, false, false, false) }
                val thumb = makePreviewThumbnail(bitmap)
                previews += thumb

                // Aquí NO hacemos OCR. Primero preparamos/medimos todas las capturas y
                // luego el pipeline completo las procesa de una en una en un orden único.
                items += ManualBatchOcrItem("", quality)
                if (!bitmap.isRecycled) bitmap.recycle()
                if (!destroyedForAsync) runOnUiThread { processAt(index + 1) }
            }
        }

        processAt(0)
    }

    private fun loadPhotosFromUris(uris: List<Uri>) {
        if (uris.size > MAX_MANUAL_BATCH_IMAGES) {
            binding.tvStatus.text = "Seleccionaste ${uris.size} imágenes. GI X acepta hasta $MAX_MANUAL_BATCH_IMAGES por lote."
            Toast.makeText(this, "Elige máximo $MAX_MANUAL_BATCH_IMAGES imágenes.", Toast.LENGTH_LONG).show()
            return
        }
        // v1.6.22: visión primero; sin API, el lote manual usa OCR local de respaldo.
        if (apiSettings.hasApiKey()) {
            processVisionUriBatch(uris)
        } else {
            binding.tvStatus.text = "Sin API disponible para visión. Usando OCR local de respaldo..."
            processManualImageBatch(uris)
        }
    }

    private fun processVisionUriBatch(uris: List<Uri>) {
        if (uris.isEmpty()) return
        if (!processing.compareAndSet(false, true)) {
            binding.tvStatus.text = "Espera: GI X todavía está procesando el trabajo anterior."
            return
        }
        if (!apiSettings.hasApiKey()) {
            processing.set(false)
            binding.tvStatus.text = "Visión IA no disponible. Activando OCR local de respaldo..."
            processManualImageBatch(uris)
            return
        }

        stopped = false
        activeCameraPhotoIds = emptyList()
        lastExtractedQuestions = emptyList()
        lastDisplayedOcrText = ""
        lastSourceLabel = "visión IA manual · ${uris.size} imagen(es)"
        pendingOcrDisplayOverride = null
        pendingBatchInfo = null
        pendingMissingQuestionNumbers = emptyList()
        pendingCoverageNote = null
        clearAllPreviews()
        binding.tvOcr.text = "Enviando ${uris.size} imagen(es) originales a la IA..."
        binding.tvAnswer.text = "Esperando lectura visual..."
        binding.tvStatus.text = "Visión IA: preparando las imágenes originales sin OCR local."

        ioExecutor.execute {
            val payloads = mutableListOf<VisionImagePayload>()
            val previews = mutableListOf<Bitmap>()
            var readError: String? = null

            uris.take(MAX_MANUAL_BATCH_IMAGES).forEachIndexed { index, uri ->
                if (stopped || readError != null) return@forEachIndexed
                val mime = normalizeVisionMime(contentResolver.getType(uri), uri)
                if (mime == null) {
                    readError = "La imagen ${index + 1} no es JPG, PNG o WEBP compatible."
                    return@forEachIndexed
                }
                val bytes = runCatching {
                    contentResolver.openInputStream(uri)?.use { it.readBytes() }
                }.getOrNull()
                if (bytes == null || bytes.isEmpty()) {
                    readError = "No pude abrir la imagen ${index + 1}."
                    return@forEachIndexed
                }
                payloads += VisionImagePayload(bytes, mime)

                val bitmap = runCatching { ImageLoader.load(this, uri) }.getOrNull()
                if (bitmap != null) {
                    previews += makePreviewThumbnail(bitmap)
                    if (!bitmap.isRecycled) bitmap.recycle()
                }
            }

            if (destroyedForAsync) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                processing.set(false)
                return@execute
            }

            if (readError != null || payloads.isEmpty()) {
                runOnUiThread {
                    previews.forEach { if (!it.isRecycled) it.recycle() }
                    processing.set(false)
                    binding.tvStatus.text = "No pude preparar el lote para visión IA. Probando OCR local..."
                    binding.tvAnswer.text = "Usando OCR local de respaldo."
                    processManualImageBatch(uris)
                }
                return@execute
            }

            runOnUiThread {
                batchPreviewBitmaps = previews.toList()
                previewBitmap = batchPreviewBitmaps.firstOrNull()
                previewBitmap?.let {
                    binding.ivPreview.setImageBitmap(it)
                    binding.tvPreviewPlaceholder.visibility = View.GONE
                }
                binding.tvStatus.text = "Visión IA: comparando ${payloads.size} imagen(es) juntas y usando la toma más legible de cada parte..."
            }

            val result = onlineProvider.extractQuestionsFromImages(payloads).trim()
            if (destroyedForAsync) {
                processing.set(false)
                return@execute
            }
            runOnUiThread {
                if (stopped) {
                    processing.set(false)
                    return@runOnUiThread
                }
                val visionQuestions = if (result.startsWith(OnlineAnswerProvider.API_ERROR_PREFIX)) {
                    emptyList()
                } else {
                    runCatching { OcrQuestionExtractor.extractQuestions(result) }.getOrDefault(emptyList())
                }
                if (result.startsWith(OnlineAnswerProvider.API_ERROR_PREFIX) || visionQuestions.isEmpty()) {
                    processing.set(false)
                    binding.tvStatus.text = "Visión IA no pudo reconstruir preguntas. Activando OCR local de respaldo..."
                    binding.tvAnswer.text = "Usando OCR local de respaldo."
                    processManualImageBatch(uris)
                    return@runOnUiThread
                }
                pendingBatchInfo = "Visión IA · ${payloads.size} imagen(es) comparadas"
                binding.tvStatus.text = "Visión IA terminó la lectura. Organizando preguntas..."
                handleOcrResult(result)
            }
        }
    }

    private fun normalizeVisionMime(rawMime: String?, uri: Uri): String? {
        val mime = rawMime.orEmpty().lowercase(Locale.ROOT).substringBefore(';').trim()
        if (mime == "image/jpeg" || mime == "image/png" || mime == "image/webp") return mime
        val name = uri.toString().lowercase(Locale.ROOT).substringBefore('?')
        return when {
            name.endsWith(".jpg") || name.endsWith(".jpeg") -> "image/jpeg"
            name.endsWith(".png") -> "image/png"
            name.endsWith(".webp") -> "image/webp"
            else -> null
        }
    }

    private fun processManualImageBatch(uris: List<Uri>) {
        if (!processing.compareAndSet(false, true)) {
            binding.tvStatus.text = "Espera: GI X todavía está procesando el trabajo anterior."
            return
        }
        stopped = false
        activeCameraPhotoIds = emptyList()
        lastExtractedQuestions = emptyList()
        lastDisplayedOcrText = ""
        lastSourceLabel = "lote manual · ${uris.size} imágenes"
        pendingOcrDisplayOverride = null
        pendingBatchInfo = null
        pendingMissingQuestionNumbers = emptyList()
        pendingCoverageNote = null
        clearAllPreviews()
        binding.tvOcr.text = "Procesando lote de ${uris.size} imágenes..."
        binding.tvAnswer.text = "Leyendo preguntas..."
        binding.tvStatus.text = "Lote manual: preparando imagen 1 de ${uris.size}."

        val items = mutableListOf<ManualBatchOcrItem>()
        val previews = mutableListOf<Bitmap>()
        var failedImages = 0
        var heavyPasses = 0

        fun finishBatch() {
            if (stopped) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                processing.set(false)
                return
            }
            val rawTexts = items.map { it.rawText }
            if (rawTexts.none { it.isNotBlank() }) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                processing.set(false)
                binding.tvStatus.text = "No pude identificar preguntas legibles en las imágenes."
                binding.tvOcr.text = "No se detectaron preguntas."
                binding.tvAnswer.text = "Prueba con fotos más cercanas, nítidas y con mejor iluminación."
                return
            }

            batchPreviewBitmaps = previews.toList()
            previewBitmap = batchPreviewBitmaps.firstOrNull()
            previewBitmap?.let {
                binding.ivPreview.setImageBitmap(it)
                binding.tvPreviewPlaceholder.visibility = View.GONE
            }

            val merge = MultiImageDocumentMerger.merge(
                rawTexts,
                items.map { it.quality.selectionScore() }
            )
            pendingMissingQuestionNumbers = merge.missingQuestionNumbers
            pendingCoverageNote = merge.coverageNote.takeIf { it.isNotBlank() }
            pendingOcrDisplayOverride = merge.questions.joinToString("\n\n")

            pendingBatchInfo = null

            if (merge.combinedRaw.isBlank()) {
                processing.set(false)
                binding.tvStatus.text = "El lote llegó, pero no pude reconstruir texto útil."
                binding.tvOcr.text = pendingOcrDisplayOverride.orEmpty()
                binding.tvAnswer.text = "Vuelve a tomar las zonas con más solapamiento."
                pendingOcrDisplayOverride = null
                pendingBatchInfo = null
                pendingMissingQuestionNumbers = emptyList()
        pendingCoverageNote = null
                return
            }

            // handleOcrResult conserva el mismo flujo probado de validación/API/voz,
            // pero recibe UN documento ya fusionado en vez de cuatro consultas.
            handleOcrResult(merge.combinedRaw)
        }

        fun rescueAt(order: List<Int>, position: Int) {
            if (position >= order.size) {
                finishBatch()
                return
            }
            if (stopped) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                processing.set(false)
                return
            }

            // Para máxima precisión hacemos rescate fuerte sobre TODAS las imágenes
            // del lote, de forma secuencial y controlada. Es algo más lento que
            // cortar antes, pero mejora la recuperación de preguntas finales borrosas
            // y reduce casos donde una foto buena tapa una pregunta que otra sí aporta.

            val imageIndex = order[position]
            binding.tvStatus.text = "Analizando imagen ${position + 1} de ${order.size}..."
            ioExecutor.execute {
                val bitmap = runCatching { ImageLoader.load(this, uris[imageIndex]) }.getOrNull()
                if (bitmap == null) {
                    if (!destroyedForAsync) runOnUiThread { rescueAt(order, position + 1) }
                    return@execute
                }
                ocrProcessor.process(
                    bitmap,
                    onSuccess = { raw ->
                        heavyPasses++
                        if (raw.isNotBlank()) {
                            val better = chooseBetterBatchOcr(items[imageIndex].rawText, raw.trim())
                            items[imageIndex] = ManualBatchOcrItem(better, items[imageIndex].quality)
                        } else {
                            failedImages++
                        }
                        if (!bitmap.isRecycled) bitmap.recycle()
                        if (!destroyedForAsync) runOnUiThread { rescueAt(order, position + 1) }
                    },
                    onError = {
                        failedImages++
                        if (!bitmap.isRecycled) bitmap.recycle()
                        if (!destroyedForAsync) runOnUiThread { rescueAt(order, position + 1) }
                    }
                )
            }
        }

        fun startAdaptiveRescue() {
            val order = buildAdaptiveRescueOrder(items)
            if (order.isEmpty()) {
                finishBatch()
                return
            }
            rescueAt(order, 0)
        }

        fun processAt(index: Int) {
            if (index >= uris.size) {
                startAdaptiveRescue()
                return
            }
            if (stopped) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                processing.set(false)
                return
            }

            binding.tvStatus.text = "Preparando imagen ${index + 1} de ${uris.size}..."
            ioExecutor.execute {
                val bitmap = runCatching { ImageLoader.load(this, uris[index]) }.getOrNull()
                if (bitmap == null) {
                    failedImages++
                    items += ManualBatchOcrItem(
                        "",
                        OcrProcessor.ImageQualityReport(128.0, 64.0, 0.0, false, false, true)
                    )
                    if (!destroyedForAsync) runOnUiThread { processAt(index + 1) }
                    return@execute
                }

                val quality = runCatching { ocrProcessor.assessQuality(bitmap) }
                    .getOrElse { OcrProcessor.ImageQualityReport(128.0, 64.0, 100.0, false, false, false) }
                val thumb = makePreviewThumbnail(bitmap)
                previews += thumb

                // Sin OCR duplicado: el OCR completo empieza después y procesa cada
                // captura secuencialmente con OpenCV -> Paddle -> verificación ML Kit.
                items += ManualBatchOcrItem("", quality)
                if (!bitmap.isRecycled) bitmap.recycle()
                if (!destroyedForAsync) runOnUiThread { processAt(index + 1) }
            }
        }

        processAt(0)
    }

    private fun chooseBetterBatchOcr(existing: String, candidate: String): String {
        fun localScore(text: String): Int {
            if (text.isBlank()) return Int.MIN_VALUE
            val questions = runCatching { OcrQuestionExtractor.extractQuestions(text) }
                .getOrDefault(emptyList())
            val numbered = questions.mapNotNull(OcrQuestionExtractor::questionNumber).distinct().size
            val incomplete = questions.count(::looksLikeIncompleteBatchQuestion)
            val suspicious = if (questions.size >= 3 && OcrQuestionExtractor.hasSuspiciousNumbering(questions)) 1 else 0
            val table = if (text.contains(OcrTableFormatter.TABLE_START)) 1 else 0
            return numbered * 140 + questions.size * 70 + table * 90 -
                incomplete * 220 - suspicious * 320 + minOf(text.length, 3000) / 30
        }
        return if (localScore(candidate) >= localScore(existing)) candidate else existing
    }

    private fun looksLikeIncompleteBatchQuestion(raw: String): Boolean {
        val clean = raw
            .replace(Regex("""^\s*\d{1,2}\s*[\.)\-:]\s*"""), "")
            .trim()
        if (clean.length < 10) return true

        val lower = clean.lowercase(Locale.ROOT).trimEnd('.', ',', ';', ':', '-', '–', '—')
        val dangling = listOf(
            " entre", " de", " del", " la", " el", " los", " las", " y", " o",
            " con", " sin", " para", " por", " en", " según", " segun", " desde", " hasta"
        ).any { lower.endsWith(it) }
        if (dangling) return true

        val interrogative = listOf(
            "qué ", "que ", "cuál ", "cual ", "cuáles ", "cuales ", "cómo ", "como ",
            "por qué ", "por que ", "dónde ", "donde ", "cuándo ", "cuando ",
            "quién ", "quien ", "cuánto ", "cuanto "
        ).any { lower.trimStart('¿', '?', ' ').startsWith(it) }
        if (interrogative && !clean.contains('?') && clean.length < 150) return true
        return false
    }

    private fun buildAdaptiveRescueOrder(items: List<ManualBatchOcrItem>): List<Int> {
        if (items.isEmpty()) return emptyList()
        // Ya no existe una lectura OCR rápida previa. Procesamos primero la captura de
        // mejor calidad para obtener pronto una base fiable y después las complementarias.
        // No asumimos una cantidad fija de preguntas: sirve igual para 2, 6 o 30 ítems.
        return items.indices.sortedWith(
            compareByDescending<Int> { index -> items[index].quality.selectionScore() }
                .thenBy { it }
        )
    }

    private fun makePreviewThumbnail(source: Bitmap): Bitmap {
        val maxSide = maxOf(source.width, source.height).coerceAtLeast(1)
        val target = 1100
        if (maxSide <= target) return source.copy(Bitmap.Config.ARGB_8888, false)
        val scale = target.toFloat() / maxSide.toFloat()
        return Bitmap.createScaledBitmap(
            source,
            (source.width * scale).toInt().coerceAtLeast(1),
            (source.height * scale).toInt().coerceAtLeast(1),
            true,
        )
    }

    private fun clearAllPreviews() {
        binding.ivPreview.setImageDrawable(null)
        batchPreviewBitmaps.forEach { bitmap ->
            if (!bitmap.isRecycled) bitmap.recycle()
        }
        val current = previewBitmap
        if (current != null && !current.isRecycled) current.recycle()
        batchPreviewBitmaps = emptyList()
        previewBitmap = null
        binding.tvPreviewPlaceholder.visibility = View.VISIBLE
    }

    /**
     * onDestroy no debe reciclar bitmaps que un worker pueda seguir usando. Al soltar
     * solo las referencias de UI, el GC los recupera cuando el último pipeline termine.
     */
    private fun dropPreviewReferencesForDestroy() {
        if (::binding.isInitialized) binding.ivPreview.setImageDrawable(null)
        batchPreviewBitmaps = emptyList()
        previewBitmap = null
    }

    private fun loadPhotoFromUri(uri: Uri) {
        binding.tvStatus.text = "Abriendo imagen y corrigiendo orientación..."
        ioExecutor.execute {
            val bitmap = runCatching { ImageLoader.load(this, uri) }.getOrNull()
            runOnUiThread {
                if (bitmap == null) {
                    binding.tvStatus.text = "No pude abrir esa imagen. Prueba con JPG, PNG, WEBP o una foto normal."
                    return@runOnUiThread
                }
                processBitmap(bitmap, source = "imagen manual")
            }
        }
    }

    private fun processBitmap(bitmap: Bitmap, source: String) {
        if (!processing.compareAndSet(false, true)) {
            binding.tvStatus.text = "Ya estoy procesando otra foto."
            return
        }
        stopped = false
        pendingOcrDisplayOverride = null
        pendingBatchInfo = null
        pendingMissingQuestionNumbers = emptyList()
        pendingCoverageNote = null
        lastExtractedQuestions = emptyList()
        lastDisplayedOcrText = ""
        lastSourceLabel = source
        clearAllPreviews()
        previewBitmap = bitmap
        binding.ivPreview.setImageBitmap(bitmap)
        binding.tvPreviewPlaceholder.visibility = View.GONE
        binding.tvStatus.text = "Imagen recibida. Preparando y leyendo preguntas..."
        binding.tvOcr.text = "Leyendo preguntas..."
        binding.tvAnswer.text = "Esperando texto..."

        ocrProcessor.process(
            bitmap,
            onSuccess = { rawText ->
                if (!destroyedForAsync) runOnUiThread { handleOcrResult(rawText) }
            },
            onError = { error ->
                if (!destroyedForAsync) runOnUiThread {
                    processing.set(false)
                    binding.tvStatus.text = "No se pudieron leer las preguntas: $error"
                    binding.tvOcr.text = "No se pudo detectar texto."
                    binding.tvAnswer.text = "Acerca la cámara, mejora la luz y vuelve a intentarlo."
                    scheduleNextAutoIfNeeded()
                }
            }
        )
    }

    private fun handleOcrResult(rawText: String) {
        if (stopped) {
            processing.set(false)
            return
        }
        val cleanRaw = rawText.trim()
        if (cleanRaw.isBlank()) {
            processing.set(false)
            binding.tvStatus.text = "No se encontraron preguntas legibles."
            binding.tvOcr.text = "No se detectaron preguntas."
            binding.tvAnswer.text = "Prueba con más luz, menos inclinación y enfoca mejor la pregunta."
            scheduleNextAutoIfNeeded()
            return
        }

        val questions = OcrQuestionExtractor.extractQuestions(cleanRaw)
        val normalizedQuestions = questions.map(QuestionTextNormalizer::normalize)
        lastExtractedQuestions = normalizedQuestions

        // La interfaz muestra únicamente lo que se enviará a la API: preguntas limpias.
        // Títulos, calidad, texto del escritorio y otros fragmentos OCR no se muestran.
        val batchInfo = pendingBatchInfo.also { pendingBatchInfo = null }
        val batchMissing = pendingMissingQuestionNumbers.also { pendingMissingQuestionNumbers = emptyList() }
        val coverageNote = pendingCoverageNote.also { pendingCoverageNote = null }
        pendingOcrDisplayOverride = null
        val fullDisplayText = normalizedQuestions.joinToString("\n\n")
        lastDisplayedOcrText = fullDisplayText
        binding.tvOcr.text = fullDisplayText
        scrollTextToTop(binding.tvOcr)

        if (questions.isEmpty()) {
            processing.set(false)
            binding.tvStatus.text = "Se leyó texto, pero no pude identificar preguntas claras."
            binding.tvAnswer.text = "Centra mejor el texto y vuelve a intentarlo."
            scheduleNextAutoIfNeeded()
            return
        }

        // v1.6.16: un hueco en la numeración YA NO cancela la consulta. Si la hoja no
        // se fotografió completa, GI X responde las preguntas que sí identificó y avisa
        // cuáles faltan. Antes se quedaba sin respuestas por faltar la pregunta 1.
        val missingWarning = if (batchMissing.isEmpty()) {
            ""
        } else {
            "Falta(n) ${batchMissing.joinToString(", ")}: se responden solo las detectadas."
        }
        // Barrera de seguridad: solo se cancela cuando la numeración está CORRUPTA
        // (repetida o fuera de orden), porque eso significa que la reconstrucción del
        // documento falló y las respuestas quedarían asignadas a la pregunta incorrecta.
        if (OcrQuestionExtractor.hasCorruptNumbering(normalizedQuestions)) {
            processing.set(false)
            binding.tvStatus.text = buildString {
                append("La numeración quedó repetida o fuera de orden. No se envió una hoja mal reconstruida a la API.")
                if (!batchInfo.isNullOrBlank()) append(" · ").append(batchInfo)
            }
            binding.tvAnswer.text = "GI X reconstruyó las preguntas en un orden incoherente. Vuelve a tomar la hoja y procésala otra vez."
            scrollTextToTop(binding.tvAnswer)
            scheduleNextAutoIfNeeded()
            return
        }

        // Permite probar SOLO el OCR sin gastar API. Antes, una prueba sin clave
        // terminaba mostrando "0 de N respondidas", aunque el OCR sí hubiera leído
        // correctamente la hoja, lo que confundía el diagnóstico.
        if (!apiSettings.hasApiKey()) {
            processing.set(false)
            binding.tvStatus.text = buildString {
                append("${normalizedQuestions.size} pregunta(s) detectada(s).")
                if (!batchInfo.isNullOrBlank()) append(" · ").append(batchInfo)
            }
            binding.tvAnswer.text = "Preguntas listas. Configura una API para obtener respuestas."
            scrollTextToTop(binding.tvAnswer)
            scheduleNextAutoIfNeeded()
            return
        }

        val batches = buildApiBatches(normalizedQuestions)
        val apiStatus = if (normalizedQuestions.size == 1) {
            "Pregunta detectada. Consultando la API..."
        } else if (batches.size == 1) {
            "${normalizedQuestions.size} preguntas detectadas. Consultando la API..."
        } else {
            "${normalizedQuestions.size} preguntas detectadas. Se resolverán en ${batches.size} bloques seguros."
        }
        binding.tvStatus.text = buildString {
            append(apiStatus)
            if (!batchInfo.isNullOrBlank()) append(" · ").append(batchInfo)
            if (missingWarning.isNotBlank()) append(" · ").append(missingWarning)
        }
        binding.tvAnswer.text = buildString {
            if (missingWarning.isNotBlank()) {
                if (!coverageNote.isNullOrBlank()) append(coverageNote).append("\n")
                append(missingWarning).append("\n\n")
            }
            append("Consultando IA...")
        }
        ioExecutor.execute {
            val completed = mutableListOf<String>()
            val failedNumbers = mutableListOf<Int>()
            val failureDetails = mutableListOf<String>()
            var completedQuestions = 0
            var globalOffset = 0

            for ((batchIndex, batch) in batches.withIndex()) {
                if (stopped) {
                    processing.set(false)
                    return@execute
                }

                if (batches.size > 1) {
                    mainHandler.post {
                        if (!stopped) {
                            binding.tvStatus.text = "Consultando IA: bloque ${batchIndex + 1} de ${batches.size}..."
                        }
                    }
                }

                val payload = OcrQuestionExtractor.buildQueryPayload(
                    batch,
                    forceBatch = batch.size > 1,
                    documentContext = "",
                )

                // v1.6.25: Cheaper Inference permite streaming. En lotes de varias
                // preguntas mostramos las líneas completas apenas llegan; ya no se espera
                // a que termine todo el bloque para que aparezca la primera respuesta.
                var streamedStableNormalized = ""
                val answer = if (batch.size > 1) {
                    onlineProvider.fetchShortAnswer(payload) { partial ->
                        val stable = stableStreamingAnswerPrefix(partial)
                        if (stable.isNotBlank()) {
                            val normalizedStable = normalizeBatchAnswerNumbers(stable, batch, globalOffset)
                            if (normalizedStable.isNotBlank() && normalizedStable != streamedStableNormalized) {
                                streamedStableNormalized = normalizedStable
                                val progressiveRaw = (completed + normalizedStable)
                                    .joinToString("\n\n")
                                    .trim()
                                publishProgressiveAnswers(
                                    rawAnswers = progressiveRaw,
                                    total = normalizedQuestions.size,
                                    missingWarning = missingWarning,
                                    coverageNote = coverageNote,
                                )
                            }
                        }
                    }.trim()
                } else {
                    onlineProvider.fetchShortAnswer(payload).trim()
                }

                if (!answer.startsWith(OnlineAnswerProvider.API_ERROR_PREFIX)) {
                    // Para una consulta individual guardamos un identificador interno
                    // estable. En pantalla se retirará si la pregunta original no tenía
                    // numeración. En lotes normales conservamos los números del examen.
                    if (batch.size == 1) {
                        val question = batch.first()
                        val technicalId = answerTechnicalId(question, globalOffset, normalizedQuestions)
                        completed += formatRecoveredSingleAnswer(technicalId, question, answer)
                    } else {
                        completed += normalizeBatchAnswerNumbers(answer, batch, globalOffset)
                    }
                    completedQuestions += batch.size
                    publishProgressiveAnswers(
                        rawAnswers = completed.joinToString("\n\n").trim(),
                        total = normalizedQuestions.size,
                        missingWarning = missingWarning,
                        coverageNote = coverageNote,
                    )
                    globalOffset += batch.size
                    continue
                }

                // Si el stream se cortó después de entregar respuestas completas, las
                // conservamos y recuperamos únicamente las preguntas que realmente faltan.
                val streamedIds = mutableSetOf<Int>()
                if (batch.size > 1 && streamedStableNormalized.isNotBlank()) {
                    val streamedBlocks = splitNumberedAnswerBlocks(streamedStableNormalized)
                    batch.forEachIndexed { localIndex, question ->
                        val globalNumber = answerTechnicalId(
                            question,
                            globalOffset + localIndex,
                            normalizedQuestions,
                        )
                        val body = streamedBlocks[globalNumber]?.trim().orEmpty()
                        if (body.isNotBlank()) {
                            val canonical = OnlineAnswerProvider
                                .canonicalizeAnswerForQuestion(question, body)
                                .trim()
                            completed += "$globalNumber. $canonical"
                            completedQuestions += 1
                            streamedIds += globalNumber
                        }
                    }
                    publishProgressiveAnswers(
                        rawAnswers = completed.joinToString("\n\n").trim(),
                        total = normalizedQuestions.size,
                        missingWarning = missingWarning,
                        coverageNote = coverageNote,
                    )
                }

                // Si un lote fue rechazado, quedó incompleto o alcanzó MAX_TOKENS,
                // no perdemos el examen: recuperamos ese lote pregunta por pregunta.
                // Esto también evita que un fallo de una sola pregunta borre respuestas
                // de otros bloques.
                if (batch.size > 1) {
                    for ((localIndex, question) in batch.withIndex()) {
                        if (stopped) {
                            processing.set(false)
                            return@execute
                        }
                        val globalNumber = answerTechnicalId(
                            question,
                            globalOffset + localIndex,
                            normalizedQuestions,
                        )
                        if (globalNumber in streamedIds) continue
                        val printedNumber = OcrQuestionExtractor.questionNumber(question)
                        mainHandler.post {
                            if (!stopped) {
                                binding.tvStatus.text = if (printedNumber != null) {
                                    "Recuperando pregunta $printedNumber de ${normalizedQuestions.size}..."
                                } else {
                                    "Recuperando una pregunta sin número..."
                                }
                            }
                        }

                        val singlePayload = OcrQuestionExtractor.buildQueryPayload(
                            listOf(question),
                            forceBatch = false,
                            documentContext = "",
                        )
                        val singleAnswer = onlineProvider.fetchShortAnswer(singlePayload).trim()
                        if (singleAnswer.startsWith(OnlineAnswerProvider.API_ERROR_PREFIX)) {
                            failedNumbers += globalNumber
                            failureDetails += singleAnswer
                                .removePrefix(OnlineAnswerProvider.API_ERROR_PREFIX)
                                .trim()
                                .ifBlank { "La API no devolvió una respuesta válida." }
                        } else {
                            completed += formatRecoveredSingleAnswer(globalNumber, question, singleAnswer)
                            completedQuestions += 1
                            publishProgressiveAnswers(
                                rawAnswers = completed.joinToString("\n\n").trim(),
                                total = normalizedQuestions.size,
                                missingWarning = missingWarning,
                                coverageNote = coverageNote,
                            )
                        }
                    }
                } else {
                    val globalNumber = answerTechnicalId(
                        batch.first(),
                        globalOffset,
                        normalizedQuestions,
                    )
                    failedNumbers += globalNumber
                    failureDetails += answer
                        .removePrefix(OnlineAnswerProvider.API_ERROR_PREFIX)
                        .trim()
                        .ifBlank { "La API no devolvió una respuesta válida." }
                }

                globalOffset += batch.size
            }

            runOnUiThread {
                if (stopped) {
                    processing.set(false)
                    return@runOnUiThread
                }
                val finalText = completed.joinToString("\n\n").trim()
                if (failedNumbers.isNotEmpty()) {
                    handleRecoveredApiFailure(
                        partial = finalText,
                        completed = completedQuestions,
                        total = questions.size,
                        failedNumbers = failedNumbers,
                        details = failureDetails
                    )
                } else {
                    handleAnswer(finalText)
                }
            }
        }
    }

    private fun stableStreamingAnswerPrefix(raw: String): String {
        val normalized = raw.replace("\r\n", "\n").replace('\r', '\n')
        val lastNewline = normalized.lastIndexOf('\n')
        if (lastNewline < 0) return ""
        return normalized.substring(0, lastNewline).trim()
    }

    private fun publishProgressiveAnswers(
        rawAnswers: String,
        total: Int,
        missingWarning: String,
        coverageNote: String?,
    ) {
        if (rawAnswers.isBlank()) return
        val visible = formatAnswersForDisplay(rawAnswers, includeUnanswered = false).trim()
        if (visible.isBlank()) return
        val parsedCount = splitNumberedAnswerBlocks(rawAnswers).size
        val answered = (if (parsedCount > 0) parsedCount else 1).coerceAtMost(total)

        mainHandler.post {
            if (stopped) return@post
            binding.tvAnswer.text = buildString {
                if (missingWarning.isNotBlank()) {
                    if (!coverageNote.isNullOrBlank()) append(coverageNote).append("\n")
                    append(missingWarning).append("\n\n")
                }
                append(visible)
            }
            binding.tvStatus.text = if (answered >= total) {
                "$total de $total respuestas recibidas. Finalizando..."
            } else {
                "Respondiendo... $answered de $total listas. Las demás siguen llegando."
            }
        }
    }

    private fun buildApiBatches(questions: List<String>): List<List<String>> {
        if (questions.isEmpty()) return emptyList()

        // Un documento puede mezclar preguntas numeradas y preguntas sin número.
        // En ese caso las mandamos una por una: así los identificadores técnicos que
        // usa la API nunca se confunden con una numeración impresa real.
        val printedCount = questions.count { OcrQuestionExtractor.questionNumber(it) != null }
        if (printedCount in 1 until questions.size) {
            return questions.map { listOf(it) }
        }

        val batchLimit = if (OcrQuestionExtractor.isLikelyTrueFalseQuestions(questions)) {
            TRUE_FALSE_API_BATCH_SIZE
        } else {
            STANDARD_API_BATCH_SIZE
        }

        val output = mutableListOf<List<String>>()
        val pending = mutableListOf<String>()
        fun flushPending() {
            if (pending.isNotEmpty()) {
                output += pending.toList()
                pending.clear()
            }
        }

        questions.forEach { question ->
            // Una tabla puede necesitar una respuesta por fila. La aislamos para que no
            // compita por tokens con otras preguntas del examen.
            if (question.contains(OcrTableFormatter.TABLE_START)) {
                flushPending()
                output += listOf(question)
            } else {
                pending += question
                if (pending.size >= batchLimit) flushPending()
            }
        }
        flushPending()
        return output
    }

    private fun answerTechnicalId(question: String, globalIndex: Int, allQuestions: List<String>): Int {
        OcrQuestionExtractor.questionNumber(question)?.let { return it }
        val hasPrinted = allQuestions.any { OcrQuestionExtractor.questionNumber(it) != null }
        val hasUnnumbered = allQuestions.any { OcrQuestionExtractor.questionNumber(it) == null }
        // En documentos mixtos usamos IDs >=100 solo dentro de la app para evitar
        // chocar con números impresos 1..99. Nunca se muestran al usuario.
        return if (hasPrinted && hasUnnumbered) 100 + globalIndex else globalIndex + 1
    }

    private fun formatRecoveredSingleAnswer(number: Int, question: String, answer: String): String {
        val clean = answer
            .replace(Regex("""^\s*(?:Pregunta\s+)?\d{1,3}\s*[\.):\-]\s*""", RegexOption.IGNORE_CASE), "")
            .replace(Regex("""(?i)^Respuesta\s*:\s*"""), "")
            .trim()
        val canonical = OnlineAnswerProvider.canonicalizeAnswerForQuestion(question, clean).trim()
        // El número puede ser real o un ID técnico interno. Se usa solo para asociar
        // la respuesta; formatAnswersForDisplay() decide si debe verse.
        return "$number. $canonical".trim()
    }

    private fun handleRecoveredApiFailure(
        partial: String,
        completed: Int,
        total: Int,
        failedNumbers: List<Int>,
        details: List<String>
    ) {
        processing.set(false)
        val uniqueDetail = details.firstOrNull().orEmpty()
        val pairedPartial = if (partial.isNotBlank()) formatAnswersForDisplay(partial, includeUnanswered = false) else ""
        val visible = buildString {
            if (pairedPartial.isNotBlank()) {
                append(pairedPartial)
                append("\n\n")
            }
            append("Se respondieron $completed de $total preguntas.")
            if (failedNumbers.isNotEmpty()) {
                val printed = lastExtractedQuestions.mapNotNull(OcrQuestionExtractor::questionNumber).toSet()
                val visibleFailed = failedNumbers.filter { it in printed }.distinct().sorted()
                val unnumberedFailed = failedNumbers.count { it !in printed }
                if (visibleFailed.isNotEmpty()) {
                    append(" Faltaron: ")
                    append(visibleFailed.joinToString(", "))
                    append(".")
                }
                if (unnumberedFailed > 0) {
                    append(" Quedaron $unnumberedFailed pregunta(s) sin número sin respuesta.")
                }
            }
            if (uniqueDetail.isNotBlank()) {
                append("\n")
                append(uniqueDetail)
            }
        }
        binding.tvAnswer.text = visible
        scrollTextToTop(binding.tvAnswer)
        saveToHistory(visible)
        updateApiChip()
        binding.tvStatus.text = if (completed > 0) {
            "La API respondió parcialmente; GI X conservó todas las respuestas obtenidas."
        } else {
            "La API no respondió esta vez. Las preguntas se conservaron."
        }
        if (pairedPartial.isNotBlank()) {
            requestAnswerSpeech(pairedPartial)
        } else {
            scheduleNextAutoIfNeeded()
        }
    }

    private fun normalizeBatchAnswerNumbers(
        answer: String,
        batch: List<String>,
        globalOffset: Int
    ): String {
        val printedNumbers = batch.map { OcrQuestionExtractor.questionNumber(it) }
        // Si existe numeración real, el payload ya la conserva y no debemos tocarla.
        if (printedNumbers.any { it != null }) return answer.trim()

        // Preguntas sin numeración: el proveedor responde 1..N dentro de cada lote.
        // Aquí las convertimos a una secuencia global solo para que la pantalla no
        // muestre 1,2,3 otra vez en el siguiente lote.
        if (globalOffset <= 0) return answer.trim()
        val numberedLine = Regex("^(\\s*)(?:(Pregunta)\\s+)?(\\d{1,2})([\\.):])\\s*(.*)$", RegexOption.IGNORE_CASE)
        return answer.lines().joinToString("\n") { line ->
            val match = numberedLine.find(line) ?: return@joinToString line
            val prefix = match.groupValues[1]
            val questionWord = match.groupValues[2]
            val localNumber = match.groupValues[3].toIntOrNull() ?: return@joinToString line
            val separator = match.groupValues[4]
            val tail = match.groupValues[5]
            val globalNumber = localNumber + globalOffset
            if (questionWord.isNotBlank()) {
                "$prefix$questionWord $globalNumber$separator $tail".trimEnd()
            } else {
                "$prefix$globalNumber$separator $tail".trimEnd()
            }
        }.trim()
    }

    private fun handleChunkedApiFailure(partial: String, rawError: String, completed: Int, total: Int) {
        processing.set(false)
        val error = rawError.removePrefix(OnlineAnswerProvider.API_ERROR_PREFIX).trim()
        val pairedPartial = if (partial.isNotBlank()) formatAnswersForDisplay(partial, includeUnanswered = false) else ""
        val visible = buildString {
            if (pairedPartial.isNotBlank()) {
                append(pairedPartial)
                append("\n\n")
            }
            append("No se pudieron completar las preguntas restantes ($completed de $total respondidas).\n")
            append(error.ifBlank { "La API no devolvió una respuesta válida." })
        }
        binding.tvAnswer.text = visible
        scrollTextToTop(binding.tvAnswer)
        saveToHistory(visible)
        updateApiChip()
        binding.tvStatus.text = "La API no completó todos los bloques. Las respuestas ya recibidas se conservaron."
        if (pairedPartial.isNotBlank()) {
            requestAnswerSpeech(pairedPartial)
        } else {
            scheduleNextAutoIfNeeded()
        }
    }

    private fun splitNumberedAnswerBlocks(raw: String): Map<Int, String> {
        val text = raw.trim()
        if (text.isBlank()) return emptyMap()
        val marker = Regex("(?m)^\\s*(?:Pregunta\\s+)?(\\d{1,3})\\s*[\\.\\):\\-]\\s*")
        val matches = marker.findAll(text).toList()
        if (matches.isEmpty()) return emptyMap()

        val result = linkedMapOf<Int, String>()
        matches.forEachIndexed { index, match ->
            val number = match.groupValues[1].toIntOrNull() ?: return@forEachIndexed
            val start = match.range.last + 1
            val end = matches.getOrNull(index + 1)?.range?.first ?: text.length
            val body = text.substring(start, end)
                .trim()
                .replace(Regex("(?i)^Respuesta\\s*:\\s*"), "")
                .trim()
            if (body.isNotBlank() && number !in result) result[number] = body
        }
        return result
    }

    /**
     * La API puede usar números técnicos para asociar respuestas, pero la pantalla y
     * la voz muestran SOLO respuestas. Si la pregunta tenía número impreso, se conserva
     * ese número. Si no tenía número, GI X no inventa 1, 2, 3 para el usuario.
     */
    private fun formatAnswersForDisplay(rawAnswer: String, includeUnanswered: Boolean = true): String {
        val questions = lastExtractedQuestions
        val clean = rawAnswer.trim()
        if (questions.isEmpty() || clean.isBlank()) return clean

        val blocks = splitNumberedAnswerBlocks(clean)
        val answers = MutableList<String?>(questions.size) { null }
        questions.forEachIndexed { index, question ->
            val technicalId = answerTechnicalId(question, index, questions)
            answers[index] = blocks[technicalId]
        }

        // Una única pregunta puede llegar sin identificador técnico.
        if (questions.size == 1 && answers[0].isNullOrBlank()) {
            answers[0] = clean
                .replace(Regex("""(?i)^Respuesta\s*:\s*"""), "")
                .replace(Regex("""^\s*(?:Pregunta\s+)?\d{1,3}\s*[\.):\-]\s*""", RegexOption.IGNORE_CASE), "")
                .trim()
        }

        // Respaldo conservador: si el proveedor devolvió exactamente una línea por
        // pregunta pero omitió los IDs, las asociamos por orden.
        if (answers.all { it.isNullOrBlank() } && questions.size > 1) {
            val lines = clean.lines().map { it.trim() }.filter { it.isNotBlank() }
            if (lines.size == questions.size) {
                lines.forEachIndexed { index, line ->
                    answers[index] = line
                        .replace(Regex("""(?i)^Respuesta\s*:\s*"""), "")
                        .replace(Regex("""^\s*(?:Pregunta\s+)?\d{1,3}\s*[\.):\-]\s*""", RegexOption.IGNORE_CASE), "")
                        .trim()
                }
            }
        }

        val visible = questions.mapIndexedNotNull { index, question ->
            val answer = answers[index]?.trim().orEmpty()
            if (answer.isBlank() && !includeUnanswered) return@mapIndexedNotNull null
            val body = answer
                .ifBlank { "Sin respuesta." }
                .replace(Regex("""(?i)^Respuesta\s*:\s*"""), "")
                .trim()
            val printedNumber = OcrQuestionExtractor.questionNumber(question)
            if (printedNumber != null) {
                prefixVisibleAnswerNumber(printedNumber, body)
            } else {
                body
            }
        }
        return visible.joinToString("\n\n").ifBlank { clean }
    }

    private fun prefixVisibleAnswerNumber(number: Int, answer: String): String {
        val lines = answer.lines()
        if (lines.isEmpty()) return "$number."
        val first = lines.first().trim()
        val rest = lines.drop(1).joinToString("\n").trimEnd()
        return if (rest.isBlank()) {
            "$number. $first".trimEnd()
        } else {
            "$number. $first\n$rest".trimEnd()
        }
    }

    private fun handleAnswer(answer: String) {
        processing.set(false)
        val clean = answer.trim().ifBlank { "La API no devolvió una respuesta." }
        val apiError = clean.startsWith(OnlineAnswerProvider.API_ERROR_PREFIX)
        val visibleText = if (apiError) {
            clean.removePrefix(OnlineAnswerProvider.API_ERROR_PREFIX).trim()
        } else {
            formatAnswersForDisplay(clean)
        }
        binding.tvAnswer.text = visibleText
        scrollTextToTop(binding.tvAnswer)
        saveToHistory(visibleText)
        if (!apiError && activeCameraPhotoIds.isNotEmpty()) {
            cameraJournal.acknowledge(activeCameraPhotoIds)
            activeCameraPhotoIds = emptyList()
        }
        updateApiChip()

        if (apiError) {
            binding.tvStatus.text = "La API no respondió correctamente. Revisa el detalle abajo."
            scheduleNextAutoIfNeeded()
            return
        }

        requestAnswerSpeech(visibleText)
    }

    /**
     * Punto único de salida de voz de GI X. Toda respuesta válida (normal o recuperada)
     * pasa por aquí, para que no existan rutas que muestren texto pero olviden hablar.
     */
    private fun requestAnswerSpeech(text: String) {
        val spokenText = prepareSpokenAnswer(text)
        if (spokenText.isBlank()) {
            binding.tvStatus.text = "Respuesta lista."
            scheduleNextAutoIfNeeded()
            return
        }

        speechRetryCount = 0
        speechRecoveryInProgress = false
        activeSpeechText = spokenText
        pendingSpeechText = spokenText
        binding.tvStatus.text = if (ttsReady) {
            "Respuesta lista. Reproduciendo voz..."
        } else {
            "Respuesta lista. Preparando voz..."
        }

        if (ttsReady) {
            startPendingSpeech()
        } else if (!ttsInitializing) {
            // Si el motor ya había fallado antes de recibir esta respuesta, no dejamos
            // el texto esperando indefinidamente: iniciamos una nueva instancia ahora.
            ttsInitializing = true
            reinitializeTts()
        }
    }

    private fun prepareSpokenAnswer(text: String): String {
        val withoutInternalMarkers = text.lineSequence()
            .filterNot { line ->
                val trimmed = line.trim()
                trimmed.startsWith("[GIX_", ignoreCase = true) ||
                    trimmed.startsWith("Columnas:", ignoreCase = true) ||
                    trimmed.startsWith("Fila ", ignoreCase = true)
            }
            .joinToString("\n")
            .replace("|", ", ")
        return VoiceQuestionNormalizer.prepareForTts(withoutInternalMarkers).trim()
    }

    private fun startPendingSpeech() {
        if (!ttsReady || stopped) return
        val text = pendingSpeechText?.trim().orEmpty()
        if (text.isBlank()) return

        val engine = tts ?: run {
            handleSpeechFailure()
            return
        }
        val chunks = splitForTts(text)
        if (chunks.isEmpty()) {
            pendingSpeechText = null
            activeSpeechText = null
            binding.tvStatus.text = "Respuesta lista."
            scheduleNextAutoIfNeeded()
            return
        }

        engine.stop()
        engine.setSpeechRate(prefs.speechRate)
        speechSessionId += 1
        val session = speechSessionId
        activeSpeechText = text
        pendingSpeechText = null
        isSpeakingAnswer = true
        activeSpeechFinalId = "${UTTERANCE_ANSWER}_${session}_${chunks.lastIndex}"
        binding.tvStatus.text = "Respuesta lista. Reproduciendo voz..."

        for ((index, chunk) in chunks.withIndex()) {
            val utteranceId = "${UTTERANCE_ANSWER}_${session}_${index}"
            val queueMode = if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            val result = engine.speak(chunk, queueMode, null, utteranceId)
            if (result == TextToSpeech.ERROR) {
                handleSpeechFailure()
                return
            }
        }
    }

    private fun splitForTts(text: String): List<String> {
        val platformMax = runCatching { TextToSpeech.getMaxSpeechInputLength() }.getOrDefault(4000)
        // Dejamos margen respecto al máximo del motor. 3000 también evita problemas
        // de motores que anuncian un límite mayor pero fallan con textos muy largos.
        val maxChars = minOf((platformMax - 200).coerceAtLeast(500), 3000)
        val pieces = text
            .replace("\r", "")
            .split(Regex("(?<=[.!?])\\s+|\\n+"))
            .map { it.trim() }
            .filter { it.isNotBlank() }

        val result = mutableListOf<String>()
        var current = StringBuilder()

        fun flush() {
            val value = current.toString().trim()
            if (value.isNotBlank()) result += value
            current = StringBuilder()
        }

        fun addLongPiece(piece: String) {
            val words = piece.split(Regex("\\s+")).filter { it.isNotBlank() }
            for (word in words) {
                if (word.length > maxChars) {
                    flush()
                    word.chunked(maxChars).forEach { result += it }
                    continue
                }
                val extra = if (current.isEmpty()) word.length else word.length + 1
                if (current.length + extra > maxChars) flush()
                if (current.isNotEmpty()) current.append(' ')
                current.append(word)
            }
        }

        for (piece in pieces) {
            if (piece.length > maxChars) {
                flush()
                addLongPiece(piece)
                flush()
                continue
            }
            val extra = if (current.isEmpty()) piece.length else piece.length + 1
            if (current.length + extra > maxChars) flush()
            if (current.isNotEmpty()) current.append(' ')
            current.append(piece)
        }
        flush()
        return result
    }

    override fun onInit(status: Int) {
        ttsInitializing = false
        speechRecoveryInProgress = false
        if (status != TextToSpeech.SUCCESS) {
            ttsReady = false
            if (!pendingSpeechText.isNullOrBlank() && speechRetryCount < MAX_TTS_RETRIES) {
                speechRetryCount += 1
                binding.tvStatus.text = "Respuesta lista. Reintentando el motor de voz..."
                mainHandler.postDelayed({ reinitializeTts() }, TTS_RETRY_DELAY_MS)
            } else if (!pendingSpeechText.isNullOrBlank()) {
                pendingSpeechText = null
                activeSpeechText = null
                binding.tvStatus.text = "Respuesta lista. No se pudo iniciar la voz esta vez."
                scheduleNextAutoIfNeeded()
            }
            return
        }
        val engine = tts ?: return
        val result = engine.setLanguage(Locale("es", "PE"))
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.language = Locale("es", "ES")
        }
        engine.setSpeechRate(prefs.speechRate)
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit

            override fun onDone(utteranceId: String?) {
                if (utteranceId == activeSpeechFinalId) {
                    runOnUiThread {
                        isSpeakingAnswer = false
                        activeSpeechFinalId = null
                        activeSpeechText = null
                        pendingSpeechText = null
                        speechRetryCount = 0
                        binding.tvStatus.text = if (autoMode) {
                            "Respuesta terminada. Preparando la siguiente foto..."
                        } else {
                            "Listo. Puedes pedir otra foto o elegir otra imagen."
                        }
                        scheduleNextAutoIfNeeded()
                    }
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                runOnUiThread { handleSpeechFailure() }
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                runOnUiThread { handleSpeechFailure() }
            }
        })
        ttsReady = true
        if (!pendingSpeechText.isNullOrBlank()) startPendingSpeech()
    }

    private fun handleSpeechFailure() {
        if (stopped || speechRecoveryInProgress) return
        val text = activeSpeechText ?: pendingSpeechText
        isSpeakingAnswer = false
        activeSpeechFinalId = null

        if (text.isNullOrBlank()) {
            scheduleNextAutoIfNeeded()
            return
        }

        if (speechRetryCount < MAX_TTS_RETRIES) {
            speechRetryCount += 1
            speechRecoveryInProgress = true
            pendingSpeechText = text
            activeSpeechText = text
            binding.tvStatus.text = "La respuesta está lista. Reiniciando voz..."
            reinitializeTts()
        } else {
            pendingSpeechText = null
            activeSpeechText = null
            binding.tvStatus.text = "Respuesta lista. La voz falló esta vez; el texto quedó guardado."
            scheduleNextAutoIfNeeded()
        }
    }

    private fun reinitializeTts() {
        runCatching { tts?.stop() }
        runCatching { tts?.shutdown() }
        ttsReady = false
        ttsInitializing = true
        tts = TextToSpeech(this, this)
    }

    private fun processNextQueuedCameraBatchIfReady(): Boolean {
        if (stopped || processing.get() || isSpeakingAnswer || !pendingSpeechText.isNullOrBlank()) return false
        if (isThermallySevere()) return false
        while (deferredCameraBatches.isNotEmpty()) {
            val ids = deferredCameraBatches.removeFirst()
            val entries = ids.mapNotNull { cameraJournal.read(it) }
            if (entries.isEmpty()) continue
            val photos = entries.map { QueuedCameraPhoto(it.jpeg, "cámara guardada", it.requestId, it.id) }
            processCameraBatch(QueuedCameraBatch(photos, "cámara · lote recuperado"))
            return true
        }
        while (pendingCameraBatches.isNotEmpty()) {
            val next = pendingCameraBatches.pollFirst() ?: return false
            processCameraBatch(next)
            return true
        }
        return false
    }

    private fun scheduleNextAutoIfNeeded() {
        // No se envían CAPTURE automáticos: firmware de TimerCamera-X toma y entrega
        // su foto al encender aunque /camera/poll responda WAIT.
        // Mantener el listener activo entre ciclos evita intervención en la mochila.
        if (processNextQueuedCameraBatchIfReady()) return
        if (!isThermallySevere() && restoreJournaledCameraPhotos()) return
        if (autoMode && !stopped && inputMode == InputMode.CAMERA &&
            !processing.get() && !isSpeakingAnswer && pendingSpeechText.isNullOrBlank()) {
            binding.tvStatus.text = "Cámara automática: esperando la siguiente foto de TimerCamera-X."
        }
    }

    private fun updateCameraChip() {
        binding.tvCameraChip.text = if (cameraServer?.isCameraConnected() == true) {
            "Cámara: conectada"
        } else {
            "Cámara: esperando"
        }
    }

    private fun updateApiChip() {
        val config = apiSettings.getApiConfigs()
            .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }

        if (config == null) {
            binding.tvApiChip.text = "API: sin configurar"
            binding.tvApiDetail.text = "DeepSeek · SIN CONFIGURAR"
            return
        }

        val status = apiSettings.getStatus(config)
        val message = apiSettings.getMessage(config).trim()
        binding.tvApiChip.text = "API: DeepSeek"
        binding.tvApiDetail.text = when (status) {
            "ready" -> "DeepSeek · ACTIVA ✓ · CLAVE GUARDADA · ${config.model}"
            "error" -> "DeepSeek · GUARDADA · ERROR: ${message.ifBlank { "revisa clave, saldo o modelo" }}"
            "limit" -> "DeepSeek · GUARDADA · SIN CRÉDITOS / LÍMITE: ${message.ifBlank { "revisa tu cuenta" }}"
            else -> if (message.isBlank() || message.startsWith("Sin probar", ignoreCase = true)) {
                "DeepSeek · GUARDADA · SIN PROBAR · ${config.model}"
            } else {
                "DeepSeek · GUARDADA · ÚLTIMO ESTADO: $message"
            }
        }
    }

    private fun showVoiceDialog() {
        val labels = arrayOf("0.25x", "0.50x", "0.75x", "1.00x", "1.25x", "1.50x", "1.75x", "2.00x")
        val values = floatArrayOf(0.25f, 0.50f, 0.75f, 1.00f, 1.25f, 1.50f, 1.75f, 2.00f)
        val current = values.indices.minByOrNull { abs(values[it] - prefs.speechRate) } ?: 3
        AlertDialog.Builder(this)
            .setTitle("Velocidad de voz")
            .setSingleChoiceItems(labels, current) { dialog, which ->
                prefs.speechRate = values[which]
                tts?.setSpeechRate(values[which])
                Toast.makeText(this, "Voz ${labels[which]}", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showCameraDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(4))
        }
        val info = TextView(this).apply {
            text = "TimerCamera-X U082-X: al encenderse se conecta a la Zona Wi-Fi configurada y envía sus fotos a GI X por el puerto ${CameraBridgeServer.DEFAULT_PORT}. La app ya está preparada para recibir una captura suelta o agrupar automáticamente hasta 4 imágenes del mismo documento. Si dejas la clave por defecto GIX2026CAM, el enlace queda listo."
            textSize = 14f
        }
        val tokenInput = EditText(this).apply {
            hint = "Clave de enlace"
            setText(prefs.pairingToken)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            maxLines = 1
        }
        val note = TextView(this).apply {
            text = "Firmware incluido: camera_firmware/TimerCameraX_GIX.ino. Recomendado: deja fija la clave GIX2026CAM y cambia solo nombre Wi-Fi y contraseña Wi-Fi. Si cambias la clave, debe coincidir exactamente con la app."
            textSize = 12f
        }
        box.addView(info)
        box.addView(tokenInput, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) })
        box.addView(note, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        val dialog = AlertDialog.Builder(this)
            .setTitle("Enlace con Timer Camera X")
            .setView(box)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                prefs.pairingToken = tokenInput.text?.toString().orEmpty()
                tokenInput.setText(prefs.pairingToken)
                binding.tvStatus.text = "Clave de cámara guardada. Debe coincidir con el firmware."
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun normalizeCheaperKey(raw: String): String {
        val cleaned = raw
            .trim()
            .removePrefix("Bearer ")
            .removePrefix("bearer ")
            .trim('\"', '\'')
            .replace("​", "")
            .replace("‌", "")
            .replace("‍", "")
            .replace("⁠", "")
            .replace("﻿", "")
            .replace(Regex("[\r\n\t ]+"), "")

        val embedded = Regex("(ir_live_[A-Za-z0-9._-]+|ci_live_[A-Za-z0-9._-]+)", RegexOption.IGNORE_CASE)
            .find(cleaned)
            ?.value
        return embedded ?: cleaned
    }

    private fun showApiDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }

        val title = TextView(this).apply {
            text = "CHEAPER INFERENCE · DEEPSEEK"
            textStyleBold()
            textSize = 15f
        }
        val info = TextView(this).apply {
            text = "GI X usará únicamente esta API de pago con DeepSeek V4 Flash. La clave queda guardada en el celular. Los fallos temporales no la bloquean y la app muestra el motivo real si no responde."
            textSize = 12f
            setPadding(0, dp(4), 0, dp(8))
        }

        val saved = apiSettings.getApiConfigs()
            .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }
        val keyInput = EditText(this).apply {
            hint = if (saved == null) "Clave Cheaper Inference (ir_live_… / ci_live_…)" else "Clave guardada. Pega otra solo para reemplazarla"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            maxLines = 1
        }
        val modelInput = EditText(this).apply {
            hint = "Modelo fijo"
            setText(NetProvider.CHEAPER_INFERENCE.defaultModel)
            isEnabled = false
            maxLines = 1
        }
        val statusText = TextView(this).apply {
            textSize = 12f
            setPadding(0, dp(8), 0, dp(6))
        }
        val saveTest = Button(this).apply { text = "GUARDAR Y PROBAR DEEPSEEK" }
        val testSaved = Button(this).apply { text = "PROBAR API GUARDADA" }
        val delete = Button(this).apply { text = "BORRAR API GUARDADA" }
        val close = Button(this).apply { text = "CERRAR" }

        fun refresh(message: String? = null) {
            val config = apiSettings.getApiConfigs()
                .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }
            val storedStatus = if (config == null) {
                "DeepSeek: SIN CONFIGURAR"
            } else {
                val state = apiSettings.getStatus(config)
                val detail = apiSettings.getMessage(config).trim()
                when (state) {
                    "ready" -> "DeepSeek: ACTIVA ✓ · ${config.model} · clave guardada"
                    "error" -> "DeepSeek: GUARDADA · ERROR · ${detail.ifBlank { "revisa clave, saldo o modelo" }}"
                    "limit" -> "DeepSeek: GUARDADA · SIN CRÉDITOS / LÍMITE · ${detail.ifBlank { "revisa tu cuenta" }}"
                    else -> if (detail.isBlank() || detail.startsWith("Sin probar", ignoreCase = true)) {
                        "DeepSeek: GUARDADA · SIN PROBAR · ${config.model}"
                    } else {
                        "DeepSeek: GUARDADA · ${detail}"
                    }
                }
            }
            statusText.text = listOfNotNull(message?.takeIf { it.isNotBlank() }, storedStatus).joinToString("\n")
            updateApiChip()
        }

        box.addView(title)
        box.addView(info)
        box.addView(keyInput, LinearLayout.LayoutParams(-1, dp(54)))
        box.addView(modelInput, LinearLayout.LayoutParams(-1, dp(54)))
        box.addView(saveTest, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(6) })
        box.addView(testSaved, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4) })
        box.addView(statusText, LinearLayout.LayoutParams(-1, -2))
        box.addView(delete, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4) })
        box.addView(close, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4) })

        val dialog = AlertDialog.Builder(this)
            .setTitle("API de GI X")
            .setView(box)
            .create()

        saveTest.setOnClickListener {
            val typed = normalizeCheaperKey(keyInput.text?.toString().orEmpty())
            val current = apiSettings.getApiConfigs()
                .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }
            val key = typed.ifBlank { normalizeCheaperKey(current?.apiKey.orEmpty()) }
            if (key.isBlank()) {
                keyInput.error = "Pega tu clave ir_live_… o ci_live_…"
                return@setOnClickListener
            }
            val model = modelInput.text?.toString().orEmpty().trim()
                .ifBlank { NetProvider.CHEAPER_INFERENCE.defaultModel }
            val config = NetApiConfig(
                name = "DeepSeek Pago",
                provider = NetProvider.CHEAPER_INFERENCE,
                apiKey = key,
                model = model
            ).clean(0)

            // Esta versión usa una sola API: al guardar, elimina configuraciones de respaldo.
            apiSettings.saveApiConfigs(listOf(config))
            saveTest.isEnabled = false
            testSaved.isEnabled = false
            statusText.text = "DeepSeek: GUARDADA · probando conexión…"
            ioExecutor.execute {
                val result = onlineProvider.testApiConfig(config)
                runOnUiThread {
                    saveTest.isEnabled = true
                    testSaved.isEnabled = true
                    if (result.first) keyInput.text?.clear()
                    refresh(result.second)
                }
            }
        }

        testSaved.setOnClickListener {
            val config = apiSettings.getApiConfigs()
                .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }
            if (config == null) {
                refresh("No hay una API guardada todavía.")
                return@setOnClickListener
            }
            testSaved.isEnabled = false
            statusText.text = "DeepSeek: probando API guardada…"
            ioExecutor.execute {
                val result = onlineProvider.testApiConfig(config)
                runOnUiThread {
                    testSaved.isEnabled = true
                    refresh(result.second)
                }
            }
        }

        delete.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Borrar API")
                .setMessage("¿Quieres borrar la clave DeepSeek guardada en este celular?")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Borrar") { _, _ ->
                    apiSettings.saveApiConfigs(emptyList())
                    refresh("API borrada.")
                }
                .show()
        }

        close.setOnClickListener { dialog.dismiss() }
        dialog.setOnDismissListener { updateApiChip() }
        refresh()
        dialog.show()
    }

    private fun setupInternalScroll(scroll: ScrollView) {
        scroll.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> view.parent?.requestDisallowInterceptTouchEvent(true)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.parent?.requestDisallowInterceptTouchEvent(false)
            }
            false
        }
    }

    private fun showPreviewDialog() {
        val images = if (batchPreviewBitmaps.isNotEmpty()) {
            batchPreviewBitmaps.filter { !it.isRecycled }
        } else {
            listOfNotNull(previewBitmap).filter { !it.isRecycled }
        }
        if (images.isEmpty()) {
            Toast.makeText(this, "Todavía no hay imagen para abrir.", Toast.LENGTH_SHORT).show()
            return
        }

        var currentIndex = 0
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF050A12.toInt())
        }
        val hint = TextView(this).apply {
            setTextColor(0xFFE8EEF9.toInt())
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val imageView = ZoomableImageView(this).apply {
            setImageBitmap(images[currentIndex])
            setBackgroundColor(0xFF050A12.toInt())
        }

        fun refreshHint() {
            hint.text = if (images.size > 1) {
                "Imagen ${currentIndex + 1} de ${images.size} · zoom con dos dedos · doble toque · arrastra"
            } else {
                "Pellizca para hacer zoom · doble toque para acercar · arrastra para mover"
            }
        }
        refreshHint()

        val navigation = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(6), dp(10), 0)
            visibility = if (images.size > 1) View.VISIBLE else View.GONE
        }
        val previous = Button(this).apply { text = "← ANTERIOR" }
        val next = Button(this).apply { text = "SIGUIENTE →" }
        navigation.addView(previous, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(5) })
        navigation.addView(next, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(5) })

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(8), dp(10), dp(12))
        }
        val rotate = Button(this).apply { text = "ROTAR" }
        val reset = Button(this).apply { text = "RESTABLECER" }
        val close = Button(this).apply { text = "CERRAR" }
        controls.addView(rotate, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(4) })
        controls.addView(reset, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
            marginStart = dp(4); marginEnd = dp(4)
        })
        controls.addView(close, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(4) })

        root.addView(hint, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(imageView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(navigation, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(controls, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val dialog = android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dialog.setContentView(root)

        fun showIndex(newIndex: Int) {
            currentIndex = (newIndex + images.size) % images.size
            imageView.setImageBitmap(images[currentIndex])
            imageView.resetView()
            refreshHint()
        }
        previous.setOnClickListener { showIndex(currentIndex - 1) }
        next.setOnClickListener { showIndex(currentIndex + 1) }
        rotate.setOnClickListener { imageView.rotateClockwise() }
        reset.setOnClickListener { imageView.resetView() }
        close.setOnClickListener { dialog.dismiss() }
        dialog.setOnShowListener {
            dialog.window?.apply {
                setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                setBackgroundDrawableResource(android.R.color.black)
                addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                statusBarColor = 0xFF050A12.toInt()
                navigationBarColor = 0xFF050A12.toInt()
            }
        }
        dialog.show()
    }

    private fun saveToHistory(answerText: String) {
        if (lastDisplayedOcrText.isBlank() || answerText.isBlank()) return
        val entry = HistoryEntry(
            id = System.currentTimeMillis().toString(),
            timestamp = System.currentTimeMillis(),
            source = lastSourceLabel,
            questionCount = lastExtractedQuestions.size.coerceAtLeast(1),
            ocrText = lastDisplayedOcrText,
            answerText = answerText
        )
        historyRepository.add(entry)
        renderHistory()
    }

    private fun renderHistory() {
        val items = historyRepository.getAll()
        binding.historyContainer.removeAllViews()
        binding.tvHistoryEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        items.forEach { entry ->
            binding.historyContainer.addView(createHistoryCard(entry))
        }
    }

    private fun createHistoryCard(entry: HistoryEntry): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = getDrawable(R.drawable.card_bg)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(8)
        }
        card.layoutParams = params

        val title = TextView(this).apply {
            text = "${formatHistoryDate(entry.timestamp)} · ${entry.source} · ${entry.questionCount} pregunta(s)"
            textSize = 13f
            textStyleBold()
        }
        val preview = TextView(this).apply {
            text = entry.ocrText.replace("\n", " ").take(120).ifBlank { "Sin preguntas" }
            textSize = 12f
            setPadding(0, dp(4), 0, dp(2))
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
        }
        val open = Button(this).apply { text = "ABRIR" }
        val delete = Button(this).apply { text = "BORRAR" }
        row.addView(open, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(4) })
        row.addView(delete, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(4) })

        open.setOnClickListener { showHistoryEntryDialog(entry) }
        delete.setOnClickListener {
            historyRepository.delete(entry.id)
            renderHistory()
            Toast.makeText(this, "Registro borrado.", Toast.LENGTH_SHORT).show()
        }

        card.addView(title)
        card.addView(preview)
        card.addView(row)
        return card
    }

    private fun showHistoryEntryDialog(entry: HistoryEntry) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(8))
        }
        root.addView(TextView(this).apply {
            text = "${formatHistoryDate(entry.timestamp)} · ${entry.source} · ${entry.questionCount} pregunta(s)"
            textSize = 13f
            textStyleBold()
        })
        root.addView(TextView(this).apply {
            text = "Preguntas detectadas"
            textSize = 13f
            textStyleBold()
            setPadding(0, dp(10), 0, dp(4))
        })
        val ocrScroll = ScrollView(this)
        ocrScroll.addView(TextView(this).apply {
            text = entry.ocrText
            textSize = 14f
            setTextIsSelectable(true)
            setPadding(dp(10), dp(10), dp(10), dp(10))
        })
        root.addView(ocrScroll, LinearLayout.LayoutParams(-1, dp(180)))

        root.addView(TextView(this).apply {
            text = "Respuestas"
            textSize = 13f
            textStyleBold()
            setPadding(0, dp(10), 0, dp(4))
        })
        val answerScroll = ScrollView(this)
        answerScroll.addView(TextView(this).apply {
            text = entry.answerText
            textSize = 14f
            setTextIsSelectable(true)
            setPadding(dp(10), dp(10), dp(10), dp(10))
        })
        root.addView(answerScroll, LinearLayout.LayoutParams(-1, dp(240)))

        AlertDialog.Builder(this)
            .setTitle("Historial GI X")
            .setView(root)
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun confirmClearHistory() {
        if (historyRepository.getAll().isEmpty()) {
            Toast.makeText(this, "No hay historial para borrar.", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Borrar historial")
            .setMessage("¿Quieres borrar todo el historial guardado de preguntas y respuestas?")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Borrar") { _, _ ->
                historyRepository.clear()
                renderHistory()
                Toast.makeText(this, "Historial borrado.", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun formatHistoryDate(time: Long): String {
        return try {
            SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("es", "PE")).format(Date(time))
        } catch (_: Exception) {
            Date(time).toString()
        }
    }

    private fun TextView.textStyleBold() {
        setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun scrollTextToTop(view: TextView) {
        view.post {
            view.scrollTo(0, 0)
            (view.parent as? ScrollView)?.scrollTo(0, 0)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    /**
     * v1.6.16: el celular se queda con GI X abierto todo el examen esperando las fotos
     * de la cámara. Salir por error de la app rompe el ciclo, así que ATRÁS exige
     * BACK_PRESSES_TO_EXIT pulsaciones seguidas y además una confirmación.
     */
    override fun onBackPressed() {
        if (lockAppOnScreen) {
            Toast.makeText(this, "GI X protegido: desbloquea con 3 toques.", Toast.LENGTH_SHORT).show()
            return
        }
        val now = System.currentTimeMillis()
        if (now - lastBackPressAtMs > BACK_EXIT_WINDOW_MS) backPressCount = 0
        lastBackPressAtMs = now
        backPressCount++

        if (backPressCount < BACK_PRESSES_TO_EXIT) {
            val remaining = BACK_PRESSES_TO_EXIT - backPressCount
            val message = if (remaining == 1) {
                "Pulsa ATRÁS una vez más si de verdad quieres salir de GI X."
            } else {
                "Pulsa ATRÁS $remaining veces más si de verdad quieres salir de GI X."
            }
            binding.tvStatus.text = message
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            return
        }

        backPressCount = 0
        confirmExitApp()
    }

    private fun confirmExitApp() {
        if (lockAppOnScreen) {
            Toast.makeText(this, "Desbloquea GI X con 3 toques antes de salir.", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("¿Salir de GI X?")
            .setMessage("GI X dejará de recibir fotos y responder por voz al salir.")
            .setNegativeButton("Seguir esperando fotos", null)
            .setPositiveButton("SALIR") { _, _ ->
                stopCurrentCycle()
                finish()
            }
            .show()
    }

    /** Bloquea los toques sobre la app, pero nunca interrumpe Wi-Fi, IA ni voz.
     *  La salida es recuperable sin conexión: 3 toques rápidos en DESBLOQUEAR.
     *  El anclaje de Android es opcional y puede requerir aprobación del sistema.
     */
    private fun enableTouchGuard() {
        if (lockAppOnScreen) return
        lockAppOnScreen = true
        unlockTapCount = 0
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(10, 17, 30))
            isClickable = true
            isFocusable = true
            contentDescription = "GI X protegido contra toques accidentales"
        }
        val title = TextView(this).apply {
            text = "GI X PROTEGIDO"
            setTextColor(Color.WHITE)
            textSize = 25f
            gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val subtitle = TextView(this).apply {
            text = "CÁMARA AUTOMÁTICA ACTIVA\nGI X sigue recibiendo fotos y respondiendo por voz.\nLos toques accidentales no afectan la app."
            setTextColor(Color.rgb(180, 198, 225))
            gravity = Gravity.CENTER
            textSize = 15f
            setPadding(dp(22), dp(24), dp(22), dp(30))
        }
        val unlock = Button(this).apply {
            text = "DESBLOQUEAR · 3 TOQUES"
            textSize = 16f
            isAllCaps = false
            setOnClickListener {
                val now = System.currentTimeMillis()
                if (now - lastUnlockTapAtMs > UNLOCK_TAP_WINDOW_MS) unlockTapCount = 0
                lastUnlockTapAtMs = now
                unlockTapCount++
                if (unlockTapCount >= UNLOCK_TAPS) {
                    disableTouchGuard()
                } else {
                    text = "DESBLOQUEAR · FALTAN ${UNLOCK_TAPS - unlockTapCount}"
                }
            }
        }
        overlay.addView(title, LinearLayout.LayoutParams(-1, -2))
        overlay.addView(subtitle, LinearLayout.LayoutParams(-1, -2))
        overlay.addView(unlock, LinearLayout.LayoutParams(-1, dp(58)).apply {
            leftMargin = dp(25)
            rightMargin = dp(25)
        })
        val container = findViewById<ViewGroup>(android.R.id.content)
        container.addView(overlay, ViewGroup.LayoutParams(-1, -1))
        touchGuard = overlay
        // Screen pinning is controlled by Android. It is not a guarantee against
        // power/notification gestures, and may display a one-time Android dialog.
        runCatching { startLockTask() }
    }

    private fun disableTouchGuard() {
        lockAppOnScreen = false
        unlockTapCount = 0
        touchGuard?.let { (it.parent as? ViewGroup)?.removeView(it) }
        touchGuard = null
        runCatching { stopLockTask() }
        if (inputMode == InputMode.CAMERA) {
            binding.tvStatus.text = "Cámara automática: esperando foto. Para terminar, pulsa SALIR."
        }
    }

    private fun releaseScreenAwakeIfAllowed() {
        // Con el bloqueo activo la pantalla se mantiene encendida a propósito.
        if (lockAppOnScreen || inputMode == InputMode.CAMERA) return
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (lockAppOnScreen) {
            Toast.makeText(this, "GI X debe quedarse abierto esperando la cámara.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        destroyedForAsync = true
        touchGuard = null
        stopped = true
        cameraStatusTicker?.let { mainHandler.removeCallbacks(it) }
        mainHandler.removeCallbacksAndMessages(null)
        onlineProvider.cancelActiveRequest()
        CameraLinkService.detach(this)
        pendingCameraBatches.clear()
        cameraBatchCollector.clear()
        cameraBatchFinalizeRunnable?.let { mainHandler.removeCallbacks(it) }
        cameraBatchFinalizeRunnable = null
        ocrProcessor.close()
        pendingSpeechText = null
        activeSpeechText = null
        activeSpeechFinalId = null
        isSpeakingAnswer = false
        tts?.stop()
        tts?.shutdown()
        ioExecutor.shutdownNow()
        cameraIoExecutor.shutdownNow()
        galleryExecutor.shutdownNow()
        dropPreviewReferencesForDestroy()
        super.onDestroy()
    }

    private enum class InputMode {
        CAMERA,
        IMAGE
    }

    companion object {
        // Salida protegida: el examen se pierde si la app se cierra por accidente.
        private const val UNLOCK_TAPS = 3
        private const val UNLOCK_TAP_WINDOW_MS = 4_000L
        private const val BACK_PRESSES_TO_EXIT = 3
        private const val BACK_EXIT_WINDOW_MS = 6_000L

        // Un documento combinado de hasta 10 preguntas se intenta primero en UNA sola
        // llamada. Si el proveedor falla o corta la respuesta, el mecanismo existente
        // recupera solo las preguntas necesarias de forma segura.
        private const val STANDARD_API_BATCH_SIZE = 10
        private const val MAX_PENDING_CAMERA_BATCHES = 3
        private const val MAX_PENDING_CAMERA_BYTES = 24L * 1024L * 1024L
        private const val TRUE_FALSE_API_BATCH_SIZE = 15
        private const val MAX_MANUAL_BATCH_IMAGES = 4
        private const val MAX_CAMERA_BATCH_IMAGES = 4
        private const val CAMERA_BATCH_FIRST_IDLE_MS = 8_000L
        private const val CAMERA_BATCH_CONTINUATION_IDLE_MS = 8_000L
        private const val UTTERANCE_ANSWER = "gix_answer"
        private const val MAX_TTS_RETRIES = 1
        private const val TTS_RETRY_DELAY_MS = 700L
    }
}
