# GI X v1.6.42 — Esperas y protección de saldo

Base: v1.6.41, conservando la conexión HTTP normal que se restauró a partir de v1.6.21.

Evidencia aportada: una solicitud de prueba a deepseek-v4-flash tardó 135 414 ms en total, 124 974 ms hasta las cabeceras y 118 715 ms de enrutamiento. Con los 15 s de la prueba v1.6.41, GI X agotaba el tiempo de espera ANTES de que el servidor respondiera.

Cambios:
- Prueba: una sola solicitud y 180 s de timeout de lectura, sin segundo POST automático.
- Respuestas: 180 s (210 s para preguntas complejas); solo un POST automático por consulta para evitar dobles cargos de peticiones lentas.
- Visión: 210 s de timeout de lectura.
- Mensaje de prueba informa que el proveedor puede tardar hasta 3 minutos.
- Mensaje de timeout advierte que la petición podría haber sido procesada/cobrada aun si GI X no recibió respuesta.

Limitaciones: `HttpURLConnection.readTimeout` es tiempo máximo de inactividad de lectura, no tiempo total garantizado; no existe recuperación automática de respuestas de solicitudes huérfanas sin una API de consulta asíncrona confirmada por el proveedor. Este cambio no reduce los 118 s de enrutamiento registrados por Cheaper Inference.

Pendiente: compilación APK completa en GitHub Actions, pruebas reales API y recepción cámara+voz.
