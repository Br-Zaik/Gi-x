# Validación GI X v1.6.8

- Base: GI-X v1.6.7
- versionCode: 33
- versionName: 1.6.8

## Corrección
- Corregido el error de compilación Kotlin en MainActivity.kt línea ~912: `Unsupported escape sequence`.
- La expresión regular de limpieza de numeración ahora usa una cadena raw Kotlin válida.
- Escaneo estático de todos los archivos `.kt`: no quedaron secuencias de escape no soportadas detectables en strings normales.
- No se modificó el firmware de la cámara ni el comportamiento del OCR adaptativo, salvo esta corrección de compilación.
