# GI X v1.6.10 · estabilidad de recepción + OCR adaptativo

- versionCode: 35
- versionName: 1.6.10
- La recepción Wi-Fi ya no espera a guardar la foto en Galería antes de iniciar el lote. El guardado usa una cola acotada de 4 trabajos para evitar acumulación de memoria.
- Se eliminó la decodificación ARGB_8888 completa usada solo como prueba al recibir cada JPEG.
- Nuevo CameraJpegDecoder: valida dimensiones, limita memoria al decodificar y respeta EXIF.
- Cola de cámara limitada también por memoria comprimida (24 MiB), no solo por número de lotes.
- Servidor local usa 2 hilos fijos en vez de un pool ilimitado ante reintentos de red.
- OCR fuerte ahora es adaptativo: evita pasadas extra cuando la primera lectura ya es sólida.
- PP-OCRv6 queda protegido con watchdog de 14 s; si se atasca, ML Kit continúa y Paddle se desactiva para esa sesión.
- PP-OCRv6 usa 2 hilos para reducir saturación de CPU en teléfonos modestos.
- Mejora OpenCV con enfoque suave después de CLAHE para texto de cámara ligeramente borroso.
- No se modificaron package/applicationId, API, interfaz principal ni firmware de cámara.
