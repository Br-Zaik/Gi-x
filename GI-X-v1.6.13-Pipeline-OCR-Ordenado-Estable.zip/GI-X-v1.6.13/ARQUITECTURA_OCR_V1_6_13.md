# GI X v1.6.13 — Orden del pipeline OCR

## Flujo por imagen
1. Decodificar con límite de resolución y corregir EXIF.
2. Normalizar a resolución de trabajo.
3. Detectar hoja.
4. Corregir perspectiva; si no hay cuadrilátero fiable, intentar recorte conservador del papel.
5. Medir brillo, contraste y nitidez sobre la hoja, no sobre todo el escritorio.
6. Si la calidad lo necesita, aplicar CLAHE + enfoque suave antes del OCR.
7. Ejecutar PP-OCRv6 Small como motor principal.
8. Ejecutar ML Kit solo como verificador/fallback cuando Paddle tenga baja confianza, estructura sospechosa o datos tipo tabla.
9. Como máximo una segunda variante visual.
10. Usar binarización adaptativa/manuscrito únicamente como último rescate.
11. Validar estructura y devolver el mejor texto.

## Lotes de 1–4 imágenes
- Primero se calcula calidad y vista previa, sin OCR duplicado.
- Se procesa una sola imagen a la vez.
- Empieza por la captura con mejor calidad y continúa con las complementarias.
- Cada captura conserva su puntuación de calidad para la fusión.
- El fusor alinea preguntas por número y palabras por distancia de edición.
- La salida no agrega contenido que no exista en alguna captura.
- La corrección difusa de vocabulario técnico solo se permite cuando hay varias lecturas visuales que discrepan; con una sola captura se preserva el OCR salvo normalizaciones seguras de tildes/siglas conocidas.

## Límites de estabilidad
- PP-OCRv6: timeout 7 s por pasada.
- ML Kit: timeout 6 s por pasada.
- Presupuesto aproximado del pipeline por imagen: 16 s antes de iniciar rescates adicionales.
- Máximo 3 pasadas Paddle por imagen.
- Máximo 2 pasadas ML Kit por imagen.
- Una sola inferencia pesada activa por vez.
- Los errores de una captura no abortan las demás.
- El cierre de la Activity deja de aceptar trabajo nuevo y libera motores de forma diferida para evitar carreras JNI/use-after-free.

## Objetivo
Priorizar precisión real + estabilidad. Una foto físicamente ilegible no se inventa: se intenta recuperar desde las otras capturas del mismo documento.
