# VALIDACIÓN GI-X v1.6.2

- versionCode 27 / versionName 1.6.2 / minSdk 26.
- Corregido el fallo de integración con el workflow público de Br-Zaik/Gi-x.
- El workflow público actual llama directamente a `gradle :app:assembleDebug`; ahora `preBuild` ejecuta automáticamente `scripts/prepare_ppocrv6.sh`.
- No existe dependencia `project(":ppocr-sdk")`.
- PP-OCRv6 Small se copia dentro de `:app` antes de compilar.
- Modelos oficiales con verificación SHA-256 y fallback a repositorios oficiales PaddlePaddle en Hugging Face.
- ONNX Runtime 1.21.1 y QuickBird OpenCV 4.5.3.0 se mantienen.
- Guardado de cámara en Galería/Pictures/GI-X y deduplicación SHA-256 se mantienen.
- Firmware/protocolo de TimerCamera-X sin cambios.
