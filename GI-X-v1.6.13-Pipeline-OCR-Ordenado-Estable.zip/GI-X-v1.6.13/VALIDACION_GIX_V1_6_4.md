# Validación GI X v1.6.4

Cambio principal: prueba manual con 1–4 imágenes del mismo documento.

## Implementado
- Selector múltiple Android: 1 a 4 imágenes.
- OCR secuencial para limitar RAM.
- Fusión de preguntas por número, deduplicación y orden.
- Conservación de contexto y tablas.
- Detección de preguntas faltantes; no se llama a la API si el lote parece incompleto.
- Medición de nitidez/contraste/oscuridad por imagen con OpenCV.
- La calidad de la foto ayuda a desempatar lecturas repetidas.
- Prueba OCR sin API: muestra el documento combinado y no consume créditos.
- Visor tipo galería para las imágenes del lote.
- Primer intento API en un solo bloque para hasta 10 preguntas.

## No modificado
- Firmware TimerCamera-X.
- Puerto/token de cámara.
- Flujo de una sola foto recibido desde la cámara actual.

## Verificaciones locales
- MultiImageDocumentMerger y OcrQuestionExtractor compilados como Kotlin/JVM con stubs mínimos.
- Prueba sintética 4 fotos solapadas -> preguntas 1–10 ordenadas, sin huecos.
- Prueba sintética con preguntas 2,3,5 -> detecta faltantes 1 y 4.
- Prueba con tabla estructurada -> tabla preservada como contexto y preguntas reextraídas correctamente.
- El entorno local no incluye Android SDK/Gradle completo; la compilación APK final corresponde a GitHub Actions.
