#include "M5TimerCAM.h"
#include <WiFi.h>
#include <HTTPClient.h>

// GI X v1.5.4 - M5Stack TimerCamera-X U082-X
// Flujo: PWR -> Zona Wi-Fi -> UNA foto -> reintentar envio de ESA MISMA foto -> apagado.

// ========= CONFIGURACIÓN RÁPIDA =========
const char* WIFI_NAME = "TU_ZONA_WIFI";
const char* WIFI_PASSWORD = "TU_CLAVE_WIFI";
const char* GIX_TOKEN = "GIX2026CAM";   // Déjalo así salvo que quieras usar otra clave en la app
// En la mayoría de casos, deja fija la clave GIX2026CAM y cambia solo Wi-Fi.
// ==============================================

const uint16_t GIX_PORT = 8765;
const uint32_t WIFI_TIMEOUT_MS = 30000;
const uint32_t DELIVERY_WINDOW_MS = 45000;
const uint32_t HTTP_TIMEOUT_MS = 12000;
const uint32_t RETRY_DELAY_MS = 1200;

String phoneBaseUrl() {
  // En una Zona Wi-Fi del celular, el gateway de la cámara es el propio celular.
  IPAddress gateway = WiFi.gatewayIP();
  return String("http://") + gateway.toString() + ":" + String(GIX_PORT);
}

bool connectWifi() {
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(WIFI_NAME, WIFI_PASSWORD);

  Serial.print("Conectando a la Zona Wi-Fi");
  unsigned long started = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - started < WIFI_TIMEOUT_MS) {
    delay(400);
    Serial.print(".");
  }
  Serial.println();

  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("No se pudo conectar a la Zona Wi-Fi.");
    return false;
  }

  Serial.print("Conectada. IP camara: ");
  Serial.println(WiFi.localIP());
  Serial.print("Celular/gateway: ");
  Serial.println(WiFi.gatewayIP());
  return true;
}

String getPendingRequestId() {
  if (WiFi.status() != WL_CONNECTED) return "";

  HTTPClient http;
  http.setTimeout(4500);
  String url = phoneBaseUrl() + "/camera/poll?token=" + String(GIX_TOKEN);
  http.begin(url);
  int code = http.GET();
  String result = "";
  if (code == 200) {
    String body = http.getString();
    body.trim();
    if (body.startsWith("CAPTURE|")) {
      result = body.substring(8);
      result.trim();
    }
  }
  http.end();
  return result;
}

void warmUpCamera() {
  // Descarta tomas iniciales solo para estabilizar exposición/balance de blancos.
  // Estas NO se envían a GI X. La foto útil se captura una sola vez después.
  for (int i = 0; i < 3; i++) {
    if (TimerCAM.Camera.get()) {
      TimerCAM.Camera.free();
    }
    delay(220);
  }
}

bool captureAndDeliverOnePhoto(const String& requestId) {
  if (WiFi.status() != WL_CONNECTED) return false;

  // IMPORTANTE: una sola captura útil por encendido.
  if (!TimerCAM.Camera.get()) {
    Serial.println("No se pudo capturar la foto util");
    return false;
  }

  String url = phoneBaseUrl() + "/camera/photo?token=" + String(GIX_TOKEN);
  if (requestId.length() > 0) {
    url += "&requestId=" + requestId;
  }

  const uint8_t* jpegData = TimerCAM.Camera.fb->buf;
  const size_t jpegSize = TimerCAM.Camera.fb->len;
  Serial.printf("Foto capturada una vez: %u bytes\n", (unsigned int)jpegSize);

  bool sent = false;
  unsigned long started = millis();
  int attempt = 0;

  // Si GI X aún está arrancando, reintentamos EL MISMO JPEG. No volvemos a tomar otra foto.
  while (!sent && millis() - started < DELIVERY_WINDOW_MS) {
    attempt++;
    if (WiFi.status() != WL_CONNECTED) {
      Serial.println("Wi-Fi se desconecto antes del envio.");
      break;
    }

    HTTPClient http;
    http.setTimeout(HTTP_TIMEOUT_MS);
    http.begin(url);
    http.addHeader("Content-Type", "image/jpeg");
    int code = http.POST(jpegData, jpegSize);
    String response = code > 0 ? http.getString() : "";
    http.end();

    if (code == 200) {
      sent = true;
      Serial.printf("Foto enviada a GI X en intento %d\n", attempt);
    } else {
      Serial.printf("Fallo enviando la misma foto. Intento %d, HTTP %d %s\n",
                    attempt, code, response.c_str());
      delay(RETRY_DELAY_MS);
    }
  }

  TimerCAM.Camera.free();
  return sent;
}

void powerDown() {
  Serial.println("Apagando Timer Camera X...");
  TimerCAM.Power.setLed(0);
  WiFi.disconnect(true);
  WiFi.mode(WIFI_OFF);
  delay(250);
  TimerCAM.Power.powerOff();

  // Con batería debería apagarse. Si está alimentada por USB externo,
  // puede seguir energizada físicamente; este bucle impide tomar otra foto.
  while (true) delay(1000);
}

void setup() {
  Serial.begin(115200);
  delay(250);

  TimerCAM.begin();
  TimerCAM.Power.begin();
  TimerCAM.Power.setLed(40);

  if (!TimerCAM.Camera.begin()) {
    Serial.println("ERROR: no se pudo iniciar OV3660");
    delay(2500);
    powerDown();
  }

  TimerCAM.Camera.sensor->set_pixformat(TimerCAM.Camera.sensor, PIXFORMAT_JPEG);
  // 1600x1200 prioriza detalle para OCR y aprovecha la PSRAM de la U082-X.
  TimerCAM.Camera.sensor->set_framesize(TimerCAM.Camera.sensor, FRAMESIZE_UXGA);
  TimerCAM.Camera.sensor->set_quality(TimerCAM.Camera.sensor, 8);
  TimerCAM.Camera.sensor->set_vflip(TimerCAM.Camera.sensor, 1);
  TimerCAM.Camera.sensor->set_hmirror(TimerCAM.Camera.sensor, 0);

  if (!connectWifi()) {
    delay(1500);
    powerDown();
  }

  // No hace falta pulsar "PEDIR FOTO": al encender, la cámara manda una foto igual.
  // Si GI X dejó una orden pendiente, adjuntamos su ID solo para asociarla mejor.
  warmUpCamera();
  String requestId = getPendingRequestId();
  bool sent = captureAndDeliverOnePhoto(requestId);

  if (!sent) {
    Serial.println("No se pudo entregar la foto a GI X dentro del tiempo de espera.");
  }
  powerDown();
}

void loop() {
  // Nunca se toman fotos desde loop(). Un encendido = una foto útil.
  delay(1000);
}
