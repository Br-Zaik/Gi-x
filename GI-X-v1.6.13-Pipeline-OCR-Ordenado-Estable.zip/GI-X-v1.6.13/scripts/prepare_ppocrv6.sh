#!/usr/bin/env bash
set -euo pipefail

# GI-X v1.6.3
# Integra el SDK oficial PaddleOCR directamente dentro del módulo app.
# Motivo: evita por completo el variant-matching de un subproyecto :ppocr-sdk,
# que puede fallar en compilaciones de ZIP/GitHub Actions.
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WORK_DIR="${ROOT_DIR}/.ppocr-cache"
PADDLE_DIR="${WORK_DIR}/PaddleOCR"
APP_PADDLE_DIR="${ROOT_DIR}/app/src/main/java/com/paddle/ocr"
MODEL_DIR="${ROOT_DIR}/app/src/main/assets/models"

PADDLE_TAG="v3.7.0"
DET_URL="https://paddle-model-ecology.bj.bcebos.com/paddlex/official_inference_model/paddle3.0.0/PP-OCRv6_small_det_onnx_infer.tar"
REC_URL="https://paddle-model-ecology.bj.bcebos.com/paddlex/official_inference_model/paddle3.0.0/PP-OCRv6_small_rec_onnx_infer.tar"
DET_SHA256="d218f6fbf0f1c23d2161bd6ac7f5eaa6104fa89955c09290497e31008e2618e4"
REC_SHA256="d267ab077a44a0eedb1ea8f8c542d263f211de8e9d7a029bf9fcfff7e5a88fb1"
HF_DET_BASE="https://huggingface.co/PaddlePaddle/PP-OCRv6_small_det_onnx/resolve/main"
HF_REC_BASE="https://huggingface.co/PaddlePaddle/PP-OCRv6_small_rec_onnx/resolve/main"

rm -rf "${WORK_DIR}" "${APP_PADDLE_DIR}" "${MODEL_DIR}"
mkdir -p "${WORK_DIR}" "${MODEL_DIR}/det" "${MODEL_DIR}/rec"

echo "[GI-X] Descargando SDK oficial PaddleOCR ${PADDLE_TAG}..."
git clone --quiet --depth 1 --branch "${PADDLE_TAG}" --filter=blob:none --sparse \
  https://github.com/PaddlePaddle/PaddleOCR.git "${PADDLE_DIR}"
git -C "${PADDLE_DIR}" sparse-checkout set deploy/ppocr-android/ppocr-sdk/src/main/java/com/paddle/ocr

UPSTREAM_SRC="${PADDLE_DIR}/deploy/ppocr-android/ppocr-sdk/src/main/java/com/paddle/ocr"
if [[ ! -d "${UPSTREAM_SRC}" ]]; then
  echo "[GI-X] ERROR: no apareció el código Android oficial de PaddleOCR."
  exit 2
fi
mkdir -p "$(dirname "${APP_PADDLE_DIR}")"
cp -a "${UPSTREAM_SRC}" "${APP_PADDLE_DIR}"

fetch() {
  local url="$1" out="$2"
  curl --fail --location --retry 4 --retry-delay 2 --connect-timeout 20 --max-time 300 \
    "$url" -o "$out"
}

extract_official_tars() {
  local det_tar="${WORK_DIR}/det.tar" rec_tar="${WORK_DIR}/rec.tar"
  echo "[GI-X] Descargando modelos oficiales PP-OCRv6 Small..."
  fetch "${DET_URL}" "${det_tar}" || return 1
  fetch "${REC_URL}" "${rec_tar}" || return 1
  echo "${DET_SHA256}  ${det_tar}" | sha256sum -c - || return 1
  echo "${REC_SHA256}  ${rec_tar}" | sha256sum -c - || return 1

  mkdir -p "${WORK_DIR}/det" "${WORK_DIR}/rec"
  tar -xf "${det_tar}" -C "${WORK_DIR}/det"
  tar -xf "${rec_tar}" -C "${WORK_DIR}/rec"

  local det_model rec_model rec_yml
  det_model="$(find "${WORK_DIR}/det" -type f -name inference.onnx | head -n 1)"
  rec_model="$(find "${WORK_DIR}/rec" -type f -name inference.onnx | head -n 1)"
  rec_yml="$(find "${WORK_DIR}/rec" -type f -name inference.yml | head -n 1)"
  [[ -n "${det_model}" && -n "${rec_model}" && -n "${rec_yml}" ]] || return 1
  cp "${det_model}" "${MODEL_DIR}/det/inference.onnx"
  cp "${rec_model}" "${MODEL_DIR}/rec/inference.onnx"
  cp "${rec_yml}" "${MODEL_DIR}/rec/inference.yml"
}

fetch_huggingface_fallback() {
  echo "[GI-X] BOS no respondió; usando repositorios oficiales PaddlePaddle en Hugging Face..."
  fetch "${HF_DET_BASE}/inference.onnx?download=true" "${MODEL_DIR}/det/inference.onnx"
  fetch "${HF_REC_BASE}/inference.onnx?download=true" "${MODEL_DIR}/rec/inference.onnx"
  fetch "${HF_REC_BASE}/inference.yml?download=true" "${MODEL_DIR}/rec/inference.yml"
}

if ! extract_official_tars; then
  rm -f "${MODEL_DIR}/det/inference.onnx" "${MODEL_DIR}/rec/inference.onnx" "${MODEL_DIR}/rec/inference.yml"
  fetch_huggingface_fallback
fi

[[ -s "${MODEL_DIR}/det/inference.onnx" ]]
[[ -s "${MODEL_DIR}/rec/inference.onnx" ]]
[[ -s "${MODEL_DIR}/rec/inference.yml" ]]
[[ -f "${APP_PADDLE_DIR}/PaddleOCR.kt" ]]

SOURCE_COUNT="$(find "${APP_PADDLE_DIR}" -type f \( -name '*.kt' -o -name '*.java' \) | wc -l | tr -d ' ')"
if [[ "${SOURCE_COUNT}" -lt 5 ]]; then
  echo "[GI-X] ERROR: SDK PaddleOCR incompleto (${SOURCE_COUNT} archivos fuente)."
  exit 3
fi

echo "[GI-X] PP-OCRv6 Small preparado dentro de :app (${SOURCE_COUNT} fuentes)."
