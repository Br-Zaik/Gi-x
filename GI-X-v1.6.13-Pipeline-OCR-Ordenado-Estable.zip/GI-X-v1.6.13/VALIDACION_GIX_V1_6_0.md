# VALIDACIÓN GI-X v1.6.0

- versionCode 25 / versionName 1.6.0 / minSdk 26.
- No se modificó el protocolo TimerCamera-X: puerto 8765, token GIX2026CAM.
- PP-OCRv6 Small: integración local mediante SDK oficial PaddleOCR v3.7.0 y ONNX Runtime 1.21.1.
- OpenCV Android fijado a 4.5.3.0 para librerías nativas.
- ML Kit permanece como segundo motor y fallback.
- Preprocesado OpenCV es conservador: corrección de perspectiva solo con cuadrilátero >55% del área; si no, conserva la foto.
- Galería: Android 10+ usa MediaStore/Pictures/GI-X; Android 8-9 usa permiso legacy.
- Duplicados: SHA-256 con ventana de 120 s para no repetir foto/repuesta por reintentos de cámara.
- Cola: hasta 3 fotos nuevas recibidas mientras hay OCR/API/TTS en curso.
- GitHub Actions prepara automáticamente SDK/modelos antes de compilar y verifica hashes de modelos oficiales.
- Si Paddle/OpenCV no inicializan, el OCR continúa con ML Kit.
- Cola de cámara usa JPEG comprimido (hasta 12 pendientes) para no retener Bitmaps grandes en RAM.
- Deduplicación ajustada a 70 s: cubre la ventana de reintentos del firmware sin bloquear durante demasiado tiempo una captura intencional idéntica.
