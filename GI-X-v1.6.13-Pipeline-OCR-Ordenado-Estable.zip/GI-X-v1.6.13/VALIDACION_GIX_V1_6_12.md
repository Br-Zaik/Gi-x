GI-X v1.6.12

Cambios:
- rescate OCR fuerte sobre todas las imágenes del lote (1–4) para máxima recuperación;
- lectura rápida con recorte/perspectiva segura cuando OpenCV detecta la hoja;
- recorte de hoja más tolerante para fotos en escritorio;
- filtro de ruido externo en contexto (ej. Core i5, fragmentos cortos ajenos al documento);
- pulido conservador de preguntas: mayúsculas iniciales y tildes frecuentes (Qué, minería, topografía, geográficas, UTM).

Sin cambios en:
- package/applicationId: com.gix.cameraai
- firmware
- API
