# Validación GI X v1.6.5

- Base: GI-X v1.6.4
- versionCode: 30
- versionName: 1.6.5

## Cambios aplicados
- El modo IMAGEN MANUAL mantiene el lote de 1 a 4 imágenes como un solo documento.
- El modo CÁMARA ahora también puede agrupar automáticamente hasta 4 imágenes recibidas por Wi-Fi como un solo lote lógico.
- Si las fotos llegan mientras GI X está ocupado, el lote completo queda en cola, no cada foto por separado.
- El OCR combinado conserva contexto, tablas, datos y preguntas antes de consultar la API.
- Sin API, GI X muestra el OCR final combinado para validar preguntas faltantes, duplicadas u ordenadas.

## Pendiente intencional
- El firmware de cámara incluido en este ZIP sigue enviando una sola foto por encendido. La app ya quedó preparada para el futuro lote de 4 fotos desde cámara.
