package com.gix.cameraai

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Guarda cada foto ÚNICA recibida de la cámara en Galería/Pictures/GI-X. */
object CameraPhotoStore {

    data class SaveResult(
        val saved: Boolean,
        val displayPath: String,
        val needsLegacyPermission: Boolean = false,
        val error: String? = null,
    )

    fun save(context: Context, jpeg: ByteArray): SaveResult {
        if (jpeg.isEmpty()) return SaveResult(false, "", error = "JPEG vacío")
        val name = "GIX_${SimpleDateFormat("yyyy-MM-dd_HH-mm-ss-SSS", Locale.US).format(Date())}.jpg"
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            saveModern(context, jpeg, name)
        } else {
            saveLegacy(context, jpeg, name)
        }
    }

    private fun saveModern(context: Context, jpeg: ByteArray, name: String): SaveResult {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/GI-X")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: return SaveResult(false, "", error = "Android no creó el archivo en Galería")
        return try {
            resolver.openOutputStream(uri, "w")?.use { it.write(jpeg) }
                ?: throw IllegalStateException("No se pudo abrir el archivo de Galería")
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            SaveResult(true, "Pictures/GI-X/$name")
        } catch (t: Throwable) {
            runCatching { resolver.delete(uri, null, null) }
            SaveResult(false, "", error = t.message ?: "No se pudo guardar la foto")
        }
    }

    @Suppress("DEPRECATION")
    private fun saveLegacy(context: Context, jpeg: ByteArray, name: String): SaveResult {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            return SaveResult(false, "", needsLegacyPermission = true, error = "Falta permiso para guardar en Galería")
        }
        return try {
            val pictures = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
            val dir = File(pictures, "GI-X")
            if (!dir.exists() && !dir.mkdirs()) throw IllegalStateException("No se pudo crear Pictures/GI-X")
            val file = File(dir, name)
            FileOutputStream(file).use { it.write(jpeg) }
            MediaScannerConnection.scanFile(context, arrayOf(file.absolutePath), arrayOf("image/jpeg"), null)
            SaveResult(true, "Pictures/GI-X/$name")
        } catch (t: Throwable) {
            SaveResult(false, "", error = t.message ?: "No se pudo guardar la foto")
        }
    }
}
