package com.gix.cameraai

import android.content.Context
import android.graphics.Matrix
import android.graphics.RectF
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.appcompat.widget.AppCompatImageView
import kotlin.math.max
import kotlin.math.min

/**
 * Visor de imagen estilo galería para GI X.
 *
 * - pinch-to-zoom 1x..6x;
 * - doble toque alterna entre ajuste y 2.5x;
 * - arrastre cuando la imagen está ampliada;
 * - rotación de 90° sin crear copias gigantes del bitmap;
 * - restablecimiento seguro al cambiar tamaño/orientación.
 */
class ZoomableImageView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : AppCompatImageView(context, attrs, defStyleAttr) {

    private val drawMatrix = Matrix()
    private val baseMatrix = Matrix()
    private val values = FloatArray(9)
    private var userScale = 1f
    private var quarterTurns = 0
    private val minScale = 1f
    private val maxScale = 6f

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val desired = (userScale * detector.scaleFactor).coerceIn(minScale, maxScale)
            val factor = desired / userScale
            if (factor.isFinite() && factor > 0f) {
                drawMatrix.postScale(factor, factor, detector.focusX, detector.focusY)
                userScale = desired
                fixTranslation()
                imageMatrix = drawMatrix
            }
            return true
        }
    })

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
            if (userScale <= minScale + 0.001f) return false
            drawMatrix.postTranslate(-distanceX, -distanceY)
            fixTranslation()
            imageMatrix = drawMatrix
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (userScale > 1.15f) {
                resetView()
            } else {
                val target = 2.5f
                drawMatrix.postScale(target, target, e.x, e.y)
                userScale = target
                fixTranslation()
                imageMatrix = drawMatrix
            }
            return true
        }
    })

    init {
        scaleType = ScaleType.MATRIX
        isClickable = true
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        val scaleHandled = scaleDetector.onTouchEvent(event)
        val gestureHandled = gestureDetector.onTouchEvent(event)
        if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
            fixTranslation()
            imageMatrix = drawMatrix
        }
        return scaleHandled || gestureHandled || super.onTouchEvent(event)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w > 0 && h > 0) post { rebuildBaseMatrix() }
    }

    override fun setImageDrawable(drawable: android.graphics.drawable.Drawable?) {
        super.setImageDrawable(drawable)
        post { rebuildBaseMatrix() }
    }

    fun rotateClockwise() {
        quarterTurns = (quarterTurns + 1) % 4
        userScale = 1f
        rebuildBaseMatrix()
    }

    fun resetView() {
        userScale = 1f
        rebuildBaseMatrix()
    }

    private fun rebuildBaseMatrix() {
        val d = drawable ?: return
        if (width <= 0 || height <= 0 || d.intrinsicWidth <= 0 || d.intrinsicHeight <= 0) return

        baseMatrix.reset()
        val dw = d.intrinsicWidth.toFloat()
        val dh = d.intrinsicHeight.toFloat()
        val rotated = quarterTurns % 2 != 0
        val rw = if (rotated) dh else dw
        val rh = if (rotated) dw else dh
        val fit = min(width / rw, height / rh).coerceAtLeast(0.001f)

        // Giramos alrededor del centro del drawable y luego centramos el rectángulo
        // resultante dentro del visor.
        baseMatrix.postTranslate(-dw / 2f, -dh / 2f)
        baseMatrix.postRotate(quarterTurns * 90f)
        baseMatrix.postScale(fit, fit)
        baseMatrix.postTranslate(width / 2f, height / 2f)

        drawMatrix.set(baseMatrix)
        userScale = 1f
        imageMatrix = drawMatrix
        invalidate()
    }

    private fun fixTranslation() {
        val d = drawable ?: return
        val rect = RectF(0f, 0f, d.intrinsicWidth.toFloat(), d.intrinsicHeight.toFloat())
        drawMatrix.mapRect(rect)

        var dx = 0f
        var dy = 0f
        if (rect.width() <= width) {
            dx = width / 2f - rect.centerX()
        } else if (rect.left > 0f) {
            dx = -rect.left
        } else if (rect.right < width) {
            dx = width - rect.right
        }

        if (rect.height() <= height) {
            dy = height / 2f - rect.centerY()
        } else if (rect.top > 0f) {
            dy = -rect.top
        } else if (rect.bottom < height) {
            dy = height - rect.bottom
        }
        drawMatrix.postTranslate(dx, dy)
    }
}
