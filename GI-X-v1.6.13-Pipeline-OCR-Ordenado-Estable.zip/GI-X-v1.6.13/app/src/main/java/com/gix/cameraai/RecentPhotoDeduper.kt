package com.gix.cameraai

import java.security.MessageDigest
import java.util.LinkedHashMap

/** Evita que los reintentos HTTP de la TimerCamera-X vuelvan a ejecutar OCR/API/voz. */
class RecentPhotoDeduper(
    private val ttlMs: Long = 70_000L,
    private val maxEntries: Int = 12,
) {
    private val recent = LinkedHashMap<String, Long>()

    @Synchronized
    fun isDuplicate(bytes: ByteArray, now: Long = System.currentTimeMillis()): Boolean {
        val iterator = recent.entries.iterator()
        while (iterator.hasNext()) {
            if (now - iterator.next().value > ttlMs) iterator.remove()
        }
        val hash = sha256(bytes)
        val previous = recent[hash]
        recent[hash] = now
        while (recent.size > maxEntries) {
            val first = recent.entries.firstOrNull()?.key ?: break
            recent.remove(first)
        }
        return previous != null && now - previous <= ttlMs
    }

    private fun sha256(bytes: ByteArray): String {
        return MessageDigest.getInstance("SHA-256")
            .digest(bytes)
            .joinToString("") { "%02x".format(it) }
    }
}
