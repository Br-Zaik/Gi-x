package com.gix.cameraai

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.gix.cameraai.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.Executors
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener, CameraBridgeServer.Listener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: AppPrefs
    private lateinit var apiSettings: GeminiSettings
    private lateinit var onlineProvider: OnlineAnswerProvider
    private lateinit var cameraServer: CameraBridgeServer
    private lateinit var historyRepository: HistoryRepository
    private lateinit var ocrProcessor: OcrProcessor
    private val ioExecutor = Executors.newSingleThreadExecutor()
    private val cameraIoExecutor = Executors.newSingleThreadExecutor()
    private val galleryExecutor = ThreadPoolExecutor(
        1,
        1,
        0L,
        TimeUnit.MILLISECONDS,
        ArrayBlockingQueue<Runnable>(4),
        ThreadPoolExecutor.DiscardOldestPolicy(),
    )
    private val recentPhotoDeduper = RecentPhotoDeduper()
    private val pendingCameraBatches = ArrayDeque<QueuedCameraBatch>()
    private val cameraBatchCollector = ArrayDeque<QueuedCameraPhoto>()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val processing = AtomicBoolean(false)

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsInitializing = false
    private var pendingSpeechText: String? = null
    private var activeSpeechText: String? = null
    private var activeSpeechFinalId: String? = null
    private var speechRetryCount = 0
    private var speechSessionId = 0L
    private var speechRecoveryInProgress = false
    private var isSpeakingAnswer = false
    private var autoMode = false
    private var stopped = false
    @Volatile private var destroyedForAsync = false
    private var inputMode = InputMode.CAMERA
    @Volatile private var activeCaptureRequestId: String? = null
    private var cameraStatusTicker: Runnable? = null
    private var lastExtractedQuestions: List<String> = emptyList()
    private var previewBitmap: Bitmap? = null
    private var batchPreviewBitmaps: List<Bitmap> = emptyList()
    private var lastDisplayedOcrText: String = ""
    private var lastSourceLabel: String = "desconocido"
    private var pendingOcrDisplayOverride: String? = null
    private var pendingBatchInfo: String? = null
    private var pendingMissingQuestionNumbers: List<Int> = emptyList()
    private var cameraBatchFinalizeRunnable: Runnable? = null
    private var cameraBatchOpenedAtMs: Long = 0L

    private data class QueuedCameraPhoto(
        val jpeg: ByteArray,
        val source: String,
        val requestId: String? = null,
    )

    private data class QueuedCameraBatch(
        val photos: List<QueuedCameraPhoto>,
        val label: String,
    )

    private data class ManualBatchOcrItem(
        val rawText: String,
        val quality: OcrProcessor.ImageQualityReport,
    )

    private val openPhotosLauncher = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isEmpty()) return@registerForActivityResult
        loadPhotosFromUris(uris)
    }

    private val legacyGalleryPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (::binding.isInitialized && !granted) {
            binding.tvStatus.text = "GI X seguirá funcionando, pero Android no permitió guardar fotos en Galería."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = AppPrefs(this)
        apiSettings = GeminiSettings(this)
        onlineProvider = OnlineAnswerProvider(this)
        historyRepository = HistoryRepository(this)
        ocrProcessor = OcrProcessor(this)
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            legacyGalleryPermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        ttsInitializing = true
        tts = TextToSpeech(this, this)

        // Limpia estados antiguos de "espera" de la API pagada sin borrar la clave.
        apiSettings.getApiConfigs()
            .filter { it.provider == NetProvider.CHEAPER_INFERENCE }
            .forEach { apiSettings.shouldSkip(it) }

        setupButtons()
        setupInternalScroll(binding.svOcr)
        setupInternalScroll(binding.svAnswer)
        renderHistory()
        updateApiChip()
        startCameraServer()
        startCameraStatusTicker()
    }

    private fun setupButtons() {
        binding.inputModeGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            when (checkedId) {
                R.id.btnModeCamera -> setInputMode(InputMode.CAMERA)
                R.id.btnModeImage -> setInputMode(InputMode.IMAGE)
            }
        }
        binding.inputModeGroup.check(R.id.btnModeCamera)

        binding.btnCapture.setOnClickListener {
            stopped = false
            requestCameraCapture(manual = true)
        }

        binding.btnAuto.setOnClickListener {
            if (inputMode != InputMode.CAMERA) {
                binding.tvStatus.text = "El modo AUTO funciona con la cámara. Cambia a CÁMARA."
                return@setOnClickListener
            }
            autoMode = !autoMode
            stopped = false
            binding.btnAuto.text = if (autoMode) "AUTO: ON" else "AUTO: OFF"
            if (autoMode) {
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                binding.tvStatus.text = "AUTO activo: GI X quedará listo para recibir la cámara. Cada encendido enviará 1 foto → OCR → API → voz."
                requestCameraCapture(manual = false)
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                binding.tvStatus.text = "AUTO detenido. Cuando quieras otra foto, vuelve a encender la cámara."
            }
        }

        binding.btnStop.setOnClickListener { stopCurrentCycle() }

        binding.btnChooseImage.setOnClickListener {
            stopped = false
            openPhotosLauncher.launch(arrayOf("image/*"))
        }

        binding.btnApi.setOnClickListener { showApiDialog() }
        binding.btnVoice.setOnClickListener { showVoiceDialog() }
        binding.btnCameraSettings.setOnClickListener { showCameraDialog() }
        binding.btnOpenPreview.setOnClickListener { showPreviewDialog() }
        binding.btnClearHistory.setOnClickListener { confirmClearHistory() }
    }

    private fun setInputMode(mode: InputMode) {
        if (inputMode == mode && binding.cameraActions.visibility == if (mode == InputMode.CAMERA) View.VISIBLE else View.GONE) {
            return
        }
        inputMode = mode
        when (mode) {
            InputMode.CAMERA -> {
                binding.cameraActions.visibility = View.VISIBLE
                binding.btnChooseImage.visibility = View.GONE
                binding.tvStatus.text = "Modo CÁMARA. Activa tu Zona Wi-Fi y deja GI X abierto. La app ya está preparada para recibir una foto suelta o agrupar automáticamente hasta 4 imágenes del mismo documento cuando la cámara las envíe."
            }
            InputMode.IMAGE -> {
                autoMode = false
                binding.btnAuto.text = "AUTO: OFF"
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                cameraServer.cancelCapture()
                activeCaptureRequestId = null
                binding.cameraActions.visibility = View.GONE
                binding.btnChooseImage.visibility = View.VISIBLE
                binding.tvStatus.text = "Modo IMAGEN MANUAL. Puedes elegir de 1 a 4 imágenes del mismo documento. GI X las une, ordena y evita duplicados."
            }
        }
    }

    private fun startCameraServer() {
        cameraServer = CameraBridgeServer(
            CameraBridgeServer.DEFAULT_PORT,
            tokenProvider = { prefs.pairingToken },
            listener = this
        )
        cameraServer.start()
    }

    private fun startCameraStatusTicker() {
        val ticker = object : Runnable {
            override fun run() {
                updateCameraChip()
                mainHandler.postDelayed(this, 2_000L)
            }
        }
        cameraStatusTicker = ticker
        mainHandler.post(ticker)
    }

    private fun requestCameraCapture(manual: Boolean) {
        if (processing.get()) {
            binding.tvStatus.text = "Espera: GI X todavía está procesando la foto anterior."
            return
        }
        if (activeCaptureRequestId != null) {
            binding.tvStatus.text = "Ya hay una foto solicitada. Esperando a la cámara..."
            return
        }

        val requestId = cameraServer.requestCapture()
        activeCaptureRequestId = requestId
        binding.tvStatus.text = if (cameraServer.isCameraConnected()) {
            "Orden enviada. Esperando la foto de Timer Camera X..."
        } else {
            "Orden preparada. Enciende la cámara y verifica que esté conectada a tu Zona Wi-Fi."
        }

        mainHandler.postDelayed({
            if (activeCaptureRequestId == requestId) {
                cameraServer.cancelCapture()
                activeCaptureRequestId = null
                if (!processing.get()) {
                    binding.tvStatus.text = if (manual) {
                        "La cámara no respondió. Revisa Zona Wi-Fi, cámara y clave de enlace."
                    } else {
                        "Auto: cámara sin respuesta. Reintentaré cuando vuelva a estar disponible."
                    }
                }
            }
        }, 25_000L)
    }

    private fun stopCurrentCycle() {
        stopped = true
        autoMode = false
        binding.btnAuto.text = "AUTO: OFF"
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        cameraServer.cancelCapture()
        activeCaptureRequestId = null
        onlineProvider.cancelActiveRequest()
        tts?.stop()
        pendingSpeechText = null
        activeSpeechText = null
        activeSpeechFinalId = null
        isSpeakingAnswer = false
        speechRetryCount = 0
        speechRecoveryInProgress = false
        ttsInitializing = false
        processing.set(false)
        pendingOcrDisplayOverride = null
        pendingBatchInfo = null
        pendingMissingQuestionNumbers = emptyList()
        pendingCameraBatches.clear()
        cameraBatchCollector.clear()
        cameraBatchFinalizeRunnable?.let { mainHandler.removeCallbacks(it) }
        cameraBatchFinalizeRunnable = null
        binding.tvStatus.text = if (inputMode == InputMode.CAMERA) {
            "Detenido. Vuelve a encender la cámara cuando quieras otra foto."
        } else {
            "Detenido. Pulsa ELEGIR 1–4 IMÁGENES cuando quieras continuar."
        }
    }

    override fun onServerStarted(port: Int) {
        runOnUiThread {
            if (inputMode == InputMode.CAMERA) {
                binding.tvStatus.text = "GI X listo. Activa tu Zona Wi-Fi y enciende la cámara; recibirá la foto por el puerto $port."
            }
        }
    }

    override fun onServerError(message: String) {
        runOnUiThread {
            binding.tvStatus.text = "Error del enlace con cámara: $message"
            binding.tvCameraChip.text = "Cámara: error"
        }
    }

    override fun onCameraSeen() {
        runOnUiThread { updateCameraChip() }
    }

    override fun onPhotoReceived(jpeg: ByteArray, requestId: String?) {
        activeCaptureRequestId = null

        // La cámara puede reenviar el MISMO JPEG si la red falla. Lo confirmamos,
        // pero no repetimos OCR/API/voz si el contenido es idéntico.
        if (recentPhotoDeduper.isDuplicate(jpeg)) {
            runOnUiThread {
                binding.tvStatus.text = "La cámara reenvió la misma foto. GI X evitó procesarla dos veces."
            }
            return
        }

        cameraIoExecutor.execute {
            // Validación de dimensiones SIN expandir el JPEG completo a memoria. La v1.6.8
            // hacía aquí una decodificación ARGB_8888 completa antes incluso de encolar.
            val info = CameraJpegDecoder.inspect(jpeg)
            if (info == null) {
                runOnUiThread {
                    binding.tvStatus.text = "La cámara envió una imagen JPEG inválida o demasiado grande."
                }
                return@execute
            }

            // El guardado en Galería ya no bloquea la recepción del siguiente JPEG ni el
            // inicio del OCR. El ByteArray recibido es propio de esta petición; no hace
            // falta duplicarlo con copyOf(), ahorrando memoria cuando llegan varias fotos.
            runCatching {
                galleryExecutor.execute {
                    CameraPhotoStore.save(this, jpeg)
                }
            }

            runOnUiThread {
                // Una foto física de la TimerCamera siempre tiene prioridad y activa el
                // modo CÁMARA aunque el usuario hubiera dejado la pantalla en MANUAL.
                if (inputMode != InputMode.CAMERA) {
                    binding.inputModeGroup.check(R.id.btnModeCamera)
                }

                enqueueCameraPhotoForBatch(
                    QueuedCameraPhoto(jpeg, "cámara", requestId)
                )
            }
        }
    }

    private fun enqueueCameraPhotoForBatch(photo: QueuedCameraPhoto) {
        val incomingRequestId = photo.requestId?.trim().orEmpty()
        val currentRequestId = cameraBatchCollector.firstOrNull()?.requestId?.trim().orEmpty()

        // Si cambia el requestId, cerramos el lote anterior antes de mezclar capturas.
        if (cameraBatchCollector.isNotEmpty() && incomingRequestId.isNotBlank() &&
            currentRequestId.isNotBlank() && incomingRequestId != currentRequestId) {
            finalizeCameraCollector()
        }

        if (cameraBatchCollector.isEmpty()) {
            cameraBatchOpenedAtMs = System.currentTimeMillis()
        }

        while (cameraBatchCollector.size >= MAX_CAMERA_BATCH_IMAGES) {
            finalizeCameraCollector()
        }

        cameraBatchCollector.addLast(photo)
        val received = cameraBatchCollector.size
        val waitingForMore = received < MAX_CAMERA_BATCH_IMAGES
        binding.tvStatus.text = if (waitingForMore) {
            "Cámara: recibí $received de $MAX_CAMERA_BATCH_IMAGES imágenes del mismo documento. Esperando más para formar el lote..."
        } else {
            "Cámara: recibí $received imágenes. Preparando el lote automático..."
        }

        cameraBatchFinalizeRunnable?.let { mainHandler.removeCallbacks(it) }
        cameraBatchFinalizeRunnable = Runnable {
            cameraBatchFinalizeRunnable = null
            finalizeCameraCollector()
        }

        if (received >= MAX_CAMERA_BATCH_IMAGES) {
            mainHandler.post(cameraBatchFinalizeRunnable!!)
        } else {
            mainHandler.postDelayed(cameraBatchFinalizeRunnable!!, CAMERA_BATCH_IDLE_MS)
        }
    }

    private fun finalizeCameraCollector() {
        cameraBatchFinalizeRunnable?.let { mainHandler.removeCallbacks(it) }
        cameraBatchFinalizeRunnable = null
        if (cameraBatchCollector.isEmpty()) return

        val photos = buildList {
            while (cameraBatchCollector.isNotEmpty()) {
                add(cameraBatchCollector.removeFirst())
            }
        }
        val label = if (photos.size > 1) {
            "lote cámara · ${photos.size} imágenes"
        } else {
            photos.first().source
        }
        val batch = QueuedCameraBatch(photos, label)
        cameraBatchOpenedAtMs = 0L

        if (stopped) return

        if (processing.get() || isSpeakingAnswer || !pendingSpeechText.isNullOrBlank()) {
            enqueuePendingCameraBatch(batch)
            binding.tvStatus.text = if (photos.size > 1) {
                "Recibí ${photos.size} imágenes de cámara. GI X las procesará juntas al terminar el trabajo actual."
            } else {
                "Foto recibida. GI X la procesará al terminar el trabajo actual."
            }
            return
        }

        processCameraBatch(batch)
    }

    private fun enqueuePendingCameraBatch(batch: QueuedCameraBatch) {
        val incomingBytes = batch.photos.sumOf { it.jpeg.size.toLong() }
        fun queuedBytes(): Long = pendingCameraBatches.sumOf { queued ->
            queued.photos.sumOf { it.jpeg.size.toLong() }
        }

        // No dejamos que una ráfaga/reintentos acumulen decenas de MB comprimidos mientras
        // OCR/API/voz siguen ocupados. Se conserva siempre el trabajo más reciente.
        while (pendingCameraBatches.isNotEmpty() &&
            (pendingCameraBatches.size >= MAX_PENDING_CAMERA_BATCHES ||
                queuedBytes() + incomingBytes > MAX_PENDING_CAMERA_BYTES)) {
            pendingCameraBatches.pollFirst()
        }
        pendingCameraBatches.addLast(batch)
    }

    private fun processCameraBatch(batch: QueuedCameraBatch) {
        if (batch.photos.size <= 1) {
            val single = batch.photos.firstOrNull() ?: return
            val bitmap = CameraJpegDecoder.decodeForOcr(single.jpeg)
            if (bitmap == null) {
                binding.tvStatus.text = "La cámara envió una imagen que Android no pudo abrir."
                scheduleNextAutoIfNeeded()
                return
            }
            processBitmap(bitmap, source = batch.label)
            return
        }
        processCameraImageBatch(batch)
    }

    private fun processCameraImageBatch(batch: QueuedCameraBatch) {
        if (!processing.compareAndSet(false, true)) {
            enqueuePendingCameraBatch(batch)
            binding.tvStatus.text = "GI X está ocupado. El lote de cámara quedó en espera."
            return
        }
        stopped = false
        lastExtractedQuestions = emptyList()
        lastDisplayedOcrText = ""
        lastSourceLabel = batch.label
        pendingOcrDisplayOverride = null
        pendingBatchInfo = null
        pendingMissingQuestionNumbers = emptyList()
        clearAllPreviews()
        binding.tvOcr.text = "Procesando lote de ${batch.photos.size} imágenes de cámara..."
        binding.tvAnswer.text = "Esperando OCR combinado..."
        binding.tvStatus.text = "Lote cámara: preparando imagen 1 de ${batch.photos.size}."

        val items = mutableListOf<ManualBatchOcrItem>()
        val previews = mutableListOf<Bitmap>()
        var failedImages = 0
        var heavyPasses = 0

        fun finishBatch() {
            if (stopped) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                processing.set(false)
                return
            }
            val rawTexts = items.map { it.rawText }
            if (rawTexts.none { it.isNotBlank() }) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                processing.set(false)
                binding.tvStatus.text = "Ninguna de las imágenes de cámara produjo texto OCR legible."
                binding.tvOcr.text = "Sin texto detectado."
                binding.tvAnswer.text = "Acerca la cámara, mejora la luz y vuelve a intentarlo."
                scheduleNextAutoIfNeeded()
                return
            }

            batchPreviewBitmaps = previews.toList()
            previewBitmap = batchPreviewBitmaps.firstOrNull()
            previewBitmap?.let {
                binding.ivPreview.setImageBitmap(it)
                binding.tvPreviewPlaceholder.visibility = View.GONE
            }

            val merge = MultiImageDocumentMerger.merge(
                rawTexts,
                items.map { it.quality.selectionScore() }
            )
            val qualitySummary = items.mapIndexed { index, item ->
                "Captura ${index + 1}: ${item.quality.shortLabel()} · nitidez ${item.quality.sharpness.toInt()}"
            }.joinToString("\n")
            val failedText = if (failedImages > 0) "\nImágenes sin OCR: $failedImages" else ""
            pendingMissingQuestionNumbers = merge.missingQuestionNumbers

            pendingOcrDisplayOverride = buildString {
                append(merge.combinedDisplay.ifBlank { "Documento combinado sin preguntas claras." })
                append("\n\nCALIDAD DE LAS CAPTURAS\n")
                append(qualitySummary)
                append(failedText)
            }.trim()
            pendingBatchInfo = buildString {
                append("${batch.photos.size} imágenes de cámara como un solo documento")
                if (merge.duplicateQuestionNumbersResolved > 0) {
                    append(" · ${merge.duplicateQuestionNumbersResolved} repetición(es) resuelta(s)")
                }
                append(" · $heavyPasses OCR completo(s)")
            }

            if (merge.combinedRaw.isBlank()) {
                processing.set(false)
                binding.tvStatus.text = "El lote de cámara llegó, pero no pude reconstruir texto útil."
                binding.tvOcr.text = pendingOcrDisplayOverride.orEmpty()
                binding.tvAnswer.text = "Vuelve a tomar la hoja con mejor luz o mayor solapamiento."
                pendingOcrDisplayOverride = null
                pendingBatchInfo = null
                pendingMissingQuestionNumbers = emptyList()
                scheduleNextAutoIfNeeded()
                return
            }

            handleOcrResult(merge.combinedRaw)
        }

        fun rescueAt(order: List<Int>, position: Int) {
            if (position >= order.size) {
                finishBatch()
                return
            }
            if (stopped) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                processing.set(false)
                return
            }

            // Para máxima precisión hacemos rescate fuerte sobre TODAS las imágenes
            // del lote, de forma secuencial y controlada. Es algo más lento que
            // cortar antes, pero mejora la recuperación de preguntas finales borrosas
            // y reduce casos donde una foto buena tapa una pregunta que otra sí aporta.

            val imageIndex = order[position]
            binding.tvStatus.text = "Lote cámara: OCR ordenado ${position + 1}/${order.size}, imagen ${imageIndex + 1}..."
            ioExecutor.execute {
                val photo = batch.photos[imageIndex]
                val bitmap = CameraJpegDecoder.decodeForOcr(photo.jpeg)
                if (bitmap == null) {
                    if (!destroyedForAsync) runOnUiThread { rescueAt(order, position + 1) }
                    return@execute
                }
                ocrProcessor.process(
                    bitmap,
                    onSuccess = { raw ->
                        heavyPasses++
                        if (raw.isNotBlank()) {
                            val better = chooseBetterBatchOcr(items[imageIndex].rawText, raw.trim())
                            items[imageIndex] = ManualBatchOcrItem(better, items[imageIndex].quality)
                        } else {
                            failedImages++
                        }
                        if (!bitmap.isRecycled) bitmap.recycle()
                        if (!destroyedForAsync) runOnUiThread { rescueAt(order, position + 1) }
                    },
                    onError = {
                        failedImages++
                        if (!bitmap.isRecycled) bitmap.recycle()
                        if (!destroyedForAsync) runOnUiThread { rescueAt(order, position + 1) }
                    }
                )
            }
        }

        fun startAdaptiveRescue() {
            val order = buildAdaptiveRescueOrder(items)
            if (order.isEmpty()) {
                finishBatch()
                return
            }
            rescueAt(order, 0)
        }

        fun processAt(index: Int) {
            if (index >= batch.photos.size) {
                startAdaptiveRescue()
                return
            }
            if (stopped) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                processing.set(false)
                return
            }

            binding.tvStatus.text = "Lote cámara: preparando ${index + 1} de ${batch.photos.size} (calidad + vista previa)..."
            ioExecutor.execute {
                val photo = batch.photos[index]
                val bitmap = CameraJpegDecoder.decodeForOcr(photo.jpeg)
                if (bitmap == null) {
                    failedImages++
                    items += ManualBatchOcrItem(
                        "",
                        OcrProcessor.ImageQualityReport(128.0, 64.0, 0.0, false, false, true)
                    )
                    if (!destroyedForAsync) runOnUiThread { processAt(index + 1) }
                    return@execute
                }

                val quality = runCatching { ocrProcessor.assessQuality(bitmap) }
                    .getOrElse { OcrProcessor.ImageQualityReport(128.0, 64.0, 100.0, false, false, false) }
                val thumb = makePreviewThumbnail(bitmap)
                previews += thumb

                // Aquí NO hacemos OCR. Primero preparamos/medimos todas las capturas y
                // luego el pipeline completo las procesa de una en una en un orden único.
                items += ManualBatchOcrItem("", quality)
                if (!bitmap.isRecycled) bitmap.recycle()
                if (!destroyedForAsync) runOnUiThread { processAt(index + 1) }
            }
        }

        processAt(0)
    }

    private fun loadPhotosFromUris(uris: List<Uri>) {
        if (uris.size > MAX_MANUAL_BATCH_IMAGES) {
            binding.tvStatus.text = "Seleccionaste ${uris.size} imágenes. GI X acepta hasta $MAX_MANUAL_BATCH_IMAGES por lote para no saturar la memoria."
            Toast.makeText(this, "Elige máximo $MAX_MANUAL_BATCH_IMAGES imágenes.", Toast.LENGTH_LONG).show()
            return
        }
        if (uris.size == 1) {
            clearAllPreviews()
            loadPhotoFromUri(uris.first())
            return
        }
        processManualImageBatch(uris)
    }

    private fun processManualImageBatch(uris: List<Uri>) {
        if (!processing.compareAndSet(false, true)) {
            binding.tvStatus.text = "Espera: GI X todavía está procesando el trabajo anterior."
            return
        }
        stopped = false
        lastExtractedQuestions = emptyList()
        lastDisplayedOcrText = ""
        lastSourceLabel = "lote manual · ${uris.size} imágenes"
        pendingOcrDisplayOverride = null
        pendingBatchInfo = null
        pendingMissingQuestionNumbers = emptyList()
        clearAllPreviews()
        binding.tvOcr.text = "Procesando lote de ${uris.size} imágenes..."
        binding.tvAnswer.text = "Esperando OCR combinado..."
        binding.tvStatus.text = "Lote manual: preparando imagen 1 de ${uris.size}."

        val items = mutableListOf<ManualBatchOcrItem>()
        val previews = mutableListOf<Bitmap>()
        var failedImages = 0
        var heavyPasses = 0

        fun finishBatch() {
            if (stopped) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                processing.set(false)
                return
            }
            val rawTexts = items.map { it.rawText }
            if (rawTexts.none { it.isNotBlank() }) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                processing.set(false)
                binding.tvStatus.text = "Ninguna de las imágenes produjo texto OCR legible."
                binding.tvOcr.text = "Sin texto detectado."
                binding.tvAnswer.text = "Prueba con fotos más cercanas, nítidas y con mejor iluminación."
                return
            }

            batchPreviewBitmaps = previews.toList()
            previewBitmap = batchPreviewBitmaps.firstOrNull()
            previewBitmap?.let {
                binding.ivPreview.setImageBitmap(it)
                binding.tvPreviewPlaceholder.visibility = View.GONE
            }

            val merge = MultiImageDocumentMerger.merge(
                rawTexts,
                items.map { it.quality.selectionScore() }
            )
            val qualitySummary = items.mapIndexed { index, item ->
                "Imagen ${index + 1}: ${item.quality.shortLabel()} · nitidez ${item.quality.sharpness.toInt()}"
            }.joinToString("\n")
            val failedText = if (failedImages > 0) "\nImágenes sin OCR: $failedImages" else ""
            pendingMissingQuestionNumbers = merge.missingQuestionNumbers

            pendingOcrDisplayOverride = buildString {
                append(merge.combinedDisplay.ifBlank { "Documento combinado sin preguntas claras." })
                append("\n\nCALIDAD DE LAS CAPTURAS\n")
                append(qualitySummary)
                append(failedText)
            }.trim()
            pendingBatchInfo = buildString {
                append("${uris.size} imágenes como un solo documento")
                if (merge.duplicateQuestionNumbersResolved > 0) {
                    append(" · ${merge.duplicateQuestionNumbersResolved} repetición(es) resuelta(s)")
                }
                append(" · $heavyPasses OCR completo(s)")
            }

            if (merge.combinedRaw.isBlank()) {
                processing.set(false)
                binding.tvStatus.text = "El lote llegó, pero no pude reconstruir texto útil."
                binding.tvOcr.text = pendingOcrDisplayOverride.orEmpty()
                binding.tvAnswer.text = "Vuelve a tomar las zonas con más solapamiento."
                pendingOcrDisplayOverride = null
                pendingBatchInfo = null
                pendingMissingQuestionNumbers = emptyList()
                return
            }

            // handleOcrResult conserva el mismo flujo probado de validación/API/voz,
            // pero recibe UN documento ya fusionado en vez de cuatro consultas.
            handleOcrResult(merge.combinedRaw)
        }

        fun rescueAt(order: List<Int>, position: Int) {
            if (position >= order.size) {
                finishBatch()
                return
            }
            if (stopped) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                processing.set(false)
                return
            }

            // Para máxima precisión hacemos rescate fuerte sobre TODAS las imágenes
            // del lote, de forma secuencial y controlada. Es algo más lento que
            // cortar antes, pero mejora la recuperación de preguntas finales borrosas
            // y reduce casos donde una foto buena tapa una pregunta que otra sí aporta.

            val imageIndex = order[position]
            binding.tvStatus.text = "Lote manual: OCR ordenado ${position + 1}/${order.size}, imagen ${imageIndex + 1}..."
            ioExecutor.execute {
                val bitmap = runCatching { ImageLoader.load(this, uris[imageIndex]) }.getOrNull()
                if (bitmap == null) {
                    if (!destroyedForAsync) runOnUiThread { rescueAt(order, position + 1) }
                    return@execute
                }
                ocrProcessor.process(
                    bitmap,
                    onSuccess = { raw ->
                        heavyPasses++
                        if (raw.isNotBlank()) {
                            val better = chooseBetterBatchOcr(items[imageIndex].rawText, raw.trim())
                            items[imageIndex] = ManualBatchOcrItem(better, items[imageIndex].quality)
                        } else {
                            failedImages++
                        }
                        if (!bitmap.isRecycled) bitmap.recycle()
                        if (!destroyedForAsync) runOnUiThread { rescueAt(order, position + 1) }
                    },
                    onError = {
                        failedImages++
                        if (!bitmap.isRecycled) bitmap.recycle()
                        if (!destroyedForAsync) runOnUiThread { rescueAt(order, position + 1) }
                    }
                )
            }
        }

        fun startAdaptiveRescue() {
            val order = buildAdaptiveRescueOrder(items)
            if (order.isEmpty()) {
                finishBatch()
                return
            }
            rescueAt(order, 0)
        }

        fun processAt(index: Int) {
            if (index >= uris.size) {
                startAdaptiveRescue()
                return
            }
            if (stopped) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                processing.set(false)
                return
            }

            binding.tvStatus.text = "Lote manual: preparando ${index + 1} de ${uris.size} (calidad + vista previa)..."
            ioExecutor.execute {
                val bitmap = runCatching { ImageLoader.load(this, uris[index]) }.getOrNull()
                if (bitmap == null) {
                    failedImages++
                    items += ManualBatchOcrItem(
                        "",
                        OcrProcessor.ImageQualityReport(128.0, 64.0, 0.0, false, false, true)
                    )
                    if (!destroyedForAsync) runOnUiThread { processAt(index + 1) }
                    return@execute
                }

                val quality = runCatching { ocrProcessor.assessQuality(bitmap) }
                    .getOrElse { OcrProcessor.ImageQualityReport(128.0, 64.0, 100.0, false, false, false) }
                val thumb = makePreviewThumbnail(bitmap)
                previews += thumb

                // Sin OCR duplicado: el OCR completo empieza después y procesa cada
                // captura secuencialmente con OpenCV -> Paddle -> verificación ML Kit.
                items += ManualBatchOcrItem("", quality)
                if (!bitmap.isRecycled) bitmap.recycle()
                if (!destroyedForAsync) runOnUiThread { processAt(index + 1) }
            }
        }

        processAt(0)
    }

    private fun chooseBetterBatchOcr(existing: String, candidate: String): String {
        fun localScore(text: String): Int {
            if (text.isBlank()) return Int.MIN_VALUE
            val questions = runCatching { OcrQuestionExtractor.extractQuestions(text) }
                .getOrDefault(emptyList())
            val numbered = questions.mapNotNull(OcrQuestionExtractor::questionNumber).distinct().size
            val incomplete = questions.count(::looksLikeIncompleteBatchQuestion)
            val suspicious = if (questions.size >= 3 && OcrQuestionExtractor.hasSuspiciousNumbering(questions)) 1 else 0
            val table = if (text.contains(OcrTableFormatter.TABLE_START)) 1 else 0
            return numbered * 140 + questions.size * 70 + table * 90 -
                incomplete * 220 - suspicious * 320 + minOf(text.length, 3000) / 30
        }
        return if (localScore(candidate) >= localScore(existing)) candidate else existing
    }

    private fun looksLikeIncompleteBatchQuestion(raw: String): Boolean {
        val clean = raw
            .replace(Regex("""^\s*\d{1,2}\s*[\.)\-:]\s*"""), "")
            .trim()
        if (clean.length < 10) return true

        val lower = clean.lowercase(Locale.ROOT).trimEnd('.', ',', ';', ':', '-', '–', '—')
        val dangling = listOf(
            " entre", " de", " del", " la", " el", " los", " las", " y", " o",
            " con", " sin", " para", " por", " en", " según", " segun", " desde", " hasta"
        ).any { lower.endsWith(it) }
        if (dangling) return true

        val interrogative = listOf(
            "qué ", "que ", "cuál ", "cual ", "cuáles ", "cuales ", "cómo ", "como ",
            "por qué ", "por que ", "dónde ", "donde ", "cuándo ", "cuando ",
            "quién ", "quien ", "cuánto ", "cuanto "
        ).any { lower.trimStart('¿', '?', ' ').startsWith(it) }
        if (interrogative && !clean.contains('?') && clean.length < 150) return true
        return false
    }

    private fun buildAdaptiveRescueOrder(items: List<ManualBatchOcrItem>): List<Int> {
        if (items.isEmpty()) return emptyList()
        // Ya no existe una lectura OCR rápida previa. Procesamos primero la captura de
        // mejor calidad para obtener pronto una base fiable y después las complementarias.
        // No asumimos una cantidad fija de preguntas: sirve igual para 2, 6 o 30 ítems.
        return items.indices.sortedWith(
            compareByDescending<Int> { index -> items[index].quality.selectionScore() }
                .thenBy { it }
        )
    }

    private fun makePreviewThumbnail(source: Bitmap): Bitmap {
        val maxSide = maxOf(source.width, source.height).coerceAtLeast(1)
        val target = 1100
        if (maxSide <= target) return source.copy(Bitmap.Config.ARGB_8888, false)
        val scale = target.toFloat() / maxSide.toFloat()
        return Bitmap.createScaledBitmap(
            source,
            (source.width * scale).toInt().coerceAtLeast(1),
            (source.height * scale).toInt().coerceAtLeast(1),
            true,
        )
    }

    private fun clearAllPreviews() {
        binding.ivPreview.setImageDrawable(null)
        batchPreviewBitmaps.forEach { bitmap ->
            if (!bitmap.isRecycled) bitmap.recycle()
        }
        val current = previewBitmap
        if (current != null && !current.isRecycled) current.recycle()
        batchPreviewBitmaps = emptyList()
        previewBitmap = null
        binding.tvPreviewPlaceholder.visibility = View.VISIBLE
    }

    /**
     * onDestroy no debe reciclar bitmaps que un worker pueda seguir usando. Al soltar
     * solo las referencias de UI, el GC los recupera cuando el último pipeline termine.
     */
    private fun dropPreviewReferencesForDestroy() {
        if (::binding.isInitialized) binding.ivPreview.setImageDrawable(null)
        batchPreviewBitmaps = emptyList()
        previewBitmap = null
    }

    private fun loadPhotoFromUri(uri: Uri) {
        binding.tvStatus.text = "Abriendo imagen y corrigiendo orientación..."
        ioExecutor.execute {
            val bitmap = runCatching { ImageLoader.load(this, uri) }.getOrNull()
            runOnUiThread {
                if (bitmap == null) {
                    binding.tvStatus.text = "No pude abrir esa imagen. Prueba con JPG, PNG, WEBP o una foto normal."
                    return@runOnUiThread
                }
                processBitmap(bitmap, source = "imagen manual")
            }
        }
    }

    private fun processBitmap(bitmap: Bitmap, source: String) {
        if (!processing.compareAndSet(false, true)) {
            binding.tvStatus.text = "Ya estoy procesando otra foto."
            return
        }
        stopped = false
        pendingOcrDisplayOverride = null
        pendingBatchInfo = null
        pendingMissingQuestionNumbers = emptyList()
        lastExtractedQuestions = emptyList()
        lastDisplayedOcrText = ""
        lastSourceLabel = source
        clearAllPreviews()
        previewBitmap = bitmap
        binding.ivPreview.setImageBitmap(bitmap)
        binding.tvPreviewPlaceholder.visibility = View.GONE
        binding.tvStatus.text = "Imagen recibida ($source). OCR local reforzado: PP-OCRv6 + ML Kit..."
        binding.tvOcr.text = "Procesando OCR..."
        binding.tvAnswer.text = "Esperando texto..."

        ocrProcessor.process(
            bitmap,
            onSuccess = { rawText ->
                if (!destroyedForAsync) runOnUiThread { handleOcrResult(rawText) }
            },
            onError = { error ->
                if (!destroyedForAsync) runOnUiThread {
                    processing.set(false)
                    binding.tvStatus.text = "OCR falló: $error"
                    binding.tvOcr.text = "No se pudo detectar texto."
                    binding.tvAnswer.text = "Acerca la cámara, mejora la luz y vuelve a intentarlo."
                    scheduleNextAutoIfNeeded()
                }
            }
        )
    }

    private fun handleOcrResult(rawText: String) {
        if (stopped) {
            processing.set(false)
            return
        }
        val cleanRaw = rawText.trim()
        if (cleanRaw.isBlank()) {
            processing.set(false)
            binding.tvStatus.text = "OCR terminado, pero no encontró texto legible."
            binding.tvOcr.text = "Sin texto detectado."
            binding.tvAnswer.text = "Prueba con más luz, menos inclinación y enfoca mejor la pregunta."
            scheduleNextAutoIfNeeded()
            return
        }

        val questions = OcrQuestionExtractor.extractQuestions(cleanRaw)
        val documentContext = OcrQuestionExtractor.extractDocumentContext(cleanRaw)
        lastExtractedQuestions = questions

        // Muestra lo que OCR leyó de TODA la hoja, no únicamente las preguntas.
        // Esto permite verificar lecturas, tablas, datos, formularios y respuestas
        // manuscritas sin gastar API. Los marcadores internos de tablas se ocultan.
        val batchInfo = pendingBatchInfo.also { pendingBatchInfo = null }
        val batchMissing = pendingMissingQuestionNumbers.also { pendingMissingQuestionNumbers = emptyList() }
        val fullDisplayText = pendingOcrDisplayOverride
            ?.takeIf { it.isNotBlank() }
            ?.also { pendingOcrDisplayOverride = null }
            ?: OcrTableFormatter.toDisplayText(cleanRaw)
                .ifBlank { OcrQuestionExtractor.extract(cleanRaw).ifBlank { cleanRaw.take(6500) } }
        lastDisplayedOcrText = fullDisplayText
        binding.tvOcr.text = fullDisplayText
        scrollTextToTop(binding.tvOcr)

        if (questions.isEmpty()) {
            processing.set(false)
            binding.tvStatus.text = "Se leyó texto, pero no pude identificar preguntas claras."
            binding.tvAnswer.text = "Centra mejor el texto y vuelve a intentarlo."
            scheduleNextAutoIfNeeded()
            return
        }

        // En lotes manuales también detectamos si la primera zona visible empieza
        // en 2..10. El extractor normal solo ve saltos ENTRE preguntas; esta barrera
        // evita mandar 2..10 como si el documento estuviera completo sin la 1.
        if (batchMissing.isNotEmpty()) {
            processing.set(false)
            binding.tvStatus.text = buildString {
                append("Documento combinado incompleto: faltan ${batchMissing.joinToString(", ")}.")
                if (!batchInfo.isNullOrBlank()) append(" · ").append(batchInfo)
            }
            binding.tvAnswer.text = "No se usó la API. Toma otra foto de la zona faltante y vuelve a seleccionar el lote completo."
            scrollTextToTop(binding.tvAnswer)
            scheduleNextAutoIfNeeded()
            return
        }

        // Barrera de seguridad: si una hoja numerada todavía tiene saltos, duplicados
        // o números fuera de orden, no enviamos una estructura corrupta a DeepSeek.
        // Es preferible pedir otra lectura a responder 18 preguntas como si fueran 20.
        if (OcrQuestionExtractor.hasSuspiciousNumbering(questions)) {
            processing.set(false)
            binding.tvStatus.text = buildString {
                append("La numeración del examen quedó incompleta. No se envió una hoja mal reconstruida a la API.")
                if (!batchInfo.isNullOrBlank()) append(" · ").append(batchInfo)
            }
            binding.tvAnswer.text = "GI X detectó un salto en la numeración. Vuelve a procesar la misma imagen; si persiste, mejora ligeramente el encuadre o la nitidez."
            scrollTextToTop(binding.tvAnswer)
            scheduleNextAutoIfNeeded()
            return
        }

        // Permite probar SOLO el OCR sin gastar API. Antes, una prueba sin clave
        // terminaba mostrando "0 de N respondidas", aunque el OCR sí hubiera leído
        // correctamente la hoja, lo que confundía el diagnóstico.
        if (!apiSettings.hasApiKey()) {
            processing.set(false)
            binding.tvStatus.text = buildString {
                append("OCR listo: ${questions.size} pregunta(s) detectada(s). No se usó ninguna API.")
                if (!batchInfo.isNullOrBlank()) append(" · ").append(batchInfo)
            }
            binding.tvAnswer.text = "Prueba OCR completada sin gastar API. Cuando quieras respuestas, entra a API y guarda una clave."
            scrollTextToTop(binding.tvAnswer)
            scheduleNextAutoIfNeeded()
            return
        }

        val batches = buildApiBatches(questions)
        val apiStatus = if (questions.size == 1) {
            "Pregunta detectada. Consultando la API..."
        } else if (batches.size == 1) {
            "${questions.size} preguntas detectadas. Consultando la API..."
        } else {
            "${questions.size} preguntas detectadas. Se resolverán en ${batches.size} bloques seguros."
        }
        binding.tvStatus.text = if (batchInfo.isNullOrBlank()) apiStatus else "$apiStatus · $batchInfo"
        binding.tvAnswer.text = "Consultando IA..."
        ioExecutor.execute {
            val completed = mutableListOf<String>()
            val failedNumbers = mutableListOf<Int>()
            val failureDetails = mutableListOf<String>()
            var completedQuestions = 0
            var globalOffset = 0

            for ((batchIndex, batch) in batches.withIndex()) {
                if (stopped) {
                    processing.set(false)
                    return@execute
                }

                if (batches.size > 1) {
                    mainHandler.post {
                        if (!stopped) {
                            binding.tvStatus.text = "Consultando IA: bloque ${batchIndex + 1} de ${batches.size}..."
                        }
                    }
                }

                val payload = OcrQuestionExtractor.buildQueryPayload(
                    batch,
                    forceBatch = batch.size > 1,
                    documentContext = documentContext,
                )
                val answer = onlineProvider.fetchShortAnswer(payload).trim()

                if (!answer.startsWith(OnlineAnswerProvider.API_ERROR_PREFIX)) {
                    // Si las preguntas ya traen numeración impresa (11,12,...), la
                    // conservamos exactamente. Solo renumeramos lotes de preguntas
                    // realmente sin número para evitar IDs locales repetidos.
                    completed += normalizeBatchAnswerNumbers(answer, batch, globalOffset)
                    completedQuestions += batch.size
                    globalOffset += batch.size
                    continue
                }

                // Si un lote fue rechazado, quedó incompleto o alcanzó MAX_TOKENS,
                // no perdemos el examen: recuperamos ese lote pregunta por pregunta.
                // Esto también evita que un fallo de una sola pregunta borre respuestas
                // de otros bloques.
                if (batch.size > 1) {
                    for ((localIndex, question) in batch.withIndex()) {
                        if (stopped) {
                            processing.set(false)
                            return@execute
                        }
                        val globalNumber = OcrQuestionExtractor.questionNumber(question)
                            ?: (globalOffset + localIndex + 1)
                        mainHandler.post {
                            if (!stopped) {
                                binding.tvStatus.text = "Recuperando pregunta $globalNumber de ${questions.size}..."
                            }
                        }

                        val singlePayload = OcrQuestionExtractor.buildQueryPayload(
                            listOf(question),
                            forceBatch = false,
                            documentContext = documentContext,
                        )
                        val singleAnswer = onlineProvider.fetchShortAnswer(singlePayload).trim()
                        if (singleAnswer.startsWith(OnlineAnswerProvider.API_ERROR_PREFIX)) {
                            failedNumbers += globalNumber
                            failureDetails += singleAnswer
                                .removePrefix(OnlineAnswerProvider.API_ERROR_PREFIX)
                                .trim()
                                .ifBlank { "La API no devolvió una respuesta válida." }
                        } else {
                            completed += formatRecoveredSingleAnswer(globalNumber, question, singleAnswer)
                            completedQuestions += 1
                        }
                    }
                } else {
                    val globalNumber = OcrQuestionExtractor.questionNumber(batch.first())
                        ?: (globalOffset + 1)
                    failedNumbers += globalNumber
                    failureDetails += answer
                        .removePrefix(OnlineAnswerProvider.API_ERROR_PREFIX)
                        .trim()
                        .ifBlank { "La API no devolvió una respuesta válida." }
                }

                globalOffset += batch.size
            }

            runOnUiThread {
                if (stopped) {
                    processing.set(false)
                    return@runOnUiThread
                }
                val finalText = completed.joinToString("\n\n").trim()
                if (failedNumbers.isNotEmpty()) {
                    handleRecoveredApiFailure(
                        partial = finalText,
                        completed = completedQuestions,
                        total = questions.size,
                        failedNumbers = failedNumbers,
                        details = failureDetails
                    )
                } else {
                    handleAnswer(finalText)
                }
            }
        }
    }

    private fun buildApiBatches(questions: List<String>): List<List<String>> {
        if (questions.isEmpty()) return emptyList()
        val batchLimit = if (OcrQuestionExtractor.isLikelyTrueFalseQuestions(questions)) {
            TRUE_FALSE_API_BATCH_SIZE
        } else {
            STANDARD_API_BATCH_SIZE
        }

        val output = mutableListOf<List<String>>()
        val pending = mutableListOf<String>()
        fun flushPending() {
            if (pending.isNotEmpty()) {
                output += pending.toList()
                pending.clear()
            }
        }

        questions.forEach { question ->
            // Una tabla puede necesitar una respuesta por fila. La aislamos para que no
            // compita por tokens con otras preguntas del examen.
            if (question.contains(OcrTableFormatter.TABLE_START)) {
                flushPending()
                output += listOf(question)
            } else {
                pending += question
                if (pending.size >= batchLimit) flushPending()
            }
        }
        flushPending()
        return output
    }

    private fun formatRecoveredSingleAnswer(number: Int, question: String, answer: String): String {
        val clean = answer
            .replace(Regex("^\\s*(?:Pregunta\\s+)?\\d{1,2}\\s*[\\.):\\-]\\s*", RegexOption.IGNORE_CASE), "")
            .trim()
        val canonical = OnlineAnswerProvider.canonicalizeAnswerForQuestion(question, clean).trim()
        val normalizedQuestion = ResponseRepository.normalize(question)
        val rawLower = question.lowercase()
        val isTrueFalse = normalizedQuestion.contains("verdadero o falso") ||
            normalizedQuestion.contains("verdadero falso") || rawLower.contains("v/f") ||
            Regex("\\(\\s*\\)\\s*[.?!]*\\s*$").containsMatchIn(question.trim())
        val isMultipleChoice = Regex("(?i)(?:^|\\s)[A-H][\\)\\].:-]\\s+").findAll(question).count() >= 2 ||
            normalizedQuestion.contains("cual de los siguientes") ||
            normalizedQuestion.contains("cual de las siguientes") ||
            normalizedQuestion.contains("alternativa correcta") ||
            normalizedQuestion.contains("opcion correcta")
        val isCompletion = VoiceQuestionNormalizer.isCompletionExercise(question) ||
            question.contains("___") || question.contains(".....")

        return when {
            isTrueFalse -> "$number. ${canonical.removeSuffix(".")}."
            isMultipleChoice -> "$number. $canonical"
            isCompletion -> "$number. $canonical"
            '\n' in canonical -> "$number. Respuesta:\n$canonical"
            else -> "$number. Respuesta: $canonical"
        }
    }

    private fun handleRecoveredApiFailure(
        partial: String,
        completed: Int,
        total: Int,
        failedNumbers: List<Int>,
        details: List<String>
    ) {
        processing.set(false)
        val uniqueDetail = details.firstOrNull().orEmpty()
        val visible = buildString {
            if (partial.isNotBlank()) {
                append(partial.trim())
                append("\n\n")
            }
            append("Se respondieron $completed de $total preguntas.")
            if (failedNumbers.isNotEmpty()) {
                append(" Faltaron: ")
                append(failedNumbers.distinct().sorted().joinToString(", "))
                append(".")
            }
            if (uniqueDetail.isNotBlank()) {
                append("\n")
                append(uniqueDetail)
            }
        }
        binding.tvAnswer.text = visible
        scrollTextToTop(binding.tvAnswer)
        saveToHistory(visible)
        updateApiChip()
        binding.tvStatus.text = if (completed > 0) {
            "La API respondió parcialmente; GI X conservó todas las respuestas obtenidas."
        } else {
            "La API no respondió esta vez. El OCR y las preguntas se conservaron."
        }
        if (partial.isNotBlank()) {
            requestAnswerSpeech(partial)
        } else {
            scheduleNextAutoIfNeeded()
        }
    }

    private fun normalizeBatchAnswerNumbers(
        answer: String,
        batch: List<String>,
        globalOffset: Int
    ): String {
        val printedNumbers = batch.map { OcrQuestionExtractor.questionNumber(it) }
        // Si existe numeración real, el payload ya la conserva y no debemos tocarla.
        if (printedNumbers.any { it != null }) return answer.trim()

        // Preguntas sin numeración: el proveedor responde 1..N dentro de cada lote.
        // Aquí las convertimos a una secuencia global solo para que la pantalla no
        // muestre 1,2,3 otra vez en el siguiente lote.
        if (globalOffset <= 0) return answer.trim()
        val numberedLine = Regex("^(\\s*)(?:(Pregunta)\\s+)?(\\d{1,2})([\\.):])\\s*(.*)$", RegexOption.IGNORE_CASE)
        return answer.lines().joinToString("\n") { line ->
            val match = numberedLine.find(line) ?: return@joinToString line
            val prefix = match.groupValues[1]
            val questionWord = match.groupValues[2]
            val localNumber = match.groupValues[3].toIntOrNull() ?: return@joinToString line
            val separator = match.groupValues[4]
            val tail = match.groupValues[5]
            val globalNumber = localNumber + globalOffset
            if (questionWord.isNotBlank()) {
                "$prefix$questionWord $globalNumber$separator $tail".trimEnd()
            } else {
                "$prefix$globalNumber$separator $tail".trimEnd()
            }
        }.trim()
    }

    private fun handleChunkedApiFailure(partial: String, rawError: String, completed: Int, total: Int) {
        processing.set(false)
        val error = rawError.removePrefix(OnlineAnswerProvider.API_ERROR_PREFIX).trim()
        val visible = buildString {
            if (partial.isNotBlank()) {
                append(partial.trim())
                append("\n\n")
            }
            append("No se pudieron completar las preguntas restantes ($completed de $total respondidas).\n")
            append(error.ifBlank { "La API no devolvió una respuesta válida." })
        }
        binding.tvAnswer.text = visible
        scrollTextToTop(binding.tvAnswer)
        saveToHistory(visible)
        updateApiChip()
        binding.tvStatus.text = "La API no completó todos los bloques. Las respuestas ya recibidas se conservaron."
        if (partial.isNotBlank()) {
            requestAnswerSpeech(partial)
        } else {
            scheduleNextAutoIfNeeded()
        }
    }

    private fun handleAnswer(answer: String) {
        processing.set(false)
        val clean = answer.trim().ifBlank { "La API no devolvió una respuesta." }
        val displayText = when {
            lastExtractedQuestions.size == 1 && !clean.contains("Respuesta:", ignoreCase = true) -> {
                "${lastExtractedQuestions.first()}\nRespuesta: $clean"
            }
            else -> clean
        }
        val apiError = clean.startsWith(OnlineAnswerProvider.API_ERROR_PREFIX)
        val visibleText = if (apiError) clean.removePrefix(OnlineAnswerProvider.API_ERROR_PREFIX).trim() else displayText
        binding.tvAnswer.text = visibleText
        scrollTextToTop(binding.tvAnswer)
        saveToHistory(visibleText)
        updateApiChip()

        if (apiError) {
            binding.tvStatus.text = "La API no respondió correctamente. Revisa el detalle abajo."
            scheduleNextAutoIfNeeded()
            return
        }

        requestAnswerSpeech(displayText)
    }

    /**
     * Punto único de salida de voz de GI X. Toda respuesta válida (normal o recuperada)
     * pasa por aquí, para que no existan rutas que muestren texto pero olviden hablar.
     */
    private fun requestAnswerSpeech(text: String) {
        val spokenText = prepareSpokenAnswer(text)
        if (spokenText.isBlank()) {
            binding.tvStatus.text = "Respuesta lista."
            scheduleNextAutoIfNeeded()
            return
        }

        speechRetryCount = 0
        speechRecoveryInProgress = false
        activeSpeechText = spokenText
        pendingSpeechText = spokenText
        binding.tvStatus.text = if (ttsReady) {
            "Respuesta lista. Reproduciendo voz..."
        } else {
            "Respuesta lista. Preparando voz..."
        }

        if (ttsReady) {
            startPendingSpeech()
        } else if (!ttsInitializing) {
            // Si el motor ya había fallado antes de recibir esta respuesta, no dejamos
            // el texto esperando indefinidamente: iniciamos una nueva instancia ahora.
            ttsInitializing = true
            reinitializeTts()
        }
    }

    private fun prepareSpokenAnswer(text: String): String {
        val withoutInternalMarkers = text.lineSequence()
            .filterNot { line ->
                val trimmed = line.trim()
                trimmed.startsWith("[GIX_", ignoreCase = true) ||
                    trimmed.startsWith("Columnas:", ignoreCase = true) ||
                    trimmed.startsWith("Fila ", ignoreCase = true)
            }
            .joinToString("\n")
            .replace("|", ", ")
        return VoiceQuestionNormalizer.prepareForTts(withoutInternalMarkers).trim()
    }

    private fun startPendingSpeech() {
        if (!ttsReady || stopped) return
        val text = pendingSpeechText?.trim().orEmpty()
        if (text.isBlank()) return

        val engine = tts ?: run {
            handleSpeechFailure()
            return
        }
        val chunks = splitForTts(text)
        if (chunks.isEmpty()) {
            pendingSpeechText = null
            activeSpeechText = null
            binding.tvStatus.text = "Respuesta lista."
            scheduleNextAutoIfNeeded()
            return
        }

        engine.stop()
        engine.setSpeechRate(prefs.speechRate)
        speechSessionId += 1
        val session = speechSessionId
        activeSpeechText = text
        pendingSpeechText = null
        isSpeakingAnswer = true
        activeSpeechFinalId = "${UTTERANCE_ANSWER}_${session}_${chunks.lastIndex}"
        binding.tvStatus.text = "Respuesta lista. Reproduciendo voz..."

        for ((index, chunk) in chunks.withIndex()) {
            val utteranceId = "${UTTERANCE_ANSWER}_${session}_${index}"
            val queueMode = if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            val result = engine.speak(chunk, queueMode, null, utteranceId)
            if (result == TextToSpeech.ERROR) {
                handleSpeechFailure()
                return
            }
        }
    }

    private fun splitForTts(text: String): List<String> {
        val platformMax = runCatching { TextToSpeech.getMaxSpeechInputLength() }.getOrDefault(4000)
        // Dejamos margen respecto al máximo del motor. 3000 también evita problemas
        // de motores que anuncian un límite mayor pero fallan con textos muy largos.
        val maxChars = minOf((platformMax - 200).coerceAtLeast(500), 3000)
        val pieces = text
            .replace("\r", "")
            .split(Regex("(?<=[.!?])\\s+|\\n+"))
            .map { it.trim() }
            .filter { it.isNotBlank() }

        val result = mutableListOf<String>()
        var current = StringBuilder()

        fun flush() {
            val value = current.toString().trim()
            if (value.isNotBlank()) result += value
            current = StringBuilder()
        }

        fun addLongPiece(piece: String) {
            val words = piece.split(Regex("\\s+")).filter { it.isNotBlank() }
            for (word in words) {
                if (word.length > maxChars) {
                    flush()
                    word.chunked(maxChars).forEach { result += it }
                    continue
                }
                val extra = if (current.isEmpty()) word.length else word.length + 1
                if (current.length + extra > maxChars) flush()
                if (current.isNotEmpty()) current.append(' ')
                current.append(word)
            }
        }

        for (piece in pieces) {
            if (piece.length > maxChars) {
                flush()
                addLongPiece(piece)
                flush()
                continue
            }
            val extra = if (current.isEmpty()) piece.length else piece.length + 1
            if (current.length + extra > maxChars) flush()
            if (current.isNotEmpty()) current.append(' ')
            current.append(piece)
        }
        flush()
        return result
    }

    override fun onInit(status: Int) {
        ttsInitializing = false
        speechRecoveryInProgress = false
        if (status != TextToSpeech.SUCCESS) {
            ttsReady = false
            if (!pendingSpeechText.isNullOrBlank() && speechRetryCount < MAX_TTS_RETRIES) {
                speechRetryCount += 1
                binding.tvStatus.text = "Respuesta lista. Reintentando el motor de voz..."
                mainHandler.postDelayed({ reinitializeTts() }, TTS_RETRY_DELAY_MS)
            } else if (!pendingSpeechText.isNullOrBlank()) {
                pendingSpeechText = null
                activeSpeechText = null
                binding.tvStatus.text = "Respuesta lista. No se pudo iniciar la voz esta vez."
                scheduleNextAutoIfNeeded()
            }
            return
        }
        val engine = tts ?: return
        val result = engine.setLanguage(Locale("es", "PE"))
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.language = Locale("es", "ES")
        }
        engine.setSpeechRate(prefs.speechRate)
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit

            override fun onDone(utteranceId: String?) {
                if (utteranceId == activeSpeechFinalId) {
                    runOnUiThread {
                        isSpeakingAnswer = false
                        activeSpeechFinalId = null
                        activeSpeechText = null
                        pendingSpeechText = null
                        speechRetryCount = 0
                        binding.tvStatus.text = if (autoMode) {
                            "Respuesta terminada. Preparando la siguiente foto..."
                        } else {
                            "Listo. Puedes pedir otra foto o elegir otra imagen."
                        }
                        scheduleNextAutoIfNeeded()
                    }
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                runOnUiThread { handleSpeechFailure() }
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                runOnUiThread { handleSpeechFailure() }
            }
        })
        ttsReady = true
        if (!pendingSpeechText.isNullOrBlank()) startPendingSpeech()
    }

    private fun handleSpeechFailure() {
        if (stopped || speechRecoveryInProgress) return
        val text = activeSpeechText ?: pendingSpeechText
        isSpeakingAnswer = false
        activeSpeechFinalId = null

        if (text.isNullOrBlank()) {
            scheduleNextAutoIfNeeded()
            return
        }

        if (speechRetryCount < MAX_TTS_RETRIES) {
            speechRetryCount += 1
            speechRecoveryInProgress = true
            pendingSpeechText = text
            activeSpeechText = text
            binding.tvStatus.text = "La respuesta está lista. Reiniciando voz..."
            reinitializeTts()
        } else {
            pendingSpeechText = null
            activeSpeechText = null
            binding.tvStatus.text = "Respuesta lista. La voz falló esta vez; el texto quedó guardado."
            scheduleNextAutoIfNeeded()
        }
    }

    private fun reinitializeTts() {
        runCatching { tts?.stop() }
        runCatching { tts?.shutdown() }
        ttsReady = false
        ttsInitializing = true
        tts = TextToSpeech(this, this)
    }

    private fun processNextQueuedCameraBatchIfReady(): Boolean {
        if (stopped || processing.get() || isSpeakingAnswer || !pendingSpeechText.isNullOrBlank()) return false
        while (pendingCameraBatches.isNotEmpty()) {
            val next = pendingCameraBatches.pollFirst() ?: return false
            processCameraBatch(next)
            return true
        }
        return false
    }

    private fun scheduleNextAutoIfNeeded() {
        if (processNextQueuedCameraBatchIfReady()) return
        if (!autoMode || stopped || inputMode != InputMode.CAMERA) return
        if (isSpeakingAnswer || !pendingSpeechText.isNullOrBlank()) return
        mainHandler.postDelayed({
            if (autoMode && !stopped && !processing.get() && activeCaptureRequestId == null &&
                !isSpeakingAnswer && pendingSpeechText.isNullOrBlank()) {
                requestCameraCapture(manual = false)
            }
        }, AUTO_NEXT_DELAY_MS)
    }

    private fun updateCameraChip() {
        binding.tvCameraChip.text = if (cameraServer.isCameraConnected()) {
            "Cámara: conectada"
        } else {
            "Cámara: esperando"
        }
    }

    private fun updateApiChip() {
        val config = apiSettings.getApiConfigs()
            .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }

        if (config == null) {
            binding.tvApiChip.text = "API: sin configurar"
            binding.tvApiDetail.text = "DeepSeek · SIN CONFIGURAR"
            return
        }

        val status = apiSettings.getStatus(config)
        val message = apiSettings.getMessage(config).trim()
        binding.tvApiChip.text = "API: DeepSeek"
        binding.tvApiDetail.text = when (status) {
            "ready" -> "DeepSeek · ACTIVA ✓ · CLAVE GUARDADA · ${config.model}"
            "error" -> "DeepSeek · GUARDADA · ERROR: ${message.ifBlank { "revisa clave, saldo o modelo" }}"
            "limit" -> "DeepSeek · GUARDADA · SIN CRÉDITOS / LÍMITE: ${message.ifBlank { "revisa tu cuenta" }}"
            else -> if (message.isBlank() || message.startsWith("Sin probar", ignoreCase = true)) {
                "DeepSeek · GUARDADA · SIN PROBAR · ${config.model}"
            } else {
                "DeepSeek · GUARDADA · ÚLTIMO ESTADO: $message"
            }
        }
    }

    private fun showVoiceDialog() {
        val labels = arrayOf("0.25x", "0.50x", "0.75x", "1.00x", "1.25x", "1.50x", "1.75x", "2.00x")
        val values = floatArrayOf(0.25f, 0.50f, 0.75f, 1.00f, 1.25f, 1.50f, 1.75f, 2.00f)
        val current = values.indices.minByOrNull { abs(values[it] - prefs.speechRate) } ?: 3
        AlertDialog.Builder(this)
            .setTitle("Velocidad de voz")
            .setSingleChoiceItems(labels, current) { dialog, which ->
                prefs.speechRate = values[which]
                tts?.setSpeechRate(values[which])
                Toast.makeText(this, "Voz ${labels[which]}", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showCameraDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(4))
        }
        val info = TextView(this).apply {
            text = "TimerCamera-X U082-X: al encenderse se conecta a la Zona Wi-Fi configurada y envía sus fotos a GI X por el puerto ${CameraBridgeServer.DEFAULT_PORT}. La app ya está preparada para recibir una captura suelta o agrupar automáticamente hasta 4 imágenes del mismo documento. Si dejas la clave por defecto GIX2026CAM, el enlace queda listo."
            textSize = 14f
        }
        val tokenInput = EditText(this).apply {
            hint = "Clave de enlace"
            setText(prefs.pairingToken)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            maxLines = 1
        }
        val note = TextView(this).apply {
            text = "Firmware incluido: camera_firmware/TimerCameraX_GIX.ino. Recomendado: deja fija la clave GIX2026CAM y cambia solo nombre Wi-Fi y contraseña Wi-Fi. Si cambias la clave, debe coincidir exactamente con la app."
            textSize = 12f
        }
        box.addView(info)
        box.addView(tokenInput, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) })
        box.addView(note, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        val dialog = AlertDialog.Builder(this)
            .setTitle("Enlace con Timer Camera X")
            .setView(box)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                prefs.pairingToken = tokenInput.text?.toString().orEmpty()
                tokenInput.setText(prefs.pairingToken)
                binding.tvStatus.text = "Clave de cámara guardada. Debe coincidir con el firmware."
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun normalizeCheaperKey(raw: String): String {
        val cleaned = raw
            .trim()
            .removePrefix("Bearer ")
            .removePrefix("bearer ")
            .trim('\"', '\'')
            .replace("​", "")
            .replace("‌", "")
            .replace("‍", "")
            .replace("⁠", "")
            .replace("﻿", "")
            .replace(Regex("[\r\n\t ]+"), "")

        val embedded = Regex("(ir_live_[A-Za-z0-9._-]+|ci_live_[A-Za-z0-9._-]+)", RegexOption.IGNORE_CASE)
            .find(cleaned)
            ?.value
        return embedded ?: cleaned
    }

    private fun showApiDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }

        val title = TextView(this).apply {
            text = "CHEAPER INFERENCE · DEEPSEEK"
            textStyleBold()
            textSize = 15f
        }
        val info = TextView(this).apply {
            text = "GI X usará únicamente esta API de pago con DeepSeek V4 Flash. La clave queda guardada en el celular. Los fallos temporales no la bloquean y la app muestra el motivo real si no responde."
            textSize = 12f
            setPadding(0, dp(4), 0, dp(8))
        }

        val saved = apiSettings.getApiConfigs()
            .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }
        val keyInput = EditText(this).apply {
            hint = if (saved == null) "Clave Cheaper Inference (ir_live_… / ci_live_…)" else "Clave guardada. Pega otra solo para reemplazarla"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            maxLines = 1
        }
        val modelInput = EditText(this).apply {
            hint = "Modelo fijo"
            setText(NetProvider.CHEAPER_INFERENCE.defaultModel)
            isEnabled = false
            maxLines = 1
        }
        val statusText = TextView(this).apply {
            textSize = 12f
            setPadding(0, dp(8), 0, dp(6))
        }
        val saveTest = Button(this).apply { text = "GUARDAR Y PROBAR DEEPSEEK" }
        val testSaved = Button(this).apply { text = "PROBAR API GUARDADA" }
        val delete = Button(this).apply { text = "BORRAR API GUARDADA" }
        val close = Button(this).apply { text = "CERRAR" }

        fun refresh(message: String? = null) {
            val config = apiSettings.getApiConfigs()
                .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }
            val storedStatus = if (config == null) {
                "DeepSeek: SIN CONFIGURAR"
            } else {
                val state = apiSettings.getStatus(config)
                val detail = apiSettings.getMessage(config).trim()
                when (state) {
                    "ready" -> "DeepSeek: ACTIVA ✓ · ${config.model} · clave guardada"
                    "error" -> "DeepSeek: GUARDADA · ERROR · ${detail.ifBlank { "revisa clave, saldo o modelo" }}"
                    "limit" -> "DeepSeek: GUARDADA · SIN CRÉDITOS / LÍMITE · ${detail.ifBlank { "revisa tu cuenta" }}"
                    else -> if (detail.isBlank() || detail.startsWith("Sin probar", ignoreCase = true)) {
                        "DeepSeek: GUARDADA · SIN PROBAR · ${config.model}"
                    } else {
                        "DeepSeek: GUARDADA · ${detail}"
                    }
                }
            }
            statusText.text = listOfNotNull(message?.takeIf { it.isNotBlank() }, storedStatus).joinToString("\n")
            updateApiChip()
        }

        box.addView(title)
        box.addView(info)
        box.addView(keyInput, LinearLayout.LayoutParams(-1, dp(54)))
        box.addView(modelInput, LinearLayout.LayoutParams(-1, dp(54)))
        box.addView(saveTest, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(6) })
        box.addView(testSaved, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4) })
        box.addView(statusText, LinearLayout.LayoutParams(-1, -2))
        box.addView(delete, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4) })
        box.addView(close, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4) })

        val dialog = AlertDialog.Builder(this)
            .setTitle("API de GI X")
            .setView(box)
            .create()

        saveTest.setOnClickListener {
            val typed = normalizeCheaperKey(keyInput.text?.toString().orEmpty())
            val current = apiSettings.getApiConfigs()
                .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }
            val key = typed.ifBlank { normalizeCheaperKey(current?.apiKey.orEmpty()) }
            if (key.isBlank()) {
                keyInput.error = "Pega tu clave ir_live_… o ci_live_…"
                return@setOnClickListener
            }
            val model = modelInput.text?.toString().orEmpty().trim()
                .ifBlank { NetProvider.CHEAPER_INFERENCE.defaultModel }
            val config = NetApiConfig(
                name = "DeepSeek Pago",
                provider = NetProvider.CHEAPER_INFERENCE,
                apiKey = key,
                model = model
            ).clean(0)

            // Esta versión usa una sola API: al guardar, elimina configuraciones de respaldo.
            apiSettings.saveApiConfigs(listOf(config))
            saveTest.isEnabled = false
            testSaved.isEnabled = false
            statusText.text = "DeepSeek: GUARDADA · probando conexión…"
            ioExecutor.execute {
                val result = onlineProvider.testApiConfig(config)
                runOnUiThread {
                    saveTest.isEnabled = true
                    testSaved.isEnabled = true
                    if (result.first) keyInput.text?.clear()
                    refresh(result.second)
                }
            }
        }

        testSaved.setOnClickListener {
            val config = apiSettings.getApiConfigs()
                .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }
            if (config == null) {
                refresh("No hay una API guardada todavía.")
                return@setOnClickListener
            }
            testSaved.isEnabled = false
            statusText.text = "DeepSeek: probando API guardada…"
            ioExecutor.execute {
                val result = onlineProvider.testApiConfig(config)
                runOnUiThread {
                    testSaved.isEnabled = true
                    refresh(result.second)
                }
            }
        }

        delete.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Borrar API")
                .setMessage("¿Quieres borrar la clave DeepSeek guardada en este celular?")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Borrar") { _, _ ->
                    apiSettings.saveApiConfigs(emptyList())
                    refresh("API borrada.")
                }
                .show()
        }

        close.setOnClickListener { dialog.dismiss() }
        dialog.setOnDismissListener { updateApiChip() }
        refresh()
        dialog.show()
    }

    private fun setupInternalScroll(scroll: ScrollView) {
        scroll.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> view.parent?.requestDisallowInterceptTouchEvent(true)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.parent?.requestDisallowInterceptTouchEvent(false)
            }
            false
        }
    }

    private fun showPreviewDialog() {
        val images = if (batchPreviewBitmaps.isNotEmpty()) {
            batchPreviewBitmaps.filter { !it.isRecycled }
        } else {
            listOfNotNull(previewBitmap).filter { !it.isRecycled }
        }
        if (images.isEmpty()) {
            Toast.makeText(this, "Todavía no hay imagen para abrir.", Toast.LENGTH_SHORT).show()
            return
        }

        var currentIndex = 0
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF050A12.toInt())
        }
        val hint = TextView(this).apply {
            setTextColor(0xFFE8EEF9.toInt())
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val imageView = ZoomableImageView(this).apply {
            setImageBitmap(images[currentIndex])
            setBackgroundColor(0xFF050A12.toInt())
        }

        fun refreshHint() {
            hint.text = if (images.size > 1) {
                "Imagen ${currentIndex + 1} de ${images.size} · zoom con dos dedos · doble toque · arrastra"
            } else {
                "Pellizca para hacer zoom · doble toque para acercar · arrastra para mover"
            }
        }
        refreshHint()

        val navigation = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(6), dp(10), 0)
            visibility = if (images.size > 1) View.VISIBLE else View.GONE
        }
        val previous = Button(this).apply { text = "← ANTERIOR" }
        val next = Button(this).apply { text = "SIGUIENTE →" }
        navigation.addView(previous, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(5) })
        navigation.addView(next, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(5) })

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(8), dp(10), dp(12))
        }
        val rotate = Button(this).apply { text = "ROTAR" }
        val reset = Button(this).apply { text = "RESTABLECER" }
        val close = Button(this).apply { text = "CERRAR" }
        controls.addView(rotate, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(4) })
        controls.addView(reset, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
            marginStart = dp(4); marginEnd = dp(4)
        })
        controls.addView(close, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(4) })

        root.addView(hint, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(imageView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(navigation, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(controls, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val dialog = android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dialog.setContentView(root)

        fun showIndex(newIndex: Int) {
            currentIndex = (newIndex + images.size) % images.size
            imageView.setImageBitmap(images[currentIndex])
            imageView.resetView()
            refreshHint()
        }
        previous.setOnClickListener { showIndex(currentIndex - 1) }
        next.setOnClickListener { showIndex(currentIndex + 1) }
        rotate.setOnClickListener { imageView.rotateClockwise() }
        reset.setOnClickListener { imageView.resetView() }
        close.setOnClickListener { dialog.dismiss() }
        dialog.setOnShowListener {
            dialog.window?.apply {
                setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                setBackgroundDrawableResource(android.R.color.black)
                addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                statusBarColor = 0xFF050A12.toInt()
                navigationBarColor = 0xFF050A12.toInt()
            }
        }
        dialog.show()
    }

    private fun saveToHistory(answerText: String) {
        if (lastDisplayedOcrText.isBlank() || answerText.isBlank()) return
        val entry = HistoryEntry(
            id = System.currentTimeMillis().toString(),
            timestamp = System.currentTimeMillis(),
            source = lastSourceLabel,
            questionCount = lastExtractedQuestions.size.coerceAtLeast(1),
            ocrText = lastDisplayedOcrText,
            answerText = answerText
        )
        historyRepository.add(entry)
        renderHistory()
    }

    private fun renderHistory() {
        val items = historyRepository.getAll()
        binding.historyContainer.removeAllViews()
        binding.tvHistoryEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        items.forEach { entry ->
            binding.historyContainer.addView(createHistoryCard(entry))
        }
    }

    private fun createHistoryCard(entry: HistoryEntry): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = getDrawable(R.drawable.card_bg)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(8)
        }
        card.layoutParams = params

        val title = TextView(this).apply {
            text = "${formatHistoryDate(entry.timestamp)} · ${entry.source} · ${entry.questionCount} pregunta(s)"
            textSize = 13f
            textStyleBold()
        }
        val preview = TextView(this).apply {
            text = entry.ocrText.replace("\n", " ").take(120).ifBlank { "Sin texto OCR" }
            textSize = 12f
            setPadding(0, dp(4), 0, dp(2))
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
        }
        val open = Button(this).apply { text = "ABRIR" }
        val delete = Button(this).apply { text = "BORRAR" }
        row.addView(open, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(4) })
        row.addView(delete, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(4) })

        open.setOnClickListener { showHistoryEntryDialog(entry) }
        delete.setOnClickListener {
            historyRepository.delete(entry.id)
            renderHistory()
            Toast.makeText(this, "Registro borrado.", Toast.LENGTH_SHORT).show()
        }

        card.addView(title)
        card.addView(preview)
        card.addView(row)
        return card
    }

    private fun showHistoryEntryDialog(entry: HistoryEntry) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(8))
        }
        root.addView(TextView(this).apply {
            text = "${formatHistoryDate(entry.timestamp)} · ${entry.source} · ${entry.questionCount} pregunta(s)"
            textSize = 13f
            textStyleBold()
        })
        root.addView(TextView(this).apply {
            text = "Texto detectado por OCR"
            textSize = 13f
            textStyleBold()
            setPadding(0, dp(10), 0, dp(4))
        })
        val ocrScroll = ScrollView(this)
        ocrScroll.addView(TextView(this).apply {
            text = entry.ocrText
            textSize = 14f
            setTextIsSelectable(true)
            setPadding(dp(10), dp(10), dp(10), dp(10))
        })
        root.addView(ocrScroll, LinearLayout.LayoutParams(-1, dp(180)))

        root.addView(TextView(this).apply {
            text = "Respuestas"
            textSize = 13f
            textStyleBold()
            setPadding(0, dp(10), 0, dp(4))
        })
        val answerScroll = ScrollView(this)
        answerScroll.addView(TextView(this).apply {
            text = entry.answerText
            textSize = 14f
            setTextIsSelectable(true)
            setPadding(dp(10), dp(10), dp(10), dp(10))
        })
        root.addView(answerScroll, LinearLayout.LayoutParams(-1, dp(240)))

        AlertDialog.Builder(this)
            .setTitle("Historial GI X")
            .setView(root)
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun confirmClearHistory() {
        if (historyRepository.getAll().isEmpty()) {
            Toast.makeText(this, "No hay historial para borrar.", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Borrar historial")
            .setMessage("¿Quieres borrar todo el historial guardado de preguntas y respuestas?")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Borrar") { _, _ ->
                historyRepository.clear()
                renderHistory()
                Toast.makeText(this, "Historial borrado.", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun formatHistoryDate(time: Long): String {
        return try {
            SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("es", "PE")).format(Date(time))
        } catch (_: Exception) {
            Date(time).toString()
        }
    }

    private fun TextView.textStyleBold() {
        setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun scrollTextToTop(view: TextView) {
        view.post {
            view.scrollTo(0, 0)
            (view.parent as? ScrollView)?.scrollTo(0, 0)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        destroyedForAsync = true
        stopped = true
        cameraStatusTicker?.let { mainHandler.removeCallbacks(it) }
        mainHandler.removeCallbacksAndMessages(null)
        onlineProvider.cancelActiveRequest()
        cameraServer.stop()
        pendingCameraBatches.clear()
        cameraBatchCollector.clear()
        cameraBatchFinalizeRunnable?.let { mainHandler.removeCallbacks(it) }
        cameraBatchFinalizeRunnable = null
        ocrProcessor.close()
        pendingSpeechText = null
        activeSpeechText = null
        activeSpeechFinalId = null
        isSpeakingAnswer = false
        tts?.stop()
        tts?.shutdown()
        ioExecutor.shutdownNow()
        cameraIoExecutor.shutdownNow()
        galleryExecutor.shutdownNow()
        dropPreviewReferencesForDestroy()
        super.onDestroy()
    }

    private enum class InputMode {
        CAMERA,
        IMAGE
    }

    companion object {
        // Un documento combinado de hasta 10 preguntas se intenta primero en UNA sola
        // llamada. Si el proveedor falla o corta la respuesta, el mecanismo existente
        // recupera solo las preguntas necesarias de forma segura.
        private const val STANDARD_API_BATCH_SIZE = 10
        private const val MAX_PENDING_CAMERA_BATCHES = 3
        private const val MAX_PENDING_CAMERA_BYTES = 24L * 1024L * 1024L
        private const val TRUE_FALSE_API_BATCH_SIZE = 15
        private const val MAX_MANUAL_BATCH_IMAGES = 4
        private const val MAX_CAMERA_BATCH_IMAGES = 4
        private const val CAMERA_BATCH_IDLE_MS = 1200L
        private const val UTTERANCE_ANSWER = "gix_answer"
        private const val MAX_TTS_RETRIES = 1
        private const val TTS_RETRY_DELAY_MS = 700L
        private const val AUTO_NEXT_DELAY_MS = 3_500L
    }
}
