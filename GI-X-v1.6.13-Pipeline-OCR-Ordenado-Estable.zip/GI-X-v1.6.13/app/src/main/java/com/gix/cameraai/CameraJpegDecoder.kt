package com.gix.cameraai

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayInputStream
import kotlin.math.max

/**
 * Decodificador defensivo para fotos recibidas por Wi-Fi.
 *
 * Evita abrir de golpe un JPEG comprimido como un bitmap gigante. Primero lee solo
 * dimensiones, calcula un inSampleSize seguro y aplica EXIF si la cámara lo incluye.
 */
object CameraJpegDecoder {
    data class ImageInfo(val width: Int, val height: Int) {
        val pixelCount: Long get() = width.toLong() * height.toLong()
    }

    private const val MAX_SOURCE_SIDE = 12_000
    private const val MAX_DECODE_SIDE = 3_200
    private const val MAX_DECODE_PIXELS = 7_000_000L

    fun inspect(jpeg: ByteArray): ImageInfo? {
        if (jpeg.size < 4) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        runCatching { BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size, bounds) }.getOrNull()
        val width = bounds.outWidth
        val height = bounds.outHeight
        if (width <= 0 || height <= 0) return null
        if (width > MAX_SOURCE_SIDE || height > MAX_SOURCE_SIDE) return null
        return ImageInfo(width, height)
    }

    fun decodeForOcr(jpeg: ByteArray): Bitmap? {
        val info = inspect(jpeg) ?: return null
        val options = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
            inSampleSize = calculateSampleSize(info)
        }
        val decoded = runCatching {
            BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size, options)
        }.getOrNull() ?: return null

        val orientation = runCatching {
            ByteArrayInputStream(jpeg).use { stream ->
                ExifInterface(stream).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL,
                )
            }
        }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)

        return applyExifOrientation(decoded, orientation)
    }

    private fun calculateSampleSize(info: ImageInfo): Int {
        var sample = 1
        while (true) {
            val width = (info.width / sample).coerceAtLeast(1)
            val height = (info.height / sample).coerceAtLeast(1)
            val longSide = max(width, height)
            val pixels = width.toLong() * height.toLong()
            if (longSide <= MAX_DECODE_SIDE && pixels <= MAX_DECODE_PIXELS) return sample
            if (sample >= 16) return sample
            sample *= 2
        }
    }

    private fun applyExifOrientation(source: Bitmap, orientation: Int): Bitmap {
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.setScale(-1f, 1f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.setRotate(180f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> {
                matrix.setRotate(180f)
                matrix.postScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_TRANSPOSE -> {
                matrix.setRotate(90f)
                matrix.postScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.setRotate(90f)
            ExifInterface.ORIENTATION_TRANSVERSE -> {
                matrix.setRotate(-90f)
                matrix.postScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.setRotate(-90f)
            else -> return source
        }

        return runCatching {
            Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true).also { rotated ->
                if (rotated !== source && !source.isRecycled) source.recycle()
            }
        }.getOrElse { source }
    }
}
