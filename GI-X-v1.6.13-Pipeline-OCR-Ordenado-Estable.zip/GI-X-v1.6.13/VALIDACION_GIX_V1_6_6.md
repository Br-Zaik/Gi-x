# Validación GI X v1.6.6

- Base: GI-X v1.6.5
- versionCode: 31
- versionName: 1.6.6

## Cambios aplicados
- Limpieza del OCR combinado de lotes de hasta 4 imágenes.
- Selección de la secuencia principal de preguntas para ignorar residuos de tabla y números atípicos.
- Filtro para descartar líneas tipo `41. A-4`, `58. A-2`, `64. A-1` cuando parecen provenir de tablas/datos.
- Penalización de preguntas fusionadas con múltiples consignas.
- Recorte de texto residual tras el primer `?` cuando la cola ya no parece parte de la misma pregunta.

## Objetivo
- Que pruebas como la hoja de monitoreo ambiental ya no sean bloqueadas solo por la tabla, y que el cuadro OCR muestre una salida más limpia antes de usar la API.
