# VALIDACIÓN GI-X v1.6.1

- versionCode 26 / versionName 1.6.1 / minSdk 26.
- Corrección específica del error GitHub Actions: `Could not resolve project :ppocr-sdk`.
- `settings.gradle` contiene solo `:app`; no existe dependencia Gradle a `:ppocr-sdk`.
- PaddleOCR v3.7.0 se integra como código fuente dentro de `app` durante GitHub Actions.
- ONNX Runtime se declara directamente en `app/build.gradle`.
- Modelos PP-OCRv6 Small se descargan a `app/src/main/assets/models` antes de compilar.
- Se verifica la existencia de código/modelos antes de ejecutar Gradle.
- Se mantiene ML Kit + OpenCV + PP-OCRv6 Small.
- Se mantiene guardado automático de fotos de cámara en Galería/Pictures/GI-X.
- Se mantiene deduplicación SHA-256 para reintentos de la cámara.
- Firmware TimerCamera-X sin cambios.
