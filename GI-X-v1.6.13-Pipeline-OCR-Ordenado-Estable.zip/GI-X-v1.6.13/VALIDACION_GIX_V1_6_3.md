# VALIDACIÓN GI-X v1.6.3

- versionCode 28 / versionName 1.6.3 / minSdk 26.
- Mantiene package/namespace `com.gix.cameraai`.
- Mantiene PP-OCRv6 Small + ML Kit + OpenCV; no se eliminó ningún motor existente.
- OCR muestra documento completo y conserva contexto (lecturas/datos/tablas) para responder preguntas.
- Modo prueba OCR sin API: permite verificar lectura y número de preguntas sin gastar créditos.
- Rescate local adicional para manuscrito, lápiz, sombras y baja confianza.
- Detección de tablas ampliada para datos técnicos, cuadros y formularios con celdas vacías.
- Visor de imagen tipo galería: zoom con dos dedos, doble toque, arrastre, rotación y reset.
- Sin cambios al protocolo TimerCamera-X, puerto 8765 ni token GIX2026CAM.
