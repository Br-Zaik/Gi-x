# Validación GI X v1.6.13

- versionCode: 38
- versionName: 1.6.13
- applicationId/namespace: com.gix.cameraai (sin cambios)

Cambios implementados:
- preprocesado y mejorador de imagen antes del OCR;
- PP-OCRv6 Small como OCR principal;
- ML Kit como verificador/fallback adaptativo;
- eliminación de OCR rápido duplicado en lotes;
- procesamiento secuencial de 1–4 imágenes;
- límites de pasadas y timeouts;
- recorte conservador de hoja;
- consenso multiimagen con alineación de palabras;
- corrector técnico más conservador;
- filtros de ruido externo (Core i5/Intel/Logi y fragmentos mínimos típicos);
- cierre seguro de motores y bitmaps durante onDestroy.

Pruebas estáticas realizadas:
- compilación Kotlin aislada de OcrQuestionExtractor + MultiImageDocumentMerger con stubs: OK;
- prueba de consenso: 1 captura conserva "geogiticas"; 3 capturas con evidencia correcta producen "geográficas": OK;
- no se detectaron errores de sintaxis en OcrProcessor, OpenCvDocumentPreprocessor ni MainActivity mediante kotlinc (las dependencias Android no están disponibles localmente).
- la compilación APK final debe ejecutarse en GitHub Actions/Android SDK del proyecto.
