# Validación GI X v1.6.7

- Base: GI-X v1.6.6
- versionCode: 32
- versionName: 1.6.7

## Objetivo
Reducir el tiempo de procesamiento de lotes de 4 imágenes sin perder el rescate de OCR fuerte.

## Implementación
- Nueva ruta `OcrProcessor.processFast`: una sola lectura ML Kit y reducción moderada de resolución.
- Los 4 fotogramas se escanean primero de forma rápida.
- Se calcula prioridad por preguntas detectadas, preguntas incompletas, tabla, calidad y cantidad de contenido.
- PP-OCRv6 + OpenCV se ejecuta primero solo en la captura de mayor utilidad.
- Si el documento sigue con huecos, numeración sospechosa, pregunta cortada o falta una tabla requerida, se rescata la siguiente captura.
- Se detiene el OCR pesado tan pronto como el documento combinado queda suficientemente completo.
- Si hace falta, puede terminar usando OCR fuerte en las 4, por lo que la precisión no se sacrifica para forzar velocidad.
- Al comparar una lectura rápida con una fuerte, GI X conserva la que tenga mejor estructura en vez de reemplazar ciegamente una lectura buena por una peor.

## Compatibilidad
- Modo MANUAL: 1 a 4 imágenes.
- Modo CÁMARA: lote automático de hasta 4 imágenes ya preparado en la app.
- Firmware de cámara no modificado en esta versión.
