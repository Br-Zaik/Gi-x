GI-X v1.5.4
- versionCode 24 / versionName 1.5.4.
- Se mantuvo la lógica de respuestas de v1.5.3.
- Se preparó la app para uso más simple con TimerCamera-X: textos y guía orientados a flujo sin pulsar PEDIR FOTO.
- Se dejó la clave por defecto GIX2026CAM como referencia fija entre app y firmware.
- Se añadió guia CONFIGURAR_EN_CIBER_PASO_A_PASO.txt.
- El firmware sigue siendo: un encendido = una foto útil = envío = apagado.
