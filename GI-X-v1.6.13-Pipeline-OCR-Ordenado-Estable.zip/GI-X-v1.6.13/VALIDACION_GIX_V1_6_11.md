GI-X v1.6.11

Mejoras principales:
- fusión OCR por consenso entre varias capturas del mismo documento;
- corrección conservadora de palabras técnicas frecuentes (topografía, minería, coordenadas geográficas, etc.);
- mantenimiento de package/applicationId: com.gix.cameraai;
- versionCode 36 / versionName 1.6.11.
