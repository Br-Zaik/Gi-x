# COMPILAR GI-X v1.6.3 EN GITHUB

Esta versión está preparada para el workflow público actual del repositorio `Br-Zaik/Gi-x`.

Ese workflow descomprime el ZIP y ejecuta directamente:

```bash
gradle --no-daemon :app:assembleDebug
```

Por eso **no hace falta editar el workflow** para añadir un paso de PaddleOCR.
`app/build.gradle` registra la tarea `preparePpocr` y hace que `preBuild` dependa de ella.
Antes de compilar, Gradle ejecuta automáticamente:

```bash
bash scripts/prepare_ppocrv6.sh
```

Ese script descarga el SDK Android oficial de PaddleOCR v3.7.0 y los modelos PP-OCRv6 Small,
los coloca dentro del módulo `app` y luego continúa la compilación normal.

## Qué hacer

1. Sube este ZIP nuevo al repositorio igual que las versiones anteriores.
2. Espera a que empiece el workflow `Compilar GI X APK desde ZIP`.
3. En el log de `Compilar APK` debe aparecer primero texto con prefijo `[GI-X]` indicando la preparación de PP-OCRv6.
4. Si falla, conserva el log completo del primer error real.

No hace falta tocar el firmware de la TimerCamera-X.
