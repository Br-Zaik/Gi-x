package com.gix.cameraai

import android.content.Context

class AppPrefs(context: Context) {
    private val prefs = context.getSharedPreferences("gix_settings", Context.MODE_PRIVATE)

    var pairingToken: String
        get() = prefs.getString(KEY_TOKEN, DEFAULT_TOKEN).orEmpty().ifBlank { DEFAULT_TOKEN }
        set(value) = prefs.edit().putString(KEY_TOKEN, sanitizeToken(value)).apply()

    var speechRate: Float
        get() = prefs.getFloat(KEY_SPEECH_RATE, 1.0f).coerceIn(0.5f, 1.5f)
        set(value) = prefs.edit().putFloat(KEY_SPEECH_RATE, value.coerceIn(0.5f, 1.5f)).apply()

    companion object {
        private const val KEY_TOKEN = "pairing_token"
        private const val KEY_SPEECH_RATE = "speech_rate"
        const val DEFAULT_TOKEN = "GIX2026CAM"

        fun sanitizeToken(value: String): String {
            return value.trim().replace(Regex("[^A-Za-z0-9_-]"), "").take(32).ifBlank { DEFAULT_TOKEN }
        }
    }
}
