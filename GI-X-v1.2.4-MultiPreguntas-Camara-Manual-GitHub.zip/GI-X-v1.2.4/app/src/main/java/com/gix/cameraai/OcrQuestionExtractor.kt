package com.gix.cameraai

object OcrQuestionExtractor {
    const val MULTI_PROMPT_HEADER = "[GIX_MULTI_QUESTIONS]"

    private val numberedLine = Regex("^\\s*(\\d{1,2})[\\.)]\\s*(.+)$")
    private val optionLine = Regex("^(?:[A-Ha-h][\\)\\].:-]|[1-9][\\)\\].:-])\\s*.+")
    private val junkOnly = Regex("^[\\W_]+$")

    fun extract(raw: String): String {
        val questions = extractQuestions(raw)
        return if (questions.isNotEmpty()) {
            questions.joinToString("\n\n")
        } else {
            extractFallback(raw)
        }
    }

    fun extractQuestions(raw: String): List<String> {
        val lines = raw.lines()
            .map { cleanLine(it) }
            .filter { it.length >= 2 && !junkOnly.matches(it) }

        if (lines.isEmpty()) return emptyList()

        val questions = mutableListOf<String>()
        var currentNumber: String? = null
        var currentParts = mutableListOf<String>()

        fun flushCurrent() {
            if (currentParts.isEmpty()) return
            val merged = currentParts.joinToString(" ")
                .replace(Regex("\\s+"), " ")
                .trim(' ', '-', ':')
            if (merged.isNotBlank()) {
                val prefix = currentNumber?.let { "$it. " } ?: ""
                questions += prefix + merged
            }
            currentNumber = null
            currentParts = mutableListOf()
        }

        for (line in lines) {
            val match = numberedLine.find(line)
            if (match != null) {
                val number = match.groupValues[1]
                val body = match.groupValues[2].trim()
                if (isSectionHeading(body)) {
                    flushCurrent()
                    continue
                }
                flushCurrent()
                currentNumber = number
                currentParts += body
                continue
            }

            if (startsLikeQuestion(line) || line.contains('?') || line.contains('¿')) {
                flushCurrent()
                currentParts += line
                continue
            }

            if (currentParts.isNotEmpty()) {
                if (optionLine.matches(line) || looksLikeContinuation(line)) {
                    currentParts += line
                    continue
                }
                flushCurrent()
            }
        }

        flushCurrent()

        val deduped = linkedSetOf<String>()
        questions.forEach { q ->
            val clean = q.replace(Regex("\\s+"), " ").trim()
            if (clean.isNotBlank()) deduped += clean
        }
        return deduped.toList().take(30)
    }

    fun buildQueryPayload(questions: List<String>): String {
        if (questions.isEmpty()) return ""
        if (questions.size == 1) return questions.first()

        val numbered = questions.mapIndexed { index, raw ->
            val body = raw.replace(Regex("^\\s*\\d{1,2}[\\.)]\\s*"), "").trim()
            "${index + 1}. $body"
        }.joinToString("\n")

        return """
            $MULTI_PROMPT_HEADER
            Responde todas las preguntas numeradas en el mismo orden.
            Devuelve un solo bloque completo desde la pregunta 1 hasta la ultima.
            Formato obligatorio para cada item:
            1. [pregunta]
            Respuesta: [respuesta]

            Longitud adaptativa por pregunta:
            - Si pide formula, simbolo, dato, fecha o alternativa correcta: responde solo eso.
            - Si pide una definicion: responde con una frase clara.
            - Si pide explicar, diferenciar o decir por que: responde un poco mas, pero de forma breve y directa.
            No omitas ninguna pregunta.

            Preguntas:
            $numbered
        """.trimIndent()
    }

    private fun extractFallback(raw: String): String {
        val lines = raw.lines()
            .map { cleanLine(it) }
            .filter { it.length >= 2 && !junkOnly.matches(it) }

        if (lines.isEmpty()) return ""

        val questionIndex = lines.indexOfLast { line ->
            line.contains('?') || line.contains('¿') || startsLikeQuestion(line)
        }

        if (questionIndex >= 0) {
            val selected = mutableListOf(lines[questionIndex])
            for (i in (questionIndex + 1) until lines.size) {
                val line = lines[i]
                if (optionLine.matches(line) || (selected.size == 1 && looksLikeOption(line))) {
                    selected += line
                    if (selected.size >= 7) break
                } else if (selected.size > 1) {
                    break
                }
            }
            return selected.joinToString("\n").take(1800)
        }

        return lines.takeLast(8).joinToString("\n").take(1800)
    }

    private fun cleanLine(raw: String): String {
        return raw
            .replace(Regex("[\\t ]+"), " ")
            .replace('•', ' ')
            .trim()
    }

    private fun isSectionHeading(text: String): Boolean {
        if (text.contains('?') || text.contains('¿')) return false
        if (startsLikeQuestion(text)) return false
        if (optionLine.matches(text)) return false
        val words = text.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.isEmpty() || words.size > 7) return false
        val lettersOnly = text.replace(Regex("[^A-Za-zÁÉÍÓÚáéíóúÑñ ]"), " ").trim()
        if (lettersOnly.isBlank()) return false
        return words.all { word ->
            word.firstOrNull()?.isUpperCase() == true ||
                word.lowercase() in setOf("de", "del", "y", "e", "la", "el")
        }
    }

    private fun startsLikeQuestion(line: String): Boolean {
        val clean = line.lowercase()
        return listOf(
            "qué ", "que ", "cuál ", "cual ", "cuáles ", "cuales ", "cómo ", "como ",
            "por qué ", "por que ", "dónde ", "donde ", "cuándo ", "cuando ",
            "quién ", "quien ", "quiénes ", "quienes ", "cuánto ", "cuanto ",
            "menciona ", "explica ", "define ", "indica ", "completa ", "resuelve "
        ).any { clean.startsWith(it) }
    }

    private fun looksLikeOption(line: String): Boolean {
        val clean = line.trim()
        return clean.length in 2..120 && (clean.startsWith("(") || clean.startsWith("•"))
    }

    private fun looksLikeContinuation(line: String): Boolean {
        if (line.length < 2) return false
        if (numberedLine.matches(line)) return false
        if (isSectionHeading(line)) return false
        return true
    }
}
