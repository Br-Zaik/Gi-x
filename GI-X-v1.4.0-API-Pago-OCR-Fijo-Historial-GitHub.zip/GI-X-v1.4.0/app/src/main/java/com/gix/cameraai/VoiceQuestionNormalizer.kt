package com.gix.cameraai

object VoiceQuestionNormalizer {
    fun isCompletionExercise(question: String): Boolean {
        val normalized = ResponseRepository.normalize(question)
        return listOf(
            "completa la frase", "completar la frase", "complete la frase",
            "completa la oracion", "completar la oracion", "complete la oracion",
            "espacio en blanco", "palabra que falta", "frase que falta"
        ).any { normalized.contains(it) } ||
            normalized.startsWith("completa ") || normalized.startsWith("complete ")
    }
}
