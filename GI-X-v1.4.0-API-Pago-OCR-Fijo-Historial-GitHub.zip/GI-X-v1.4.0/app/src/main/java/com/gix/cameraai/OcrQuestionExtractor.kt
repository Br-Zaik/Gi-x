package com.gix.cameraai

object OcrQuestionExtractor {
    const val MULTI_PROMPT_HEADER = "[GIX_MULTI_QUESTIONS]"

    private val numberedLine = Regex("^\\s*(\\d{1,2})[\\.)]\\s*(.+)$")
    private val optionStart = Regex("(?i)(?:^|\\s)([A-H])[\\)\\].:-]\\s*")
    private val standaloneOption = Regex("(?i)^\\s*([A-H])[\\)\\].:-]\\s*(.+)$")
    private val junkOnly = Regex("^[\\W_]+$")

    private data class Draft(
        val number: String?,
        var body: String
    )

    private data class SplitQuestion(
        val question: String,
        val options: MutableList<Pair<Char, String>>
    )

    fun extract(raw: String): String {
        val questions = extractQuestions(raw)
        return if (questions.isNotEmpty()) questions.joinToString("\n\n") else extractFallback(raw)
    }

    fun extractQuestions(raw: String): List<String> {
        val lines = raw.lines()
            .map { cleanLine(it) }
            .map { stripDocumentNoise(it) }
            .filter { it.length >= 2 && !junkOnly.matches(it) }

        if (lines.isEmpty()) return emptyList()

        val drafts = mutableListOf<Draft>()
        var current: Draft? = null

        fun pushCurrent() {
            val item = current ?: return
            item.body = normalizeBody(stripDocumentNoise(item.body))
            if (item.body.isNotBlank() && !isPureHeading(item.body)) drafts += item
            current = null
        }

        for (line in lines) {
            val numbered = numberedLine.find(line)
            if (numbered != null) {
                pushCurrent()
                val body = stripDocumentNoise(numbered.groupValues[2]).trim()
                if (body.isNotBlank() && !isPureHeading(body)) {
                    current = Draft(numbered.groupValues[1], body)
                }
                continue
            }

            if (isPureHeading(line)) continue

            if (current == null) {
                if (startsLikeQuestion(line) || looksLikeTrueFalse(line) || looksLikeCompletion(line)) {
                    current = Draft(null, line)
                }
                continue
            }

            current!!.body = normalizeBody(current!!.body + " " + line)
        }
        pushCurrent()

        if (drafts.isEmpty()) return emptyList()

        // ML Kit a veces devuelve la opción A de la siguiente pregunta justo antes
        // de la línea numerada. Reparación: si una pregunta que NO es de alternativas
        // termina en A)/B)/... y la siguiente sí es de alternativas, movemos esas
        // opciones a la siguiente pregunta.
        val split = drafts.map { draft -> splitQuestionAndOptions(draft.body) }.toMutableList()
        val pendingForNext = mutableListOf<Pair<Char, String>>()

        for (i in split.indices) {
            val currentSplit = split[i]
            val alternative = isAlternativeQuestion(currentSplit.question)

            if (pendingForNext.isNotEmpty() && alternative) {
                val merged = (pendingForNext + currentSplit.options)
                    .distinctBy { it.first.uppercaseChar() }
                    .sortedBy { it.first.uppercaseChar() }
                currentSplit.options.clear()
                currentSplit.options.addAll(merged)
                pendingForNext.clear()
            }

            if (!alternative && currentSplit.options.isNotEmpty()) {
                val nextAlternative = split.getOrNull(i + 1)?.let { isAlternativeQuestion(it.question) } == true
                if (nextAlternative) {
                    pendingForNext += currentSplit.options
                    currentSplit.options.clear()
                }
            }
        }

        val result = mutableListOf<String>()
        for (i in drafts.indices) {
            val draft = drafts[i]
            val item = split[i]
            val questionText = normalizeBody(stripDocumentNoise(item.question))
            if (questionText.isBlank() || isPureHeading(questionText)) continue

            val options = if (isAlternativeQuestion(questionText)) {
                item.options
                    .map { it.first.uppercaseChar() to normalizeBody(stripDocumentNoise(it.second)) }
                    .filter { it.second.isNotBlank() }
                    .distinctBy { it.first }
                    .sortedBy { it.first }
            } else {
                emptyList()
            }

            val body = buildString {
                append(questionText)
                if (options.isNotEmpty()) {
                    options.forEach { (letter, text) ->
                        append("\n")
                        append(letter)
                        append(") ")
                        append(text)
                    }
                }
            }.trim()

            val prefix = draft.number?.let { "$it. " } ?: ""
            result += prefix + body
        }

        return result
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
            .take(30)
    }

    fun buildQueryPayload(questions: List<String>): String {
        if (questions.isEmpty()) return ""
        if (questions.size == 1) return questions.first()

        val numbered = questions.mapIndexed { index, raw ->
            val body = raw.replace(Regex("^\\s*\\d{1,2}[\\.)]\\s*"), "").trim()
            "${index + 1}. $body"
        }.joinToString("\n")

        return """
            $MULTI_PROMPT_HEADER
            Responde TODAS las preguntas en el mismo orden y en UNA sola respuesta.
            Clasifica cada ejercicio de forma independiente: pregunta normal, verdadero/falso, alternativas o completar frase.

            Formato obligatorio:
            1. [pregunta completa]
            Respuesta: [respuesta]

            Reglas por tipo:
            - Alternativas A/B/C/D/E: conserva la pregunta y responde "Respuesta: La respuesta correcta es B. Texto de la opcion". No expliques salvo que la pregunta lo pida.
            - Verdadero o falso: conserva la afirmacion y responde solo "Respuesta: Verdadero" o "Respuesta: Falso"; justifica brevemente solo si lo pide.
            - Completar frase: conserva la frase y responde "Respuesta: La palabra o frase correcta es: ...".
            - Formula, simbolo, fecha o dato puntual: usa el dato exacto y nada innecesario.
            - Pregunta normal: respuesta clara, suficiente y breve; si pide explicar, comparar o decir por que, usa las oraciones necesarias sin relleno.
            - No omitas ninguna pregunta ni cambies el orden.
            - No inventes opciones que no aparecen en el texto.

            Preguntas:
            $numbered
        """.trimIndent()
    }

    private fun splitQuestionAndOptions(raw: String): SplitQuestion {
        val body = normalizeBody(stripDocumentNoise(raw))
        val matches = optionStart.findAll(body).toList()
        if (matches.isEmpty()) return SplitQuestion(body, mutableListOf())

        val question = body.substring(0, matches.first().range.first).trim()
        val options = mutableListOf<Pair<Char, String>>()
        for (index in matches.indices) {
            val match = matches[index]
            val letter = match.groupValues[1].first().uppercaseChar()
            val start = match.range.last + 1
            val end = matches.getOrNull(index + 1)?.range?.first ?: body.length
            val optionBody = body.substring(start, end).trim(' ', ',', ';', '-')
            if (optionBody.isNotBlank()) options += letter to optionBody
        }
        return SplitQuestion(question.ifBlank { body }, options)
    }

    private fun stripDocumentNoise(raw: String): String {
        var text = raw
        val patterns = listOf(
            Regex("(?i)PR[ÁA]CTICA\\s*\\d+\\s*[-–—]\\s*MINER[ÍI]A"),
            Regex("(?i)HOJA\\s+DE\\s+PRUEBA\\s+OCR\\s*\\d*\\s*[-–—]?\\s*MINER[ÍI]A"),
            Regex("(?i)Instituto\\s*/\\s*Universidad\\s*[-–—]\\s*Hoja\\s+de\\s+preguntas"),
            Regex("(?i)Preguntas\\s+mixtas\\s*:\\s*normales.*?completar\\s+frase"),
            Regex("(?i)Documento\\s+de\\s+pr[áa]ctica\\s+acad[ée]mica\\s+para\\s+prueba\\s+de\\s+OCR\\.?"),
            Regex("(?i)Prueba\\s+diseñada\\s+para\\s+verificar\\s+OCR.*?respuestas\\s+cortas\\.?")
        )
        patterns.forEach { pattern -> text = text.replace(pattern, " ") }
        return normalizeBody(text)
    }

    private fun cleanLine(raw: String): String {
        return raw
            .replace(Regex("[\\t ]+"), " ")
            .replace('•', ' ')
            .trim()
    }

    private fun normalizeBody(raw: String): String {
        return raw
            .replace(Regex("[ \\t]+"), " ")
            .replace(Regex("\\s*\\n\\s*"), "\n")
            .trim(' ', '-', ':')
    }

    private fun isPureHeading(text: String): Boolean {
        val clean = text.trim()
        if (clean.isBlank()) return true
        if (clean.contains('?') || clean.contains('¿')) return false
        if (looksLikeTrueFalse(clean) || looksLikeCompletion(clean)) return false
        if (standaloneOption.matches(clean)) return false
        if (Regex("(?i)^(pr[áa]ctica|hoja de prueba|instituto / universidad|preguntas mixtas|documento de pr[áa]ctica)").containsMatchIn(clean)) {
            return true
        }
        val words = clean.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.size !in 1..7) return false
        val letters = clean.replace(Regex("[^A-Za-zÁÉÍÓÚáéíóúÑñ ]"), " ").trim()
        if (letters.isBlank()) return false
        return words.all { word ->
            word.firstOrNull()?.isUpperCase() == true ||
                word.lowercase() in setOf("de", "del", "y", "e", "la", "el", "para")
        }
    }

    private fun startsLikeQuestion(line: String): Boolean {
        val clean = line.trim().lowercase()
        return listOf(
            "qué ", "que ", "cuál ", "cual ", "cuáles ", "cuales ", "cómo ", "como ",
            "por qué ", "por que ", "dónde ", "donde ", "cuándo ", "cuando ",
            "quién ", "quien ", "quiénes ", "quienes ", "cuánto ", "cuanto ",
            "menciona ", "explica ", "define ", "indica ", "completa ", "resuelve ",
            "señala ", "selecciona ", "marca "
        ).any { clean.startsWith(it) }
    }

    private fun looksLikeTrueFalse(line: String): Boolean {
        val clean = line.lowercase()
        return clean.startsWith("verdadero o falso") ||
            clean.startsWith("verdadero/falso") ||
            clean.startsWith("v/f") ||
            clean.contains(" verdadero o falso") ||
            clean.endsWith(" v/f")
    }

    private fun looksLikeCompletion(line: String): Boolean {
        val clean = line.lowercase()
        return clean.startsWith("completa ") || clean.startsWith("complete ") ||
            line.contains("___") || line.contains("……") || line.contains(".....")
    }

    private fun isAlternativeQuestion(raw: String): Boolean {
        val clean = raw.lowercase()
        return clean.contains("cuál de los siguientes") ||
            clean.contains("cual de los siguientes") ||
            clean.contains("cuál de las siguientes") ||
            clean.contains("cual de las siguientes") ||
            clean.contains("de las siguientes opciones") ||
            clean.contains("de los siguientes ejemplos") ||
            clean.contains("alternativa correcta") ||
            clean.contains("opción correcta") ||
            clean.contains("opcion correcta") ||
            clean.startsWith("selecciona ") || clean.startsWith("señala ")
    }

    private fun extractFallback(raw: String): String {
        val lines = raw.lines()
            .map { stripDocumentNoise(cleanLine(it)) }
            .filter { it.length >= 2 && !junkOnly.matches(it) && !isPureHeading(it) }
        if (lines.isEmpty()) return ""
        return lines.takeLast(12).joinToString("\n").take(2200)
    }
}
