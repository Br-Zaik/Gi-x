#!/usr/bin/env bash
set -euo pipefail

# GI-X: prepara el SDK oficial PaddleOCR Android v3.7.0 y PP-OCRv6 Small.
# Se ejecuta automáticamente en GitHub Actions antes de compilar el APK.
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WORK_DIR="${ROOT_DIR}/.ppocr-cache"
SDK_DIR="${ROOT_DIR}/ppocr-sdk"
PADDLE_DIR="${WORK_DIR}/PaddleOCR"
MODEL_DIR="${SDK_DIR}/src/main/assets/models"

PADDLE_TAG="v3.7.0"
DET_URL="https://paddle-model-ecology.bj.bcebos.com/paddlex/official_inference_model/paddle3.0.0/PP-OCRv6_small_det_onnx_infer.tar"
REC_URL="https://paddle-model-ecology.bj.bcebos.com/paddlex/official_inference_model/paddle3.0.0/PP-OCRv6_small_rec_onnx_infer.tar"
DET_SHA256="d218f6fbf0f1c23d2161bd6ac7f5eaa6104fa89955c09290497e31008e2618e4"
REC_SHA256="d267ab077a44a0eedb1ea8f8c542d263f211de8e9d7a029bf9fcfff7e5a88fb1"
HF_DET_BASE="https://huggingface.co/PaddlePaddle/PP-OCRv6_small_det_onnx/resolve/main"
HF_REC_BASE="https://huggingface.co/PaddlePaddle/PP-OCRv6_small_rec_onnx/resolve/main"

rm -rf "${WORK_DIR}" "${SDK_DIR}"
mkdir -p "${WORK_DIR}"

echo "[GI-X] Descargando código oficial PaddleOCR ${PADDLE_TAG}..."
git clone --quiet --depth 1 --branch "${PADDLE_TAG}" --filter=blob:none --sparse \
  https://github.com/PaddlePaddle/PaddleOCR.git "${PADDLE_DIR}"
git -C "${PADDLE_DIR}" sparse-checkout set deploy/ppocr-android/ppocr-sdk
cp -a "${PADDLE_DIR}/deploy/ppocr-android/ppocr-sdk" "${SDK_DIR}"

# El módulo oficial usa version catalog del demo. En GI-X lo hacemos autónomo y
# compatible con nuestro proyecto Groovy/AGP.
rm -f "${SDK_DIR}/build.gradle.kts"
cat > "${SDK_DIR}/build.gradle" <<'GRADLE'
plugins {
    id 'com.android.library'
    id 'org.jetbrains.kotlin.android'
}

android {
    namespace 'com.paddle.ocr'
    compileSdk 34

    defaultConfig {
        minSdk 26
    }

    buildTypes {
        release {
            minifyEnabled false
            consumerProguardFiles 'proguard-rules.pro'
        }
    }

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = '17'
    }
}

dependencies {
    implementation 'com.microsoft.onnxruntime:onnxruntime-android:1.21.1'
    // 4.5.3.0 corrige el empaquetado de librerías nativas frente a 4.5.3.
    implementation 'com.quickbirdstudios:opencv:4.5.3.0'
    implementation 'org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0'
    implementation 'androidx.core:core-ktx:1.13.1'
}
GRADLE

mkdir -p "${MODEL_DIR}/det" "${MODEL_DIR}/rec"
DET_TAR="${WORK_DIR}/det.tar"
REC_TAR="${WORK_DIR}/rec.tar"

fetch() {
  local url="$1" out="$2"
  curl --fail --location --retry 4 --retry-delay 2 --connect-timeout 20 --max-time 300 \
    "$url" -o "$out"
}

extract_official_tars() {
  echo "[GI-X] Descargando modelos oficiales PP-OCRv6 Small (BOS)..."
  fetch "${DET_URL}" "${DET_TAR}" || return 1
  fetch "${REC_URL}" "${REC_TAR}" || return 1
  echo "${DET_SHA256}  ${DET_TAR}" | sha256sum -c - || return 1
  echo "${REC_SHA256}  ${REC_TAR}" | sha256sum -c - || return 1

  mkdir -p "${WORK_DIR}/det" "${WORK_DIR}/rec"
  tar -xf "${DET_TAR}" -C "${WORK_DIR}/det"
  tar -xf "${REC_TAR}" -C "${WORK_DIR}/rec"

  local det_model rec_model rec_yml
  det_model="$(find "${WORK_DIR}/det" -type f -name inference.onnx | head -n 1)"
  rec_model="$(find "${WORK_DIR}/rec" -type f -name inference.onnx | head -n 1)"
  rec_yml="$(find "${WORK_DIR}/rec" -type f -name inference.yml | head -n 1)"
  [[ -n "${det_model}" && -n "${rec_model}" && -n "${rec_yml}" ]] || return 1
  cp "${det_model}" "${MODEL_DIR}/det/inference.onnx"
  cp "${rec_model}" "${MODEL_DIR}/rec/inference.onnx"
  cp "${rec_yml}" "${MODEL_DIR}/rec/inference.yml"
}

fetch_huggingface_fallback() {
  echo "[GI-X] BOS no respondió; usando repositorios oficiales PaddlePaddle en Hugging Face..."
  fetch "${HF_DET_BASE}/inference.onnx?download=true" "${MODEL_DIR}/det/inference.onnx"
  fetch "${HF_REC_BASE}/inference.onnx?download=true" "${MODEL_DIR}/rec/inference.onnx"
  fetch "${HF_REC_BASE}/inference.yml?download=true" "${MODEL_DIR}/rec/inference.yml"

  # Checksums publicados por el repositorio oficial HF para los ONNX.
  echo "d73e0058b7a8086bbd57f3d10b8bcd4ff95363f67e06e2762b5e814fe9c9410e  ${MODEL_DIR}/det/inference.onnx" | sha256sum -c -
  echo "5435fd747c9e0efe15a96d0b378d5bd157e9492ed8fd80edf08f30d02fa24634  ${MODEL_DIR}/rec/inference.onnx" | sha256sum -c -
}

if ! extract_official_tars; then
  rm -f "${MODEL_DIR}/det/inference.onnx" "${MODEL_DIR}/rec/inference.onnx" "${MODEL_DIR}/rec/inference.yml"
  fetch_huggingface_fallback
fi

[[ -s "${MODEL_DIR}/det/inference.onnx" ]]
[[ -s "${MODEL_DIR}/rec/inference.onnx" ]]
[[ -s "${MODEL_DIR}/rec/inference.yml" ]]

echo "[GI-X] PP-OCRv6 Small preparado correctamente."
