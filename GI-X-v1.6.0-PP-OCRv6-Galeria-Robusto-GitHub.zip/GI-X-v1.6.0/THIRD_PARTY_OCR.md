# Dependencias OCR de GI-X v1.6.0

- PaddleOCR / PP-OCRv6 Small: PaddlePaddle, Apache License 2.0, versión fijada v3.7.0.
- ONNX Runtime Android 1.21.1: Microsoft.
- OpenCV Android 4.5.3.0: OpenCV/QuickBird Studios.
- Google ML Kit Text Recognition 16.0.1: segundo motor OCR.

El workflow obtiene el código y los pesos PP-OCRv6 desde fuentes oficiales durante la compilación; no se guardan credenciales ni servicios cloud en la APK.
