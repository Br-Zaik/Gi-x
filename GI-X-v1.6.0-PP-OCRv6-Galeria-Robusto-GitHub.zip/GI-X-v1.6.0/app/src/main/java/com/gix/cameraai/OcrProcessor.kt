package com.gix.cameraai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.util.Log
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.paddle.ocr.EngineConfig
import com.paddle.ocr.PaddleOCR
import com.paddle.ocr.PaddleOCRConfig
import com.paddle.ocr.util.OpenCVUtils
import kotlinx.coroutines.runBlocking
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * OCR híbrido local de GI-X v1.6.0.
 *
 * PP-OCRv6 Small es el motor principal para texto difícil/manuscrito y ML Kit se
 * mantiene como segunda lectura, especialmente valiosa por su geometría para tablas.
 * OpenCV hace una preparación conservadora del documento. Si Paddle/OpenCV fallan,
 * ML Kit sigue funcionando: una mejora nueva nunca debe dejar al usuario sin OCR.
 */
class OcrProcessor(context: Context) {
    private val appContext = context.applicationContext
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val prepExecutor = Executors.newSingleThreadExecutor()
    private val closed = AtomicBoolean(false)
    private val paddleLock = Any()

    @Volatile private var paddle: PaddleOCR? = null
    @Volatile private var paddleInitAttempted = false
    @Volatile private var openCvReady = false

    private data class PaddleCandidate(
        val text: String,
        val averageConfidence: Float,
    )

    fun process(bitmap: Bitmap, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        if (closed.get()) {
            onError("El motor OCR ya fue cerrado")
            return
        }

        prepExecutor.execute {
            var baseRef: Bitmap? = null
            var enhancedRef: Bitmap? = null
            var normalizedRef: Bitmap? = null
            try {
                val normalizedBitmap = normalizeForOcr(bitmap)
                normalizedRef = normalizedBitmap
                openCvReady = ensureOpenCv()

                val corrected = if (openCvReady) {
                    OpenCvDocumentPreprocessor.correctPerspectiveIfSafe(normalizedBitmap)
                } else null
                val baseBitmap = corrected ?: normalizedBitmap
                baseRef = baseBitmap
                if (corrected != null && normalizedBitmap !== corrected && !normalizedBitmap.isRecycled) {
                    normalizedBitmap.recycle()
                    normalizedRef = null
                }

                val quality = if (openCvReady) {
                    OpenCvDocumentPreprocessor.quality(baseBitmap)
                } else {
                    OpenCvDocumentPreprocessor.Quality(128.0, 64.0, 100.0)
                }

                val enhancedBitmap = if (openCvReady) {
                    OpenCvDocumentPreprocessor.enhanceForText(baseBitmap) ?: enhanceFallback(baseBitmap)
                } else {
                    enhanceFallback(baseBitmap)
                }
                enhancedRef = enhancedBitmap

                val mlFirst = recognizeMlBlocking(baseBitmap)
                val mlSecond = recognizeMlBlocking(enhancedBitmap)
                val mlBest = chooseBestMl(mlFirst, mlSecond, baseBitmap.width)
                val mlText = if (mlBest != null && mlBest.text.isNotBlank()) {
                    cleanText(OcrTableFormatter.formatDocument(mlBest, baseBitmap.width))
                } else ""

                var paddleBest = recognizePaddle(baseBitmap)
                // Una segunda pasada PP-OCRv6 solo se hace cuando la foto lo merece o
                // la primera lectura dejó una estructura sospechosa. Evita gastar CPU
                // innecesariamente en documentos impresos limpios.
                val firstPaddleSuspicious = paddleBest?.text?.let { isStructurallyWeak(it) } ?: true
                if (enhancedBitmap !== baseBitmap && (quality.needsExtraPass || firstPaddleSuspicious)) {
                    val second = recognizePaddle(enhancedBitmap)
                    paddleBest = chooseBestPaddle(paddleBest, second)
                }

                val output = chooseHybrid(mlText, paddleBest).trim()
                if (output.isNotBlank()) {
                    Log.d(
                        "GIX-OCR",
                        "OCR OK ml=${mlText.length} paddle=${paddleBest?.text?.length ?: 0} " +
                            "conf=${paddleBest?.averageConfidence ?: 0f} dark=${quality.looksDark} " +
                            "blur=${quality.looksBlurry}",
                    )
                    onSuccess(output)
                } else {
                    onSuccess("")
                }
            } catch (t: Throwable) {
                Log.e("GIX-OCR", "OCR pipeline failed", t)
                onError(t.message ?: "No se pudo preparar la imagen para OCR")
            } finally {
                // Nunca reciclamos el bitmap original que mantiene la vista previa.
                val enhancedBitmap = enhancedRef
                val baseBitmap = baseRef
                val normalizedBitmap = normalizedRef
                if (enhancedBitmap != null && enhancedBitmap !== bitmap && enhancedBitmap !== baseBitmap && !enhancedBitmap.isRecycled) enhancedBitmap.recycle()
                if (baseBitmap != null && baseBitmap !== bitmap && !baseBitmap.isRecycled) baseBitmap.recycle()
                if (normalizedBitmap != null && normalizedBitmap !== bitmap && normalizedBitmap !== baseBitmap && !normalizedBitmap.isRecycled) normalizedBitmap.recycle()
            }
        }
    }

    private fun ensureOpenCv(): Boolean {
        if (openCvReady) return true
        return runCatching { OpenCVUtils.init(appContext) }
            .onFailure { Log.w("GIX-OCR", "OpenCV no disponible: ${it.message}") }
            .getOrDefault(false)
    }

    private fun getPaddle(): PaddleOCR? {
        paddle?.let { return it }
        synchronized(paddleLock) {
            paddle?.let { return it }
            if (paddleInitAttempted || closed.get()) return null
            paddleInitAttempted = true
            if (!ensureOpenCv()) return null
            return try {
                runBlocking {
                    PaddleOCR.create(
                        context = appContext,
                        config = PaddleOCRConfig(
                            detThresh = 0.20f,
                            detBoxThresh = 0.45f,
                            detUnclipRatio = 1.40f,
                            recScoreThresh = 0.05f,
                            recBatchSize = 1,
                        ),
                        engineConfig = EngineConfig(numThreads = 4),
                    )
                }.also { paddle = it }
            } catch (t: Throwable) {
                Log.e("GIX-OCR", "PP-OCRv6 no pudo inicializar; ML Kit seguirá activo", t)
                null
            }
        }
    }

    private fun recognizePaddle(bitmap: Bitmap): PaddleCandidate? {
        val engine = getPaddle() ?: return null
        return try {
            val result = runBlocking { engine.recognize(bitmap) }
            val items = result.results
                .filter { it.text.isNotBlank() }
            if (items.isEmpty()) return null
            val text = cleanText(items.joinToString("\n") { it.text.trim() })
            val confidence = items.map { it.confidence }.average().toFloat()
            PaddleCandidate(text, confidence)
        } catch (t: Throwable) {
            Log.w("GIX-OCR", "PP-OCRv6 pass failed: ${t.message}")
            null
        }
    }

    private fun recognizeMlBlocking(bitmap: Bitmap): Text? {
        if (closed.get()) return null
        return try {
            val image = InputImage.fromBitmap(bitmap, 0)
            Tasks.await(recognizer.process(image), 20, TimeUnit.SECONDS)
        } catch (t: Throwable) {
            Log.w("GIX-OCR", "ML Kit pass failed: ${t.message}")
            null
        }
    }

    private fun normalizeForOcr(source: Bitmap): Bitmap {
        val width = source.width.coerceAtLeast(1)
        val height = source.height.coerceAtLeast(1)
        val longSide = max(width, height)

        // OCR de documentos: suficiente detalle sin disparar memoria en equipos modestos.
        val desiredLongSide = when {
            longSide < 1200 -> 1800
            longSide > 2600 -> 2300
            else -> longSide
        }
        val scale = desiredLongSide.toFloat() / longSide.toFloat()
        val targetW = max(1, (width * scale).roundToInt())
        val targetH = max(1, (height * scale).roundToInt())
        return if (targetW == width && targetH == height) {
            source.copy(Bitmap.Config.ARGB_8888, false)
        } else {
            Bitmap.createScaledBitmap(source, targetW, targetH, true)
        }
    }

    private fun enhanceFallback(source: Bitmap): Bitmap {
        val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val gray = ColorMatrix().apply { setSaturation(0f) }
        val contrast = 1.28f
        val translate = (-0.5f * contrast + 0.5f) * 255f
        val boost = ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, translate,
                0f, contrast, 0f, 0f, translate,
                0f, 0f, contrast, 0f, translate,
                0f, 0f, 0f, 1f, 0f,
            ),
        )
        gray.postConcat(boost)
        paint.colorFilter = ColorMatrixColorFilter(gray)
        canvas.drawBitmap(source, 0f, 0f, paint)
        return output
    }

    private fun chooseBestMl(first: Text?, second: Text?, imageWidth: Int): Text? {
        if (first == null) return second
        if (second == null) return first
        val a = cleanText(first.text)
        val b = cleanText(second.text)
        if (a.isBlank()) return second
        if (b.isBlank()) return first
        val scoreA = score(a) + structureScoreMl(first, imageWidth)
        val scoreB = score(b) + structureScoreMl(second, imageWidth)
        return if (scoreB > scoreA + 6) second else first
    }

    private fun chooseBestPaddle(a: PaddleCandidate?, b: PaddleCandidate?): PaddleCandidate? {
        if (a == null) return b
        if (b == null) return a
        val scoreA = score(a.text) + structureScoreText(a.text) + (a.averageConfidence * 120).toInt()
        val scoreB = score(b.text) + structureScoreText(b.text) + (b.averageConfidence * 120).toInt()
        return if (scoreB > scoreA + 8) b else a
    }

    private fun chooseHybrid(mlText: String, paddleCandidate: PaddleCandidate?): String {
        val paddleText = paddleCandidate?.text.orEmpty()
        if (mlText.isBlank()) return paddleText
        if (paddleText.isBlank()) return mlText

        // Fusiona pregunta por pregunta cuando ambos motores recuperan numeración.
        // Esto permite, por ejemplo, conservar una tabla de ML Kit pero rescatar una
        // pregunta manuscrita que solo leyó PP-OCRv6.
        mergeNumberedQuestions(mlText, paddleText)?.let { return it }

        val mlQuestions = safeQuestions(mlText)
        val paddleQuestions = safeQuestions(paddleText)
        val mlSuspicious = mlQuestions.isNotEmpty() && OcrQuestionExtractor.hasSuspiciousNumbering(mlQuestions)
        val paddleSuspicious = paddleQuestions.isNotEmpty() && OcrQuestionExtractor.hasSuspiciousNumbering(paddleQuestions)

        if (!paddleSuspicious && mlSuspicious && paddleQuestions.isNotEmpty()) return paddleText
        if (!mlSuspicious && paddleSuspicious && mlQuestions.isNotEmpty()) return mlText

        if (!paddleSuspicious && paddleQuestions.size > mlQuestions.size && paddleQuestions.size >= 2) return paddleText
        if (!mlSuspicious && mlQuestions.size > paddleQuestions.size && mlQuestions.size >= 2) return mlText

        // Para tablas válidas, la geometría de ML Kit conserva filas/celdas vacías.
        if (mlText.contains(OcrTableFormatter.TABLE_START) && !mlSuspicious) return mlText

        val mlScore = score(mlText) + structureScoreText(mlText)
        val paddleScore = score(paddleText) + structureScoreText(paddleText) +
            ((paddleCandidate?.averageConfidence ?: 0f) * 100).toInt()
        return if (paddleScore > mlScore + 20) paddleText else mlText
    }

    private fun mergeNumberedQuestions(mlText: String, paddleText: String): String? {
        val mlQuestions = safeQuestions(mlText)
        val paddleQuestions = safeQuestions(paddleText)
        if (mlQuestions.isEmpty() || paddleQuestions.isEmpty()) return null

        val mlMap = mlQuestions.mapNotNull { q -> OcrQuestionExtractor.questionNumber(q)?.let { it to q } }.toMap()
        val paddleMap = paddleQuestions.mapNotNull { q -> OcrQuestionExtractor.questionNumber(q)?.let { it to q } }.toMap()
        if (mlMap.isEmpty() || paddleMap.isEmpty()) return null

        val ids = (mlMap.keys + paddleMap.keys).distinct().sorted()
        if (ids.size < 2 || ids.zipWithNext().any { (a, b) -> b != a + 1 }) return null

        val merged = ids.mapNotNull { id ->
            val ml = mlMap[id]
            val pp = paddleMap[id]
            when {
                ml == null -> pp
                pp == null -> ml
                ml.contains(OcrTableFormatter.TABLE_START) -> ml
                questionScore(pp) > questionScore(ml) + 35 -> pp
                else -> ml
            }
        }
        if (merged.size != ids.size) return null
        return merged.joinToString("\n\n")
    }

    private fun safeQuestions(text: String): List<String> {
        return try { OcrQuestionExtractor.extractQuestions(text) } catch (_: Throwable) { emptyList() }
    }

    private fun questionScore(question: String): Int {
        var value = score(question)
        if (Regex("(?i)\\b(?:Fe|Pb|Ag|Au|Cu|Zn|H2O|CO2|EPP|GPS|GNSS|USB)\\b").containsMatchIn(question)) value += 40
        if (question.contains(".....") || question.contains("___")) value += 20
        if (question.contains(OcrTableFormatter.TABLE_START)) value += 200
        return value
    }

    private fun isStructurallyWeak(text: String): Boolean {
        val questions = safeQuestions(text)
        if (text.length < 18) return true
        if (questions.size >= 2 && OcrQuestionExtractor.hasSuspiciousNumbering(questions)) return true
        return false
    }

    private fun structureScoreMl(result: Text, imageWidth: Int): Int {
        return try {
            structureScoreText(OcrTableFormatter.formatDocument(result, imageWidth))
        } catch (_: Throwable) {
            0
        }
    }

    private fun structureScoreText(text: String): Int {
        return try {
            val questions = OcrQuestionExtractor.extractQuestions(text)
            var value = questions.size * 90
            if (questions.size >= 3 && !OcrQuestionExtractor.hasSuspiciousNumbering(questions)) value += 180
            if (OcrQuestionExtractor.hasSuspiciousNumbering(questions)) value -= 420
            if (text.contains(OcrTableFormatter.TABLE_START)) value += 80
            val ids = questions.mapNotNull { OcrQuestionExtractor.questionNumber(it) }
            if (ids.size >= 3 && ids.zipWithNext().all { (x, y) -> y == x + 1 }) value += 220
            value
        } catch (_: Throwable) {
            0
        }
    }

    private fun score(text: String): Int {
        val trimmed = text.trim()
        if (trimmed.isBlank()) return Int.MIN_VALUE
        val chars = trimmed.length
        val useful = trimmed.count { it.isLetterOrDigit() || it in "¿?¡!.,:;()[]%-+/=_" }
        val letters = trimmed.count { it.isLetterOrDigit() }
        val weird = trimmed.count { it == '\uFFFD' || it == '�' }
        val words = trimmed.split(Regex("\\s+")).count { it.length >= 2 }
        val lines = trimmed.lines().count { it.trim().length >= 2 }
        val questionBonus = if ('?' in trimmed || '¿' in trimmed) 18 else 0
        val lineList = trimmed.lines()
        val optionBonus = lineList.count { Regex("^\\s*[A-Ha-h][\\)\\].:-]\\s+.+").matches(it) } * 4
        val numberedQuestionBonus = lineList.count {
            Regex("^\\s*\\d{1,2}\\s*[\\.)\\-:]\\s*.*$").matches(it)
        } * 10
        val shortDataBonus = lineList.count {
            val line = it.trim()
            Regex("^[A-Z][a-z]?$|^[A-Z][A-Za-z0-9₀-₉]{1,7}$").matches(line)
        } * 4
        val ratio = if (chars == 0) 0 else (useful * 100 / chars)
        val noisePenalty = max(0, 65 - ratio) * 2 + weird * 20
        return min(chars, 2600) + letters / 2 + words * 3 + min(lines, 24) * 2 +
            questionBonus + optionBonus + numberedQuestionBonus + shortDataBonus - noisePenalty
    }

    private fun cleanText(raw: String): String {
        return raw
            .replace("\r\n", "\n")
            .replace('\r', '\n')
            .lines()
            .map { line -> line.replace(Regex("[ \\t]+"), " ").trimEnd() }
            .dropWhile { it.isBlank() }
            .dropLastWhile { it.isBlank() }
            .joinToString("\n")
            .replace(Regex("\n{3,}"), "\n\n")
            .trim()
    }

    fun close() {
        if (!closed.compareAndSet(false, true)) return
        val instance = paddle
        paddle = null
        if (instance != null) {
            runCatching { runBlocking { instance.release() } }
        }
        prepExecutor.shutdownNow()
        recognizer.close()
    }
}
