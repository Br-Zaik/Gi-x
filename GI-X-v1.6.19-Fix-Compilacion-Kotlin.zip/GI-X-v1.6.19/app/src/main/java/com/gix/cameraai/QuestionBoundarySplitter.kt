package com.gix.cameraai

/**
 * Separa preguntas que el OCR devolvió pegadas dentro de una misma línea.
 *
 * Causa real del error de v1.6.14: cuando PP-OCR o ML Kit entregan varias preguntas
 * en un solo renglón ("4. ¿QUE ES LA ESCALA? 5. En un plano... 6. DIFERENCIA..."),
 * OcrQuestionExtractor solo reconocía el PRIMER número, porque su expresión regular
 * está anclada al inicio de la línea. Todo lo demás quedaba dentro del cuerpo de la
 * pregunta 4 y después aparecía duplicado.
 *
 * Aquí no hay ninguna corrección escrita a mano de un examen concreto: solo se
 * reconocen formatos de numeración y se comprueba que la secuencia sea coherente.
 *
 * Formatos aceptados: "1." "1)" "1-" "1.-" "1:" "01." "Pregunta 1" "Ítem 1" "Ejercicio 1".
 *
 * Números que NO son marcadores (y que esta clase deja intactos):
 * - escalas: 1:1000
 * - medidas: 480 mm
 * - puntos/etiquetas: A1, A2, N240
 * - decimales: 3.5
 * - enumeraciones internas: "los procesos 1, 2 y 3"
 */
object QuestionBoundarySplitter {

    private const val MAX_QUESTION_NUMBER = 60

    /** Cierre de respuesta de una afirmación verdadero/falso. */
    private val TRUE_FALSE_MARKER = Regex("""\(\s*\)""")

    /**
     * Número + delimitador + espacio. El delimitador es obligatorio y el número no
     * puede ir pegado a otra letra o dígito (eso descarta A1, N240 y 1:1000).
     */
    private val NUMBER_MARKER = Regex("""(?<![\p{L}\p{N}])(\d{1,2})\s?(\.\s?-|\.|\)|-|:)(?=[\s¿¡])""")

    private val WORD_MARKER = Regex(
        """(?i)(?<![\p{L}\p{N}])(?:pregunta|preg|ítem|item|ejercicio)\s+(\d{1,2})\s?[.)\-:]?(?=[\s¿¡])"""
    )

    private data class Marker(
        val start: Int,
        val bodyStart: Int,
        val number: Int,
    )

    /**
     * Devuelve el mismo texto pero con una pregunta por línea y el marcador
     * normalizado a "N. ". No borra contenido: lo que no es marcador se conserva.
     */
    fun normalize(raw: String): String {
        if (raw.isBlank()) return raw

        val lines = raw.replace("\r\n", "\n").replace('\r', '\n').split('\n')
        val output = ArrayList<String>(lines.size + 8)
        var lastNumber = 0

        for (line in lines) {
            val clean = line.replace(Regex("[\\t ]+"), " ").trim()
            if (clean.isEmpty()) {
                output += ""
                continue
            }
            val pieces = splitLine(clean, lastNumber)
            for (piece in pieces) {
                if (piece.first.isNotBlank()) output += piece.first
                piece.second?.let { lastNumber = it }
            }
        }

        return output.joinToString("\n")
    }

    /** Pares (texto de la línea resultante, número del marcador si lo tiene). */
    private fun splitLine(line: String, previousNumber: Int): List<Pair<String, Int?>> {
        val markers = findMarkers(line)
        if (markers.isEmpty()) return listOf(line to null)

        var lastNumber = previousNumber
        val accepted = ArrayList<Marker>()

        for ((index, marker) in markers.withIndex()) {
            val bodyEnd = markers.getOrNull(index + 1)?.start ?: line.length
            val body = line.substring(marker.bodyStart.coerceAtMost(bodyEnd), bodyEnd).trim()

            if (marker.start == 0 && accepted.isEmpty()) {
                // Marcador propio de la línea: ya lo entendía el extractor, pero lo
                // registramos para que la secuencia siga siendo coherente.
                if (marker.number in 1..MAX_QUESTION_NUMBER) {
                    accepted += marker
                    lastNumber = marker.number
                }
                continue
            }

            if (marker.number !in 1..MAX_QUESTION_NUMBER) continue
            if (!looksLikeQuestionBody(body)) continue

            val letters = body.count { it.isLetter() }
            val expected = lastNumber + 1
            val trueFalseItem = TRUE_FALSE_MARKER.containsMatchIn(body)
            val acceptable = when {
                // Primera numeración vista: exigimos un cuerpo con entidad real.
                lastNumber == 0 -> letters >= 12
                // Caso normal: la numeración continúa.
                marker.number == expected -> true
                // El OCR pudo perder una pregunta intermedia; se admite un salto
                // pequeño solo si el texto que sigue parece un enunciado completo.
                marker.number in (expected + 1)..(expected + 3) -> letters >= 12
                // Afirmación de verdadero/falso: el cierre "( )" es evidencia fuerte,
                // así que se acepta aunque el OCR haya perdido varias afirmaciones.
                marker.number > lastNumber && trueFalseItem -> letters >= 12
                // Si en esta misma línea ya se separaron dos preguntas correctamente,
                // es una línea claramente enumerada y el resto también se separa.
                marker.number > lastNumber && accepted.size >= 2 -> letters >= 12
                else -> false
            }
            if (!acceptable) continue

            accepted += marker
            lastNumber = marker.number
        }

        if (accepted.isEmpty()) return listOf(line to null)

        val pieces = ArrayList<Pair<String, Int?>>(accepted.size + 1)

        val firstStart = accepted.first().start
        if (firstStart > 0) {
            val head = line.substring(0, firstStart).trim()
            if (head.isNotEmpty()) pieces += head to null
        }

        for ((index, marker) in accepted.withIndex()) {
            val end = accepted.getOrNull(index + 1)?.start ?: line.length
            val body = line.substring(marker.bodyStart.coerceAtMost(end), end).trim()
            pieces += ("${marker.number}. $body").trim() to marker.number
        }

        return pieces
    }

    private fun findMarkers(line: String): List<Marker> {
        val markers = ArrayList<Marker>()

        WORD_MARKER.findAll(line).forEach { match ->
            val number = match.groupValues[1].toIntOrNull() ?: return@forEach
            markers += Marker(match.range.first, match.range.last + 1, number)
        }

        NUMBER_MARKER.findAll(line).forEach { match ->
            val number = match.groupValues[1].toIntOrNull() ?: return@forEach
            val start = match.range.first
            // Si "Pregunta 5" ya cubrió esta posición, no la duplicamos.
            if (markers.any { start >= it.start && start < it.bodyStart }) return@forEach
            markers += Marker(start, match.range.last + 1, number)
        }

        return markers.sortedBy { it.start }
    }

    /**
     * Un cuerpo válido empieza con letra, con signo de interrogación de apertura o con
     * la línea de puntos de un ejercicio de completar. Nunca con un dígito: así
     * "escala 1:1000. ¿Cuál..." o "2 - 3 metros" no se parten por error.
     */
    private fun looksLikeQuestionBody(body: String): Boolean {
        if (body.isBlank()) return false
        val first = body.first()
        val startsWell = first.isLetter() || first in "¿¡(\"'“._…"
        if (!startsWell) return false
        return body.count { it.isLetter() } >= 2
    }
}
