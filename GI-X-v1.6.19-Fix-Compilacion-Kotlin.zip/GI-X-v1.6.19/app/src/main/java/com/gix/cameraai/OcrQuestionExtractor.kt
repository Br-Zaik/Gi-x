package com.gix.cameraai

object OcrQuestionExtractor {
    const val MULTI_PROMPT_HEADER = "[GIX_MULTI_QUESTIONS]"
    const val TRUE_FALSE_BATCH_HEADER = "[GIX_TRUE_FALSE_BATCH]"
    const val DOCUMENT_CONTEXT_HEADER = "[GIX_DOCUMENT_CONTEXT]"

    private val numberedLine = Regex("^\\s*(\\d{1,2})\\s*[\\.)\\-:]\\s*(.*)$")
    // ML Kit a veces conserva el número pero pierde el punto: "4 Cuales son...".
    private val spacedNumberLine = Regex("^\\s*(\\d{1,2})\\s+(.+)$")
    private val bareNumberLine = Regex("^\\s*(\\d{1,2})\\s*$")
    private val optionStart = Regex("(?i)(?:^|\\s)([A-H])[\\)\\].:-]\\s*")
    private val standaloneOption = Regex("(?i)^\\s*([A-H])[\\)\\].:-]\\s*(.+)$")
    private val junkOnly = Regex("^[\\W_]+$")

    private data class Draft(
        val number: String?,
        var body: String
    )

    private val visibleQuestionNumber = Regex("^\\s*(\\d{1,2})\\s*[\\.)\\-:]\\s*")
    private val trueFalseAnswerMarker = Regex("\\(\\s*\\)")

    private data class SplitQuestion(
        val question: String,
        val options: MutableList<Pair<Char, String>>
    )

    fun extract(raw: String): String {
        val questions = extractQuestions(raw)
        return if (questions.isNotEmpty()) questions.joinToString("\n\n") else extractFallback(raw)
    }

    fun extractQuestions(raw: String): List<String> {
        val structuredTables = OcrTableFormatter.parseStructuredTables(raw)
        // GI X v1.6.15: el OCR puede devolver varias preguntas dentro de un mismo
        // renglón. Antes de segmentar por líneas se separan los marcadores de
        // numeración pegados; sin esto, 4+5+6+7 terminaban en un solo bloque.
        val baseRaw = QuestionBoundarySplitter.normalize(
            OcrTableFormatter.removeStructuredTables(raw)
        )
        val lines = baseRaw.lines()
            .map { cleanLine(it) }
            .map { stripDocumentNoise(it) }
            .filter { line ->
                // ML Kit puede devolver el número de pregunta como una línea de un solo
                // carácter ("2", "3", ...). Nunca lo descartamos antes de reconstruir.
                (line.length >= 2 || bareNumberLine.matches(line)) && !junkOnly.matches(line)
            }

        if (lines.isEmpty()) {
            return structuredTables.mapIndexed { index, table -> "Tabla ${index + 1}:\n${table.trim()}" }
        }

        val drafts = mutableListOf<Draft>()
        var current: Draft? = null

        fun pushCurrent() {
            val item = current ?: return
            item.body = normalizeBody(stripDocumentNoise(item.body))
            if (item.body.isNotBlank() && (item.number != null || !isPureHeading(item.body))) drafts += item
            current = null
        }

        for (line in lines) {
            val numbered = numberedLine.find(line)
            val spaced = if (numbered == null) spacedNumberLine.find(line)?.takeIf { match ->
                val n = match.groupValues[1].toIntOrNull() ?: 99
                val body = match.groupValues[2].trim()
                n in 1..40 && body.length >= 4
            } else null
            val bareNumber = if (numbered == null && spaced == null) bareNumberLine.find(line) else null
            if (numbered != null || spaced != null || bareNumber != null) {
                pushCurrent()
                val number = numbered?.groupValues?.get(1)
                    ?: spaced?.groupValues?.get(1)
                    ?: bareNumber!!.groupValues[1]
                val body = (numbered?.groupValues?.getOrNull(2)
                    ?: spaced?.groupValues?.getOrNull(2)
                    ?: "")
                    .let { stripDocumentNoise(it).trim() }

                // "1. Tabla de puntos", "2. Datos adicionales", "3. Preguntas"
                // son secciones del documento, no ejercicios. En formularios y fichas
                // técnicas esta distinción evita numeraciones 1,2,3,1,2,3... falsas.
                if (isNumberedSectionHeading(body)) {
                    current = null
                    continue
                }
                // ML Kit puede separar visualmente "1." del enunciado. Conservamos el
                // número aunque esta línea todavía no tenga texto y unimos las líneas
                // siguientes hasta encontrar la próxima pregunta numerada.
                current = Draft(number, body)
                continue
            }

            if (isInstructionHeading(line)) continue

            val startsNewUnnumberedQuestion = startsLikeQuestion(line) ||
                looksLikeTrueFalse(line) || looksLikeCompletion(line)

            // Las alternativas A), B), C)... suelen ser líneas cortas con mayúscula y
            // antes podían confundirse con títulos y desaparecer. Si ya hay una
            // pregunta abierta, se conservan siempre como parte de ella.
            if (current != null && standaloneOption.matches(line)) {
                current!!.body = normalizeBody(current!!.body + "\n" + line)
                continue
            }

            // v1.6.17: si la pregunta abierta pide llenar un cuadro, las líneas cortas
            // que siguen son CELDAS (APLICACIÓN, FUNCIÓN, NAVEGADOR, CORREO
            // ELECTRÓNICO...). Antes se perdían porque parecen títulos en mayúsculas.
            val tableContext = current?.let { looksLikeTableQuestion(it.body) } == true
            val tableCell = tableContext && looksLikeTableCell(line)

            if (isPureHeading(line) && !shouldKeepAsQuestionData(line, current) && !tableCell) continue

            if (current == null) {
                if (startsNewUnnumberedQuestion) {
                    current = Draft(null, line)
                }
                continue
            }

            if (tableCell) {
                // Cada celda en su propia línea: así la relación fila/columna llega
                // entera a la API en vez de convertirse en un párrafo desordenado.
                current!!.body = normalizeBody(current!!.body + "\n" + line)
                continue
            }

            // Datos cortos en columna debajo de una pregunta: Fe / Pb / Ag, "Sin :",
            // "Epi :", o una línea de puntos con muy poco texto. Se conservan como
            // líneas propias para no perder la correspondencia dato por dato.
            val shortDataLine = looksLikeScientificOrShortData(line) ||
                (completionBlank.containsMatchIn(line) && line.count { it.isLetter() } <= 12)
            if (current != null && shortDataLine) {
                current!!.body = normalizeBody(current!!.body + "\n" + line)
                continue
            }

            // Si estamos leyendo una hoja sin numeración y aparece otra línea que
            // claramente inicia una nueva pregunta, cerramos la anterior. Antes,
            // dos preguntas consecutivas sin 1., 2., 3. podían terminar unidas.
            if (current!!.number == null && startsNewUnnumberedQuestion) {
                pushCurrent()
                current = Draft(null, line)
                continue
            }

            current!!.body = normalizeBody(current!!.body + " " + line)
        }
        pushCurrent()

        // Una afirmación V/F puede llegar desde ML Kit con el número de las líneas
        // intermedias perdido. Ejemplo real: la pregunta 7 termina conteniendo también
        // las afirmaciones 8 y 9, y la siguiente numerada visible es 10. Si el cuerpo
        // contiene exactamente los cierres ( ) necesarios para cubrir ese salto,
        // reconstruimos 7, 8 y 9 antes de consultar a la API.
        val repairedDrafts = repairMergedTrueFalseDrafts(drafts)
        drafts.clear()
        drafts.addAll(repairedDrafts)

        if (drafts.isEmpty()) {
            return structuredTables.mapIndexed { index, table -> "Tabla ${index + 1}:\n${table.trim()}" }
        }

        // ML Kit a veces devuelve la opción A de la siguiente pregunta justo antes
        // de la línea numerada. Reparación: si una pregunta que NO es de alternativas
        // termina en A)/B)/... y la siguiente sí es de alternativas, movemos esas
        // opciones a la siguiente pregunta.
        val split = drafts.map { draft -> splitQuestionAndOptions(draft.body) }.toMutableList()
        val pendingForNext = mutableListOf<Pair<Char, String>>()

        for (i in split.indices) {
            val currentSplit = split[i]
            val alternative = isAlternativeQuestion(currentSplit.question)

            if (pendingForNext.isNotEmpty() && alternative) {
                val merged = (pendingForNext + currentSplit.options)
                    .distinctBy { it.first.uppercaseChar() }
                    .sortedBy { it.first.uppercaseChar() }
                currentSplit.options.clear()
                currentSplit.options.addAll(merged)
                pendingForNext.clear()
            }

            if (!alternative && currentSplit.options.isNotEmpty()) {
                val nextAlternative = split.getOrNull(i + 1)?.let { isAlternativeQuestion(it.question) } == true
                if (nextAlternative) {
                    pendingForNext += currentSplit.options
                    currentSplit.options.clear()
                }
            }
        }

        val result = mutableListOf<String>()
        for (i in drafts.indices) {
            val draft = drafts[i]
            val item = split[i]
            val questionText = normalizeBody(stripDocumentNoise(item.question))
            if (questionText.isBlank() || (draft.number == null && isPureHeading(questionText))) continue

            val options = if (isAlternativeQuestion(questionText)) {
                item.options
                    .map { it.first.uppercaseChar() to normalizeBody(stripDocumentNoise(it.second)) }
                    .filter { it.second.isNotBlank() }
                    .distinctBy { it.first }
                    .sortedBy { it.first }
            } else {
                emptyList()
            }

            val body = buildString {
                append(questionText)
                if (options.isNotEmpty()) {
                    options.forEach { (letter, text) ->
                        append("\n")
                        append(letter)
                        append(") ")
                        append(text)
                    }
                }
            }.trim()

            val prefix = draft.number?.let { "$it. " } ?: ""
            result += prefix + body
        }

        val cleanedResult = result
            .map { QuestionTextNormalizer.normalize(it.trim()) }
            .filter { it.isNotBlank() }
            .distinct()
            .toMutableList()

        // GI X v1.6.15: la tabla reconstruida se adjunta a la pregunta que la pide
        // ("COMPLETE LA FUNCIÓN QUE CORRESPONDE"), ya normalizada, para que la API
        // reciba la relación fila/columna. Si no hay ninguna pregunta de tabla, la
        // tabla NO se convierte en una pregunta extra: sigue fuera del payload.
        attachStructuredTables(cleanedResult, structuredTables)

        // Títulos y contexto OCR siguen fuera del texto que irá a la API.
        return cleanedResult
            .filter { it.isNotBlank() }
            .distinct()
            .take(30)
    }

    /**
     * Señala si el conjunto parece una hoja de verdadero/falso. Se usa para elegir
     * bloques de API más compactos y seguros.
     */
    fun isLikelyTrueFalseQuestions(questions: List<String>): Boolean = isLikelyTrueFalseBatch(questions)

    /**
     * Comprueba la numeración visible sin exigir que toda hoja esté numerada. Si hay
     * al menos tres números, deben ser crecientes y sin saltos grandes. Sirve como
     * última barrera para no mandar a la API una reconstrucción claramente corrupta.
     */
    fun hasSuspiciousNumbering(questions: List<String>): Boolean {
        val ids = questions.mapNotNull(::questionNumber)
        if (ids.size < 3) return false
        if (ids.zipWithNext().any { (a, b) -> b <= a }) return true
        // En una hoja numerada completa, un solo salto ya puede significar que OCR
        // se comió una pregunta. Antes se toleraba un salto aislado (7 -> 10) y la
        // consulta se enviaba igual; eso produjo respuestas con numeración incorrecta.
        return ids.zipWithNext().any { (a, b) -> b != a + 1 }
    }

    /**
     * Numeración CORRUPTA: repetida o fuera de orden. Indica que la reconstrucción del
     * documento falló y las respuestas se asignarían a la pregunta equivocada.
     *
     * A diferencia de hasSuspiciousNumbering, un simple hueco (falta la 1 porque la
     * foto no llegó a la cabecera de la hoja) NO se considera corrupto: esas preguntas
     * sí se pueden responder.
     */
    fun hasCorruptNumbering(questions: List<String>): Boolean {
        val ids = questions.mapNotNull(::questionNumber)
        if (ids.size < 3) return false
        return ids.zipWithNext().any { (a, b) -> b <= a }
    }

    fun questionNumber(raw: String): Int? {
        return visibleQuestionNumber.find(raw)?.groupValues?.getOrNull(1)?.toIntOrNull()
    }

    private fun isNumberedSectionHeading(raw: String): Boolean {
        val clean = raw.trim().trimEnd(':', '.', '-').replace(Regex("\\s+"), " ")
        if (clean.isBlank()) return false
        if ('?' in clean || '¿' in clean) return false
        val words = clean.split(" ").filter { it.isNotBlank() }
        if (words.size > 8) return false
        val lower = clean.lowercase()
        return listOf(
            "tabla", "tabla de", "datos", "datos adicionales", "información", "informacion",
            "contexto", "lectura", "preguntas", "cuestionario", "instrucciones", "sección",
            "seccion", "parte", "texto", "texto breve", "plano", "información adicional",
            "informacion adicional", "lista de verificación", "lista de verificacion",
            "operaciones", "observaciones", "resultados"
        ).any { lower == it || lower.startsWith("$it ") }
    }

    /**
     * Extrae el material que las preguntas necesitan para poder responderse: lectura,
     * datos, instrucciones y tablas. Antes GI X mostraba/mandaba casi solo las
     * preguntas; eso hacía que una pregunta basada en un cuadro pudiera llegar a la
     * API sin los valores del cuadro.
     */
    fun extractDocumentContext(raw: String): String {
        val base = OcrTableFormatter.removeStructuredTables(raw)
        val tables = OcrTableFormatter.parseStructuredTables(raw)
        val lines = base.lines()
            .map { stripDocumentNoise(cleanLine(it)) }
            .filter { it.isNotBlank() && !isLikelyContextNoise(it) }

        var questionStart = -1
        val explicitHeading = lines.indexOfFirst { line ->
            val normalized = line
                .replace(Regex("^\\s*\\d{1,2}\\s*[\\.)\\-:]\\s*"), "")
                .replace(Regex("(?i)^secci[oó]n\\s+[A-Z0-9]+\\s*[-–—:]\\s*"), "")
                .trim().trimEnd(':').lowercase()
            normalized in setOf("preguntas", "cuestionario", "preguntas y respuestas", "responde") ||
                normalized.startsWith("preguntas ")
        }
        if (explicitHeading >= 0) {
            questionStart = explicitHeading
        } else {
            questionStart = lines.indexOfFirst { line -> looksLikeActualQuestionStart(line) }
        }

        val contextLines = when {
            questionStart > 0 -> lines.take(questionStart)
            questionStart == 0 -> emptyList()
            else -> lines.takeWhile { line -> !looksLikeActualQuestionStart(line) }
        }

        val tableText = tables.joinToString("\n\n") { it.trim() }
        return buildString {
            if (contextLines.isNotEmpty()) append(contextLines.joinToString("\n").trim())
            if (tableText.isNotBlank()) {
                if (isNotEmpty()) append("\n\n")
                append(tableText)
            }
        }.trim().take(6500)
    }

    private fun looksLikeActualQuestionStart(raw: String): Boolean {
        val line = cleanLine(raw)
        val numbered = numberedLine.find(line)
        val spaced = spacedNumberLine.find(line)
        val body = when {
            numbered != null -> numbered.groupValues[2].trim()
            spaced != null -> spaced.groupValues[2].trim()
            else -> line
        }
        if (body.isBlank()) return false
        if ('?' in body || '¿' in body) return true
        val lower = body.lowercase().trimStart('¿', '?', '-', '–', '—', ' ')
        return listOf(
            "resuelve", "calcula", "convierte", "simplifica", "continúa", "continua",
            "menciona", "explique", "explica", "defina", "define", "completa", "complete",
            "escribe", "indica", "señala", "senala", "marca", "verdadero o falso"
        ).any { lower.startsWith(it) }
    }

    fun buildQueryPayload(
        questions: List<String>,
        forceBatch: Boolean = false,
        documentContext: String = "",
    ): String {
        if (questions.isEmpty()) return ""
        // GI X v1.6.14: la API recibe únicamente las preguntas detectadas.
        // El contexto OCR se mantiene fuera del payload para evitar ruido del entorno.
        val safeContext = ""
        if (!forceBatch && questions.size == 1 &&
            !questions.first().contains(OcrTableFormatter.TABLE_START) && safeContext.isBlank()) {
            return questions.first()
        }

        // Conservamos el número IMPRESO del examen. Nunca renumeramos 11 como 1 o
        // 20 como 18. Para preguntas realmente sin numeración usamos números locales
        // solo como identificadores técnicos del lote.
        val numbered = questions.mapIndexed { index, raw ->
            val normalizedQuestion = QuestionTextNormalizer.normalize(raw)
            val originalNumber = questionNumber(normalizedQuestion)
            // Conserva alternativas, filas de tabla y líneas de completar tal como
            // quedaron: solo se reescribe el número al inicio de la primera línea.
            val body = normalizedQuestion.replace(visibleQuestionNumber, "").trim()
            "${originalNumber ?: (index + 1)}. $body"
        }.joinToString("\n")
        val typeLine = ExamStructureDetector.payloadTypeLine(questions)
        val trueFalseMarker = if (isLikelyTrueFalseBatch(questions)) {
            "$TRUE_FALSE_BATCH_HEADER\n"
        } else {
            ""
        }

        return buildString {
            append(MULTI_PROMPT_HEADER).append('\n')
            if (trueFalseMarker.isNotBlank()) append(trueFalseMarker)
            // "TIPO: ..." va antes de "Preguntas:" para no alterar el conteo de
            // preguntas que hace OnlineAnswerProvider.
            append(typeLine).append('\n')
            if (safeContext.isNotBlank()) {
                append(DOCUMENT_CONTEXT_HEADER).append('\n')
                append("Contexto del documento:").append('\n')
                append(safeContext).append("\n\n")
            }
            append("Preguntas:").append('\n')
            append(numbered)
        }.trim()
    }

    private fun repairMergedTrueFalseDrafts(input: List<Draft>): List<Draft> {
        if (input.size < 2) return input.map { it.copy() }
        val output = mutableListOf<Draft>()

        for (index in input.indices) {
            val draft = input[index]
            val currentNumber = draft.number?.toIntOrNull()
            val nextNumber = input.getOrNull(index + 1)?.number?.toIntOrNull()
            if (currentNumber == null || nextNumber == null || nextNumber <= currentNumber + 1) {
                output += draft
                continue
            }

            val gapSize = nextNumber - currentNumber
            val segments = splitByTrueFalseMarkers(draft.body)
            // Solo reparamos cuando la evidencia es fuerte: el número de afirmaciones
            // terminadas en ( ) coincide exactamente con 7,8,9 antes de ver el 10, etc.
            if (segments.size == gapSize && segments.all { segment -> segment.count { ch -> ch.isLetter() } >= 8 }) {
                segments.forEachIndexed { segmentIndex, segment ->
                    output += Draft((currentNumber + segmentIndex).toString(), segment)
                }
            } else {
                output += draft
            }
        }
        return output
    }

    private fun splitByTrueFalseMarkers(raw: String): List<String> {
        val matches = trueFalseAnswerMarker.findAll(raw).toList()
        if (matches.size <= 1) return listOf(raw.trim())
        val parts = mutableListOf<String>()
        var start = 0
        matches.forEach { match ->
            val endExclusive = match.range.last + 1
            val part = raw.substring(start, endExclusive).trim()
            if (part.isNotBlank()) parts += part
            start = endExclusive
        }
        val tail = raw.substring(start).trim()
        if (tail.isNotBlank()) {
            // Si hay texto después del último ( ), pertenece a la última afirmación
            // salvo que tenga entidad suficiente para formar otra pregunta; no
            // inventamos una numeración sin evidencia.
            if (parts.isNotEmpty()) parts[parts.lastIndex] = normalizeBody(parts.last() + " " + tail)
            else parts += tail
        }
        return parts
    }

    private fun attachStructuredTables(result: MutableList<String>, tables: List<String>) {
        if (tables.isEmpty()) return

        val candidateIndexes = result.indices.filter { index -> looksLikeTableQuestion(result[index]) }.toMutableList()
        var candidateCursor = 0

        tables.forEachIndexed { tableIndex, table ->
            val normalizedTable = table.trim()
            if (normalizedTable.isBlank()) return@forEachIndexed

            val targetIndex = when {
                candidateCursor < candidateIndexes.size -> candidateIndexes[candidateCursor++]
                else -> -1
            }

            if (targetIndex >= 0) {
                result[targetIndex] = result[targetIndex].trim() + "\n" + normalizedTable
            } else if (result.isEmpty()) {
                // Una tabla puede ser el ejercicio completo. Si ya existen preguntas,
                // la tabla es contexto y NO debe contarse como una pregunta extra.
                result += "Tabla ${tableIndex + 1}:\n$normalizedTable"
            }
        }
    }

    /**
     * Celda de un cuadro: línea corta, sin pregunta propia y sin ser una instrucción.
     * Solo se usa cuando la pregunta abierta ya pidió completar una tabla.
     */
    private fun looksLikeTableCell(raw: String): Boolean {
        val clean = raw.trim().trim('|').trim()
        if (clean.length !in 2..46) return false
        if ('?' in clean || '¿' in clean) return false
        if (isInstructionHeading(clean)) return false
        if (numberedLine.matches(clean)) return false
        val words = clean.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.size > 6) return false
        return clean.any { it.isLetterOrDigit() }
    }

    private fun looksLikeTableQuestion(raw: String): Boolean {
        val clean = raw.lowercase()
        return listOf(
            "tabla", "cuadro", "complete la funcion", "complete la función",
            "completa la funcion", "completa la función", "funcion que corresponda",
            "función que corresponda", "relacione las columnas", "relaciona las columnas",
            "columnas de la tabla", "filas de la tabla", "llene la tabla", "llena la tabla",
            "rellene la tabla", "rellena la tabla", "llene el cuadro", "llena el cuadro",
            "rellene el cuadro", "rellena el cuadro"
        ).any { clean.contains(it) }
    }

    private fun shouldKeepAsQuestionData(line: String, current: Draft?): Boolean {
        if (current == null) return false
        val clean = line.trim()
        if (clean.isBlank()) return false
        // No aceptamos automáticamente un título solo porque haya un número esperando.
        // Un encabezado como "SEGUNDO EXAMEN..." o "SEGÚN SUS CARACTERÍSTICAS..."
        // debe seguir siendo encabezado. Los datos cortos válidos se conservan abajo.

        // Símbolos químicos, fórmulas, unidades, abreviaturas y etiquetas cortas pueden
        // aparecer solos debajo de una pregunta (Fe, Pb, Ag, Au, H2O, CO2, cm, %, Sin:, Epi:).
        // No deben confundirse con títulos solo por ser cortos o empezar con mayúscula.
        if (looksLikeScientificOrShortData(clean)) return true
        if (clean.length <= 16 && clean.endsWith(":")) return true
        return false
    }

    private fun looksLikeScientificOrShortData(raw: String): Boolean {
        val clean = raw.trim().trim(',', ';')
        if (clean.isBlank() || clean.length > 18) return false

        val elementSymbols = setOf(
            "H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne", "Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar",
            "K", "Ca", "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn", "Ga", "Ge", "As", "Se", "Br", "Kr",
            "Rb", "Sr", "Y", "Zr", "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn", "Sb", "Te", "I", "Xe",
            "Cs", "Ba", "La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb", "Lu",
            "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg", "Tl", "Pb", "Bi", "Po", "At", "Rn", "Fr", "Ra",
            "Ac", "Th", "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm", "Md", "No", "Lr", "Rf", "Db",
            "Sg", "Bh", "Hs", "Mt", "Ds", "Rg", "Cn", "Nh", "Fl", "Mc", "Lv", "Ts", "Og"
        )
        if (clean in elementSymbols) return true

        val compact = clean.replace(" ", "")
        if (Regex("^[A-Z][a-z]?(?:[0-9₀-₉]+)?(?:[A-Z][a-z]?[0-9₀-₉]*)+$").matches(compact)) return true
        if (Regex("^[A-Za-z]{1,4}[0-9₀-₉²³/%°.-]*$").matches(compact) && compact.any { it.isDigit() }) return true

        val units = setOf(
            "m", "cm", "mm", "km", "m2", "m²", "m3", "m³", "kg", "g", "mg", "t", "ton", "%", "°", "°c", "pa", "kpa", "mpa"
        )
        return compact.lowercase() in units || compact.lowercase() in setOf("sin", "epi") || Regex("^[A-Z]{2,5}$").matches(compact)
    }

    private fun isInstructionHeading(raw: String): Boolean {
        val clean = raw.lowercase().replace(Regex("\\s+"), " ").trim().trimEnd(':')
        return clean.startsWith("complete con las palabras que corresponda") ||
            clean.startsWith("complete con la palabra que corresponda") ||
            clean.startsWith("completa con las palabras que correspondan") ||
            clean.startsWith("ponga si es verdadero") ||
            clean.startsWith("marque verdadero o falso")
    }

    private fun isLikelyTrueFalseBatch(questions: List<String>): Boolean {
        if (questions.size < 3) return false
        val emptyAnswerParens = Regex("\\(\\s*\\)\\s*[.?!]*\\s*$")
        val explicit = questions.count { q ->
            val normalized = q.lowercase()
            normalized.contains("verdadero o falso") || normalized.contains("v/f") ||
                emptyAnswerParens.containsMatchIn(q.trim())
        }
        return explicit * 100 / questions.size >= 60
    }

    private fun splitQuestionAndOptions(raw: String): SplitQuestion {
        val body = normalizeBody(stripDocumentNoise(raw))
        val matches = optionStart.findAll(body).toList()
        if (matches.isEmpty()) return SplitQuestion(body, mutableListOf())

        val question = body.substring(0, matches.first().range.first).trim()
        val options = mutableListOf<Pair<Char, String>>()
        for (index in matches.indices) {
            val match = matches[index]
            val letter = match.groupValues[1].first().uppercaseChar()
            val start = match.range.last + 1
            val end = matches.getOrNull(index + 1)?.range?.first ?: body.length
            val optionBody = body.substring(start, end).trim(' ', ',', ';', '-')
            if (optionBody.isNotBlank()) options += letter to optionBody
        }
        return SplitQuestion(question.ifBlank { body }, options)
    }

    private fun stripDocumentNoise(raw: String): String {
        var text = raw
        val patterns = listOf(
            Regex("(?i)PR[ÁA]CTICA\\s*\\d+\\s*[-–—]\\s*MINER[ÍI]A"),
            Regex("(?i)HOJA\\s+DE\\s+PRUEBA\\s+OCR\\s*\\d*\\s*[-–—]?\\s*MINER[ÍI]A"),
            Regex("(?i)Instituto\\s*/\\s*Universidad\\s*[-–—]\\s*Hoja\\s+de\\s+preguntas"),
            Regex("(?i)Preguntas\\s+mixtas\\s*:\\s*normales.*?completar\\s+frase"),
            Regex("(?i)Documento\\s+de\\s+pr[áa]ctica\\s+acad[ée]mica\\s+para\\s+prueba\\s+de\\s+OCR\\.?"),
            Regex("(?i)Prueba\\s+diseñada\\s+para\\s+verificar\\s+OCR.*?respuestas\\s+cortas\\.?"),
            Regex("(?i)\\s+P[áa]gina\\s+\\d{1,3}\\s*$"),
            Regex("(?i)\\s+C[óo]digo\\s*:\\s*[A-Z0-9._/-]{2,30}\\s*$"),
            Regex("(?i)\\s+Nombre\\s+del\\s+estudiante\\s*:\\s*_+.*$"),
            Regex("(?i)\\s+Fecha\\s*:\\s*_+\\s*$"),
            Regex("(?i)(?:^|\\s)(?:Intel\\s*)?Core\\s+i?[3579s](?=\\s|$|[.,;:])"),
            Regex("(?i)(?:^|\\s)logi(?:tech)?(?=\\s|$|[.,;:])")
        )
        patterns.forEach { pattern -> text = text.replace(pattern, " ") }
        val normalized = normalizeBody(text)
        // Fragmentos minúsculos tipo "te)" suelen ser OCR de objetos externos.
        // No tocamos A) respuesta, fórmulas, siglas ni elementos químicos normales.
        if (Regex("""^[a-z]{1,3}[\)\].:]$""").matches(normalized)) return ""
        return normalized
    }

    private fun cleanLine(raw: String): String {
        return raw
            .replace(Regex("[\\t ]+"), " ")
            .replace('•', ' ')
            .trim()
    }

    private fun normalizeBody(raw: String): String {
        return raw
            .replace(Regex("[ \\t]+"), " ")
            .replace(Regex("\\s*\\n\\s*"), "\n")
            .trim(' ', '-', ':')
    }

    private fun isPureHeading(text: String): Boolean {
        val clean = text.trim()
        if (clean.isBlank()) return true
        if (clean.contains('?') || clean.contains('¿')) return false
        if (startsLikeQuestion(clean) || looksLikeTrueFalse(clean) || looksLikeCompletion(clean)) return false
        if (standaloneOption.matches(clean)) return false
        if (Regex("(?i)^(pr[áa]ctica|hoja de prueba|instituto / universidad|preguntas mixtas|documento de pr[áa]ctica)").containsMatchIn(clean)) {
            return true
        }
        val words = clean.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.size !in 1..14) return false
        val letters = clean.replace(Regex("[^A-Za-zÁÉÍÓÚáéíóúÑñ ]"), " ").trim()
        if (letters.isBlank()) return false
        return words.all { word ->
            word.firstOrNull()?.isUpperCase() == true ||
                word.lowercase() in setOf("de", "del", "y", "e", "la", "el", "para")
        }
    }

    private fun startsLikeQuestion(line: String): Boolean {
        val clean = line
            .trim()
            .trimStart('¿', '?', '¡', '!', '-', '–', '—', ':', ';', '.', ' ')
            .lowercase()

        // Un signo de cierre es una señal fuerte incluso cuando la pregunta no
        // empieza por una palabra interrogativa, por ejemplo: "En un plano... ?".
        if (line.trim().endsWith("?") && clean.length >= 4) return true

        return listOf(
            "qué ", "que ", "cuál ", "cual ", "a cuál ", "a cual ", "cuáles ", "cuales ", "cómo ", "como ",
            "por qué ", "por que ", "dónde ", "donde ", "cuándo ", "cuando ",
            "quién ", "quien ", "quiénes ", "quienes ", "cuánto ", "cuanto ",
            "menciona ", "mencione ", "mencione las ", "mencione los ",
            "explica ", "explique ", "define ", "defina ", "indica ", "indique ",
            "completa ", "complete ", "resuelve ", "resuelva ", "señala ", "señale ",
            "selecciona ", "seleccione ", "marca ", "marque ", "calcula ", "calcule ",
            "determina ", "determine ", "describe ", "describa ", "enumera ", "enumere ",
            "compara ", "compare ", "diferencia entre ", "diferencie ",
            "convertir ", "convierte ", "convierta ", "halle ", "obtenga ",
            "realice ", "desarrolle ", "responda ", "identifique ", "relacione ",
            "escriba ", "justifique ", "demuestre ", "señale la ", "señale el "
        ).any { clean.startsWith(it) }
    }

    private fun looksLikeTrueFalse(line: String): Boolean {
        val clean = line.lowercase()
        val emptyAnswer = Regex("\\(\\s*\\)\\s*[.?!]*\\s*$").containsMatchIn(line.trim())
        return clean.startsWith("verdadero o falso") ||
            clean.startsWith("verdadero/falso") ||
            clean.startsWith("v/f") ||
            clean.contains(" verdadero o falso") ||
            clean.endsWith(" v/f") ||
            // En una hoja V/F, cada afirmación suele terminar en ( ). Esto permite
            // recuperar una afirmación aunque ML Kit haya perdido su número.
            (emptyAnswer && line.count { it.isLetter() } >= 12)
    }

    private val completionBlank = Regex("""(\.{4,}|_{3,}|…{2,})""")

    private fun looksLikeCompletion(line: String): Boolean {
        val clean = line.lowercase()
        return clean.startsWith("completa ") || clean.startsWith("complete ") ||
            completionBlank.containsMatchIn(line)
    }

    private fun isAlternativeQuestion(raw: String): Boolean {
        val clean = raw.lowercase()
        return clean.contains("cuál de los siguientes") ||
            clean.contains("cual de los siguientes") ||
            clean.contains("cuál de las siguientes") ||
            clean.contains("cual de las siguientes") ||
            clean.contains("de las siguientes opciones") ||
            clean.contains("de los siguientes ejemplos") ||
            clean.contains("alternativa correcta") ||
            clean.contains("opción correcta") ||
            clean.contains("opcion correcta") ||
            clean.startsWith("selecciona ") || clean.startsWith("señala ")
    }
    private fun polishQuestionText(raw: String): String {
        if (raw.isBlank()) return raw
        val numbered = Regex("""^\s*(\d{1,2}\s*[\.)\-:]\s*)(.*)$""").find(raw)
        val prefix = numbered?.groupValues?.get(1).orEmpty()
        var body = (numbered?.groupValues?.get(2) ?: raw).trim()
        if (body.isBlank()) return raw.trim()

        val lowerLead = body.trimStart().lowercase()
        body = when {
            lowerLead.startsWith("¿que") -> body.replaceFirst(Regex("""(?i)^¿?que\b"""), "¿Qué")
            lowerLead.startsWith("¿cual") -> body.replaceFirst(Regex("""(?i)^¿?cual\b"""), "¿Cuál")
            lowerLead.startsWith("¿como") -> body.replaceFirst(Regex("""(?i)^¿?como\b"""), "¿Cómo")
            lowerLead.startsWith("¿donde") -> body.replaceFirst(Regex("""(?i)^¿?donde\b"""), "¿Dónde")
            lowerLead.startsWith("¿cuando") -> body.replaceFirst(Regex("""(?i)^¿?cuando\b"""), "¿Cuándo")
            lowerLead.startsWith("¿quien") -> body.replaceFirst(Regex("""(?i)^¿?quien\b"""), "¿Quién")
            lowerLead.startsWith("¿cuanto") -> body.replaceFirst(Regex("""(?i)^¿?cuanto\b"""), "¿Cuánto")
            else -> body
        }
        body = body.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
        body = body.replace(Regex("""(?i)\btopografia\b"""), "topografía")
            .replace(Regex("""(?i)\bmineria\b"""), "minería")
            .replace(Regex("""(?i)\bgeograficas\b"""), "geográficas")
            .replace(Regex("""(?i)\bcoordenadas utm\b"""), "coordenadas UTM")
        return (prefix + body).trim()
    }

    private fun isLikelyContextNoise(raw: String): Boolean {
        val clean = raw.trim()
        if (clean.isBlank()) return true
        val lower = clean.lowercase()
        if (Regex("""(?i)^core\s*i?[3579s]\b""").containsMatchIn(clean)) return true
        if (lower in setOf("core i5", "core is", "intel", "logi", "hp", "dell", "asus", "lenovo")) return true
        if (clean.length <= 4 && clean.count { it.isLetterOrDigit() } <= 4) return true
        if (Regex("""^[A-Z0-9]{1,6}$""").matches(clean)) return true
        if (Regex("""^[a-z]{1,3}[\)\].:]?$""", RegexOption.IGNORE_CASE).matches(clean)) return true
        return false
    }

    private fun extractFallback(raw: String): String {
        val lines = raw.lines()
            .map { stripDocumentNoise(cleanLine(it)) }
            .filter { it.length >= 2 && !junkOnly.matches(it) && !isPureHeading(it) }
        if (lines.isEmpty()) return ""
        return lines.takeLast(12).joinToString("\n").take(2200)
    }
}
