package com.gix.cameraai

import java.text.Normalizer
import kotlin.math.max
import kotlin.math.min

/**
 * Fusiona OCR de varias fotos del MISMO documento.
 *
 * Objetivos de v1.6.11:
 * - conservar contexto/lecturas/tablas aunque aparezcan solo en una foto;
 * - fusionar preguntas repetidas usando su número impreso;
 * - elegir la lectura más completa cuando la misma pregunta aparece en varias fotos;
 * - reconstruir palabras dudosas por consenso entre capturas del mismo documento;
 * - aplicar una corrección final muy conservadora de vocabulario técnico frecuente;
 * - ordenar las preguntas por numeración y detectar huecos antes de usar la API;
 * - no inventar contenido que no apareció en ninguna captura.
 */
object MultiImageDocumentMerger {

    data class MergeResult(
        val combinedRaw: String,
        val combinedDisplay: String,
        val questions: List<String>,
        val documentContext: String,
        val missingQuestionNumbers: List<Int>,
        val duplicateQuestionNumbersResolved: Int,
        val usableImageCount: Int,
        /** Faltan porque esa zona del documento no aparece en ninguna captura. */
        val notPhotographedNumbers: List<Int> = emptyList(),
        /** Estaban dentro de la zona fotografiada, pero el OCR no las pudo leer. */
        val unreadableNumbers: List<Int> = emptyList(),
        /** Explicación corta y lista para mostrar al usuario. */
        val coverageNote: String = "",
    ) {
        val hasQuestions: Boolean get() = questions.isNotEmpty()
        val looksComplete: Boolean get() = missingQuestionNumbers.isEmpty()
    }

    private data class QuestionCandidate(
        val text: String,
        val imageIndex: Int,
        val score: Int,
    )

    private data class TokenVote(
        val token: String,
        val weight: Int,
    )

    private val visibleNumber = Regex("^\\s*(\\d{1,2})\\s*[\\.)\\-:]\\s*")
    private val technicalMarker = Regex("^\\[GIX_[A-Z0-9_]+]$")
    private val leadingPunctuation = Regex("^[¿¡(\"'\\[]+")
    private val trailingPunctuation = Regex("[?.,;:!¡)\"'\\]]+$")

    private val technicalLexicon = linkedSetOf(
        "qué", "cuál", "cómo", "dónde", "por", "que", "es", "un", "una", "de", "del", "la", "el", "las", "los", "y", "entre",
        "menciona", "diferencia", "explica", "define", "indica", "responde",
        "topografía", "topográfico", "topográficos", "minería", "minero", "minera",
        "instrumento", "instrumentos", "coordenada", "coordenadas", "geográfica", "geográficas", "utm",
        "banco", "marca", "peligro", "riesgo", "seguridad", "accidente", "trabajo",
        "condición", "subestándar", "acto", "señalización", "equipo", "protección", "personal",
        "referencia", "frente", "labor", "galería", "acceso", "cota", "punto"
    )
    private val lexiconByNormalized = technicalLexicon.associateBy { normalizeWordKey(it) }

    fun merge(rawTexts: List<String>, sourceQualityScores: List<Double> = emptyList()): MergeResult {
        val usable = rawTexts.mapIndexedNotNull { index, raw ->
            raw.trim().takeIf { it.isNotBlank() }?.let { clean ->
                Triple(clean, index, sourceQualityScores.getOrNull(index) ?: 0.0)
            }
        }
        if (usable.isEmpty()) {
            return MergeResult("", "", emptyList(), "", emptyList(), 0, 0)
        }

        val numbered = linkedMapOf<Int, MutableList<QuestionCandidate>>()
        val unnumbered = mutableListOf<QuestionCandidate>()
        val perImageNumbers = mutableListOf<List<Int>>()
        var duplicateResolved = 0

        usable.forEach { (raw, imageIndex, qualityScore) ->
            val imageNumbers = mutableListOf<Int>()
            OcrQuestionExtractor.extractQuestions(raw).forEach questionLoop@{ question ->
                val clean = normalizeVisibleQuestion(question)
                if (clean.isBlank()) return@questionLoop
                val qualityBonus = qualityScore.coerceIn(-40.0, 80.0).toInt()
                val candidate = QuestionCandidate(clean, imageIndex, questionQuality(clean) + qualityBonus)
                val number = OcrQuestionExtractor.questionNumber(clean)
                if (number != null) {
                    imageNumbers += number
                    val list = numbered.getOrPut(number) { mutableListOf() }
                    if (list.isNotEmpty()) duplicateResolved++
                    list += candidate
                } else {
                    val similarIndex = unnumbered.indexOfFirst { existing ->
                        semanticSimilarity(existing.text, clean) >= 0.82
                    }
                    if (similarIndex >= 0) {
                        duplicateResolved++
                        if (candidate.score > unnumbered[similarIndex].score) {
                            unnumbered[similarIndex] = candidate
                        }
                    } else {
                        unnumbered += candidate
                    }
                }
            }
            perImageNumbers += imageNumbers.distinct().sorted()
        }

        val selectedNumbers = selectPrimaryQuestionNumbers(numbered.keys.toList())
        val mergedNumbered = numbered
            .toSortedMap()
            .filterKeys { key -> selectedNumbers.isEmpty() || key in selectedNumbers }
            .map { (_, candidates) -> chooseBestQuestion(candidates) }

        // En documentos numerados, las preguntas sin número suelen ser fragmentos de
        // una lectura repetida. Solo las añadimos si de verdad parecen preguntas y no
        // son casi iguales a una ya numerada.
        val mergedUnnumbered = unnumbered
            .sortedBy { it.imageIndex }
            .map { postCorrectQuestion(sanitizeQuestionText(it.text)) }
            .filter { q ->
                mergedNumbered.none { numberedQ -> semanticSimilarity(numberedQ, q) >= 0.78 }
            }

        val questions = (mergedNumbered + mergedUnnumbered)
            .map { postCorrectQuestion(sanitizeQuestionText(it)).trim() }
            .filter { it.isNotBlank() }
            .distinctBy { normalizeForCompare(it) }
            .take(40)

        // Solo conservamos preguntas. El OCR puede leer títulos/objetos externos,
        // pero esos textos no deben llegar a la interfaz ni a la API.
        val context = ""

        val missing = detectMissingQuestionNumbers(questions)
        val combinedRaw = questions.joinToString("\n\n")
        val display = questions.joinToString("\n\n")

        // GI X v1.6.15: no es lo mismo "el OCR no pudo leer esto" que "esta zona del
        // documento nunca fue fotografiada". Con lo segundo, tomar otra foto del mismo
        // encuadre no sirve: hay que reencuadrar la hoja.
        val notPhotographed = mutableListOf<Int>()
        val unreadable = mutableListOf<Int>()
        val photographedRanges = perImageNumbers
            .filter { it.isNotEmpty() }
            .map { numbers -> numbers.first() to numbers.last() }
        missing.forEach { number ->
            val insideSomePhoto = photographedRanges.any { (low, high) -> number in low..high }
            if (insideSomePhoto) unreadable += number else notPhotographed += number
        }

        return MergeResult(
            combinedRaw = combinedRaw,
            combinedDisplay = display,
            questions = questions,
            documentContext = context,
            missingQuestionNumbers = missing,
            duplicateQuestionNumbersResolved = duplicateResolved,
            usableImageCount = usable.size,
            notPhotographedNumbers = notPhotographed,
            unreadableNumbers = unreadable,
            coverageNote = buildCoverageNote(notPhotographed, unreadable),
        )
    }

    private fun buildCoverageNote(notPhotographed: List<Int>, unreadable: List<Int>): String {
        if (notPhotographed.isEmpty() && unreadable.isEmpty()) return ""
        return buildString {
            if (notPhotographed.isNotEmpty()) {
                append("La zona de ")
                append(notPhotographed.joinToString(", "))
                append(" no aparece en ninguna foto: hay que encuadrar la hoja completa.")
            }
            if (unreadable.isNotEmpty()) {
                if (isNotEmpty()) append(" ")
                append("El OCR no pudo leer ")
                append(unreadable.joinToString(", "))
                append(", aunque esa zona sí estaba en la imagen: mejora luz/enfoque.")
            }
        }
    }

    private fun chooseBestQuestion(candidates: List<QuestionCandidate>): String {
        if (candidates.isEmpty()) return ""
        if (candidates.size == 1) return postCorrectQuestion(sanitizeQuestionText(candidates.first().text))

        val sorted = candidates.sortedWith(
            compareByDescending<QuestionCandidate> { it.score }
                .thenByDescending { it.text.length }
                .thenByDescending { it.imageIndex }
        )
        val best = sorted.first()
        val similar = sorted.filter { semanticSimilarity(best.text, it.text) >= 0.45 }
        val bestSanitized = postCorrectQuestion(sanitizeQuestionText(best.text))
        if (similar.size < 2) return bestSanitized

        val fused = postCorrectQuestion(sanitizeQuestionText(fuseSimilarQuestions(similar)))
        if (fused.isBlank()) return bestSanitized

        val bestScore = questionQuality(bestSanitized)
        val fusedScore = questionQuality(fused)
        return if (fusedScore >= bestScore - 4) fused else bestSanitized
    }

    private fun fuseSimilarQuestions(candidates: List<QuestionCandidate>): String {
        val sorted = candidates.sortedWith(
            compareByDescending<QuestionCandidate> { it.score }
                .thenByDescending { it.text.length }
                .thenBy { it.imageIndex }
        )
        val topScore = sorted.firstOrNull()?.score ?: return ""
        // Para fusionar, preferimos la lectura más completa entre candidatas todavía
        // competitivas. Así una foto muy nítida pero cortada no fija un ancla truncada.
        val anchorCandidate = sorted
            .filter { it.score >= topScore - 80 }
            .maxWithOrNull(compareBy<QuestionCandidate> { it.text.length }.thenBy { it.score })
            ?: sorted.first()
        val anchorBase = sanitizeQuestionText(anchorCandidate.text)
        // GI X v1.6.15: si una toma cortó el final de la pregunta y otra tiene esa
        // cola, se unen por SOLAPE literal de palabras. Todo el texto proviene de una
        // captura real; no se inventa ni se concatenan preguntas distintas.
        val stitched = stitchReadings(anchorBase, sorted)
        val anchor = if (stitched.length > anchorBase.length) stitched else anchorBase
        val number = OcrQuestionExtractor.questionNumber(anchor)
        val anchorTokens = tokenizeQuestionBody(anchor.replace(visibleNumber, "").trim())
        if (anchorTokens.isEmpty()) return anchor

        val alignedCandidates = sorted.mapNotNull { candidate ->
            val body = sanitizeQuestionText(candidate.text).replace(visibleNumber, "").trim()
            val tokens = tokenizeQuestionBody(body)
            if (tokens.isEmpty()) null
            else candidate to alignTokensToAnchor(anchorTokens, tokens)
        }

        val reconstructed = anchorTokens.mapIndexed { index, anchorToken ->
            val votes = alignedCandidates.mapNotNull { (candidate, aligned) ->
                aligned.getOrNull(index)?.let { TokenVote(it, candidate.score) }
            }
            chooseConsensusToken(anchorToken, votes)
        }.joinToString(" ")

        val body = cleanupSpacing(reconstructed)
        return (number?.let { "$it. " } ?: "") + body
    }

    private const val MAX_STITCHED_CHARS = 1400
    private const val MIN_OVERLAP_TOKENS = 4

    /**
     * Une la lectura base con las colas o cabeceras que aportan otras capturas de la
     * MISMA pregunta. Solo une cuando coinciden al menos 4 palabras consecutivas, así
     * que nunca pega dos preguntas diferentes ni añade texto inexistente.
     */
    private fun stitchReadings(base: String, candidates: List<QuestionCandidate>): String {
        var best = base
        var rounds = 0
        var changed = true
        while (changed && rounds < 4 && best.length < MAX_STITCHED_CHARS) {
            changed = false
            rounds++
            for (candidate in candidates) {
                val other = sanitizeQuestionText(candidate.text)
                if (other.isBlank()) continue
                val forward = extendWithOverlap(best, other)
                if (forward.length > best.length && forward.length <= MAX_STITCHED_CHARS) {
                    best = forward
                    changed = true
                    continue
                }
                val backward = extendWithOverlap(other, best)
                if (backward.length > best.length && backward.length <= MAX_STITCHED_CHARS) {
                    best = backward
                    changed = true
                }
            }
        }
        return best
    }

    private fun extendWithOverlap(base: String, other: String): String {
        val number = OcrQuestionExtractor.questionNumber(base) ?: OcrQuestionExtractor.questionNumber(other)
        val baseTokens = tokenizeQuestionBody(base.replace(visibleNumber, "").trim())
        val otherTokens = tokenizeQuestionBody(other.replace(visibleNumber, "").trim())
        if (baseTokens.size < MIN_OVERLAP_TOKENS || otherTokens.size < MIN_OVERLAP_TOKENS) return base

        val maxOverlap = min(baseTokens.size, otherTokens.size)
        for (overlap in maxOverlap downTo MIN_OVERLAP_TOKENS) {
            if (otherTokens.size <= overlap) continue
            val tail = baseTokens.takeLast(overlap).map(::normalizeWordKey)
            val head = otherTokens.take(overlap).map(::normalizeWordKey)
            if (tail == head) {
                val fused = (baseTokens + otherTokens.drop(overlap)).joinToString(" ")
                return (number?.let { "$it. " } ?: "") + cleanupSpacing(fused)
            }
        }
        return base
    }

    /**
     * Alineación palabra-a-palabra por distancia de edición. Devuelve, para cada token
     * del ancla, el token equivalente de la otra captura o null si esa captura lo perdió.
     * Las inserciones ajenas al ancla se descartan: nunca inventan texto final.
     */
    private fun alignTokensToAnchor(anchor: List<String>, candidate: List<String>): List<String?> {
        val n = anchor.size
        val m = candidate.size
        val dp = Array(n + 1) { IntArray(m + 1) }
        for (i in 0..n) dp[i][0] = i
        for (j in 0..m) dp[0][j] = j

        for (i in 1..n) {
            for (j in 1..m) {
                val a = normalizeWordKey(anchor[i - 1])
                val b = normalizeWordKey(candidate[j - 1])
                val substitute = dp[i - 1][j - 1] + if (a == b) 0 else min(2, editDistance(a, b))
                val delete = dp[i - 1][j] + 1
                val insert = dp[i][j - 1] + 1
                dp[i][j] = min(substitute, min(delete, insert))
            }
        }

        val aligned = MutableList<String?>(n) { null }
        var i = n
        var j = m
        while (i > 0 || j > 0) {
            if (i > 0 && j > 0) {
                val a = normalizeWordKey(anchor[i - 1])
                val b = normalizeWordKey(candidate[j - 1])
                val cost = if (a == b) 0 else min(2, editDistance(a, b))
                if (dp[i][j] == dp[i - 1][j - 1] + cost) {
                    // Solo asociamos palabras razonablemente parecidas. Una sustitución
                    // totalmente distinta se trata como evidencia ausente.
                    val maxLen = max(a.length, b.length).coerceAtLeast(1)
                    val dist = editDistance(a, b)
                    if (a == b || dist <= max(2, maxLen / 3)) aligned[i - 1] = candidate[j - 1]
                    i--
                    j--
                    continue
                }
            }
            if (i > 0 && dp[i][j] == dp[i - 1][j] + 1) {
                i--
            } else if (j > 0) {
                j--
            } else {
                break
            }
        }
        return aligned
    }

    private fun chooseConsensusToken(anchor: String, votes: List<TokenVote>): String {
        if (votes.isEmpty()) return correctTechnicalToken(anchor, allowFuzzy = false)

        val anchorKey = normalizeWordKey(anchor)
        val grouped = linkedMapOf<String, MutableList<TokenVote>>()
        votes.forEach { vote ->
            val key = normalizeWordKey(vote.token)
            if (key.isNotBlank()) grouped.getOrPut(key) { mutableListOf() } += vote
        }
        if (grouped.isEmpty()) return correctTechnicalToken(anchor, allowFuzzy = false)

        val bestEntry = grouped.entries.maxByOrNull { entry ->
            val support = entry.value.sumOf { max(it.weight, 0) + 1 }
            val anchorBonus = if (entry.key == anchorKey) 35 else 0
            support + anchorBonus
        } ?: return correctTechnicalToken(anchor, allowFuzzy = false)

        val representative = bestEntry.value.maxWithOrNull(
            compareBy<TokenVote> { max(it.weight, 0) }
                .thenBy { diacriticBonus(it.token) }
                .thenBy { it.token.length }
        )?.token ?: anchor

        val differentVisualReadings = votes.map { normalizeWordKey(it.token) }.filter { it.isNotBlank() }.distinct().size
        val allowFuzzy = votes.size >= 2 && differentVisualReadings >= 2
        return correctTechnicalToken(representative, allowFuzzy = allowFuzzy)
    }

    private fun postCorrectQuestion(raw: String): String {
        val text = raw.trim()
        if (text.isBlank()) return ""
        // v1.6.15: la corrección de vocabulario se aplica al enunciado. Las líneas
        // siguientes (alternativas, filas de tabla, datos tipo Fe/Pb/Ag) se conservan.
        if (text.contains('\n')) {
            val lines = text.split('\n')
            val head = postCorrectQuestion(lines.first())
            val tail = lines.drop(1).joinToString("\n") { it.trimEnd() }
            return (head + "\n" + tail).trimEnd()
        }
        val number = OcrQuestionExtractor.questionNumber(text)
        val body = text.replace(visibleNumber, "").trim()
        val correctedBody = tokenizeQuestionBody(body)
            .map { correctTechnicalToken(it, allowFuzzy = false) }
            .joinToString(" ")
            .let(::cleanupSpacing)
            .let(::polishQuestionBody)
        return QuestionTextNormalizer.normalize((number?.let { "$it. " } ?: "") + correctedBody)
    }

    private fun polishQuestionBody(raw: String): String {
        var body = raw.trim()
        if (body.isBlank()) return body
        val lowerLead = body.trimStart().lowercase()
        body = when {
            lowerLead.startsWith("¿que") -> body.replaceFirst(Regex("""(?i)^¿?que\b"""), "¿Qué")
            lowerLead.startsWith("¿cual") -> body.replaceFirst(Regex("""(?i)^¿?cual\b"""), "¿Cuál")
            lowerLead.startsWith("¿como") -> body.replaceFirst(Regex("""(?i)^¿?como\b"""), "¿Cómo")
            lowerLead.startsWith("¿donde") -> body.replaceFirst(Regex("""(?i)^¿?donde\b"""), "¿Dónde")
            lowerLead.startsWith("¿cuando") -> body.replaceFirst(Regex("""(?i)^¿?cuando\b"""), "¿Cuándo")
            lowerLead.startsWith("¿quien") -> body.replaceFirst(Regex("""(?i)^¿?quien\b"""), "¿Quién")
            lowerLead.startsWith("¿cuanto") -> body.replaceFirst(Regex("""(?i)^¿?cuanto\b"""), "¿Cuánto")
            else -> body
        }
        body = body.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
        return body.replace(Regex("""(?i)\btopografia\b"""), "topografía")
            .replace(Regex("""(?i)\bmineria\b"""), "minería")
            .replace(Regex("""(?i)\bgeograficas\b"""), "geográficas")
            .replace(Regex("""(?i)\bcoordenadas utm\b"""), "coordenadas UTM")
    }

    private fun correctTechnicalToken(rawToken: String, allowFuzzy: Boolean): String {
        val token = rawToken.trim()
        if (token.isBlank()) return token

        val prefix = leadingPunctuation.find(token)?.value.orEmpty()
        val suffix = trailingPunctuation.find(token)?.value.orEmpty()
        val core = token.removePrefix(prefix).removeSuffix(suffix)
        if (core.isBlank()) return token

        val normalized = normalizeWordKey(core)
        if (normalized.isBlank()) return token

        val exact = lexiconByNormalized[normalized]
        if (exact != null) return prefix + exact + suffix
        if (normalized.all { it.isDigit() } || normalized == "utm") return prefix + core + suffix
        if (!allowFuzzy || normalized.length <= 3) return prefix + core + suffix
        if (core.any { it.isDigit() }) return prefix + core + suffix
        if (core.length <= 6 && core.count { it.isUpperCase() } >= 2) return prefix + core + suffix

        var bestWord: String? = null
        var bestDistance = Int.MAX_VALUE
        technicalLexicon.forEach { candidate ->
            val candidateKey = normalizeWordKey(candidate)
            if (kotlin.math.abs(candidateKey.length - normalized.length) > 3) return@forEach
            val distance = editDistance(normalized, candidateKey)
            if (distance < bestDistance) {
                bestDistance = distance
                bestWord = candidate
            } else if (distance == bestDistance && bestWord != null) {
                if (candidate.length > bestWord!!.length) bestWord = candidate
            }
        }

        val threshold = when {
            normalized.length >= 10 -> 2
            normalized.length >= 7 -> 1
            else -> 1
        }
        val corrected = if (bestDistance <= threshold) bestWord else null
        return prefix + (corrected ?: core) + suffix
    }

    private fun tokenizeQuestionBody(body: String): List<String> {
        return body
            .replace("\n", " ")
            .replace(Regex("[ \\t]+"), " ")
            .trim()
            .split(' ')
            .filter { it.isNotBlank() }
    }

    private fun cleanupSpacing(raw: String): String {
        return raw
            .replace(Regex("\\s+([?.,;:!])"), "$1")
            .replace(Regex("([¿¡])\\s+"), "$1")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun diacriticBonus(raw: String): Int {
        return raw.count { it in "áéíóúÁÉÍÓÚñÑ" }
    }

    private fun normalizeWordKey(raw: String): String {
        val decomposed = Normalizer.normalize(raw.lowercase(), Normalizer.Form.NFD)
        return decomposed
            .replace(Regex("\\p{M}+"), "")
            .replace(Regex("[^a-z0-9]+"), "")
            .trim()
    }

    private fun editDistance(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val temp = dp[j]
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                dp[j] = min(
                    min(dp[j] + 1, dp[j - 1] + 1),
                    prev + cost,
                )
                prev = temp
            }
        }
        return dp[b.length]
    }

    private fun questionQuality(raw: String): Int {
        val text = raw.trim()
        if (text.isBlank()) return Int.MIN_VALUE
        val letters = text.count { it.isLetter() }
        val digits = text.count { it.isDigit() }
        val weird = text.count { ch ->
            !ch.isLetterOrDigit() && !ch.isWhitespace() && ch !in "¿?¡!.,;:()[]{}%/+×÷=\u00b0_-–—'\"\$"
        }
        val optionCount = Regex("(?im)(?:^|\\n)\\s*[A-H][\\)\\].:-]\\s+").findAll(text).count()
        val tableBonus = if (text.contains(OcrTableFormatter.TABLE_START)) 90 else 0
        val questionBonus = if ('?' in text || '¿' in text) 35 else 0
        val completionBonus = if ("___" in text || "....." in text) 10 else 0
        val truncationPenalty = if (text.endsWith("-") || text.endsWith("…")) 18 else 0
        val extraPromptPenalty = extraQuestionPrompts(text) * 24
        return letters * 2 + digits + optionCount * 28 + tableBonus + questionBonus + completionBonus - weird * 10 - truncationPenalty - extraPromptPenalty
    }

    private fun mergeContexts(contexts: List<String>): String {
        if (contexts.isEmpty()) return ""

        val structuredTables = mutableListOf<String>()
        val plainChunks = mutableListOf<String>()

        contexts.forEach { context ->
            val tables = extractTableBlocksLoose(context)
            structuredTables += tables
            val base = removeTableBlocksLoose(context).trim()
            if (base.isNotBlank()) plainChunks += base
        }

        // Dedupe por líneas/frases, preservando el orden aproximado de aparición de
        // las fotos. Es conservador: ante duda mantiene información en vez de borrarla.
        val kept = mutableListOf<String>()
        plainChunks.forEach { chunk ->
            chunk.lines()
                .map { it.replace(Regex("[ \\t]+"), " ").trim() }
                .filter { it.isNotBlank() && !technicalMarker.matches(it) }
                .forEach { line ->
                    val duplicate = kept.any { previous ->
                        val sim = semanticSimilarity(previous, line)
                        sim >= 0.90 || containsMeaningfully(previous, line)
                    }
                    if (!duplicate) kept += line
                }
        }

        val uniqueTables = mutableListOf<String>()
        structuredTables.forEach { table ->
            val duplicate = uniqueTables.any { existing -> semanticSimilarity(existing, table) >= 0.88 }
            if (!duplicate) uniqueTables += table
        }

        return buildString {
            if (kept.isNotEmpty()) append(kept.joinToString("\n"))
            if (uniqueTables.isNotEmpty()) {
                if (isNotEmpty()) append("\n\n")
                append(OcrTableFormatter.STRUCTURED_TABLES_HEADER).append('\n')
                uniqueTables.forEachIndexed { index, table ->
                    if (index > 0) append('\n')
                    append(table.trim()).append('\n')
                }
            }
        }.trim().take(9000)
    }

    private fun extractTableBlocksLoose(raw: String): List<String> {
        val regex = Regex(
            Regex.escape(OcrTableFormatter.TABLE_START) + "(.*?)" + Regex.escape(OcrTableFormatter.TABLE_END),
            setOf(RegexOption.DOT_MATCHES_ALL)
        )
        return regex.findAll(raw).map { match ->
            OcrTableFormatter.TABLE_START + "\n" + match.groupValues[1].trim() + "\n" + OcrTableFormatter.TABLE_END
        }.toList()
    }

    private fun removeTableBlocksLoose(raw: String): String {
        val regex = Regex(
            Regex.escape(OcrTableFormatter.TABLE_START) + ".*?" + Regex.escape(OcrTableFormatter.TABLE_END),
            setOf(RegexOption.DOT_MATCHES_ALL)
        )
        return raw
            .replace(regex, "")
            .replace(OcrTableFormatter.STRUCTURED_TABLES_HEADER, "")
            .trim()
    }

    private fun detectMissingQuestionNumbers(questions: List<String>): List<Int> {
        val ids = questions.mapNotNull(OcrQuestionExtractor::questionNumber).distinct().sorted()
        if (ids.size < 2) return emptyList()

        val primary = selectPrimaryQuestionNumbers(ids)
        if (primary.isEmpty()) return emptyList()
        val ordered = primary.sorted()
        val expectedStart = when {
            ordered.first() == 1 -> 1
            ordered.first() in 2..10 -> 1
            else -> ordered.first()
        }
        val maxId = ordered.last()
        if (maxId - expectedStart > 39) return emptyList()
        val present = ordered.toSet()
        return (expectedStart..maxId).filterNot { it in present }
    }

    private fun buildCombinedRaw(context: String, questions: List<String>): String {
        // Los metadatos de tabla SIEMPRE van al final. OcrTableFormatter usa el
        // encabezado como separador; si una tabla quedara antes de las preguntas,
        // esas preguntas desaparecerían al reconstruir el texto normal.
        val plainContext = OcrTableFormatter.removeStructuredTables(context).trim()
        val tables = OcrTableFormatter.parseStructuredTables(context)
        return buildString {
            append("DOCUMENTO COMBINADO DE VARIAS IMÁGENES")
            if (plainContext.isNotBlank()) {
                append("\n\nCONTEXTO DEL DOCUMENTO\n")
                append(plainContext)
            }
            if (questions.isNotEmpty()) {
                append("\n\nPreguntas:\n")
                append(questions.joinToString("\n\n"))
            }
            if (tables.isNotEmpty()) {
                append("\n\n").append(OcrTableFormatter.STRUCTURED_TABLES_HEADER).append('\n')
                tables.forEachIndexed { index, table ->
                    if (index > 0) append('\n')
                    append(table.trim()).append('\n')
                }
            }
        }.trim()
    }

    private fun buildDisplay(
        context: String,
        questions: List<String>,
        missing: List<Int>,
        imageCount: Int,
    ): String {
        val cleanContext = OcrTableFormatter.toDisplayText(context)
        return buildString {
            append("DOCUMENTO COMBINADO · ").append(imageCount).append(" IMAGEN(ES)")
            if (missing.isNotEmpty()) {
                append("\n⚠ Posibles preguntas faltantes: ")
                append(missing.joinToString(", "))
            }
            if (cleanContext.isNotBlank()) {
                append("\n\nCONTEXTO / DATOS\n")
                append(cleanContext.trim())
            }
            if (questions.isNotEmpty()) {
                append("\n\nPREGUNTAS ORDENADAS\n")
                append(questions.joinToString("\n\n"))
            }
        }.trim()
    }

    private fun extraQuestionPrompts(text: String): Int {
        val body = text.replace(visibleNumber, "").trim()
        if (body.isBlank()) return 0
        val pattern = Regex("""(?i)(?:^|[.\n])\s*(?:¿)?(?:qué|que|cuál|cual|cómo|como|por qué|por que|dónde|donde|menciona|explica|escribe|indica|define|completa|responde|calcula|señala|redacta|describe)\b""")
        val matches = pattern.findAll(body).count()
        return (matches - 1).coerceAtLeast(0)
    }

    private fun selectPrimaryQuestionNumbers(numbers: List<Int>): Set<Int> {
        val sorted = numbers.distinct().sorted()
        if (sorted.isEmpty()) return emptySet()
        data class Segment(val values: MutableList<Int>)
        val segments = mutableListOf<Segment>()
        var current = Segment(mutableListOf(sorted.first()))
        for (i in 1 until sorted.size) {
            val value = sorted[i]
            val prev = current.values.last()
            if (value - prev <= 3) {
                current.values += value
            } else {
                segments += current
                current = Segment(mutableListOf(value))
            }
        }
        segments += current

        val best = segments.maxWithOrNull(
            compareBy<Segment> { segment ->
                val values = segment.values
                val start = values.first()
                val end = values.last()
                val span = (end - start + 1).coerceAtLeast(1)
                val density = values.size.toDouble() / span.toDouble()
                density * 1000 + values.size
            }.thenByDescending { segment ->
                val start = segment.values.first()
                when {
                    start == 1 -> 1000
                    start in 2..10 -> 500 - start
                    else -> -start
                }
            }
        ) ?: return sorted.toSet()
        return best.values.toSet()
    }

    private fun sanitizeQuestionText(raw: String): String {
        var text = raw.trim().replace(Regex("""\n{3,}"""), "\n\n")
        val number = OcrQuestionExtractor.questionNumber(text)
        val body = text.replace(visibleNumber, "").trim()
        if (number != null && isLikelyTableResidue(number, body)) return ""

        if (body.contains('?')) {
            val firstQuestion = body.indexOf('?')
            if (firstQuestion >= 0 && firstQuestion < body.lastIndex) {
                val tail = body.substring(firstQuestion + 1).trim()
                val optionLine = Regex("""(?i)^\s*[A-H][\)\].:-]\s+.+$""")
                val tailLooksLikeOptions = tail.lines().all { line ->
                    line.isBlank() || optionLine.matches(line.trim())
                }
                if (tail.isNotBlank() && !tailLooksLikeOptions) {
                    val trimmedBody = body.substring(0, firstQuestion + 1).trim()
                    text = (number?.let { "$it. " } ?: "") + trimmedBody
                }
            }
        }

        // v1.6.15: solo se colapsan espacios/tabulaciones. Los saltos de línea se
        // conservan porque son los que mantienen juntas las alternativas A)…D) y las
        // filas de una tabla.
        return text
            .replace(Regex("""[ \t]+"""), " ")
            .replace(Regex("""[ \t]*\n[ \t]*"""), "\n")
            .trim()
    }

    private fun isLikelyTableResidue(number: Int, body: String): Boolean {
        val clean = body.trim()
        if (clean.isBlank()) return true
        if (clean.contains('?') || clean.contains('¿')) return false
        val tokens = clean.split(Regex("""\s+|\|"""))
            .map { it.trim(' ', ',', ';') }
            .filter { it.isNotBlank() }
        val shortAlphaNum = Regex("""^[A-Za-z]-?\d+""")
        val numericLike = tokens.count { token -> token.count(Char::isDigit) >= 1 }
        val letterCount = clean.count { it.isLetter() }
        val hasTablePunctuation = '|' in clean || clean.contains("[VAC")
        if (number > 40 && tokens.size <= 4) return true
        if (tokens.size <= 3 && tokens.any { shortAlphaNum.containsMatchIn(it) } && letterCount <= 6) return true
        if (hasTablePunctuation && numericLike >= 2) return true
        return false
    }

    private fun normalizeVisibleQuestion(raw: String): String {
        return raw
            .replace("\r", "")
            .replace(Regex("[ \\t]+"), " ")
            .replace(Regex("\\n{3,}"), "\n\n")
            .trim()
    }

    private fun containsMeaningfully(a: String, b: String): Boolean {
        val na = normalizeForCompare(a)
        val nb = normalizeForCompare(b)
        if (na.length < 18 || nb.length < 18) return false
        val short = if (na.length <= nb.length) na else nb
        val long = if (na.length > nb.length) na else nb
        return short.length >= (long.length * 0.72).toInt() && long.contains(short)
    }

    private fun semanticSimilarity(a: String, b: String): Double {
        val na = normalizeForCompare(a)
        val nb = normalizeForCompare(b)
        if (na.isBlank() || nb.isBlank()) return 0.0
        if (na == nb) return 1.0
        if (na.length >= 18 && nb.length >= 18 && (na.contains(nb) || nb.contains(na))) {
            val ratio = min(na.length, nb.length).toDouble() / max(na.length, nb.length).toDouble()
            if (ratio >= 0.72) return 0.93
        }
        val ta = na.split(' ').filter { it.length >= 2 }.toSet()
        val tb = nb.split(' ').filter { it.length >= 2 }.toSet()
        if (ta.isEmpty() || tb.isEmpty()) return 0.0
        val intersection = ta.intersect(tb).size.toDouble()
        val union = ta.union(tb).size.toDouble().coerceAtLeast(1.0)
        return intersection / union
    }

    private fun normalizeForCompare(raw: String): String {
        val noNumber = raw.replace(visibleNumber, "")
        val decomposed = Normalizer.normalize(noNumber.lowercase(), Normalizer.Form.NFD)
        return decomposed
            .replace(Regex("\\p{M}+"), "")
            .replace(OcrTableFormatter.TABLE_START.lowercase(), " ")
            .replace(OcrTableFormatter.TABLE_END.lowercase(), " ")
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()
            .replace(Regex("\\s+"), " ")
    }
}
