package com.gix.cameraai

import java.text.Normalizer

/**
 * Limpieza final CONSERVADORA de preguntas OCR.
 *
 * No intenta reescribir frases ni adivinar contenido. Solo corrige:
 * - tildes/capitalización de palabras conocidas;
 * - confusiones visuales letra/número cuando el resultado coincide exactamente
 *   con una palabra protegida (p. ej. c0ordenadas -> coordenadas);
 * - siglas técnicas conocidas.
 */
object QuestionTextNormalizer {
    private val visibleNumber = Regex("^\\s*(\\d{1,2})\\s*[\\.)\\-:]\\s*")
    private val leading = Regex("^[¿¡(\"'\\[]+")
    private val trailing = Regex("[?.,;:!¡)\"'\\]]+$")

    private val canonicalWords = linkedSetOf(
        // Interrogativos y verbos frecuentes de examen.
        "qué", "cuál", "cuáles", "cómo", "dónde", "cuándo", "quién", "quiénes", "cuánto", "cuántos", "cuánta", "cuántas",
        "menciona", "mencione", "explica", "explique", "define", "defina", "indica", "indique", "describe", "describa",
        "diferencia", "diferencie", "calcula", "calcule", "determina", "determine", "completa", "complete", "responde", "responda",
        // Vocabulario técnico común en GI X.
        "topografía", "topográfico", "topográfica", "topográficos", "topográficas",
        "minería", "minero", "minera", "mineros", "mineras",
        "coordenada", "coordenadas", "geográfica", "geográficas", "geográfico", "geográficos",
        "instrumento", "instrumentos", "peligro", "peligros", "riesgo", "riesgos", "banco", "marca",
        "nivelación", "nivelacion", "altitud", "elevación", "elevacion", "distancia", "azimut", "rumbo",
        "seguridad", "accidente", "incidente", "protección", "proteccion", "personal", "señalización", "senalizacion",
        "referencia", "galería", "galeria", "labor", "frente", "cota", "punto", "plano", "escala"
    )

    private val canonicalByKey: Map<String, String> = canonicalWords
        .associateBy { wordKey(it) }
        .toMutableMap()
        .apply {
            put("utm", "UTM")
            put("gps", "GPS")
            put("gnss", "GNSS")
            put("ocr", "OCR")
        }

    /**
     * GI X v1.6.15: si la pregunta trae varias líneas (alternativas A)…D), filas de
     * tabla, datos como Fe/Pb/Ag), cada línea se conserva. Antes todo se unía en un
     * solo renglón y una tabla terminaba convertida en un párrafo desordenado.
     */
    fun normalize(raw: String): String {
        if (!raw.contains('\n')) return normalizeLine(raw)

        val lines = raw.replace("\r\n", "\n").replace('\r', '\n').split('\n')
        val head = normalizeLine(lines.first())
        val tail = lines.drop(1).map { line -> line.replace(Regex("[ \\t]+"), " ").trimEnd() }
        return (listOf(head) + tail).joinToString("\n").trimEnd()
    }

    private fun normalizeLine(raw: String): String {
        var text = raw.replace('\r', ' ').replace(Regex("[ \\t]+"), " ").trim()
        if (text.isBlank()) return text

        val number = visibleNumber.find(text)?.groupValues?.getOrNull(1)?.toIntOrNull()
        var body = text.replace(visibleNumber, "").trim()
        if (body.isBlank()) return text

        body = body.split(Regex("\\s+"))
            .filter { it.isNotBlank() }
            .joinToString(" ") { normalizeToken(it) }
            .replace(Regex("\\s+([?.,;:!])"), "$1")
            .replace(Regex("([¿¡])\\s+"), "$1")
            .trim()

        body = normalizeInterrogativeStart(body)
        body = capitalizeQuestionStart(body)
        return (number?.let { "$it. " } ?: "") + body
    }

    private fun normalizeToken(raw: String): String {
        val prefix = leading.find(raw)?.value.orEmpty()
        val suffix = trailing.find(raw)?.value.orEmpty()
        val core = raw.removePrefix(prefix).removeSuffix(suffix)
        if (core.isBlank()) return raw

        val directKey = wordKey(core)
        canonicalByKey[directKey]?.let { return prefix + it + suffix }

        // Solo tocamos dígitos dentro de una palabra cuando la sustitución lleva
        // exactamente a una palabra protegida. Números, coordenadas y fórmulas quedan intactos.
        if (core.any(Char::isLetter) && core.any(Char::isDigit)) {
            val common = buildString(core.length) {
                core.forEach { ch ->
                    append(when (ch) {
                        '0' -> 'o'
                        '5' -> 's'
                        '8' -> 'b'
                        else -> ch
                    })
                }
            }
            val candidates = linkedSetOf(
                common,
                common.replace('1', 'i'),
                common.replace('1', 'l'),
            )
            val matches = candidates.mapNotNull { candidate -> canonicalByKey[wordKey(candidate)] }.distinct()
            if (matches.size == 1) return prefix + matches.first() + suffix

            // Si el OCR además perdió UNA letra (pelig0 -> peligro), permitimos una
            // sola edición adicional, únicamente contra el vocabulario protegido.
            if (core.count(Char::isDigit) == 1 && core.count(Char::isLetter) >= 4) {
                val fuzzyMatches = candidates.flatMap { candidate ->
                    val key = wordKey(candidate)
                    canonicalByKey.entries
                        .filter { (candidateKey, _) -> kotlin.math.abs(candidateKey.length - key.length) <= 1 }
                        .filter { (candidateKey, _) -> editDistance(key, candidateKey) <= 1 }
                        .map { it.value }
                }.distinct()
                if (fuzzyMatches.size == 1) return prefix + fuzzyMatches.first() + suffix
            }
        }

        return prefix + core + suffix
    }

    private fun capitalizeQuestionStart(raw: String): String {
        if (raw.isBlank()) return raw
        val chars = raw.toCharArray()
        var index = 0
        while (index < chars.size && chars[index] in "¿¡\"'(") index++
        if (index < chars.size && chars[index].isLowerCase()) {
            val upper = chars[index].uppercaseChar()
            chars[index] = upper
        }
        return String(chars)
    }

    private fun normalizeInterrogativeStart(raw: String): String {
        var body = raw.trim()
        val replacements = listOf(
            Regex("""(?i)^¿?que\b""") to "¿Qué",
            Regex("""(?i)^¿?cual\b""") to "¿Cuál",
            Regex("""(?i)^¿?cuales\b""") to "¿Cuáles",
            Regex("""(?i)^¿?como\b""") to "¿Cómo",
            Regex("""(?i)^¿?donde\b""") to "¿Dónde",
            Regex("""(?i)^¿?cuando\b""") to "¿Cuándo",
            Regex("""(?i)^¿?quien\b""") to "¿Quién",
            Regex("""(?i)^¿?quienes\b""") to "¿Quiénes",
            Regex("""(?i)^¿?cuanto\b""") to "¿Cuánto"
        )
        for ((regex, replacement) in replacements) {
            if (regex.containsMatchIn(body)) {
                body = body.replaceFirst(regex, replacement)
                break
            }
        }
        return body
    }

    private fun editDistance(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        val row = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = row[0]
            row[0] = i
            for (j in 1..b.length) {
                val old = row[j]
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                row[j] = minOf(row[j] + 1, row[j - 1] + 1, prev + cost)
                prev = old
            }
        }
        return row[b.length]
    }

    private fun wordKey(raw: String): String {
        return Normalizer.normalize(raw.lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .replace(Regex("[^a-z0-9]+"), "")
    }
}
