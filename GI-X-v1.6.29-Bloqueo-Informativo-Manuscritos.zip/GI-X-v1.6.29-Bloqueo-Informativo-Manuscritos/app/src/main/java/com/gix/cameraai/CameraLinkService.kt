package com.gix.cameraai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat

/** Enlace Wi-Fi independiente de la Activity; SOLO escucha/guarda fotos.
 *  El OCR, la API y TTS siguen en MainActivity mientras esté abierta.
 */
class CameraLinkService : Service(), CameraBridgeServer.Listener {
    private lateinit var journal: CameraPhotoJournal
    private lateinit var power: PowerManager
    private var wakeLock: PowerManager.WakeLock? = null
    private var wakeLockRenewedAt = 0L
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var server: CameraBridgeServer? = null
    private var stoppedByUser = false
    private var nextRestartAt = 0L
    @Volatile private var restartDelayMs = 5_000L
    private val health = object : Runnable {
        override fun run() {
            if (stoppedByUser) return
            refreshWakeLock()
            if (server?.isListening() != true && System.currentTimeMillis() >= nextRestartAt) {
                recreateServer()
            }
            handler.postDelayed(this, 5_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        journal = CameraPhotoJournal(this)
        power = getSystemService(Context.POWER_SERVICE) as PowerManager
        active = this
        val notifications = getSystemService(NotificationManager::class.java)
        notifications.createNotificationChannel(NotificationChannel(
            CHANNEL, "GI X · Cámara conectada", NotificationManager.IMPORTANCE_LOW
        ))
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_logo_small)
            .setContentTitle("GI X · Cámara a la espera")
            .setContentText("Recepción Wi-Fi activa. Abre GI X para IA y voz.")
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        } else startForeground(NOTIFICATION_ID, notification)
        refreshWakeLock()
        handler.post(health)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stoppedByUser = true
            stopSelf()
            return START_NOT_STICKY
        }
        stoppedByUser = false
        if (server?.isListening() != true) recreateServer()
        return START_STICKY // Tras muerte de proceso, Android PUEDE reiniciar el enlace.
    }

    private fun refreshWakeLock() {
        // Conservamos pantalla encendida en MainActivity; esto es respaldo de CPU.
        val lock = wakeLock ?: power.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK, "GIX:CameraReception"
        ).also { wakeLock = it }
        val now = System.currentTimeMillis()
        if (!lock.isHeld || now - wakeLockRenewedAt >= 6 * 60 * 1000L) {
            if (lock.isHeld) lock.release()
            lock.acquire(12 * 60 * 1000L)
            wakeLockRenewedAt = now
        }
        // Se renueva ANTES del timeout; el timeout es respaldo si Android mata el servicio.
    }

    private fun recreateServer() {
        val now = System.currentTimeMillis()
        if (now < nextRestartAt) return
        server?.stop()
        server = CameraBridgeServer(CameraBridgeServer.DEFAULT_PORT,
            tokenProvider = { AppPrefs(this).pairingToken }, listener = this)
        server?.start()
        nextRestartAt = now + restartDelayMs
        restartDelayMs = (restartDelayMs * 2).coerceAtMost(60_000L)
    }

    override fun onServerStarted(port: Int) {
        restartDelayMs = 5_000L
        observer?.onServerStarted(port)
    }
    override fun onServerError(message: String) {
        observer?.onServerError(message)
    }
    override fun onCameraSeen() { observer?.onCameraSeen() }
    override fun onPhotoReceived(jpeg: ByteArray, requestId: String?) {
        if (CameraJpegDecoder.inspect(jpeg) == null) {
            throw IllegalArgumentException("JPEG inválido; no se confirma recepción")
        }
        // La devolución HTTP 200 solo ocurre si este guardado se completa sin error.
        journal.save(jpeg, requestId)
        // Una UI ya destruida no debe forzar reenvíos: el JPEG está en el diario.
        runCatching { observer?.onPhotoReceived(jpeg, requestId) }
    }

    override fun onDestroy() {
        stoppedByUser = true
        handler.removeCallbacksAndMessages(null)
        server?.stop()
        server = null
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        if (active === this) active = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL = "gix_camera_monitor_v1"
        private const val NOTIFICATION_ID = 8765
        const val ACTION_STOP = "com.gix.cameraai.STOP_CAMERA_LINK"
        @Volatile private var active: CameraLinkService? = null
        @Volatile private var observer: CameraBridgeServer.Listener? = null
        fun attach(listener: CameraBridgeServer.Listener) { observer = listener }
        fun detach(listener: CameraBridgeServer.Listener) {
            if (observer === listener) observer = null
        }
        fun currentServer(): CameraBridgeServer? = active?.server
    }
}
