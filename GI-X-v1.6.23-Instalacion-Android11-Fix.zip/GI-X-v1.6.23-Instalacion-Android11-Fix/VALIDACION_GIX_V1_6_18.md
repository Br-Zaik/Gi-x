# GI X v1.6.18 · Orden por especialidad entre los motores + APK más liviana

Versión:
- versionCode: 43
- versionName: 1.6.18
- Sin motores nuevos. Sin cambios en package, API, diseño ni firmware.

## 1. Reparto de trabajo (lo que antes faltaba)

Los tres motores ya estaban, pero al final competían: cada uno entregaba un texto completo y
GI X elegía uno. Ahora se reparten el trabajo por especialidad.

- OpenCV: geometría de la hoja. No lee texto.
- ML Kit: geometría del texto. Aporta el ORDEN de lectura, columnas y tablas.
- PP-OCRv6 Small: precisión de CARACTERES, sobre todo en letra pequeña, dígitos y símbolos.
- Lógica de GI X: estructura, tipo de ejercicio y payload.

Archivo nuevo: `OcrLayoutFusion.kt`.
- Toma el esqueleto ordenado de ML Kit.
- Para cada renglón busca la lectura de PP-OCR del MISMO renglón (similitud ≥ 0.62 sobre texto
  normalizado sin tildes).
- Sustituye el renglón por el de PP-OCR solo si su confianza es ≥ 0.80 y aporta algo:
  al menos 3 caracteres útiles más, o más dígitos/símbolos con confianza ≥ 0.92.
- Renglones casi idénticos se quedan con ML Kit, para no perder tildes ni el espaciado que ya
  resolvió la geometría.
- Los bloques de tabla de ML Kit no se tocan.
- Lo que PP-OCR leyó y ML Kit no vio se añade al final si tiene confianza alta y contenido real.

Integración en `OcrProcessor.kt`:
- `PaddleCandidate` ahora conserva las lecturas individuales con su confianza
  (`lines: List<OcrLayoutFusion.PaddleLine>`), que antes se perdían al unirlas en un solo texto.
- `chooseHybrid` intenta primero la fusión por capas. Se acepta solo si el resultado iguala o
  supera la puntuación de estructura de los dos motores por separado y la numeración no queda
  corrupta. Si no, sigue exactamente la lógica anterior.
- Se registra en el log `06B_LAYOUT_FUSION` cuántos renglones vinieron de cada motor.

## 2. Peso de la APK

El peso no venía de los modelos PP-OCRv6 (los `.onnx` small son pocos MB), sino de las librerías
nativas duplicadas por arquitectura: ONNX Runtime y OpenCV se incluían para arm64-v8a,
armeabi-v7a, x86 y x86_64, y x86/x86_64 solo sirven para emulador.

- `app/build.gradle`: `ndk { abiFilters 'arm64-v8a' }`.
- Efecto esperado: la APK debería quedar en el orden de la cuarta parte. No puedo medirlo aquí
  porque la compilación ocurre en GitHub Actions; el número real se verá en el artefacto.
- Contrapartida: la APK solo instalará en celulares arm64 (prácticamente todos los actuales).
  Para volver a soportar 32 bits basta añadir `'armeabi-v7a'` en esa misma línea.
- Los modelos siguen locales: GI X no manda imágenes a ningún servidor de OCR.

## Archivos de esta versión
1. `app/src/main/java/com/gix/cameraai/OcrLayoutFusion.kt` (NUEVO).
2. `app/src/main/java/com/gix/cameraai/OcrProcessor.kt` — lecturas por renglón + fusión por capas.
3. `app/build.gradle` — abiFilters arm64-v8a, versionCode 43, versionName 1.6.18.
4. `ARQUITECTURA_OCR_V1_6_18.md` (NUEVO) — orden de trabajo escrito.

## Pruebas realizadas
- Balance de bloques de los archivos modificados: sin desbalances.
- Revisión del diff frente a v1.6.17: solo cambian los archivos listados.

## Pendiente
- Compilación en GitHub Actions: aquí no hay SDK de Android ni compilador de Kotlin.
- Medir en el celular cuántos renglones acaba aportando cada motor (queda en el log
  `06B_LAYOUT_FUSION`) y el tamaño final de la APK.

## Corrección del workflow de GitHub Actions (añadido)

El fallo "Android SDK / failed in 16s" no era del proyecto: era del paso
`android-actions/setup-android@v3`. En el log se ve la secuencia:
`Found preinstalled sdkmanager ... Pkg.Revision=12.0` → `Wrong version in preinstalled sdkmanager`
→ descarga `commandlinetools-linux-12266719` → `sdkmanager --licenses` → `failed with exit code 1`
en "10% Computing updates".

El runner de Ubuntu ya trae el Android SDK en `/usr/local/lib/android/sdk` (aparece en ese mismo
log), así que ese paso era innecesario. Cambios en `.github/workflows/compilar_zip.yml` y
`.github/workflows/build-apk.yml`:

- Se elimina `android-actions/setup-android@v3`.
- Paso nuevo "Android SDK del runner": usa `ANDROID_SDK_ROOT` / `ANDROID_HOME` o
  `/usr/local/lib/android/sdk`, exporta las variables y escribe `local.properties` con `sdk.dir`.
  Solo falla si de verdad no hay SDK en el runner.
- Paso nuevo "Licencias y paquetes": busca el `sdkmanager` que exista en el runner, acepta
  licencias e instala `platforms;android-34` + `build-tools;34.0.0`, pero cualquier error queda
  como aviso y no corta la compilación (las licencias ya vienen aceptadas en la imagen y Gradle
  puede descargar lo que falte).
- `gradle ... --stacktrace` y un paso "Tamaño de la APK" con `ls -lh`, para ver de una vez el
  efecto de `abiFilters 'arm64-v8a'`.

IMPORTANTE: el workflow que se ejecuta es el del repositorio, no el del ZIP. Hay que reemplazar el
contenido de `.github/workflows/compilar_zip.yml` en GitHub con la versión corregida.
