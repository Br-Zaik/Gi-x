# GI X v1.6.16 · Enviar lo detectado a la API + no salir de la app por error

Versión:
- versionCode: 41
- versionName: 1.6.16
- Incluye todo lo de v1.6.15 (segmentación de preguntas, fusión por solape, tipo de examen).
- Sin cambios en package, API, diseño general ni firmware respecto a v1.6.15.

## 1. La API ahora sí recibe las preguntas detectadas

Antes, si faltaba una pregunta (por ejemplo la 1, porque la foto no llegó a la cabecera de la
hoja), GI X cancelaba la consulta y el examen se quedaba sin respuestas.

- `OcrQuestionExtractor.hasCorruptNumbering()` (NUEVO): detecta solo numeración repetida o fuera
  de orden, que es lo que de verdad significa una reconstrucción fallida.
- `MainActivity`: un hueco en la numeración ya NO cancela nada. Se consulta la API con las
  preguntas identificadas y en el estado aparece "Falta(n) 1: se responden solo las detectadas".
- La consulta se cancela únicamente si la numeración está corrupta (por ejemplo 4, 3, 7, 3),
  porque ahí las respuestas quedarían asignadas a la pregunta equivocada.
- `hasSuspiciousNumbering` se mantiene tal cual donde sirve: elegir entre la lectura de PP-OCR y
  la de ML Kit dentro de `OcrProcessor`.

## 2. La app no se sale por error

El celular se queda con GI X abierto todo el examen esperando las fotos de la cámara, así que
cualquier toque accidental en los botones de navegación rompía el ciclo.

- **ATRÁS pide 3 pulsaciones seguidas** (ventana de 6 s). La 1.ª y la 2.ª solo avisan, en el
  estado y con un aviso corto en pantalla.
- **Tras la 3.ª aparece una confirmación**: "Seguir esperando fotos" / "Salir de todos modos".
  Es decir: 3 pulsaciones + 1 confirmación.
- **Casilla "Bloquear GI X en pantalla"** (nueva, dentro del bloque de cámara): usa el anclaje de
  pantalla de Android (`startLockTask` / `stopLockTask`), que es la única forma legítima de que
  INICIO y RECIENTES no saquen la app. Si el celular no lo permite, GI X lo dice y sigue
  protegido por la confirmación de ATRÁS. Para liberar la pantalla se desmarca la casilla.
- **Pantalla siempre encendida en modo CÁMARA**, no solo con AUTO en ON. Con DETENER sí se
  permite que la pantalla descanse, salvo que el bloqueo esté activado.
- `onUserLeaveHint` avisa si la app queda en segundo plano con el bloqueo pedido.

## Archivos modificados en esta versión
1. `app/src/main/java/com/gix/cameraai/OcrQuestionExtractor.kt` — nuevo `hasCorruptNumbering`.
2. `app/src/main/java/com/gix/cameraai/MainActivity.kt` — envío a la API con aviso de faltantes,
   `onBackPressed` con 3 confirmaciones, `confirmExitApp`, `setScreenLock`,
   `releaseScreenAwakeIfAllowed`, `onUserLeaveHint`, pantalla encendida en modo cámara.
3. `app/src/main/res/layout/activity_main.xml` — casilla `cbLockApp`.
4. `app/build.gradle` — versionCode 41, versionName 1.6.16.

## Pruebas realizadas
- XML del layout validado como documento bien formado.
- Balance de bloques de `MainActivity.kt` y `OcrQuestionExtractor.kt` comparado con el archivo
  original: sin desbalances nuevos.
- Diff archivo por archivo frente a v1.6.14: solo cambian los archivos listados en este
  documento y en `VALIDACION_GIX_V1_6_15.md`.

## Pendiente de comprobar en el celular
- Compilación completa en GitHub Actions: aquí no hay SDK de Android ni compilador de Kotlin.
- El anclaje de pantalla depende del celular y de si el sistema pide confirmación la primera vez.
- Falta medir con un examen real cuántas preguntas identifica el OCR ahora que la consulta ya no
  se cancela por huecos de numeración.
