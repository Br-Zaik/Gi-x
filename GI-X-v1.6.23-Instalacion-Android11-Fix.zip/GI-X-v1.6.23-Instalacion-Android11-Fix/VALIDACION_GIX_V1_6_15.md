# GI X v1.6.15 · Segmentación real de preguntas + exposición de cámara

Versión:
- versionCode: 40
- versionName: 1.6.15
- applicationId/namespace: com.gix.cameraai (sin cambios)
- API, diseño y demás funciones: sin cambios

## Archivos modificados / nuevos

1. `app/src/main/java/com/gix/cameraai/QuestionBoundarySplitter.kt` (NUEVO)
   - Separa marcadores de pregunta pegados dentro de un mismo renglón del OCR.
   - Formatos reconocidos: `1.` `1)` `1-` `1.-` `1:` `01.` `Pregunta 1` `Ítem 1` `Ejercicio 1`.
   - Guardas genéricas: el número no puede ir pegado a letra o dígito (descarta `A1`, `A2`, `N240`),
     el delimitador es obligatorio (descarta `480 mm`), después del delimitador no puede venir un
     dígito (descarta `1:1000` y `3.5`), y la coma no es delimitador (descarta "los procesos 1, 2 y 3").
   - Guarda de secuencia: un marcador a mitad de línea se acepta si continúa la numeración
     (`n+1`) o si hay un salto pequeño con un enunciado de al menos 12 letras.
   - No contiene ningún texto de examen ni corrección escrita a mano.

2. `app/src/main/java/com/gix/cameraai/ExamStructureDetector.kt` (NUEVO)
   - Clasifica cada pregunta: Verdadero/Falso (cierres `( )`), Completar (puntos/guiones bajos),
     Alternativas (dos o más letras `A)…H)`, en línea aparte o en el mismo renglón), Tabla
     (bloque `[GIX_TABLE_START]`), Pregunta abierta.
   - Decide el tipo del documento por mayoría (60 %) y devuelve `Mixto` cuando conviven varios.
   - Genera la línea `TIPO: ...` que ahora viaja en el payload.

3. `app/src/main/java/com/gix/cameraai/OcrQuestionExtractor.kt`
   - `extractQuestions` pasa el texto por `QuestionBoundarySplitter` antes de segmentar por líneas.
     Esta era la causa del error de v1.6.14: la expresión regular de numeración está anclada al
     inicio de línea, así que 4+5+6+7 en un mismo renglón quedaban dentro de la pregunta 4.
   - Se reactiva `attachStructuredTables`, ya después de normalizar, y solo sobre preguntas que
     piden tabla. Si no hay pregunta de tabla, la tabla no se convierte en pregunta extra.
   - `buildQueryPayload` añade `TIPO: ...` antes de `Preguntas:` (no altera el conteo de preguntas
     que hace `OnlineAnswerProvider`, que lee a partir de `Preguntas:`).
   - `looksLikeCompletion` reconoce cualquier línea de puntos de 4 o más, no solo `.....`.

4. `app/src/main/java/com/gix/cameraai/QuestionTextNormalizer.kt`
   - `normalize` trabaja por líneas: corrige el enunciado y conserva las líneas siguientes
     (alternativas, filas de tabla, datos como `Fe` `Pb` `Ag`). Antes todo se unía en un renglón.

5. `app/src/main/java/com/gix/cameraai/MultiImageDocumentMerger.kt`
   - Fusión por solape literal: `stitchReadings` / `extendWithOverlap` unen la lectura base con la
     cola o la cabecera que aporta otra toma cuando coinciden al menos 4 palabras consecutivas.
     Todo el texto proviene de una captura real; nunca se pegan preguntas distintas ni se inventa.
   - `sanitizeQuestionText` y `postCorrectQuestion` ya no destruyen los saltos de línea.
   - Nuevos campos en `MergeResult`: `notPhotographedNumbers`, `unreadableNumbers`, `coverageNote`.
     Se calculan comparando cada número faltante con el rango de números que sí vio cada foto:
     dentro del rango fotografiado = el OCR no pudo leerlo; fuera = esa zona no fue fotografiada.

6. `app/src/main/java/com/gix/cameraai/MainActivity.kt`
   - Cambio mínimo: guarda `merge.coverageNote` y lo muestra en el aviso de documento incompleto,
     para distinguir "hay que reencuadrar la hoja" de "mejora luz/enfoque".

7. `camera_firmware/TimerCameraX_GIX.ino`
   - Resolución: se mantiene `FRAMESIZE_UXGA` = 1600×1200 reales (1.92 MP) y se imprime por serie
     `fb->width x fb->height` para confirmarlo en cada captura. No hay reescalado en el firmware.
   - Exposición corregida en el sensor, no con filtros: `set_exposure_ctrl(1)`, `set_aec2(1)`,
     `set_ae_level(+1)`, `set_gain_ctrl(1)`, `set_gainceiling(16X)`, `set_whitebal(1)`,
     `set_awb_gain(1)`, `set_wb_mode(0)`, `set_lenc(1)`, `set_bpc(1)`, `set_wpc(1)`,
     `set_raw_gma(1)`, `set_brightness(+1)`, `set_contrast(+1)`, `set_saturation(-1)`.
   - Estabilización real de 1500 ms descartando frames antes de la foto útil (antes ~700 ms).
   - Un único reintento por subexposición evidente: si el JPEG a 1600×1200 pesa menos de 45 KB,
     sube `ae_level`/`brightness` un paso, reestabiliza 700 ms y sustituye la captura. Sigue
     entregándose UNA sola foto por encendido.

8. `app/build.gradle`: versionCode 40, versionName 1.6.15.

## Qué NO se cambió
- No se añadió ningún motor OCR nuevo: se siguen usando PP-OCRv6 Small, ML Kit y OpenCV.
- No hay correcciones escritas a mano de preguntas concretas de los exámenes de prueba.
- No se tocó el package, la API, el diseño ni el resto de funciones.
- No se cambiaron los timeouts ni los límites de pasadas del pipeline.

## Pruebas realizadas
- Lógica del separador de preguntas ejecutada en un script equivalente (mismas expresiones
  regulares, mismo motor) con los textos reales del examen de Topografía pegado en un solo
  renglón, la hoja V/F de Cloud Computing, la hoja de completar con líneas de puntos, un caso de
  alternativas y un caso con salto de numeración. Resultado: 7 preguntas separadas correctamente,
  `1:1000`, `480 mm`, `A1`, `A2`, `N240`, `3.5`, `2 - 3` y "los procesos 1, 2 y 3" no generaron
  cortes falsos.
- Resolución de las 7 fotos entregadas por la TimerCamera-X leída de las cabeceras JPEG:
  1600×1200 en todas. Brillo medio: 141–146 en el primer grupo y 91–100 en el segundo (de 255),
  que es la subexposición que corrige esta versión.
- Revisión del diff archivo por archivo contra el ZIP de v1.6.14: solo cambian los 8 archivos
  listados arriba.

## Pendiente de comprobar en dispositivo
- La compilación completa de Android debe ejecutarse en GitHub Actions: este entorno no tiene
  SDK de Android ni compilador de Kotlin, así que los cambios de Kotlin no están compilados.
- Falta medir en la cámara real el efecto de la nueva exposición y confirmar en el monitor serie
  la línea "Resolucion real entregada: 1600 x 1200".

## Observación sobre el encuadre
Ninguna de las tomas recibidas incluye la pregunta 1 ni el título de la hoja: las cuatro empiezan
en la 2 o la 3. Eso no lo puede arreglar el software; la app ahora lo dice explícitamente en vez de
pedir "otra foto de la zona faltante" sin explicar que hay que reencuadrar o alejar la cámara.
