# GI X v1.6.18 — Orden de trabajo de los motores

## Regla base: cada motor hace SOLO lo que hace mejor

1. **OpenCV — geometría de la hoja.** Detecta el papel, corrige perspectiva, recorta,
   normaliza iluminación y mide brillo/contraste/nitidez. Nunca lee texto.
2. **ML Kit — geometría del TEXTO (esqueleto).** Devuelve bloques y líneas con coordenadas,
   así que aporta el orden de lectura, las columnas y las tablas. Es rápido y ligero.
3. **PP-OCRv6 Small — caracteres (contenido).** Es el más preciso en letra pequeña, poco
   contraste, dígitos y símbolos, pero entrega sus lecturas en orden de detección, sin orden
   de lectura garantizado.
4. **Lógica propia de GI X — estructura.** Separa preguntas, detecta el tipo de ejercicio,
   fusiona las fotos y arma el payload.

## Secuencia por imagen

1. Decodificar con límite de resolución y corregir EXIF.
2. Normalizar a resolución de trabajo.
3. OpenCV: detectar hoja → perspectiva → recorte conservador si no hay cuadrilátero fiable.
4. OpenCV: medir calidad sobre la hoja, no sobre el escritorio.
5. OpenCV: preparación conservadora (fondo, CLAHE suave, enfoque mínimo).
6. PP-OCRv6 sobre la hoja preparada.
7. ML Kit sobre la hoja rectificada, siempre, como lector independiente.
8. **Fusión por capas (nuevo):** se toma el esqueleto de ML Kit y, renglón por renglón, se
   sustituye el texto por el de PP-OCR cuando esa lectura corresponde al mismo renglón
   (similitud ≥ 0.62) y viene con confianza ≥ 0.80 aportando algo: más caracteres útiles, o
   más dígitos y símbolos con confianza ≥ 0.92. Los bloques de tabla de ML Kit no se tocan.
   Lo que PP-OCR leyó y ML Kit no vio se añade al final si tiene confianza alta.
   La fusión se acepta solo si iguala o supera a los dos motores por separado y la numeración
   no queda corrupta; si no, se usa la lógica anterior sin cambios.
9. Como máximo una segunda variante visual.
10. Binarización adaptativa solo como último rescate.
11. Segmentación de preguntas, tipo de examen y payload.

## Lotes de 1–4 imágenes
- Una imagen a la vez, empezando por la de mejor calidad.
- Las preguntas se alinean por número impreso y se fusionan por solape literal de palabras.
- Ninguna salida agrega contenido que no exista en alguna captura.

## Límites de estabilidad (sin cambios)
- PP-OCRv6: 7 s por pasada, máximo 3 pasadas por imagen.
- ML Kit: 6 s por pasada, máximo 2 pasadas por imagen.
- Presupuesto del pipeline por imagen: ~16 s antes de rescates.
- Una sola inferencia pesada activa a la vez.

## Tamaño de la APK
- El peso venía de las librerías nativas duplicadas por arquitectura (ONNX Runtime + OpenCV
  para arm64-v8a, armeabi-v7a, x86 y x86_64), no de los modelos PP-OCRv6.
- v1.6.18 compila solo `arm64-v8a`, que es lo que usan los celulares actuales.
- Los modelos siguen locales: GI X no manda imágenes a ningún servidor de OCR.
