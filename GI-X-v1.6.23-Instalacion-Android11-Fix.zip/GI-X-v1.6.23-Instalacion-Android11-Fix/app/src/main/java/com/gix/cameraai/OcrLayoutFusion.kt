package com.gix.cameraai

import java.text.Normalizer
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Reparto de trabajo entre los motores que YA están dentro de GI X, por especialidad:
 *
 * - OpenCV: geometría de la hoja (perspectiva, recorte, iluminación). No lee texto.
 * - ML Kit: geometría del TEXTO. Devuelve bloques y líneas con coordenadas, así que sabe
 *   el orden de lectura, las columnas y dónde empieza cada renglón. Es el ESQUELETO.
 * - PP-OCRv6 Small: precisión de CARACTERES en texto pequeño o con poco contraste, pero
 *   sus resultados llegan en orden de detección, sin garantía de orden de lectura.
 *
 * Esta clase usa el esqueleto de ML Kit y, renglón por renglón, se queda con los
 * caracteres de PP-OCR cuando esa lectura es del mismo renglón y viene con mejor
 * confianza. Nada se inventa: cada línea final proviene de uno de los dos motores.
 */
object OcrLayoutFusion {

    data class PaddleLine(
        val text: String,
        val confidence: Float,
    )

    data class FusionResult(
        val text: String,
        val linesFromPaddle: Int,
        val linesFromMlKit: Int,
        val paddleLinesAppended: Int,
    ) {
        val usedLines: Int get() = linesFromPaddle + linesFromMlKit + paddleLinesAppended
    }

    /** Similitud mínima para considerar que dos lecturas son el MISMO renglón. */
    private const val SAME_LINE_SIMILARITY = 0.62
    /** Ventaja que debe tener PP-OCR para pisar el renglón de ML Kit. */
    private const val PADDLE_CONFIDENCE_FLOOR = 0.80f

    /**
     * @param mlFormatted texto ya ordenado por ML Kit (incluye bloques de tabla).
     * @param paddleLines lecturas individuales de PP-OCR con su confianza.
     */
    fun fuse(mlFormatted: String, paddleLines: List<PaddleLine>): FusionResult? {
        if (mlFormatted.isBlank() || paddleLines.isEmpty()) return null

        // Los bloques de tabla ya vienen resueltos por geometría: no se tocan.
        val tableBlocks = OcrTableFormatter.parseStructuredTables(mlFormatted)
        val skeleton = OcrTableFormatter.removeStructuredTables(mlFormatted)
        val skeletonLines = skeleton.lines()
        if (skeletonLines.none { it.isNotBlank() }) return null

        val available = paddleLines
            .filter { it.text.isNotBlank() }
            .map { it.copy(text = it.text.trim()) }
            .toMutableList()
        val consumed = BooleanArray(available.size)

        var fromPaddle = 0
        var fromMlKit = 0
        val fused = ArrayList<String>(skeletonLines.size + available.size)

        for (rawLine in skeletonLines) {
            val mlLine = rawLine.trim()
            if (mlLine.isEmpty()) {
                fused += ""
                continue
            }

            var bestIndex = -1
            var bestScore = 0.0
            for (index in available.indices) {
                if (consumed[index]) continue
                val candidate = available[index]
                val similarity = similarity(mlLine, candidate.text)
                if (similarity >= SAME_LINE_SIMILARITY && similarity > bestScore) {
                    bestScore = similarity
                    bestIndex = index
                }
            }

            if (bestIndex < 0) {
                fused += mlLine
                fromMlKit++
                continue
            }

            consumed[bestIndex] = true
            val paddleLine = available[bestIndex]
            if (preferPaddle(mlLine, paddleLine, bestScore)) {
                fused += paddleLine.text
                fromPaddle++
            } else {
                fused += mlLine
                fromMlKit++
            }
        }

        // Lo que PP-OCR leyó y ML Kit no vio no se descarta: se añade al final para que
        // la segmentación de preguntas pueda recuperarlo.
        var appended = 0
        for (index in available.indices) {
            if (consumed[index]) continue
            val leftover = available[index]
            if (leftover.confidence < PADDLE_CONFIDENCE_FLOOR) continue
            if (leftover.text.count { it.isLetterOrDigit() } < 6) continue
            fused += leftover.text
            appended++
        }

        val body = fused.joinToString("\n").replace(Regex("\n{3,}"), "\n\n").trim()
        if (body.isBlank()) return null

        val withTables = if (tableBlocks.isEmpty()) {
            body
        } else {
            buildString {
                append(body)
                append("\n\n").append(OcrTableFormatter.STRUCTURED_TABLES_HEADER).append('\n')
                tableBlocks.forEachIndexed { index, table ->
                    if (index > 0) append('\n')
                    append(table.trim()).append('\n')
                }
            }.trim()
        }

        return FusionResult(withTables, fromPaddle, fromMlKit, appended)
    }

    /**
     * PP-OCR solo pisa el renglón de ML Kit si su confianza es alta y aporta algo: más
     * caracteres útiles, o corrige dígitos y símbolos cuando ML Kit dejó el renglón corto.
     */
    private fun preferPaddle(mlLine: String, paddle: PaddleLine, similarity: Double): Boolean {
        if (paddle.confidence < PADDLE_CONFIDENCE_FLOOR) return false

        val mlUseful = mlLine.count { it.isLetterOrDigit() }
        val paddleUseful = paddle.text.count { it.isLetterOrDigit() }
        if (paddleUseful == 0) return false

        // Renglones casi idénticos: se queda el de ML Kit para no perder tildes ni el
        // espaciado que ya respetó la geometría.
        if (similarity >= 0.97 && abs(mlUseful - paddleUseful) <= 1) return false

        // PP-OCR recuperó texto que ML Kit dejó fuera del renglón.
        if (paddleUseful >= mlUseful + 3) return true

        // Datos técnicos: si PP-OCR trae más dígitos o símbolos con confianza alta,
        // suele ser una escala, una unidad o un símbolo químico que ML Kit perdió.
        val mlTechnical = mlLine.count { it.isDigit() || it in "%°:/.-" }
        val paddleTechnical = paddle.text.count { it.isDigit() || it in "%°:/.-" }
        if (paddle.confidence >= 0.92f && paddleTechnical > mlTechnical) return true

        return false
    }

    private fun similarity(a: String, b: String): Double {
        val ka = key(a)
        val kb = key(b)
        if (ka.isEmpty() || kb.isEmpty()) return 0.0
        if (ka == kb) return 1.0
        val distance = editDistance(ka, kb)
        val longest = max(ka.length, kb.length)
        return 1.0 - distance.toDouble() / longest.toDouble()
    }

    private fun key(raw: String): String {
        val decomposed = Normalizer.normalize(raw.lowercase(), Normalizer.Form.NFD)
        return decomposed
            .replace(Regex("\\p{M}+"), "")
            .replace(Regex("[^a-z0-9]+"), "")
    }

    private fun editDistance(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val temp = dp[j]
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                dp[j] = min(min(dp[j] + 1, dp[j - 1] + 1), prev + cost)
                prev = temp
            }
        }
        return dp[b.length]
    }
}
