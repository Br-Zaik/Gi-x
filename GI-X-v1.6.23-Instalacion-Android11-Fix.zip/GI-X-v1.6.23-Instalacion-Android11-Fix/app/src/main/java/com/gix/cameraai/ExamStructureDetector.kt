package com.gix.cameraai

/**
 * Reconoce QUÉ tipo de ejercicio se reconstruyó antes de consultar la API.
 *
 * No se apoya en ningún examen concreto: mira la forma del texto ya reconstruido
 * (cierres "( )", líneas de puntos, alternativas A)…D), bloques de tabla) y decide
 * una etiqueta. Esa etiqueta viaja en el payload como "TIPO: ..." para que la IA
 * responda con el formato correcto y no convierta 20 afirmaciones V/F en un resumen.
 */
object ExamStructureDetector {

    enum class ExamType(val label: String) {
        TRUE_FALSE("Verdadero/Falso"),
        COMPLETION("Completar"),
        MULTIPLE_CHOICE("Alternativas"),
        TABLE("Tabla"),
        OPEN("Preguntas abiertas"),
        MIXED("Mixto"),
    }

    private val emptyAnswerParens = Regex("""\(\s*\)""")
    private val dottedBlank = Regex("""(\.{4,}|_{3,}|…{2,})""")
    // Las alternativas pueden quedar en líneas propias o dentro del mismo renglón.
    private val optionMarker = Regex("""(?:^|[\s\n])([A-H])[)\]]\s+\S""")
    private val visibleNumber = Regex("""^\s*(\d{1,2})\s*[.)\-:]\s*""")

    fun classifyQuestion(raw: String): ExamType {
        val text = raw.trim()
        if (text.isBlank()) return ExamType.OPEN
        if (text.contains(OcrTableFormatter.TABLE_START)) return ExamType.TABLE
        val optionLetters = optionMarker.findAll(text)
            .map { it.groupValues[1].uppercase() }
            .distinct()
            .count()
        if (optionLetters >= 2) return ExamType.MULTIPLE_CHOICE
        if (emptyAnswerParens.containsMatchIn(text) && text.count { it.isLetter() } >= 10) return ExamType.TRUE_FALSE
        if (dottedBlank.containsMatchIn(text)) return ExamType.COMPLETION

        val body = text.replace(visibleNumber, "").lowercase()
        if (body.startsWith("verdadero o falso") || body.startsWith("v/f")) return ExamType.TRUE_FALSE
        if (body.startsWith("complete ") || body.startsWith("completa ") ||
            body.startsWith("complete:") || body.startsWith("completar")
        ) {
            return ExamType.COMPLETION
        }
        return ExamType.OPEN
    }

    fun detect(questions: List<String>): ExamType {
        val real = questions.filter { it.isNotBlank() }
        if (real.isEmpty()) return ExamType.OPEN

        val counts = linkedMapOf<ExamType, Int>()
        real.forEach { question ->
            val type = classifyQuestion(question)
            counts[type] = (counts[type] ?: 0) + 1
        }

        val total = real.size
        val dominant = counts.maxByOrNull { it.value } ?: return ExamType.OPEN
        val dominantShare = dominant.value * 100 / total

        // Una tabla suele convivir con otros ejercicios; solo manda si es casi todo.
        if (dominant.key == ExamType.TABLE && dominantShare < 60) return ExamType.MIXED
        if (dominantShare >= 60) return dominant.key

        val strongOthers = counts.count { (_, value) -> value * 100 / total >= 25 }
        return if (strongOthers >= 2) ExamType.MIXED else dominant.key
    }

    /** Etiqueta lista para el payload: "TIPO: Verdadero/Falso". */
    fun payloadTypeLine(questions: List<String>): String {
        val type = detect(questions)
        val extras = mutableListOf<String>()
        if (questions.any { it.contains(OcrTableFormatter.TABLE_START) } && type != ExamType.TABLE) {
            extras += ExamType.TABLE.label
        }
        val detail = if (extras.isEmpty()) type.label else "${type.label} + ${extras.joinToString(" + ")}"
        return "TIPO: $detail"
    }
}
