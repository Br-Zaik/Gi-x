package com.gix.cameraai

object VoiceQuestionNormalizer {
    private val allCapsWord = Regex("(?<![\\p{L}\\p{N}])[A-ZÁÉÍÓÚÜÑ]{2,}(?![\\p{L}\\p{N}])")

    // Siglas que sí conviene conservar como siglas. El resto de palabras en
    // mayúsculas se pasa a minúsculas SOLO para la voz; la pantalla no cambia.
    private val spokenAcronyms = setOf(
        "IA", "AI", "GPS", "GNSS", "USB", "OCR", "PDF", "API", "APK", "AAB",
        "CPU", "GPU", "RAM", "ROM", "TTS", "URL", "HTTP", "HTTPS", "IP", "DNS",
        "LED", "LCD", "NFC", "RFID", "SIM", "SSD", "HDD", "PC"
    )

    fun prepareForTts(text: String): String {
        return allCapsWord.replace(text) { match ->
            val word = match.value
            if (word in spokenAcronyms) word else word.lowercase()
        }
    }

    fun isCompletionExercise(question: String): Boolean {
        val normalized = ResponseRepository.normalize(question)
        // ML Kit puede convertir una línea larga de puntos en ".." o incluso dejar
        // un solo punto aislado entre dos fragmentos (ej.: "reservas .del depósito").
        // Esas marcas siguen siendo evidencia de un espacio por completar.
        val ocrBlankMarker = Regex("_{2,}|\\.{2,}|…{2,}|\\s\\.\\s*[\\p{L}]").containsMatchIn(question)
        return listOf(
            "completa la frase", "completar la frase", "complete la frase",
            "completa la oracion", "completar la oracion", "complete la oracion",
            "espacio en blanco", "palabra que falta", "frase que falta"
        ).any { normalized.contains(it) } ||
            normalized.startsWith("completa ") || normalized.startsWith("complete ") ||
            ocrBlankMarker
    }
}
