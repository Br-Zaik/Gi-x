# GI X v1.6.23 — corrección de instalación

Cambios limitados a compatibilidad de instalación y compilación:

- `versionCode 48`, `versionName 1.6.23`.
- Se mantiene `applicationId com.gix.cameraai`.
- APK ARM universal: `arm64-v8a` + `armeabi-v7a`.
- `jniLibs.useLegacyPackaging = true` para compatibilidad con Android 11/Android Go y las librerías nativas de ONNX Runtime/OpenCV.
- No se cambia visión IA, OCR, API, cámara, interfaz ni lógica funcional de v1.6.22.
- Workflow corregido para compilar exactamente el ZIP añadido/modificado en el commit.
- La compilación hace `clean` y comprueba integridad ZIP, firma APK y alineación antes de publicar.
- El workflow usa `upload-artifact@v7` con `archive: false`: el teléfono descarga directamente `GI-X-v1.6.23-debug.apk`, sin ZIP intermedio.
