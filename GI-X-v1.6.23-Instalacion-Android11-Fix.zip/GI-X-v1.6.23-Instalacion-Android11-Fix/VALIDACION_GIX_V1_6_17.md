# GI X v1.6.17 · Extracción completa de las 4 estructuras de examen

Versión:
- versionCode: 42
- versionName: 1.6.17
- Incluye v1.6.15 (segmentación + fusión por solape + TIPO) y v1.6.16 (envío a la API aunque
  falte una pregunta + bloqueo de salida de la app).
- Sin cambios en package, API, diseño ni firmware.

## Cambios de esta versión (todos en OcrQuestionExtractor / QuestionBoundarySplitter)

1. **Celdas de cuadro conservadas.** Si la pregunta abierta pide llenar una tabla
   ("COMPLETE LA FUNCION QUE CORRESPONDE"), las líneas cortas que siguen se tratan como CELDAS y
   se guardan una por línea dentro de esa pregunta. Antes caían en el filtro de títulos porque son
   textos cortos en mayúsculas (APLICACIÓN, FUNCIÓN, NAVEGADOR, CORREO ELECTRÓNICO, REDES
   SOCIALES, ALMACENAMIENTO NUBE, E-COMMERCE, VIDEOCONFERENCIA) y desaparecían.
   Nuevo `looksLikeTableCell`: línea de 2 a 46 caracteres, máximo 6 palabras, sin signos de
   pregunta, que no sea instrucción ni línea numerada. Solo se aplica dentro de una pregunta de
   tabla, así que no afecta al resto de hojas.

2. **Datos cortos en columna conservados con su formato.** Fe / Pb / Ag, "Sin :", "Epi :" y las
   líneas de puntos con poco texto se guardan como líneas propias de la pregunta, no pegadas en un
   párrafo. Mantiene la correspondencia dato por dato.

3. **Saltos grandes de numeración en hojas V/F.** Un marcador a mitad de línea con un cierre `( )`
   se acepta aunque el OCR haya perdido varias afirmaciones intermedias (caso real: se leen 1–10 y
   después 19–20). Igual criterio cuando en la misma línea ya se separaron dos preguntas
   correctamente: es una línea claramente enumerada. Las trampas siguen protegidas por las guardas
   anteriores (número pegado a letra o dígito, delimitador obligatorio, cuerpo que no empiece por
   dígito).

## Comportamiento esperado con las 4 hojas de referencia

- **Topografía superficial (7 preguntas abiertas):** TIPO Preguntas abiertas. `1:1000`, `480 mm`,
  `A1`, `A2`, `N240` no cortan preguntas.
- **Fundamentos de Minería (completar + datos):** TIPO Completar. Se conservan las líneas de
  puntos, "Los procesos 1, 2 y 3" no se parte, `Sin :` / `Epi :` y `Fe` `Pb` `Ag` quedan dentro de
  sus preguntas 6 y 7. El dibujo de los cerros no genera una pregunta nueva.
- **Aplicaciones en Internet (completar + cuadro):** TIPO Completar + Tabla. Las 8 primeras
  conservan su línea de puntos; la 9 llega con las 6 filas del cuadro.
- **Aplicación de Internet / Explotación Minera (20 afirmaciones V/F):** TIPO Verdadero/Falso. Los
  títulos de sección ("SEGÚN SUS CARACTERÍSTICAS…") no se cuentan como preguntas y las 20
  afirmaciones conservan su `( )`.

## Pruebas realizadas
- Lógica de separación ejecutada en el script equivalente con el texto de las hojas 1, 2 y 4
  pegado en un solo renglón, como lo devuelve el OCR: 7/7, 9/9 y las afirmaciones V/F quedaron
  separadas, con títulos de sección intactos y sin cortes falsos en los casos trampa
  (`1, 2 y 3`, `2 - 3`, `3.5`, `480 mm`, `archivo_final_v2_editado.docx`).
- Balance de bloques de los archivos modificados: sin desbalances.

## Pendiente
- Compilación en GitHub Actions (aquí no hay SDK de Android ni compilador de Kotlin).
- Prueba real con la cámara: cuántas celdas del cuadro recupera el OCR depende de la calidad de la
  foto, no de esta lógica.
