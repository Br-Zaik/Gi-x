# GI X v1.6.19 · Fix de compilación Kotlin

Versión:
- versionCode: 44
- versionName: 1.6.19
- package/applicationId: com.gix.cameraai (sin cambios)

## Error corregido

GitHub Actions alcanzaba `:app:assembleDebug`, pero Kotlin detenía la compilación en
`OcrProcessor.layoutFusedText(...)`. El parámetro `paddleCandidate` es nullable. Aunque se obtenían
sus líneas con `paddleCandidate?.lines.orEmpty()`, eso NO permite a Kotlin asumir posteriormente
que `paddleCandidate` ya no es nulo. La lectura directa `paddleCandidate.text` por tanto no compila.

Corrección aplicada:
- `val candidate = paddleCandidate ?: return null` al inicio de `layoutFusedText`.
- Toda la función usa después la referencia no nula `candidate`.
- La lógica OCR, fusión ML Kit/PP-OCR, cámara, API, diseño y package no cambian.

## Archivos modificados
1. `app/src/main/java/com/gix/cameraai/OcrProcessor.kt` — null-safety de Kotlin.
2. `app/build.gradle` — versionCode 44 / versionName 1.6.19.

## Verificación estática
Se volvió a pasar el compilador Kotlin local sobre el código fuente. El error real nuevo de v1.6.18
`only safe (?.) or non-null asserted (!!.) calls are allowed on a nullable receiver` desaparece.
Los avisos restantes en esa comprobación local corresponden a clases Android no disponibles en este
entorno sin Android SDK; no son errores introducidos por este cambio.
