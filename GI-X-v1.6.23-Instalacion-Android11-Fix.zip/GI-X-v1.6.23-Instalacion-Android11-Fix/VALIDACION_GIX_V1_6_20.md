# GI X v1.6.20 — Visión IA directa

## Objetivo
Probar la lectura del examen con IA multimodal directamente desde las fotos, sin usar PP-OCR, ML Kit ni OpenCV antes de transcribir el documento.

## Flujo principal de esta versión
1. TimerCamera-X o modo Imagen entrega entre 1 y 4 fotos.
2. GI X conserva los bytes originales de cada foto.
3. Las 1–4 fotos se envían juntas a Cheaper Inference mediante `/v1/chat/completions`.
4. Para lectura visual se usa el modelo multimodal `gpt-5.6-luna`.
5. La IA reconstruye solo las preguntas/documento: numeración, líneas continuadas, alternativas, V/F, completar, tablas, escalas, fórmulas, coordenadas, unidades y símbolos.
6. GI X muestra las preguntas reconstruidas.
7. El flujo existente de respuestas continúa usando la API configurada de Cheaper Inference (DeepSeek V4 Flash en la configuración actual) y luego TTS.

## Importante
- El flujo principal NO ejecuta OCR local antes de mandar las fotos.
- No se aplica reescalado ni filtro local a los bytes enviados a la API.
- Las miniaturas locales se crean únicamente para la vista previa en pantalla y no sustituyen las fotos enviadas.
- Límite de GI X: 4 fotos por lote.
- Límites aplicados según la documentación actual de Cheaper Inference: 5 MB por imagen y 23 MB totales de datos de imagen; JPG/JPEG, PNG y WEBP.
- Si la API o Internet falla, esta versión de prueba NO cae automáticamente al OCR local: muestra el error para poder medir de forma limpia qué tan bien funciona la visión IA sola.

## Archivos modificados
- `app/src/main/java/com/gix/cameraai/MainActivity.kt`
  - Cámara y modo manual pasan al nuevo flujo de visión IA directa.
  - Se mandan 1–4 fotos originales juntas.
  - Se mantienen las miniaturas solo para vista previa.
- `app/src/main/java/com/gix/cameraai/OnlineAnswerProvider.kt`
  - Añadida petición multimodal OpenAI-compatible con `image_url` base64.
  - Añadido prompt de reconstrucción universal de exámenes/documentos.
  - Añadidos límites y validaciones de imágenes.
  - La clave API nunca se imprime ni se guarda en logs nuevos.
- `app/build.gradle`
  - `versionCode 45`
  - `versionName 1.6.20`

## Peso de APK de la versión anterior
La reducción aproximada de ~300 MB a ~80 MB en v1.6.18/v1.6.19 no eliminó los OCR principales del proyecto. El `build.gradle` todavía conserva ML Kit, ONNX Runtime/OpenCV y la preparación de PP-OCR. La reducción principal visible en el proyecto fue limitar los binarios nativos a `arm64-v8a`, evitando incluir x86/x86_64 y otras ABI en la APK para celular.
