# GI X v1.6.21 — Fix compilación Visión IA

- Base: v1.6.20 Visión IA Directa.
- Corrección: `ByteArray?` no dispone de `isNullOrEmpty()` en Kotlin.
- Se reemplazó por comprobación explícita `bytes == null || bytes.isEmpty()`.
- No se cambió el flujo de visión, API, cámara, OCR local, package ni diseño.
- versionCode: 46
- versionName: 1.6.21
