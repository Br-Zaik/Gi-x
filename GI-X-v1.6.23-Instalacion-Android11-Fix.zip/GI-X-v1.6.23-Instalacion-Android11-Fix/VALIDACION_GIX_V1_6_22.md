# GI X v1.6.22 — Visión general + OCR de respaldo

Base: GI X v1.6.21.

## Cambios realizados

- `versionCode 47` / `versionName 1.6.22`.
- Visión IA sigue siendo la ruta principal para cámara y selección manual de 1 a 4 imágenes.
- Si no hay API configurada, visión devuelve error o no produce preguntas reconocibles, GI X activa automáticamente el pipeline OCR local existente (PP-OCR / ML Kit / OpenCV).
- La transcripción visual trabaja por contenido visible: conserva la numeración original si existe, permite empezar en cualquier número y no agrega numeración a preguntas que no la tenían impresa.
- Para asociar respuestas de preguntas sin número se usan identificadores solo internos; esos identificadores no se muestran al usuario.
- La salida final junta cada pregunta original con `Respuesta: ...`, y ese mismo texto pasa al TTS.
- Se quitaron reglas/correcciones ligadas a materias o hojas de prueba concretas para que el postprocesado sea general.
- Se conserva soporte estructural para preguntas abiertas, alternativas, verdadero/falso, completar, tablas, fórmulas, unidades, símbolos y preguntas sin numeración.
- El lote de cámara conserva 1.2 s para una sola foto; si llega una segunda, amplía el tiempo de continuación a 2.2 s para dar oportunidad a una tercera/cuarta sin hacer lenta la captura única.
- Firmware de TimerCamera-X no modificado: conserva `FRAMESIZE_UXGA` (1600x1200 real) y calidad JPEG 8.

## Verificaciones realizadas en este entorno

- Revisión de sintaxis/escapes Kotlin de los archivos modificados mediante `kotlinc` (ignorando referencias Android no disponibles en este entorno).
- Verificación de que el `applicationId` sigue siendo `com.gix.cameraai`.
- Comparación SHA-256 del firmware con v1.6.21: idéntico.
- Búsqueda de hardcodes de Topografía/Minería y ejemplos de las hojas usadas durante las pruebas en la lógica modificada: retirados.

## Compilación Android

Este entorno no incluye Android SDK ni Gradle/Gradle Wrapper del proyecto, por lo que aquí no se ejecutó `assembleDebug`. El ZIP conserva el workflow de GitHub Actions para realizar la compilación Android real.
