package com.gix.cameraai

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.net.URL
import java.net.URLEncoder
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

data class VisionImagePayload(
    val bytes: ByteArray,
    val mimeType: String = "image/jpeg"
)

class OnlineAnswerProvider(private val context: Context? = null) {

    private data class NetCallResult(
        val ok: Boolean,
        val text: String,
        val error: String,
        val provider: NetProvider,
        val model: String,
        val canTryNextApi: Boolean = false,
        val failureType: FailureType = FailureType.NONE
    )

    private enum class FailureType {
        NONE, LIMIT_DAILY, LIMIT_MINUTE, LIMIT_UNKNOWN, INVALID, TEMPORARY, NETWORK, CANCELLED, OTHER
    }

    private val runtimeRequestId = AtomicInteger(0)
    private val connectionLock = Any()
    @Volatile private var activeRuntimeConnection: HttpURLConnection? = null

    /**
     * No bindProcessToNetwork(): the camera server must stay reachable over hotspot.
     * When Android selects a local-only Wi-Fi as default, use the validated mobile
     * network for EACH outgoing API HTTPS connection; do not change the whole app.
     */
    private fun openApiConnection(url: URL): HttpURLConnection {
        val appContext = context ?: return url.openConnection() as HttpURLConnection
        return try {
            val cm = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                ?: return url.openConnection() as HttpURLConnection
            val defaultNetwork = cm.activeNetwork
            val defaultCaps = defaultNetwork?.let { cm.getNetworkCapabilities(it) }
            val defaultHasInternet = defaultCaps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true &&
                defaultCaps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            if (defaultHasInternet) return url.openConnection() as HttpURLConnection
            val mobileNetwork = cm.allNetworks.firstOrNull { network ->
                val caps = cm.getNetworkCapabilities(network)
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true &&
                    caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                    caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            }
            if (mobileNetwork != null) {
                mobileNetwork.openConnection(url) as HttpURLConnection
            } else {
                url.openConnection() as HttpURLConnection
            }
        } catch (_: Exception) {
            // On restricted devices / with temporary network transitions, allow the
            // real HTTPS request to report a diagnostic instead of rejecting early.
            url.openConnection() as HttpURLConnection
        }
    }

    fun cancelActiveRequest() {
        runtimeRequestId.incrementAndGet()
        synchronized(connectionLock) {
            runCatching { activeRuntimeConnection?.disconnect() }
            activeRuntimeConnection = null
        }
    }

    fun fetchShortAnswer(rawQuery: String, onPartialAnswer: ((String) -> Unit)? = null): String {
        val query = cleanQuery(rawQuery)
        fun apiError(message: String): String = "$API_ERROR_PREFIX $message"

        if (query.length < 2) return apiError("La pregunta quedó demasiado corta después del OCR.")
        // La Zona Wi-Fi de GI X puede convivir con datos móviles y Android tarda en
        // marcar la red como VALIDATED. No bloquear una API funcional por una
        // comprobación previa: el POST real determina si existe conectividad.

        val requestId = beginRuntimeRequest()
        val settings = context?.let { GeminiSettings(it) }
        val config = settings?.getApiConfigs()
            .orEmpty()
            .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }
            ?: return apiError("No hay una API DeepSeek de Cheaper Inference guardada. Entra a API y guárdala primero.")

        val cleanConfig = config.clean(0)
        val formatError = getApiConfigError(cleanConfig)
        if (formatError != null) {
            settings?.markError(cleanConfig, formatError)
            return apiError("DeepSeek: $formatError")
        }

        var lastError = ""
        var lastFailure = FailureType.OTHER
        var lastFormatIssue = ""

        // Los lotes grandes se intentan una sola vez: si el proveedor los corta o
        // está ocupado, MainActivity los reduce inmediatamente. Las preguntas
        // individuales conservan dos intentos para tolerar fallos temporales.
        val runtimeAttempts = if (isMultiQuestionBatch(query)) 1 else RUNTIME_MAX_ATTEMPTS
        for (attempt in 1..runtimeAttempts) {
            if (!isRuntimeRequestActive(requestId)) return apiError("Consulta cancelada.")
            // No impedir el reintento por VALIDATED: una red móvil puede volver
            // durante la espera sin reflejarse inmediatamente en ConnectivityManager.

            val result = askProvider(
                cleanConfig,
                query,
                runtimeRequestId = requestId,
                onPartialAnswer = onPartialAnswer
            )
            if (!isRuntimeRequestActive(requestId) || result.failureType == FailureType.CANCELLED) {
                return apiError("Consulta cancelada.")
            }

            if (result.ok) {
                val normalizedAnswer = canonicalizeAnswerForQuestion(query, result.text)
                // Repetir exactamente el mismo lote después de MAX_TOKENS casi siempre
                // vuelve a fallar. Devolvemos el error de inmediato para que MainActivity
                // reduzca ese lote a preguntas individuales y recupere las respuestas.
                if (normalizedAnswer.trim() == TOKEN_LIMIT_ANSWER) {
                    settings?.markReady(cleanConfig)
                    clearRuntimeConnection(requestId)
                    return apiError("DeepSeek alcanzó el límite de salida en este bloque. GI X recuperará inmediatamente las preguntas de este bloque por separado.")
                }

                val issue = netAnswerIssue(normalizedAnswer, query)
                if (issue == null) {
                    settings?.saveLastGoodIndex(0)
                    settings?.markReady(cleanConfig)
                    clearRuntimeConnection(requestId)
                    return normalizedAnswer
                }

                lastFormatIssue = issue
                lastError = "DeepSeek devolvió una respuesta incompleta o con formato incorrecto: $issue"
                lastFailure = FailureType.OTHER
                settings?.markReady(cleanConfig)
            } else {
                lastError = result.error.ifBlank { "DeepSeek no devolvió una respuesta utilizable." }
                lastFailure = result.failureType

                when (result.failureType) {
                    FailureType.INVALID -> {
                        settings?.markError(cleanConfig, lastError)
                        clearRuntimeConnection(requestId)
                        return apiError(lastError)
                    }
                    FailureType.LIMIT_DAILY -> {
                        settings?.markError(cleanConfig, lastError)
                        clearRuntimeConnection(requestId)
                        return apiError("$lastError Revisa el saldo/créditos de tu cuenta de Cheaper Inference.")
                    }
                    FailureType.LIMIT_MINUTE, FailureType.LIMIT_UNKNOWN -> {
                        settings?.markUntested(
                            cleanConfig,
                            "Último intento: límite temporal del proveedor. La API NO quedó bloqueada."
                        )
                    }
                    FailureType.TEMPORARY -> {
                        settings?.markUntested(
                            cleanConfig,
                            "Último intento: error temporal del servidor. La API NO quedó bloqueada."
                        )
                    }
                    FailureType.NETWORK -> {
                        settings?.markUntested(
                            cleanConfig,
                            "Último intento: problema de conexión. La API sigue guardada."
                        )
                    }
                    FailureType.OTHER -> {
                        settings?.markUntested(
                            cleanConfig,
                            "Último intento falló. La API sigue guardada y no quedó en espera."
                        )
                    }
                    else -> Unit
                }
            }

            if (attempt < runtimeAttempts) {
                val delay = RETRY_BASE_DELAY_MS * attempt
                try {
                    Thread.sleep(delay)
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                    return apiError("Consulta interrumpida.")
                }
            }
        }

        clearRuntimeConnection(requestId)
        return when (lastFailure) {
            FailureType.NETWORK -> apiError("No se pudo conectar con DeepSeek. La API sigue guardada. $lastError")
            FailureType.LIMIT_MINUTE, FailureType.LIMIT_UNKNOWN -> apiError("DeepSeek devolvió un límite temporal. La API sigue guardada y NO queda bloqueada. $lastError")
            FailureType.TEMPORARY -> apiError("DeepSeek tuvo un error temporal. La API sigue guardada y NO queda bloqueada. $lastError")
            else -> if (lastFormatIssue.isNotBlank()) {
                apiError("DeepSeek respondió, pero la respuesta llegó incompleta: $lastFormatIssue")
            } else {
                apiError(lastError.ifBlank { "DeepSeek no devolvió una respuesta válida." })
            }
        }
    }

    /**
     * GI X v1.6.22: lectura ONLINE DIRECTA del documento.
     * Las 1-4 fotos originales se envían juntas a un modelo multimodal y NO pasan por
     * PP-OCR/ML Kit/OpenCV antes de la lectura. Si visión no está disponible o no logra
     * reconstruir preguntas, MainActivity activa automáticamente el OCR local de respaldo.
     */
    fun extractQuestionsFromImages(images: List<VisionImagePayload>): String {
        fun apiError(message: String): String = "$API_ERROR_PREFIX $message"
        if (images.isEmpty()) return apiError("No hay imágenes para enviar a la IA.")
        if (images.size > MAX_VISION_IMAGES) return apiError("La IA acepta máximo $MAX_VISION_IMAGES imágenes por lote en GI X.")
        // Intentar la conexión real: el hotspot de cámara no debe impedir usar
        // simultáneamente los datos móviles para la lectura por visión.

        val invalid = images.firstOrNull { image ->
            image.bytes.isEmpty() || image.bytes.size > MAX_VISION_IMAGE_BYTES ||
                image.mimeType.lowercase(Locale.ROOT) !in SUPPORTED_VISION_MIME_TYPES
        }
        if (invalid != null) {
            return apiError("Una imagen no es compatible o supera 5 MB. Usa JPG, PNG o WEBP sin exceder el límite del proveedor.")
        }
        val totalBytes = images.sumOf { it.bytes.size.toLong() }
        if (totalBytes > MAX_VISION_TOTAL_BYTES) {
            return apiError("El lote supera 23 MB. Reduce el tamaño de las fotos antes de enviarlas.")
        }

        val settings = context?.let { GeminiSettings(it) }
        val config = settings?.getApiConfigs()
            .orEmpty()
            .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE && it.apiKey.isNotBlank() }
            ?: return apiError("No hay una API de Cheaper Inference guardada. Entra a API y guárdala primero.")

        val cleanConfig = config.clean(0)
        val formatError = getApiConfigError(cleanConfig)
        if (formatError != null) {
            settings?.markError(cleanConfig, formatError)
            return apiError(formatError)
        }

        val requestId = beginRuntimeRequest()
        var connection: HttpURLConnection? = null
        return try {
            val url = URL(CHEAPER_CHAT_ENDPOINT)
            connection = openApiConnection(url).apply {
                requestMethod = "POST"
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = VISION_READ_TIMEOUT_MS
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Accept", "application/json")
                setRequestProperty("Authorization", "Bearer ${cleanConfig.apiKey}")
                setRequestProperty("Connection", "close")
                setRequestProperty("User-Agent", "GIX/1.6.25")
            }

            if (!registerRuntimeConnection(requestId, connection)) {
                return apiError("Consulta cancelada.")
            }

            val body = buildVisionBody(images).toString()
            connection.outputStream.use { output ->
                output.write(body.toByteArray(Charsets.UTF_8))
            }

            if (!isRuntimeRequestActive(requestId)) return apiError("Consulta cancelada.")

            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val parsed = parseProviderError(raw, code, NetProvider.CHEAPER_INFERENCE, VISION_MODEL, connection.getHeaderField("x-ci-request-id"))
                when (parsed.failureType) {
                    FailureType.INVALID, FailureType.LIMIT_DAILY -> settings?.markError(cleanConfig, parsed.error)
                    else -> settings?.markUntested(cleanConfig, "La visión IA falló temporalmente; la API sigue guardada.")
                }
                return apiError(parsed.error.ifBlank { "La IA de visión rechazó el lote de imágenes." })
            }

            val text = parseVisionChatText(raw).trim()
            if (text.isBlank()) {
                settings?.markUntested(cleanConfig, "La visión IA respondió vacía; la API sigue guardada.")
                return apiError("La IA recibió las imágenes, pero no devolvió texto.")
            }

            settings?.markReady(cleanConfig)
            clearRuntimeConnection(requestId)
            sanitizeVisionOutput(text)
        } catch (e: Exception) {
            if (!isRuntimeRequestActive(requestId)) {
                apiError("Consulta cancelada.")
            } else {
                val result = networkResult(e, NetProvider.CHEAPER_INFERENCE, VISION_MODEL)
                settings?.markUntested(cleanConfig, "La visión IA no pudo conectarse; la API sigue guardada.")
                apiError(result.error.ifBlank { "No se pudo enviar las imágenes a la IA." })
            }
        } finally {
            connection?.disconnect()
            clearRuntimeConnection(requestId, connection)
        }
    }

    private fun buildVisionBody(images: List<VisionImagePayload>): JSONObject {
        val content = JSONArray()
            .put(
                JSONObject()
                    .put("type", "text")
                    .put("text", VISION_DOCUMENT_PROMPT)
            )

        images.forEach { image ->
            val mime = image.mimeType.lowercase(Locale.ROOT)
            val b64 = Base64.encodeToString(image.bytes, Base64.NO_WRAP)
            content.put(
                JSONObject()
                    .put("type", "image_url")
                    .put(
                        "image_url",
                        JSONObject().put("url", "data:$mime;base64,$b64")
                    )
            )
        }

        return JSONObject().apply {
            put("model", VISION_MODEL)
            put(
                "messages",
                JSONArray()
                    .put(
                        JSONObject()
                            .put("role", "system")
                            .put("content", "Eres un lector visual de documentos académicos. Tu prioridad es fidelidad: reconstruye lo visible sin inventar contenido.")
                    )
                    .put(
                        JSONObject()
                            .put("role", "user")
                            .put("content", content)
                    )
            )
            put("temperature", 0.0)
            put("max_tokens", VISION_MAX_OUTPUT_TOKENS)
            put("stream", false)
        }
    }

    private fun parseVisionChatText(raw: String): String {
        val obj = JSONObject(raw)
        val choices = obj.optJSONArray("choices") ?: return ""
        val partsText = StringBuilder()
        for (i in 0 until choices.length()) {
            val choice = choices.optJSONObject(i) ?: continue
            val message = choice.optJSONObject("message") ?: choice.optJSONObject("delta")
            if (message != null) {
                val contentValue = message.opt("content")
                if (contentValue != null && contentValue != JSONObject.NULL) {
                    appendJsonContent(partsText, contentValue)
                }
                if (partsText.isBlank()) appendCleanPart(partsText, message.optString("text").trim())
            }
            if (partsText.isBlank()) appendCleanPart(partsText, choice.optString("text").trim())
            if (partsText.isNotBlank()) break
        }
        return partsText.toString().trim()
    }

    private fun sanitizeVisionOutput(raw: String): String {
        return raw
            .replace(Regex("(?is)^```(?:text|markdown|md)?\\s*"), "")
            .replace(Regex("(?is)\\s*```$"), "")
            .replace(Regex("(?im)^\\s*(?:transcripci[oó]n|preguntas detectadas|resultado)\\s*:\\s*$"), "")
            .trim()
    }

    fun testApiConfig(apiConfig: NetApiConfig): Pair<Boolean, String> {
        val clean = apiConfig.clean(0)
        val settings = context?.let { GeminiSettings(it) }
        val label = "DeepSeek (Cheaper Inference)"

        if (clean.provider != NetProvider.CHEAPER_INFERENCE) {
            return false to "$label: ERROR - Esta versión de GI X usa únicamente Cheaper Inference / DeepSeek."
        }

        val formatError = getApiConfigError(clean)
        if (formatError != null) {
            settings?.markError(clean, formatError)
            return false to "$label: ERROR - $formatError"
        }

        // Probar el endpoint, no solo la bandera VALIDATED de Android. En modo
        // cámara puede estar encendida la Zona Wi-Fi junto a los datos móviles.

        var last: NetCallResult? = null
        for (attempt in 1..TEST_MAX_ATTEMPTS) {
            val result = askProvider(clean, "Responde solo: OK", testing = true)
            last = result
            if (result.ok) {
                settings?.markReady(clean)
                settings?.saveLastGoodIndex(0)
                return true to "$label: FUNCIONANDO ✓\nLa clave quedó guardada y activa."
            }

            if (result.failureType == FailureType.INVALID || result.failureType == FailureType.LIMIT_DAILY) {
                val message = result.error.ifBlank { "Clave, modelo o saldo no disponible." }
                settings?.markError(clean, message)
                return false to "$label: ERROR - $message"
            }

            // A missing mobile network or a provider limit will not be fixed by
            // sending the same paid test again one second later.
            if (result.failureType != FailureType.TEMPORARY) break
            if (attempt < TEST_MAX_ATTEMPTS) {
                try {
                    Thread.sleep(RETRY_BASE_DELAY_MS * attempt)
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                    break
                }
            }
        }

        val result = last
        val message = result?.error?.ifBlank { "No respondió en la prueba." } ?: "No respondió en la prueba."
        settings?.markUntested(clean, "Última prueba falló: $message La API sigue guardada y NO quedó en espera.")
        return false to "$label: GUARDADA, PERO LA PRUEBA FALLÓ - $message\nNo se bloqueó la API; puedes volver a probar o hacer una consulta."
    }

    fun testApiConfigs(apiConfigs: List<NetApiConfig>): Pair<Boolean, String> {
        val config = apiConfigs
            .mapIndexed { index, item -> item.clean(index) }
            .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE && it.apiKey.isNotBlank() }
            ?: return false to "No hay una API Cheaper Inference / DeepSeek para probar."
        return testApiConfig(config)
    }

    private fun getApiConfigError(config: NetApiConfig): String? {
        val key = config.apiKey.trim()
        if (key.isBlank()) return "API vacia."
        if (key.length < 8) return "API demasiado corta o mal copiada."

        // Cheaper Inference es un intermediario compatible con OpenAI. Algunas
        // cuentas antiguas usan ir_live_ y la documentacion actual usa ci_live_.
        // GI X admite ambos formatos y evita una regex demasiado estricta.
        if (config.provider == NetProvider.CHEAPER_INFERENCE) {
            val lower = key.lowercase()
            if (!lower.startsWith("ir_live_") && !lower.startsWith("ci_live_")) {
                return "Clave de Cheaper Inference no reconocida. Debe empezar con ir_live_ o ci_live_."
            }
            if (key.any { it.code < 32 || it.code == 127 }) {
                return "La clave contiene un caracter de control. Vuelve a copiarla desde Cheaper Inference."
            }
            if (key.length < 16) {
                return "La clave parece incompleta. Copiala completa desde Cheaper Inference."
            }
        } else {
            if (key.any { it.isWhitespace() }) return "API con espacios. Pegala completa sin espacios."
            if (key.any { it.code < 32 || it.code == 127 }) {
                return "API con caracteres no validos."
            }
        }

        if (config.model.isBlank()) return "Modelo vacio. Escribe el modelo o usa el recomendado."
        if (config.model.any { it.isWhitespace() }) return "Modelo con espacios. Copia el nombre exacto del modelo."
        return null
    }

    private fun askProvider(
        config: NetApiConfig,
        question: String,
        testing: Boolean = false,
        runtimeRequestId: Int? = null,
        onPartialAnswer: ((String) -> Unit)? = null
    ): NetCallResult {
        return when (config.provider) {
            NetProvider.GEMINI -> callGemini(config, question, testing, runtimeRequestId)
            NetProvider.CHEAPER_INFERENCE -> callOpenAiCompatible(
                config = config,
                endpoint = CHEAPER_CHAT_ENDPOINT,
                question = question,
                testing = testing,
                runtimeRequestId = runtimeRequestId,
                extraHeaders = emptyMap(),
                onPartialAnswer = onPartialAnswer
            )
            NetProvider.OPENROUTER -> callOpenAiCompatible(
                config = config,
                endpoint = "https://openrouter.ai/api/v1/chat/completions",
                question = question,
                testing = testing,
                runtimeRequestId = runtimeRequestId,
                extraHeaders = mapOf(
                    "HTTP-Referer" to "https://gix.local",
                    "X-Title" to "GI X"
                )
            )
            NetProvider.MISTRAL -> callOpenAiCompatible(
                config = config,
                endpoint = "https://api.mistral.ai/v1/chat/completions",
                question = question,
                testing = testing,
                runtimeRequestId = runtimeRequestId
            )
            NetProvider.COHERE -> callCohere(config, question, testing, runtimeRequestId)
        }
    }

    private fun callGemini(
        config: NetApiConfig,
        question: String,
        testing: Boolean,
        runtimeRequestId: Int?
    ): NetCallResult {
        var connection: HttpURLConnection? = null
        val model = config.model.ifBlank { config.provider.defaultModel }

        return try {
            val encodedKey = URLEncoder.encode(config.apiKey, "UTF-8")
            val url = URL(
                "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$encodedKey"
            )

            connection = openApiConnection(url).apply {
                requestMethod = "POST"
                connectTimeout = if (testing) TEST_CONNECT_TIMEOUT_MS else CONNECT_TIMEOUT_MS
                readTimeout = if (testing) TEST_READ_TIMEOUT_MS else responseReadTimeout(question)
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Accept", "application/json")
                setRequestProperty("Connection", "close")
                setRequestProperty("User-Agent", "GIX/1.0")
            }

            if (!registerRuntimeConnection(runtimeRequestId, connection)) {
                return cancelledResult(config.provider, model)
            }

            val body = buildGeminiBody(question, testing, model).toString()
            connection.outputStream.use { output ->
                output.write(body.toByteArray(Charsets.UTF_8))
            }

            if (runtimeRequestId != null && !isRuntimeRequestActive(runtimeRequestId)) {
                return cancelledResult(config.provider, model)
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()

            if (code !in 200..299) {
                return parseProviderError(raw, code, config.provider, model)
            }

            val answer = parseGeminiText(raw, question)
            if (answer.isBlank()) {
                NetCallResult(false, "", "${config.provider.label} respondió vacío.", config.provider, model, true, FailureType.TEMPORARY)
            } else {
                NetCallResult(true, answer, "", config.provider, model)
            }
        } catch (e: Exception) {
            if (runtimeRequestId != null && !isRuntimeRequestActive(runtimeRequestId)) {
                cancelledResult(config.provider, model)
            } else {
                networkResult(e, config.provider, model)
            }
        } finally {
            connection?.disconnect()
            clearRuntimeConnection(runtimeRequestId, connection)
        }
    }

    private fun callOpenAiCompatible(
        config: NetApiConfig,
        endpoint: String,
        question: String,
        testing: Boolean,
        runtimeRequestId: Int?,
        extraHeaders: Map<String, String> = emptyMap(),
        onPartialAnswer: ((String) -> Unit)? = null
    ): NetCallResult {
        var connection: HttpURLConnection? = null
        val model = config.model.ifBlank { config.provider.defaultModel }
        val streaming = !testing && config.provider == NetProvider.CHEAPER_INFERENCE && onPartialAnswer != null

        return try {
            val url = URL(endpoint)
            connection = openApiConnection(url).apply {
                requestMethod = "POST"
                connectTimeout = if (testing) TEST_CONNECT_TIMEOUT_MS else CONNECT_TIMEOUT_MS
                readTimeout = if (testing) TEST_READ_TIMEOUT_MS else responseReadTimeout(question)
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Accept", if (streaming) "text/event-stream" else "application/json")
                setRequestProperty("Authorization", "Bearer ${config.apiKey}")
                setRequestProperty("Connection", "close")
                setRequestProperty("User-Agent", "GIX/1.0")
                extraHeaders.forEach { (key, value) -> setRequestProperty(key, value) }
            }

            if (!registerRuntimeConnection(runtimeRequestId, connection)) {
                return cancelledResult(config.provider, model)
            }

            val body = buildChatBody(
                model = model,
                question = question,
                testing = testing,
                provider = config.provider,
                streamResponse = streaming
            ).toString()
            connection.outputStream.use { output ->
                output.write(body.toByteArray(Charsets.UTF_8))
            }

            if (runtimeRequestId != null && !isRuntimeRequestActive(runtimeRequestId)) {
                return cancelledResult(config.provider, model)
            }
            val code = connection.responseCode
            val input = if (code in 200..299) connection.inputStream else connection.errorStream

            if (code !in 200..299) {
                val raw = input?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                return parseProviderError(raw, code, config.provider, model, connection.getHeaderField("x-ci-request-id"))
            }

            if (streaming) {
                val accumulated = StringBuilder()
                val nonSse = StringBuilder()
                var sawSse = false
                var finishReason = ""
                var streamError = ""

                input?.bufferedReader(Charsets.UTF_8)?.use { reader ->
                    while (true) {
                        if (runtimeRequestId != null && !isRuntimeRequestActive(runtimeRequestId)) {
                            return cancelledResult(config.provider, model)
                        }
                        val line = reader.readLine() ?: break
                        if (!line.startsWith("data:")) {
                            if (line.isNotBlank() && !line.startsWith(":")) {
                                nonSse.append(line).append('\n')
                            }
                            continue
                        }

                        sawSse = true
                        val data = line.removePrefix("data:").trim()
                        if (data.isBlank() || data == "[DONE]") continue

                        val event = runCatching { JSONObject(data) }.getOrNull() ?: continue
                        val errorObj = event.opt("error")
                        if (errorObj != null && errorObj != JSONObject.NULL) {
                            streamError = when (errorObj) {
                                is JSONObject -> errorObj.optString("message", errorObj.toString())
                                else -> errorObj.toString()
                            }.trim()
                            continue
                        }

                        val choices = event.optJSONArray("choices")
                        if (choices != null && choices.length() > 0) {
                            val choice = choices.optJSONObject(0)
                            if (choice != null) {
                                val reason = choice.optString(
                                    "finish_reason",
                                    choice.optString("native_finish_reason", choice.optString("finishReason"))
                                ).trim()
                                if (reason.isNotBlank()) finishReason = reason

                                val delta = choice.optJSONObject("delta") ?: choice.optJSONObject("message")
                                val chunk = streamContentText(delta?.opt("content"))
                                if (chunk.isNotEmpty()) {
                                    accumulated.append(chunk)
                                    runCatching { onPartialAnswer?.invoke(accumulated.toString()) }
                                }
                            }
                        }
                    }
                }

                if (streamError.isNotBlank()) {
                    return NetCallResult(
                        false,
                        accumulated.toString(),
                        "${config.provider.label}: $streamError",
                        config.provider,
                        model,
                        true,
                        FailureType.TEMPORARY
                    )
                }

                if (sawSse) {
                    val answer = cleanAnswer(accumulated.toString(), question)
                    if (finishReason.equals("length", ignoreCase = true) ||
                        finishReason.equals("MAX_TOKENS", ignoreCase = true)
                    ) {
                        val usable = if (!isMultiQuestionBatch(question) && isUsefulNetAnswer(answer, question)) answer else TOKEN_LIMIT_ANSWER
                        return NetCallResult(true, usable, "", config.provider, model)
                    }
                    if (answer.isBlank() || answer == BAD_NET_ANSWER) {
                        return NetCallResult(false, "", "${config.provider.label} respondió vacío.", config.provider, model, true, FailureType.TEMPORARY)
                    }
                    return NetCallResult(true, answer, "", config.provider, model)
                }

                // Respaldo: si un upstream ignora stream=true y devuelve JSON normal.
                val raw = nonSse.toString().trim()
                val answer = parseChatCompletionsText(raw, question)
                if (answer.isBlank()) {
                    NetCallResult(false, "", "${config.provider.label} respondió vacío.", config.provider, model, true, FailureType.TEMPORARY)
                } else {
                    NetCallResult(true, answer, "", config.provider, model)
                }
            } else {
                val raw = input?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                val answer = parseChatCompletionsText(raw, question)
                if (answer.isBlank()) {
                    NetCallResult(false, "", "${config.provider.label} respondió vacío.", config.provider, model, true, FailureType.TEMPORARY)
                } else {
                    NetCallResult(true, answer, "", config.provider, model)
                }
            }
        } catch (e: Exception) {
            if (runtimeRequestId != null && !isRuntimeRequestActive(runtimeRequestId)) {
                cancelledResult(config.provider, model)
            } else {
                networkResult(e, config.provider, model)
            }
        } finally {
            connection?.disconnect()
            clearRuntimeConnection(runtimeRequestId, connection)
        }
    }

    private fun streamContentText(value: Any?): String {
        return when (value) {
            null, JSONObject.NULL -> ""
            is String -> value
            is JSONArray -> buildString {
                for (i in 0 until value.length()) {
                    val item = value.opt(i)
                    when (item) {
                        is String -> append(item)
                        is JSONObject -> append(item.optString("text", item.optString("content")))
                    }
                }
            }
            is JSONObject -> value.optString("text", value.optString("content"))
            else -> value.toString()
        }
    }

    private fun callCohere(
        config: NetApiConfig,
        question: String,
        testing: Boolean,
        runtimeRequestId: Int?
    ): NetCallResult {
        var connection: HttpURLConnection? = null
        val model = config.model.ifBlank { config.provider.defaultModel }

        return try {
            val url = URL("https://api.cohere.com/v2/chat")
            connection = openApiConnection(url).apply {
                requestMethod = "POST"
                connectTimeout = if (testing) TEST_CONNECT_TIMEOUT_MS else CONNECT_TIMEOUT_MS
                readTimeout = if (testing) TEST_READ_TIMEOUT_MS else responseReadTimeout(question)
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Accept", "application/json")
                setRequestProperty("Authorization", "Bearer ${config.apiKey}")
                setRequestProperty("Connection", "close")
                setRequestProperty("User-Agent", "GIX/1.0")
            }

            if (!registerRuntimeConnection(runtimeRequestId, connection)) {
                return cancelledResult(config.provider, model)
            }

            val body = buildCohereBody(model, question, testing).toString()
            connection.outputStream.use { output ->
                output.write(body.toByteArray(Charsets.UTF_8))
            }

            if (runtimeRequestId != null && !isRuntimeRequestActive(runtimeRequestId)) {
                return cancelledResult(config.provider, model)
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()

            if (code !in 200..299) {
                return parseProviderError(raw, code, config.provider, model)
            }

            val answer = parseCohereText(raw, question)
            if (answer.isBlank()) {
                NetCallResult(false, "", "${config.provider.label} respondió vacío.", config.provider, model, true, FailureType.TEMPORARY)
            } else {
                NetCallResult(true, answer, "", config.provider, model)
            }
        } catch (e: Exception) {
            if (runtimeRequestId != null && !isRuntimeRequestActive(runtimeRequestId)) {
                cancelledResult(config.provider, model)
            } else {
                networkResult(e, config.provider, model)
            }
        } finally {
            connection?.disconnect()
            clearRuntimeConnection(runtimeRequestId, connection)
        }
    }

    private fun buildGeminiBody(question: String, testing: Boolean, model: String): JSONObject {
        return JSONObject().apply {
            put(
                "contents",
                JSONArray().put(
                    JSONObject().apply {
                        put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", buildPrompt(question, testing)))
                        )
                    }
                )
            )
            put(
                "generationConfig",
                JSONObject().apply {
                    put("maxOutputTokens", outputTokenLimit(question, testing))
                    put("temperature", if (testing) 0.0 else 0.2)
                    if (!testing && model.lowercase().contains("2.5")) {
                        put(
                            "thinkingConfig",
                            JSONObject().apply { put("thinkingBudget", 0) }
                        )
                    }
                }
            )
        }
    }

    private fun buildChatBody(
        model: String,
        question: String,
        testing: Boolean,
        provider: NetProvider,
        streamResponse: Boolean = false
    ): JSONObject {
        return JSONObject().apply {
            put("model", model)
            put(
                "messages",
                JSONArray()
                    .put(JSONObject().put("role", "system").put("content", buildSystemRules(testing, question)))
                    .put(JSONObject().put("role", "user").put("content", if (testing) question else cleanQuery(question)))
            )
            put("temperature", if (testing) 0.0 else 0.2)
            put("max_tokens", outputTokenLimit(question, testing))
            if (provider == NetProvider.CHEAPER_INFERENCE) {
                // La prueba también necesita la misma ruta rápida que las consultas reales.
                // Una prueba de modelo de razonamiento sin límite de esfuerzo y con solo
                // 64 tokens podía agotar el tiempo sin emitir el texto corto "OK".
                put("reasoning_effort", "minimal")
                put("ranking", "speed")
            }
            put("stream", streamResponse)
        }
    }

    private fun buildCohereBody(model: String, question: String, testing: Boolean): JSONObject {
        return JSONObject().apply {
            put("model", model)
            put(
                "messages",
                JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put("content", buildPrompt(question, testing))
                )
            )
            put("temperature", if (testing) 0.0 else 0.2)
            put("max_tokens", outputTokenLimit(question, testing))
        }
    }

    private fun buildPrompt(question: String, testing: Boolean): String {
        if (testing) return question
        val clean = cleanQuery(question)
        return if (isMultiQuestionBatch(question)) {
            "${buildSystemRules(false, question)}\n\n$clean"
        } else {
            "${buildSystemRules(false, question)}\n\nPregunta: $clean"
        }
    }

    private fun buildSystemRules(testing: Boolean, question: String): String {
        if (testing) return "Responde solo: OK"

        if (isMultiQuestionBatch(question)) {
            val count = batchQuestionCount(question)
            val trueFalseBatch = isTrueFalseBatch(question)
            val formatRule = if (trueFalseBatch) {
                "Para cada identificador escribe únicamente: N. Verdadero. o N. Falso. Escribe UNA respuesta por línea para que GI X pueda mostrarla apenas llegue. No repitas el enunciado y no justifiques salvo que se pida expresamente."
            } else {
                "Responde cada identificador según SU tipo: verdadero/falso -> N. Verdadero. o N. Falso.; alternativas -> N. B) texto exacto de la opción; completar frase -> N. palabra o frase exacta que falta; fórmula/dato puntual -> N. dato exacto; pregunta normal -> N. respuesta breve. Escribe UNA respuesta por línea para que GI X pueda mostrarla apenas llegue. No repitas los enunciados y no escribas la etiqueta Respuesta:."
            }
            return """
                Responde siempre en español, con respuestas claras, directas y académicamente correctas. La consulta proviene de texto extraído por OCR de una fotografía.
                Fecha local del celular: ${currentDateForPrompt()}. Si preguntan "hoy", "este mes" o "este año", usa esa fecha local.

                La consulta contiene $count preguntas. Debes responder TODAS, en el mismo orden y conservar exactamente los identificadores que aparecen en "Preguntas:", sin omitir ninguna.
                $formatRule

                Reglas obligatorias:
                1. Entrega SOLO la respuesta final, sin análisis ni razonamiento interno.
                2. Nunca escribas THINK, THOUGHT, REASONING, ANALYSIS, reglas, pasos internos ni explicación del proceso.
                3. Conserva EXACTAMENTE los números que aparecen en "Preguntas:". No renumeres 11 como 1 ni cambies ningún identificador.
                4. Si una pregunta es de alternativas A/B/C/D/E, responde SOLO con su número, la letra y el texto de la opción correcta. Ejemplo: 3. B) Casco. No expliques salvo que la propia pregunta lo exija.
                5. Si el lote está marcado como verdadero/falso, responde SOLO número + Verdadero/Falso. Ejemplo: 4. Verdadero. No agregues explicación salvo petición expresa.
                6. Si una pregunta pide completar una frase, responde SOLO con su número y la palabra o frase ESPECÍFICA que llena el espacio. No definas, no expliques y evita categorías generales si existe un término exacto. Si el OCR eliminó la línea de puntos y el ítem quedó como un fragmento de definición (por ejemplo empieza directamente con "Servicio que...", "Conjunto de..." o deja un punto aislado dentro de la oración), trátalo también como completar y usa sus ejemplos como pista para elegir el término MÁS específico.
                7. Si una pregunta pide fórmula química, símbolo químico, fecha o dato puntual, conserva exactamente ese dato.
                8. Si aparece [GIX_DOCUMENT_CONTEXT], usa ese bloque como fuente para responder. Puede contener una lectura, datos de un cuadro, formulario, instrucciones o valores medidos. No lo ignores y no lo trates como preguntas adicionales.
                9. Si aparece [GIX_TABLE_START], interpreta el bloque como una tabla: | separa columnas y [VACÍO] es una celda por completar.
                10. En una tabla conserva encabezados y relación fila/columna. No mezcles celdas. Si hay celdas vacías, responde cada fila con el valor que corresponde.
                11. Si una pregunta pide explicar, comparar o diferenciar, responde suficiente pero breve. Si solo pregunta "¿qué es...?" o "¿qué significa...?", da una definición de una oración. Si pregunta por una sigla o acrónimo, responde su nombre o expansión exacta cuando sea inequívoca.
                12. Algunas preguntas pueden no tener numeración impresa. GI X puede añadir un identificador técnico solo para asociar la respuesta; no lo interpretes como parte del documento.
                13. Cada respuesta debe comenzar con su identificador técnico y ocupar su propia línea para que GI X pueda asociarla y mostrarla en tiempo real. No repitas el enunciado, no escribas "Respuesta:", y NO uses otras listas numeradas dentro de la respuesta; para enumerar datos usa comas o punto y coma.
                14. No saludes, no uses Markdown, no respondas en inglés y no termines con frases incompletas.
                15. Si no sabes con seguridad, di: No tengo una respuesta segura.
            """.trimIndent()
        }

        val exerciseRule = when (classifyExercise(question)) {
            ExerciseType.COMPLETE ->
                "La consulta pide completar una frase. Responde ÚNICAMENTE con la palabra o frase concreta que falta. No escribas 'Respuesta', 'La palabra correcta es', definiciones ni explicaciones. El espacio puede estar al inicio, en medio o al final."
            ExerciseType.FORMULA ->
                "La consulta pide una formula o simbolo quimico. Responde solamente con la formula o simbolo, sin palabras adicionales."
            ExerciseType.TRUE_FALSE ->
                "La consulta es de verdadero o falso. Responde solamente: Verdadero. o Falso. No justifiques salvo que la propia pregunta lo pida."
            ExerciseType.MULTIPLE_CHOICE ->
                "La consulta es de alternativas. Elige una sola opción correcta y responde SOLO con letra + paréntesis + texto exacto de la opción, por ejemplo: B) Casco. No escribas 'La respuesta correcta es' y no expliques salvo que la pregunta lo pida."
            ExerciseType.DIRECT -> if (isComplexDirectQuestion(question)) {
                "La consulta es explicativa, comparativa o tiene varios puntos. Responde todos los elementos solicitados, menciona ambos conceptos si pide diferencias y usa varias oraciones completas cuando sea necesario. No reduzcas la respuesta a una sola idea."
            } else {
                "La consulta es directa. Responde de forma breve, precisa y académicamente correcta, sin simplificar tanto que se pierda el significado técnico."
            }
        }

        val lengthRule = when (classifyExercise(question)) {
            ExerciseType.FORMULA ->
                "Usa únicamente el formato solicitado."
            ExerciseType.COMPLETE ->
                "Usa únicamente la palabra o frase mínima necesaria para completar correctamente el espacio; normalmente entre 1 y 8 palabras."
            ExerciseType.TRUE_FALSE ->
                "Usa únicamente Verdadero o Falso, salvo que se solicite justificación."
            ExerciseType.MULTIPLE_CHOICE ->
                "Devuelve una sola alternativa en formato B) texto de la opción correcta."
            ExerciseType.DIRECT -> if (isComplexDirectQuestion(question)) {
                "Puedes usar hasta 100 palabras y varias oraciones completas para cubrir todos los puntos."
            } else {
                "Usa como máximo 55 palabras y una o dos oraciones completas."
            }
        }

        return """
            Responde siempre en español, con una respuesta clara y directa. Usa terminología académica correcta y conserva los conceptos técnicos indispensables. La pregunta proviene de texto extraído por OCR de una fotografía. Puede ser una pregunta general, académica o de opción múltiple. Identifica la pregunta principal y responde lo solicitado sin inventar texto que no esté presente.
            Fecha local del celular: ${currentDateForPrompt()}. Si preguntan "hoy", "este mes" o "este año", usa esa fecha local.

            Regla especial para esta consulta:
            $exerciseRule

            Reglas obligatorias:
            1. Entrega SOLO la respuesta final, sin análisis ni razonamiento interno.
            2. Nunca escribas THINK, THOUGHT, REASONING, ANALYSIS, reglas, pasos internos ni explicación del proceso.
            3. Si la pregunta es clara, responde sin restringirte a un tema concreto. No rechaces preguntas generales como fechas, días, cálculos simples o conceptos comunes.
            4. Nunca culpes al OCR ni pidas repetir si la pregunta recibida es suficientemente clara. La app maneja los errores de lectura antes de llamar a NET.
            5. Si no sabes con seguridad, di: No tengo una respuesta segura.
            6. Si preguntan fórmula química o símbolo químico, responde solo la fórmula o símbolo. Ejemplo: oro -> Au.
            7. Si preguntan tipos, clases, división, clasificación, lista o dicen "todos", responde los elementos principales de forma breve y completa.
            8. Si hay alternativas A/B/C/D/E o numeradas, elige una sola y responde en formato B) texto exacto de la opción. No añadas explicación salvo petición expresa.
            9. Si es verdadero o falso, responde únicamente Verdadero o Falso, salvo petición expresa de justificar.
            10. Si es completar frase, responde únicamente con la palabra o frase exacta que falta. No expliques. Si el OCR borró el hueco pero la oración quedó como un fragmento de definición, interprétala igualmente como completar y elige el término técnico más específico compatible con los ejemplos.
            11. Si es una definición simple de "qué es" o "qué significa", responde una sola oración precisa. Si pregunta por una sigla o acrónimo, da su expansión exacta cuando sea inequívoca. Si exige comparar o explicar varios puntos, responde todos.
            12. Las mismas reglas se aplican aunque la pregunta no tenga número. La falta de enumeración nunca debe cambiar el tipo ni la precisión de la respuesta.
            13. No saludes, no uses Markdown, no respondas en inglés y no termines con frases incompletas.
            14. $lengthRule
        """.trimIndent()
    }

    private fun classifyExercise(rawQuestion: String): ExerciseType {
        val normalized = ResponseRepository.normalize(rawQuestion)
        val rawLower = rawQuestion.lowercase(Locale.ROOT)
        return when {
            VoiceQuestionNormalizer.isCompletionExercise(rawQuestion) ||
                rawQuestion.contains("___") || rawQuestion.contains(".....") -> ExerciseType.COMPLETE

            normalized.contains("formula quimica") ||
                normalized.contains("simbolo quimico") ||
                normalized.contains("solo su formula") ||
                normalized.contains("solo la formula") ||
                normalized.contains("responde solo con la formula") -> ExerciseType.FORMULA

            normalized.contains("verdadero o falso") ||
                normalized.contains("verdadero falso") ||
                rawLower.contains("v/f") || rawLower.contains("v o f") ||
                (Regex("\\(\\s*\\)\\s*[.?!]*\\s*$").containsMatchIn(rawQuestion.trim()) &&
                    rawQuestion.count { it.isLetter() } >= 12) -> ExerciseType.TRUE_FALSE

            Regex("(?i)(?:^|\\s)[A-H][\\)\\].:-]\\s+").findAll(rawQuestion).count() >= 2 ||
                normalized.contains("cual de los siguientes") ||
                normalized.contains("cual de las siguientes") ||
                normalized.contains("de las siguientes opciones") ||
                normalized.contains("alternativa correcta") ||
                normalized.contains("opcion correcta") -> ExerciseType.MULTIPLE_CHOICE

            else -> ExerciseType.DIRECT
        }
    }

    private fun responseReadTimeout(question: String): Int {
        return if (isComplexDirectQuestion(question)) COMPLEX_READ_TIMEOUT_MS else READ_TIMEOUT_MS
    }

    private fun outputTokenLimit(question: String, testing: Boolean): Int {
        if (testing) return 512
        if (isMultiQuestionBatch(question)) {
            val count = batchQuestionCount(question)
            // Algunos modelos DeepSeek consumen parte del presupuesto en razonamiento
            // interno aunque la salida visible sea muy corta. Dejamos bastante margen
            // para que 5 V/F no terminen con finish_reason=length.
            if (isTrueFalseBatch(question)) return (2200 + count * 420).coerceIn(3600, 4096)
            return (2600 + count * 900).coerceIn(3800, 4096)
        }
        return when (classifyExercise(question)) {
            ExerciseType.TRUE_FALSE -> 2200
            ExerciseType.COMPLETE -> 2200
            ExerciseType.FORMULA -> 1200
            ExerciseType.MULTIPLE_CHOICE -> 2200
            ExerciseType.DIRECT -> if (isComplexDirectQuestion(question)) 3200 else 2600
        }
    }

    private fun answerWordLimit(question: String): Int {
        if (isMultiQuestionBatch(question)) {
            return (20 + batchQuestionCount(question) * 28).coerceAtMost(420)
        }
        return when (classifyExercise(question)) {
            ExerciseType.FORMULA -> 8
            ExerciseType.COMPLETE -> 12
            ExerciseType.TRUE_FALSE -> 18
            ExerciseType.MULTIPLE_CHOICE -> 24
            ExerciseType.DIRECT -> if (isComplexDirectQuestion(question)) 110 else 60
        }
    }

    private fun isComplexDirectQuestion(rawQuestion: String): Boolean {
        if (isMultiQuestionBatch(rawQuestion)) return true
        if (classifyExercise(rawQuestion) != ExerciseType.DIRECT) return false
        val question = ResponseRepository.normalize(rawQuestion)
        val complexCues = listOf(
            "explica", "explique", "describe", "describa", "compara", "compare",
            "diferencia entre", "diferencias entre", "principales diferencias", "indicando",
            "incluyendo", "causas y consecuencias", "ventajas y desventajas",
            "semejanzas y diferencias", "por que" 
        )
        val wordCount = question.split(" ").count { it.isNotBlank() }
        return complexCues.any { question == it || question.startsWith("$it ") || question.contains(" $it ") } ||
            wordCount >= 14
    }

    private fun isMultiQuestionBatch(rawQuestion: String): Boolean {
        return rawQuestion.contains(OcrQuestionExtractor.MULTI_PROMPT_HEADER)
    }

    private fun isTrueFalseBatch(rawQuestion: String): Boolean {
        return rawQuestion.contains(OcrQuestionExtractor.TRUE_FALSE_BATCH_HEADER)
    }

    private fun batchQuestionCount(rawQuestion: String): Int {
        if (!isMultiQuestionBatch(rawQuestion)) return 1
        val body = rawQuestion.substringAfter("Preguntas:", rawQuestion)
        val count = body.lines().count { Regex("^\\s*\\d{1,2}\\.").containsMatchIn(it) }
        return count.coerceAtLeast(1)
    }

    private fun batchQuestionIds(rawQuestion: String): List<Int> {
        if (!isMultiQuestionBatch(rawQuestion)) return listOf(1)
        val body = rawQuestion.substringAfter("Preguntas:", rawQuestion)
        return body.lines().mapNotNull { line ->
            Regex("^\\s*(\\d{1,2})\\.").find(line)?.groupValues?.getOrNull(1)?.toIntOrNull()
        }.distinct()
    }

    private fun maxAnswerChars(question: String): Int {
        return if (isMultiQuestionBatch(question)) {
            (2200 + batchQuestionCount(question) * 700).coerceAtMost(12000)
        } else {
            900
        }
    }

    private fun currentDateForPrompt(): String {
        return try {
            SimpleDateFormat("EEEE d 'de' MMMM 'de' yyyy, HH:mm", Locale("es", "PE"))
                .format(Calendar.getInstance().time)
        } catch (_: Exception) {
            "fecha local no disponible"
        }
    }

    private fun parseGeminiText(raw: String, question: String): String {
        val obj = JSONObject(raw)
        val candidates = obj.optJSONArray("candidates") ?: return ""
        val partsText = StringBuilder()
        var finishReason = ""

        for (i in 0 until candidates.length()) {
            val candidate = candidates.optJSONObject(i) ?: continue
            finishReason = candidate.optString("finishReason").orEmpty()
            val content = candidate.optJSONObject("content") ?: continue
            val parts = content.optJSONArray("parts") ?: continue

            for (j in 0 until parts.length()) {
                val text = parts.optJSONObject(j)?.optString("text").orEmpty().trim()
                appendCleanPart(partsText, text)
            }

            if (partsText.isNotBlank()) break
        }

        val clean = cleanAnswer(partsText.toString(), question)
        return if (finishReason.equals("MAX_TOKENS", ignoreCase = true) ||
            finishReason.equals("LENGTH", ignoreCase = true)
        ) {
            // Si una pregunta individual ya contiene una respuesta final completa,
            // la conservamos aunque el upstream haya marcado LENGTH después.
            if (!isMultiQuestionBatch(question) && isUsefulNetAnswer(clean, question)) clean else TOKEN_LIMIT_ANSWER
        } else {
            clean
        }
    }

    private fun parseChatCompletionsText(raw: String, question: String): String {
        val obj = JSONObject(raw)
        val choices = obj.optJSONArray("choices") ?: return ""
        val partsText = StringBuilder()
        var finishReason = ""

        for (i in 0 until choices.length()) {
            val choice = choices.optJSONObject(i) ?: continue
            finishReason = choice.optString(
                "finish_reason",
                choice.optString("native_finish_reason", choice.optString("finishReason"))
            )

            val message = choice.optJSONObject("message") ?: choice.optJSONObject("delta")
            if (message != null) {
                val contentValue = message.opt("content")
                if (contentValue != null && contentValue != JSONObject.NULL) {
                    appendJsonContent(partsText, contentValue)
                }
                if (partsText.isBlank()) {
                    appendCleanPart(partsText, message.optString("text").trim())
                }
            }

            // Algunos upstreams compatibles devuelven choices[].text.
            if (partsText.isBlank()) {
                appendCleanPart(partsText, choice.optString("text").trim())
            }
            if (partsText.isNotBlank()) break
        }

        val clean = cleanAnswer(partsText.toString(), question)
        if (finishReason.equals("length", ignoreCase = true) ||
            finishReason.equals("MAX_TOKENS", ignoreCase = true)
        ) {
            return if (!isMultiQuestionBatch(question) && isUsefulNetAnswer(clean, question)) clean else TOKEN_LIMIT_ANSWER
        }

        return clean
    }

    private fun parseCohereText(raw: String, question: String): String {
        val obj = JSONObject(raw)
        val partsText = StringBuilder()
        val message = obj.optJSONObject("message")
        val contentValue = message?.opt("content") ?: obj.opt("text") ?: return ""
        appendJsonContent(partsText, contentValue)
        val finishReason = obj.optString("finish_reason", obj.optString("finishReason"))
        val clean = cleanAnswer(partsText.toString(), question)
        return if (finishReason.equals("MAX_TOKENS", ignoreCase = true) ||
            finishReason.equals("length", ignoreCase = true)
        ) {
            if (!isMultiQuestionBatch(question) && isUsefulNetAnswer(clean, question)) clean else TOKEN_LIMIT_ANSWER
        } else {
            clean
        }
    }

    private fun appendJsonContent(builder: StringBuilder, value: Any) {
        when (value) {
            is String -> appendCleanPart(builder, value.trim())
            is JSONArray -> {
                for (i in 0 until value.length()) {
                    val item = value.opt(i)
                    when (item) {
                        is String -> appendCleanPart(builder, item.trim())
                        is JSONObject -> appendCleanPart(
                            builder,
                            item.optString("text", item.optString("content")).trim()
                        )
                    }
                }
            }
            is JSONObject -> appendCleanPart(builder, value.optString("text", value.optString("content")).trim())
        }
    }

    private fun appendCleanPart(builder: StringBuilder, text: String) {
        if (text.isBlank()) return
        if (builder.isNotBlank()) {
            val current = builder.toString().trimEnd()
            val firstChar = text.firstOrNull()
            val joinsDirectly = current.endsWith(":") ||
                current.endsWith("-") ||
                firstChar == ',' ||
                firstChar == '.' ||
                firstChar == ';' ||
                firstChar == ':'
            builder.append(if (joinsDirectly) "" else " ")
        }
        builder.append(text)
    }

    private fun safeProviderMessage(text: String): String = text
        .replace(Regex("""(?i)(?:ir_live_|ci_live_)[A-Za-z0-9._-]+"""), "[clave oculta]")
        .replace(Regex("""(?i)Bearer\s+[^\s,;"']+"""), "Bearer [clave oculta]")
        .replace(Regex("""(?i)sk-[A-Za-z0-9_-]{8,}"""), "[clave oculta]")
        .replace(Regex("""[\r\n\t]+"""), " ")
        .take(180)
        .trim()

    private fun providerRequestRef(raw: String?): String {
        val id = raw?.trim().orEmpty()
        return if (id.matches(Regex("[A-Za-z0-9_-]{6,100}"))) " · ID $id" else ""
    }

    private fun parseProviderError(raw: String, httpCode: Int, provider: NetProvider, model: String, requestRef: String? = null): NetCallResult {
        val message = safeProviderMessage(extractErrorMessage(raw))
        val httpInfo = "HTTP $httpCode${providerRequestRef(requestRef)}"
        val lower = "$message $raw".lowercase()

        return when {
            httpCode == 402 ||
                lower.contains("insufficient credits") || lower.contains("credit balance") ||
                lower.contains("no credits") || lower.contains("payment required") ->
                NetCallResult(false, "", "${provider.label} ($httpInfo): sin creditos o pago requerido.", provider, model, true, FailureType.LIMIT_DAILY)

            lower.contains("organization has been restricted") ||
                lower.contains("organization is restricted") ||
                lower.contains("organization restricted") ->
                NetCallResult(
                    false,
                    "",
                    "${provider.label} ($httpInfo): la organización de esta cuenta está restringida por el proveedor. La clave no puede usarse hasta que el proveedor quite la restricción.",
                    provider,
                    model,
                    true,
                    FailureType.INVALID
                )

            lower.contains("model_not_found") || lower.contains("model not found") ||
                lower.contains("invalid model") || lower.contains("does not exist") ||
                lower.contains("not a valid model") || lower.contains("unknown model") ->
                NetCallResult(false, "", "${provider.label} ($httpInfo): modelo incorrecto o no disponible: $model", provider, model, true, FailureType.INVALID)

            httpCode == 401 || httpCode == 403 ||
                lower.contains("api key not valid") || lower.contains("invalid api key") ||
                lower.contains("incorrect api key") || lower.contains("missing api key") ||
                lower.contains("invalid key") || lower.contains("unauthorized") ||
                lower.contains("unauthenticated") || lower.contains("authentication failed") ||
                lower.contains("permission_denied") || lower.contains("permission denied") ||
                lower.contains("forbidden") ->
                NetCallResult(false, "", "${provider.label} ($httpInfo): API Key invalida o sin permiso.", provider, model, true, FailureType.INVALID)

            lower.contains("per day") || lower.contains("perday") ||
                lower.contains("requestsperday") || lower.contains("rpd") ||
                lower.contains("daily quota") || lower.contains("daily limit") ->
                NetCallResult(false, "", "${provider.label} ($httpInfo): límite diario o créditos no disponibles.", provider, model, true, FailureType.LIMIT_DAILY)

            lower.contains("per minute") || lower.contains("perminute") ||
                lower.contains("requestsperminute") || lower.contains("tokensperminute") ||
                lower.contains("rpm") || lower.contains("tpm") ->
                NetCallResult(false, "", "${provider.label} ($httpInfo): límite por minuto.", provider, model, true, FailureType.LIMIT_MINUTE)

            httpCode == 429 || lower.contains("quota") || lower.contains("rate limit") ||
                lower.contains("ratelimit") || lower.contains("too many requests") ||
                lower.contains("resource_exhausted") || lower.contains("limit exceeded") ->
                NetCallResult(false, "", "${provider.label} ($httpInfo): límite temporal.", provider, model, true, FailureType.LIMIT_UNKNOWN)

            httpCode == 408 || httpCode == 409 || httpCode == 425 || httpCode in 500..599 ->
                NetCallResult(false, "", "${provider.label} ($httpInfo): ${message.ifBlank { "El servidor rechazó temporalmente la solicitud." }}", provider, model, true, FailureType.TEMPORARY)

            httpCode == 400 || httpCode == 404 || httpCode == 405 || httpCode == 422 ->
                NetCallResult(
                    false,
                    "",
                    "${provider.label} ($httpInfo): configuracion o modelo no aceptado. ${message.take(160)}".trim(),
                    provider,
                    model,
                    true,
                    FailureType.INVALID
                )

            httpCode in 400..499 ->
                NetCallResult(
                    false,
                    "",
                    "${provider.label} ($httpInfo): solicitud rechazada. ${message.take(160)}".trim(),
                    provider,
                    model,
                    true,
                    FailureType.INVALID
                )

            message.isNotBlank() ->
                NetCallResult(false, "", "${provider.label} ($httpInfo): ${message.take(220)}", provider, model, true, FailureType.OTHER)

            else -> NetCallResult(false, "", "${provider.label} ($httpInfo): error de API. Revisa clave, modelo o internet.", provider, model, true, FailureType.OTHER)
        }
    }

    private fun extractErrorMessage(raw: String): String {
        return try {
            val obj = JSONObject(raw)
            val error = obj.opt("error")
            when (error) {
                is JSONObject -> error.optString("message", error.optString("error", error.toString()))
                is String -> error
                else -> obj.optString("message", obj.optString("detail", raw.take(260)))
            }.trim()
        } catch (_: Exception) {
            raw.take(260).trim()
        }
    }

    private fun networkResult(e: Exception, provider: NetProvider, model: String): NetCallResult {
        val msg = (e.message ?: "error de conexión").lowercase(Locale.ROOT)
        return when (e) {
            is SocketTimeoutException -> NetCallResult(
                false, "", "${provider.label}: agotó el tiempo de espera de la conexión o de la respuesta. GI X no recibió un código HTTP que permita atribuir el fallo al servidor. Comprueba datos móviles y ruta Wi-Fi; la API permanece guardada.",
                provider, model, true, FailureType.NETWORK
            )
            is ConnectException -> NetCallResult(
                false, "", "${provider.label}: no aceptó la conexión. La API sigue guardada; revisa Internet y vuelve a intentar.",
                provider, model, true, FailureType.TEMPORARY
            )
            is UnknownHostException -> NetCallResult(
                false, "", "Sin conexión estable a Internet. Revisa datos o Wi-Fi.",
                provider, model, true, FailureType.NETWORK
            )
            else -> when {
                msg.contains("timeout") || msg.contains("timed out") -> NetCallResult(
                    false, "", "${provider.label}: la respuesta tardó más de lo permitido por GI X. La API sigue guardada.",
                    provider, model, true, FailureType.TEMPORARY
                )
                msg.contains("reset") -> NetCallResult(
                    false, "", "${provider.label}: conexión reiniciada.",
                    provider, model, true, FailureType.TEMPORARY
                )
                msg.contains("unable to resolve") || msg.contains("network is unreachable") -> NetCallResult(
                    false, "", "Sin conexión estable a Internet. Revisa datos o Wi-Fi.",
                    provider, model, true, FailureType.NETWORK
                )
                else -> NetCallResult(
                    false, "", "No se pudo conectar con ${provider.label}. La API sigue guardada; revisa Internet y vuelve a intentar.",
                    provider, model, true, FailureType.TEMPORARY
                )
            }
        }
    }

    private fun beginRuntimeRequest(): Int {
        synchronized(connectionLock) {
            val id = runtimeRequestId.incrementAndGet()
            runCatching { activeRuntimeConnection?.disconnect() }
            activeRuntimeConnection = null
            return id
        }
    }

    private fun isRuntimeRequestActive(requestId: Int): Boolean {
        return runtimeRequestId.get() == requestId && !Thread.currentThread().isInterrupted
    }

    private fun registerRuntimeConnection(requestId: Int?, connection: HttpURLConnection?): Boolean {
        if (requestId == null || connection == null) return true
        synchronized(connectionLock) {
            if (!isRuntimeRequestActive(requestId)) {
                runCatching { connection.disconnect() }
                return false
            }
            activeRuntimeConnection = connection
            return true
        }
    }

    private fun clearRuntimeConnection(requestId: Int?, connection: HttpURLConnection? = null) {
        if (requestId == null) return
        synchronized(connectionLock) {
            if (runtimeRequestId.get() == requestId &&
                (connection == null || activeRuntimeConnection === connection)
            ) {
                activeRuntimeConnection = null
            }
        }
    }

    private fun cancelledResult(provider: NetProvider, model: String): NetCallResult {
        return NetCallResult(
            ok = false,
            text = "",
            error = "Consulta NET cancelada.",
            provider = provider,
            model = model,
            canTryNextApi = false,
            failureType = FailureType.CANCELLED
        )
    }

    private fun netAnswerIssue(text: String, question: String): String? {
        if (isMultiQuestionBatch(question)) {
            return batchAnswerIssue(text, question)
        }

        if (text.trim() == TOKEN_LIMIT_ANSWER) {
            return "Se agotó el límite de salida antes de terminar la respuesta."
        }
        if (!isUsefulNetAnswer(text, question)) return "Respuesta vacía, incompleta o con formato incorrecto."

        val lower = text.lowercase(Locale.ROOT)
        if (lower.contains("<html") || lower.contains("<!doctype") || lower.contains("http error")) {
            return "Respuesta técnica inválida."
        }

        val exerciseType = classifyExercise(question)
        if (exerciseType != ExerciseType.FORMULA && looksClearlyEnglish(text)) {
            return "Respuesta claramente en inglés."
        }

        // "B) Alternativa" y "1) Respuesta" son marcadores, NO paréntesis sin abrir.
        // Antes rechazábamos respuestas correctas de selección múltiple.
        if (hasUnbalancedDelimitersForBatch(text) || hasSuspiciousCutEnding(text)) {
            return "Respuesta cortada o con signos sin cerrar."
        }

        if (exerciseType == ExerciseType.DIRECT && isComplexDirectQuestion(question)) {
            val wordCount = text.split(Regex("\\s+")).count { it.isNotBlank() }
            // Un resumen correcto de 6-11 palabras no debe desecharse después
            // de pagar la consulta. Seguimos rechazando contestaciones triviales.
            if (wordCount < 6) return "Respuesta demasiado corta para una pregunta explicativa."

            val requiredTerms = comparisonRequiredTerms(question)
            if (requiredTerms != null) {
                val normalizedAnswer = ResponseRepository.normalize(text)
                if (requiredTerms.any { term -> !normalizedAnswer.contains(term) }) {
                    return "La comparación no respondió ambos conceptos."
                }
            }
        }

        if (asksForCurrentPrice(question) && !containsPriceInformation(text)) {
            return "La consulta pide un precio actual, pero la respuesta no contiene precio ni moneda."
        }

        return null
    }

    private fun batchAnswerIssue(text: String, question: String): String? {
        val clean = text.trim()
        if (clean == TOKEN_LIMIT_ANSWER) {
            return "Se agotó el límite de salida antes de terminar todas las respuestas."
        }
        if (clean.isBlank() || clean == BAD_NET_ANSWER) {
            return "Respuesta vacía o no utilizable."
        }

        val lower = clean.lowercase(Locale.ROOT)
        if (lower.contains("<html") || lower.contains("<!doctype") || lower.contains("http error")) {
            return "Respuesta técnica inválida."
        }
        if (looksLikeInternalLeak(clean)) {
            return "La respuesta incluyó texto interno no permitido."
        }
        if (clean.length > maxAnswerChars(question)) {
            return "La respuesta superó el tamaño máximo permitido."
        }
        if (hasUnbalancedDelimitersForBatch(clean) || hasSuspiciousCutEnding(clean)) {
            return "Respuesta cortada o con signos sin cerrar."
        }
        if (looksClearlyEnglish(clean)) {
            return "Respuesta claramente en inglés."
        }

        val expectedIds = batchQuestionIds(question)
        val expected = expectedIds.size.coerceAtLeast(batchQuestionCount(question))
        // Una tabla aislada es un solo ejercicio aunque contenga muchas filas. Algunos
        // modelos responden directamente las filas sin anteponer "1. Respuesta:".
        if (expected == 1 && question.contains(OcrTableFormatter.TABLE_START) && clean.length >= 8) {
            return null
        }
        // Una sola pregunta acompañada de una lectura usa el envoltorio de lote.
        // Si el proveedor omite "1.", la respuesta sigue siendo vinculable a esa
        // única pregunta. No descartarla solo por falta de identificador.
        if (expected == 1 &&
            !hasUnbalancedDelimitersForBatch(clean) &&
            !hasSuspiciousCutEnding(clean) &&
            !Regex("(?m)^\\s*(?:pregunta\\s*)?\\d{1,2}\\s*[.):\\-]").containsMatchIn(clean)
        ) return null

        val numberedIds = Regex(
            "(?im)^\\s*(?:pregunta\\s*)?(\\d{1,2})\\s*(?:[.):]|-|$)"
        ).findAll(clean)
            .mapNotNull { it.groupValues.getOrNull(1)?.toIntOrNull() }
            .toSet()

        val answerLabels = Regex(
            "(?im)^\\s*(?:respuesta|rpta|resp)\\s*:"
        ).findAll(clean).count()

        // Para preguntas impresas 11..15 verificamos 11..15, no 1..5.
        val idCoverage = if (expectedIds.isNotEmpty()) numberedIds.intersect(expectedIds.toSet()).size else numberedIds.size
        val coverage = maxOf(idCoverage, answerLabels)
        if (coverage >= expected) return null

        val missing = if (expectedIds.isNotEmpty()) expectedIds.filterNot { it in numberedIds } else emptyList()
        return if (missing.isNotEmpty()) {
            "La respuesta cubrió $coverage de $expected preguntas. Faltaron los números: ${missing.joinToString(", ")}."
        } else {
            "La respuesta cubrió $coverage de $expected preguntas."
        }
    }

    private fun hasUnbalancedDelimiters(text: String): Boolean {
        fun balanced(open: Char, close: Char): Boolean {
            var depth = 0
            for (char in text) {
                if (char == open) depth += 1
                if (char == close) {
                    depth -= 1
                    if (depth < 0) return false
                }
            }
            return depth == 0
        }
        return !balanced('(', ')') || !balanced('[', ']') || !balanced('{', '}')
    }


    /**
     * En respuestas por lote, "1)" y "B)" son marcadores normales de listas/opciones,
     * no paréntesis de cierre reales. Los neutralizamos SOLO para comprobar equilibrio
     * de delimitadores; el texto original se conserva para mostrarlo y validarlo.
     */
    private fun hasUnbalancedDelimitersForBatch(text: String): Boolean {
        val withoutListMarkers = text
            .replace(
                Regex("""(?im)(^|[\n\r])\s*((?:pregunta\s*)?\d{1,2})\)\s+"""),
                "$1$2. "
            )
            .replace(
                Regex("""(?im)(^|[\n\r\t :;,-])([A-H])\)\s+"""),
                "$1$2. "
            )
        return hasUnbalancedDelimiters(withoutListMarkers)
    }

    private fun hasSuspiciousCutEnding(text: String): Boolean {
        val clean = text.trim()
        if (clean.isBlank()) return true
        if (Regex("(?i)(?:\\(|\\s)(?:p|ej)\\.$").containsMatchIn(clean)) return true
        if (clean.endsWith("(") || clean.endsWith("[") || clean.endsWith("{") || clean.endsWith("-") || clean.endsWith(":")) return true
        return false
    }

    private fun comparisonRequiredTerms(rawQuestion: String): List<String>? {
        val question = ResponseRepository.normalize(rawQuestion)
        val match = Regex("(?:diferencia|diferencias) entre (.+?) (?:y|e|con) (.+?)(?: indicando| incluyendo| menciona| explica|$)")
            .find(question) ?: return null
        val generic = setOf(
            "el", "la", "los", "las", "un", "una", "de", "del", "y", "e", "con",
            "concepto", "conceptos", "tema", "tipos", "tipo"
        )
        fun distinctive(phrase: String): String? = phrase.split(" ")
            .firstOrNull { it.length >= 3 && it !in generic }
        val left = distinctive(match.groupValues[1])
        val right = distinctive(match.groupValues[2])
        if (left.isNullOrBlank() || right.isNullOrBlank() || left == right) return null
        return listOf(left, right)
    }

    private fun asksForCurrentPrice(rawQuestion: String): Boolean {
        val question = ResponseRepository.normalize(rawQuestion)
        val priceCue = question.contains("cuanto vale") || question.contains("precio") ||
            question.contains("cotizacion") || question.contains("costo")
        val currentCue = question.contains("hoy") || question.contains("actual") ||
            question.contains("ahora") || question.contains("este dia")
        return priceCue && currentCue
    }

    private fun containsPriceInformation(text: String): Boolean {
        val normalizedWords = ResponseRepository.normalize(text)
            .split(" ")
            .filter { it.isNotBlank() }
            .toSet()
        val hasNumber = Regex("\\d").containsMatchIn(text)
        val hasCurrencySymbol = text.contains("$") || Regex("(?i)S\\s*/").containsMatchIn(text)
        val moneyCue = setOf(
            "sol", "soles", "dolar", "dolares", "usd", "pen", "euro", "euros"
        ).any { it in normalizedWords }
        return hasNumber && (hasCurrencySymbol || moneyCue)
    }

    private fun looksClearlyEnglish(text: String): Boolean {
        val normalized = text.lowercase(Locale.ROOT)
            .replace(Regex("[^a-záéíóúüñ ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        if (normalized.isBlank()) return false

        val words = normalized.split(" ").filter { it.isNotBlank() }
        val strongEnglishPhrases = listOf(
            "the answer is", "this is", "it is", "there are", "is defined as",
            "refers to", "according to", "in order to"
        )
        if (strongEnglishPhrases.any { normalized.contains(it) }) return true

        val englishMarkers = setOf(
            "the", "is", "are", "of", "to", "and", "in", "for", "with", "this", "that",
            "from", "by", "on", "as", "an", "its", "it", "can", "be", "which", "when"
        )
        val spanishMarkers = setOf(
            "el", "la", "los", "las", "es", "son", "de", "del", "que", "para", "por", "con",
            "una", "un", "en", "y", "se", "su", "al", "como", "cuando", "entre", "sobre"
        )

        val englishScore = words.count { it in englishMarkers }
        val spanishScore = words.count { it in spanishMarkers }
        return words.size >= 4 && englishScore >= 2 && englishScore > spanishScore + 1
    }

    private fun orderedConfigs(configs: List<NetApiConfig>, startIndex: Int): List<Pair<Int, NetApiConfig>> {
        if (configs.isEmpty()) return emptyList()
        val safeStart = startIndex.coerceIn(0, configs.size - 1)
        return configs.indices.map { offset ->
            val index = (safeStart + offset) % configs.size
            index to configs[index]
        }
    }

    private fun cleanQuery(raw: String): String {
        return raw
            .replace("\r\n", "\n")
            .replace('\r', '\n')
            .lines()
            .map { it.replace(Regex("[ \\t]+"), " ").trimEnd() }
            .dropWhile { it.isBlank() }
            .dropLastWhile { it.isBlank() }
            .joinToString("\n")
            .replace(Regex("\n{3,}"), "\n\n")
            .trim()
    }

    private fun cleanAnswer(raw: String, question: String): String {
        var candidate = raw
            .replace("**", "")
            .replace("```", "")
            .trim()

        candidate = removeReasoningLeak(candidate).trim()

        candidate = candidate
            .replace(Regex("^(Respuesta final|Respuesta|Final)\\s*:\\s*", RegexOption.IGNORE_CASE), "")
            .replace(Regex("^(Rpta|Resp)\\s*:\\s*", RegexOption.IGNORE_CASE), "")
            .trim()

        if (candidate.isBlank()) return BAD_NET_ANSWER
        if (looksLikeInternalLeak(candidate)) return BAD_NET_ANSWER

        if (isMultiQuestionBatch(question)) {
            candidate = candidate
                .replace("\r\n", "\n")
                .replace('\r', '\n')
                .lines()
                .map { line -> line.replace(Regex("[ \\t]+"), " ").trimEnd() }
                .dropWhile { it.isBlank() }
                .dropLastWhile { it.isBlank() }
                .joinToString("\n")
                .replace(Regex("\n{3,}"), "\n\n")
                .trim()
            if (candidate.length > maxAnswerChars(question)) return BAD_NET_ANSWER
            return candidate
        }

        candidate = candidate
            .replace("\\s+".toRegex(), " ")
            .trim()

        candidate = trimToSafeNetAnswer(candidate, question)

        candidate = candidate.replace(Regex("\\s+"), " ").trim()
        if (candidate.length > maxAnswerChars(question)) {
            return BAD_NET_ANSWER
        }
        return candidate
    }

    private fun looksIncompleteNetAnswer(text: String): Boolean {
        val clean = text.trim()
        if (clean.isBlank()) return true
        if (clean == BAD_NET_ANSWER) return false
        if (clean.endsWith("...") || clean.endsWith("…")) return true
        if (hasUnbalancedDelimitersForBatch(clean) || hasSuspiciousCutEnding(clean)) return true
        val normalizedEnding = ResponseRepository.normalize(
            clean.trimEnd('.', '!', '?', ',', ';', ':', '-', ' ')
        )
        val badEndings = listOf(
            "es un", "es una", "es el", "es la", "son", "sirve para",
            "se usa para", "consiste en", "significa", "de", "del", "para", "por",
            "por el", "por la", "por los", "por las", "en", "con", "sin",
            "recibe el", "recibe la", "recibe los", "recibe las",
            "comprende unicamente", "comprende solamente", "se paga por el", "se paga por la",
            "se paga por los", "se paga por las"
        )
        return badEndings.any { ending ->
            normalizedEnding == ending || normalizedEnding.endsWith(" $ending")
        }
    }

    private fun trimToSafeNetAnswer(text: String, question: String): String {
        val clean = text.replace(Regex("\\s+"), " ").trim()
        if (clean.isBlank()) return BAD_NET_ANSWER

        val maxWords = answerWordLimit(question)
        val words = clean.split(" ").filter { it.isNotBlank() }
        if (words.size <= maxWords) return clean

        // Solo se acorta en limites de oracion reales. No se toma el primer punto
        // a ciegas porque abreviaturas como "p. ej." producian respuestas "(p.".
        val sentences = clean.split(Regex("(?<=[.!?])\\s+(?=[A-ZÁÉÍÓÚÑ])"))
        val accepted = mutableListOf<String>()
        var usedWords = 0
        for (sentence in sentences) {
            val sentenceWords = sentence.trim().split(Regex("\\s+")).count { it.isNotBlank() }
            if (sentenceWords == 0) continue
            if (usedWords + sentenceWords > maxWords) break
            accepted += sentence.trim()
            usedWords += sentenceWords
        }

        return accepted.joinToString(" ").trim().takeIf { it.length >= 12 } ?: BAD_NET_ANSWER
    }

    private fun removeReasoningLeak(raw: String): String {
        if (!looksLikeInternalLeak(raw)) return raw

        val finalLabel = Regex(
            "(?is)(respuesta final|respuesta|final|answer)\\s*:\\s*(.+)$"
        ).findAll(raw).lastOrNull()
        val possibleFinal = finalLabel?.groups?.get(2)?.value.orEmpty().trim()
        if (possibleFinal.isNotBlank() && !looksLikeInternalLeak(possibleFinal)) {
            return possibleFinal
        }

        return BAD_NET_ANSWER
    }

    private fun looksLikeInternalLeak(text: String): Boolean {
        val lower = text.lowercase()
        val badMarkers = listOf(
            "think:",
            "thought:",
            "reasoning:",
            "analysis:",
            "internal reasoning",
            "chain of thought",
            "the user is asking",
            "i need to",
            "given the strict rules",
            "given the context",
            "falls under",
            "rule #",
            "system rules",
            "reglas obligatorias",
            "contexto principal:"
        )
        return badMarkers.any { lower.contains(it) }
    }

    private fun isUsefulNetAnswer(text: String, question: String): Boolean {
        val clean = text.trim()
        if (clean.isBlank()) return false
        if (clean == BAD_NET_ANSWER || clean == TOKEN_LIMIT_ANSWER) return false
        if (isMultiQuestionBatch(question)) return batchAnswerIssue(clean, question) == null
        val lower = clean.lowercase()
            .replace("í", "i")
            .replace("é", "e")
        if (lower.contains("no entendi") || lower.contains("no entendi bien") || lower.contains("repite la pregunta")) return false
        if (looksLikeInternalLeak(clean)) return false

        return when (classifyExercise(question)) {
            ExerciseType.COMPLETE -> {
                val words = clean.split(Regex("\\s+")).filter { it.isNotBlank() }
                words.isNotEmpty() && words.size <= 40 && clean.length <= 260
            }
            ExerciseType.FORMULA -> {
                val compact = clean.replace(" ", "")
                compact.length in 1..48 &&
                    Regex("^[A-Za-z0-9₀-₉⁰-⁹⁺⁻()\\[\\]{}.+−+\\-·•_/]+$").matches(compact)
            }
            ExerciseType.TRUE_FALSE -> {
                val normalizedAnswer = ResponseRepository.normalize(clean)
                normalizedAnswer.contains("verdadero") || normalizedAnswer.contains("falso")
            }
            ExerciseType.MULTIPLE_CHOICE -> {
                Regex("(?i)(?:respuesta\\s+correcta\\s*:\\s*)?[A-H][\\)\\].:-]?").containsMatchIn(clean) ||
                    clean.length in 1..160
            }
            ExerciseType.DIRECT ->
                !looksIncompleteNetAnswer(clean) && !looksLikeUnterminatedProse(clean, question)
        }
    }

    private fun looksLikeUnterminatedProse(text: String, question: String): Boolean {
        val clean = text.trim()
        if (clean.isBlank()) return true
        if (clean.lastOrNull() in listOf('.', '!', '?')) return false

        val words = clean.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.size <= 4) return false

        val normalizedQuestion = ResponseRepository.normalize(question)
        val listExpected = listOf(
            "tipos", "clases", "lista", "enumera", "menciona", "cuales son",
            "componentes", "elementos"
        ).any { normalizedQuestion.contains(it) }

        if (listExpected && (clean.contains(',') || clean.contains(';'))) return false
        return true
    }

    private enum class ExerciseType {
        COMPLETE, FORMULA, TRUE_FALSE, MULTIPLE_CHOICE, DIRECT
    }

    companion object {
        private const val CHEAPER_CHAT_ENDPOINT = "https://api.cheaperinference.com/v1/chat/completions"
        private const val VISION_MODEL = "gpt-5.6-luna"
        private const val VISION_MAX_OUTPUT_TOKENS = 5000
        private const val VISION_READ_TIMEOUT_MS = 120_000
        private const val MAX_VISION_IMAGES = 4
        private const val MAX_VISION_IMAGE_BYTES = 5 * 1024 * 1024
        private const val MAX_VISION_TOTAL_BYTES = 23L * 1024L * 1024L
        private val SUPPORTED_VISION_MIME_TYPES = setOf("image/jpeg", "image/png", "image/webp")
        private val VISION_DOCUMENT_PROMPT = """
            Estas imágenes son 1 a 4 fotografías del MISMO documento o examen. Léelas TODAS juntas. Para cada pregunta, línea, símbolo o zona compara las tomas y toma como base la imagen donde ESA PARTE esté más nítida y legible; usa las demás para completar lo que falte. No descartes una foto completa solo porque otra sea mejor en general.

            TAREA ÚNICA: reconstruye TODO el contenido del documento necesario para responder: texto de referencia, lecturas, tablas, instrucciones y TODAS las preguntas visibles. NO respondas las preguntas.

            Reglas obligatorias:
            - Conserva la numeración original y el orden real.
            - Si el documento empieza, por ejemplo, en 6 o 11, empieza exactamente ahí: NO inventes preguntas anteriores ni renumeres.
            - Si una pregunta NO tiene número impreso, NO le agregues 1, 2, 3 ni ningún número; sepárala de la siguiente con una línea en blanco.
            - Si una pregunta continúa en la línea siguiente, únela completa.
            - Si la misma pregunta aparece en varias fotos, compara nitidez y legibilidad de esa zona y devuelve una sola versión usando la toma más clara para esa parte, complementada únicamente con información visible en las otras tomas.
            - Reconoce preguntas abiertas, alternativas A/B/C/D, verdadero/falso, completar espacios, tablas, fórmulas, escalas, coordenadas, unidades y símbolos técnicos.
            - La escritura puede ser a mano: compara formas de letras manuscritas, números, signos y alternativas entre las 1-4 tomas; conserva la redacción original y usa contexto solo para desambiguar trazos visibles, nunca para inventar texto.
            - No confundas escalas, medidas, códigos alfanuméricos, fechas/años ni números internos de tablas con nuevas preguntas.
            - Incluye el texto explicativo de arriba y el que aparezca entre preguntas: no lo resumas ni lo sustituyas por conocimientos tuyos.
            - En alternativas, conserva cada opción debajo de su pregunta.
            - En V/F, conserva cada afirmación numerada.
            - En tablas, conserva encabezados, filas, columnas y números con su unidad. Una tabla de referencia va en CONTEXTO DETECTADO; una tabla que se deba completar permanece debajo de su pregunta.
            - Si una captura incluye solo lectura y otra solo preguntas, reconstruye ambas partes en el mismo documento.
            - Ignora mesa, fondos, marcas externas, métricas, nombres de archivos y texto que claramente no pertenezca al documento.
            - NO inventes preguntas, palabras ni números que no sean visibles en ninguna toma.
            - Si una parte pequeña es imposible de leer en TODAS las fotos, escribe [ilegible] solo en esa parte, sin eliminar el resto de la pregunta.
            - No escribas explicaciones, comentarios, encabezados tipo “Imagen 1”, ni bloques Markdown.

            Devuelve únicamente dos secciones de la transcripción, en este orden exacto:
            CONTEXTO DETECTADO
            (Transcribe lecturas, cuadros de referencia, datos e instrucciones vistos. Si no existen, deja vacía esta sección.)

            PREGUNTAS DETECTADAS
            (Transcribe preguntas y todas sus alternativas, afirmaciones V/F y tablas por completar. No inventes números.)
        """.trimIndent()

        const val API_ERROR_PREFIX = "[GIX_API_ERROR]"
        private const val RUNTIME_MAX_ATTEMPTS = 3
        private const val TEST_MAX_ATTEMPTS = 1
        private const val RETRY_BASE_DELAY_MS = 1500L

        fun canonicalizeAnswerForQuestion(rawQuestion: String, rawAnswer: String): String {
            val answer = rawAnswer.trim()
            if (answer.isBlank()) return answer

            // Los lotes V/F tienen un formato deliberadamente mínimo. Aunque el
            // proveedor añada "Respuesta:", lo quitamos para mantener una salida
            // estable: "1. Verdadero.".
            if (rawQuestion.contains(OcrQuestionExtractor.TRUE_FALSE_BATCH_HEADER)) {
                return answer.lines().joinToString("\n") { line ->
                    val match = Regex(
                        """^(\s*(?:Pregunta\s*)?\d{1,2}\s*[\.):\-]\s*)(?:Respuesta\s*:\s*)?(Verdadero|Falso)\.?\s*$""",
                        RegexOption.IGNORE_CASE
                    ).find(line)
                    if (match != null) {
                        val prefix = match.groupValues[1]
                            .replace(Regex("""(?i)Pregunta\s+"""), "")
                            .replace(Regex("""[):\-]\s*$"""), ". ")
                        val value = if (match.groupValues[2].equals("verdadero", ignoreCase = true)) "Verdadero" else "Falso"
                        "$prefix$value."
                    } else line
                }.trim()
            }

            if (rawQuestion.contains(OcrQuestionExtractor.MULTI_PROMPT_HEADER)) return answer

            val normalizedQuestion = ResponseRepository.normalize(rawQuestion)
            val rawLower = rawQuestion.lowercase(Locale.ROOT)
            val isTf = normalizedQuestion.contains("verdadero o falso") ||
                normalizedQuestion.contains("verdadero falso") || rawLower.contains("v/f") ||
                rawLower.contains("v o f") ||
                (Regex("""\(\s*\)\s*[.?!]*\s*$""").containsMatchIn(rawQuestion.trim()) &&
                    rawQuestion.count { it.isLetter() } >= 12)
            if (isTf) {
                val value = Regex("""(?i)\b(verdadero|falso)\b""").find(answer)?.groupValues?.getOrNull(1)
                if (!value.isNullOrBlank()) {
                    return (if (value.equals("verdadero", ignoreCase = true)) "Verdadero" else "Falso") + "."
                }
            }

            val optionMatches = Regex("""(?i)(?:^|\s)([A-H])\s*[\)\].:-]\s*(.+)$""").find(answer)
            val qOptionCount = Regex("""(?i)(?:^|\s)[A-H][\)\].:-]\s+""").findAll(rawQuestion).count()
            val isChoice = qOptionCount >= 2 ||
                normalizedQuestion.contains("cual de los siguientes") ||
                normalizedQuestion.contains("cual de las siguientes") ||
                normalizedQuestion.contains("de las siguientes opciones") ||
                normalizedQuestion.contains("alternativa correcta") ||
                normalizedQuestion.contains("opcion correcta")
            if (isChoice && optionMatches != null) {
                val letter = optionMatches.groupValues[1].uppercase(Locale.ROOT)
                val text = optionMatches.groupValues[2]
                    .replace(Regex("""(?i)^respuesta\s*:\s*"""), "")
                    .trim().trimEnd('.')
                return "$letter) $text".trim()
            }

            val isComplete = VoiceQuestionNormalizer.isCompletionExercise(rawQuestion) ||
                rawQuestion.contains("___") || rawQuestion.contains(".....")
            if (isComplete) {
                return answer
                    .replace(Regex("""(?i)^\s*(?:respuesta|rpta|resp)\s*:\s*"""), "")
                    .replace(Regex("""(?i)^\s*la\s+(?:palabra|frase)\s+(?:correcta|que\s+falta)\s+es\s*:\s*"""), "")
                    .trim()
            }

            return answer
        }

        fun requiresStructuredNetAnswer(rawQuestion: String): Boolean {
            val question = ResponseRepository.normalize(rawQuestion)
            return VoiceQuestionNormalizer.isCompletionExercise(question) ||
                question.contains("formula quimica") ||
                question.contains("simbolo quimico") ||
                question.contains("solo su formula") ||
                question.contains("solo la formula") ||
                question.contains("responde solo con la formula")
        }

        private const val CONNECT_TIMEOUT_MS = 20000
        private const val READ_TIMEOUT_MS = 90_000
        private const val COMPLEX_READ_TIMEOUT_MS = 120_000
        private const val TEST_CONNECT_TIMEOUT_MS = 10000
        private const val TEST_READ_TIMEOUT_MS = 90_000
        private const val BAD_ANSWER_COOLDOWN_MS = 10L * 60L * 1000L
        private const val MAX_CONSECUTIVE_NETWORK_FAILURES = 2
        private const val MAX_SPOKEN_NET_CHARS = 900
        private const val MAX_SPOKEN_NET_WORDS = 120
        private const val BAD_NET_ANSWER = "API_NO_UTIL"
        private const val TOKEN_LIMIT_ANSWER = "API_TOKEN_LIMIT"
    }
}
