package com.gix.cameraai

object OcrQuestionExtractor {
    private val optionLine = Regex("^(?:[A-Ha-h][\\)\\].:-]|[1-9][\\)\\].:-])\\s*.+")
    private val junkOnly = Regex("^[\\W_]+$")

    fun extract(raw: String): String {
        val lines = raw.lines()
            .map { it.replace(Regex("\\s+"), " ").trim() }
            .filter { it.length >= 2 && !junkOnly.matches(it) }

        if (lines.isEmpty()) return ""

        val questionIndex = lines.indexOfLast { line ->
            line.contains('?') || line.contains('¿') || startsLikeQuestion(line)
        }

        if (questionIndex >= 0) {
            val selected = mutableListOf(lines[questionIndex])
            for (i in (questionIndex + 1) until lines.size) {
                val line = lines[i]
                if (optionLine.matches(line) || selected.size == 1 && looksLikeOption(line)) {
                    selected += line
                    if (selected.size >= 7) break
                } else if (selected.size > 1) {
                    break
                }
            }
            return selected.joinToString("\n").take(1800)
        }

        val meaningful = lines.filter { it.length >= 5 }
        if (meaningful.isEmpty()) return lines.joinToString("\n").take(1800)

        // Para una foto centrada en una pregunta sin signos, conservar suficiente contexto
        // sin mandar una página entera a la API.
        return meaningful.takeLast(8).joinToString("\n").take(1800)
    }

    private fun startsLikeQuestion(line: String): Boolean {
        val clean = line.lowercase()
        return listOf(
            "qué ", "que ", "cuál ", "cual ", "cuáles ", "cuales ", "cómo ", "como ",
            "por qué ", "por que ", "dónde ", "donde ", "cuándo ", "cuando ",
            "quién ", "quien ", "quiénes ", "quienes ", "cuánto ", "cuanto ",
            "menciona ", "explica ", "define ", "indica ", "completa ", "resuelve "
        ).any { clean.startsWith(it) }
    }

    private fun looksLikeOption(line: String): Boolean {
        val clean = line.trim()
        return clean.length in 2..120 && (clean.startsWith("(") || clean.startsWith("•"))
    }
}
