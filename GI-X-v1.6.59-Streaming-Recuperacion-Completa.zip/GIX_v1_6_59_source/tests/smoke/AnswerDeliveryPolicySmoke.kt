import com.gix.cameraai.AnswerDeliveryPolicy

fun main() {
    val detailed = "3. Explique de qué manera realizamos una nivelación simple, los datos y los instrumentos."
    require(AnswerDeliveryPolicy.holdSingleExplanatorySpeech(detailed))
    require(!AnswerDeliveryPolicy.holdSingleExplanatorySpeech("4. ¿Qué es la escala?"))
    require(!AnswerDeliveryPolicy.shouldRetrySingle(2, false))
    require(!AnswerDeliveryPolicy.shouldRetrySingle(1, false))
    require(AnswerDeliveryPolicy.shouldRetrySingle(1, true))
    val raw = "[GIX_MULTI]\nPreguntas:\n3. Explique qué es nivelación simple."
    val updated = AnswerDeliveryPolicy.repairPayload(raw)
    require(updated.contains(raw))
    require(updated.contains("[GIX_REPAIR_FORMAT]"))
    println("OK RECUPERACIÓN: una pregunta explicativa aislada y HTTP correcto")
}
