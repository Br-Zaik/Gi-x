fun main() {
    val spokenAnswers = linkedMapOf<String, String>()
    fun pick(visible: List<String>, final: Boolean): List<String> = visible.mapIndexedNotNull { index, item ->
        val normalized = item.replace(Regex("""\s+"""), " ").trim()
        if (normalized.isBlank()) return@mapIndexedNotNull null
        val key = com.gix.cameraai.SpeechAnswerIdentity.key(index, normalized)
        val spoken = spokenAnswers[key]
        val next = when {
            spoken == null -> normalized
            spoken == normalized -> ""
            normalized.startsWith(spoken) -> normalized.drop(spoken.length).trim()
            final -> "Corrección: $normalized"
            else -> ""
        }
        if (next.isNotBlank()) spokenAnswers[key] = normalized
        next.takeIf { part -> part.any { it.isLetterOrDigit() } }
    }
    require(pick(listOf("1. La topografía mide."),false)==listOf("1. La topografía mide."))
    require(pick(listOf("1. La topografía mide."),false).isEmpty())
    require(pick(listOf("1. La topografía mide. Representa el terreno."),false)==listOf("Representa el terreno."))
    require(pick(listOf("1. La topografía mide. Representa el terreno."),true).isEmpty())
    require(pick(listOf("1. La topografía representa la superficie."),true)==listOf("Corrección: 1. La topografía representa la superficie."))
    // Recuperación tardía de la 3 no puede hacer repetir 4 y 5 por índice movido.
    spokenAnswers.clear()
    require(pick(listOf("1. Uno.", "2. Dos.", "4. Cuatro."), false).size == 3)
    require(pick(listOf("1. Uno.", "2. Dos.", "3. Tres recuperado.", "4. Cuatro."), true) ==
        listOf("3. Tres recuperado."))
    require(com.gix.cameraai.SpeechAnswerIdentity.key(1, "2. B.", true) !=
        com.gix.cameraai.SpeechAnswerIdentity.key(2, "2. C.", true))
    println("OK TTS: sin repetición y con respuesta recuperada insertada")
}
