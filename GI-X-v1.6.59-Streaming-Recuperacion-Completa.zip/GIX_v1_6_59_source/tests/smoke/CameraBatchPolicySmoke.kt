import com.gix.cameraai.CameraBatchPolicy

fun main() {
    check(CameraBatchPolicy.MAX_IMAGES == 2)
    for (count in 1..1) {
        val elapsed = (count - 1) * 800L
        val withId = CameraBatchPolicy.idleDelayMs("documento-A", elapsed)
        val withoutId = CameraBatchPolicy.idleDelayMs(null, elapsed)
        check(withId > 0L) { "Lote con $count fotografía(s) no debe quedar esperando indefinidamente" }
        check(withoutId > 0L) { "Lote sin ID con $count fotografía(s) debe cerrarse por inactividad" }
        check(withId <= 15_000L && withoutId <= 10_000L)
    }
    // El firmware toma 2 imágenes secuenciales. Incluso si el lote sigue abierto
    // durante más de 25 segundos, no debe cortarse por el límite total.
    check(CameraBatchPolicy.idleDelayMs("A", 26_000L) == 15_000L)
    check(CameraBatchPolicy.idleDelayMs("A", 70_000L) == 15_000L)
    check(CameraBatchPolicy.mustSplit("A", "B"))
    check(!CameraBatchPolicy.mustSplit("A", "A"))
    check(!CameraBatchPolicy.mustSplit(null, null))
    check(CameraBatchPolicy.mustSplit("A", null))
    check(CameraBatchPolicy.mustSplit(null, "A"))
    check(CameraBatchPolicy.idleDelayMs("A", 90_000L) == 0L)
    check(CameraBatchPolicy.idleDelayMs(null, 89_500L) == 500L)
    println("OK: 1 foto se cierra por inactividad, 2 se cierran inmediatamente " +
        "desde MainActivity, nuevos ID separan documentos, límite de 90 s.")
}
