import com.gix.cameraai.*
fun main() {
    check(CameraBatchPolicy.MAX_IMAGES == 2)
    check(CameraBatchPolicy.idleDelayMs("lote1", 0) == 15_000L)
    check(CameraBatchPolicy.mustSplit("lote1", "lote2"))
    check(!CameraBatchPolicy.mustSplit("lote1", "lote1"))

    // MINERÍA es un ámbito general; la transcripción no debe inyectar temas ni siglas.
    val hint = VisionReadingPolicy.extraInstructions(AiContextMode.MINING, false)
    check("manuscrita" in hint.lowercase())
    check("minería" in hint.lowercase())
    check("no presupongas un tema minero específico" in hint.lowercase())
    check(!hint.contains("monitoreo", ignoreCase = true))
    check(!hint.contains("PAMA", ignoreCase = true))
    val autoHint = VisionReadingPolicy.extraInstructions(AiContextMode.AUTO, false)
    check(!autoHint.contains("usuario seleccionó MINERÍA"))
    check(!autoHint.contains("monitoreo", ignoreCase = true))

    // La segunda lectura se activa por evidencia de mala lectura, NO por un tema predefinido.
    check(VisionReadingPolicy.needsSecondPass("PREGUNTAS DETECTADAS\n1. ¿Qué es [ilegible]?", AiContextMode.AUTO))
    check(VisionReadingPolicy.needsSecondPass("CONTEXTO DETECTADO\nTexto", AiContextMode.MINING))
    check(!VisionReadingPolicy.needsSecondPass("PREGUNTAS DETECTADAS\n1. ¿Qué son los depósitos minerales?", AiContextMode.MINING))
    check(!VisionReadingPolicy.needsSecondPass("PREGUNTAS DETECTADAS\n1. ¿Qué son los movimientos instintivos?", AiContextMode.MINING))

    val original = "CONTEXTO DETECTADO\n\nPREGUNTAS DETECTADAS\n8. ¿Qué indica [ilegible]?\n9. ¿Qué es QA y QC?"
    val corrected = "CONTEXTO DETECTADO\n\nPREGUNTAS DETECTADAS\n8. ¿Qué indica el documento?\n9. ¿Qué es QA y QC?"
    check(VisionReadingPolicy.chooseSafest(original, corrected) == corrected)
    check(VisionReadingPolicy.chooseSafest(corrected, "PREGUNTAS DETECTADAS\n8. ¿Qué indica?") == corrected)

    val mining = AiContextPolicy.resolve(AiContextMode.MINING, "", listOf("1. ¿Qué es un talud?"))
    check(mining.apiContext.contains("Explotación Minera"))
    check(mining.visibleLabel == "MINERÍA: prioridad minera/topográfica")
    check(!mining.apiContext.contains("monitoreo", ignoreCase = true))
    check(!mining.apiContext.contains("PAMA", ignoreCase = true))
    val auto = AiContextPolicy.resolve(AiContextMode.AUTO, "", listOf("1. ¿Qué es un talud?", "2. ¿Qué es un yacimiento?"))
    check(auto.apiContext.contains("Explotación Minera"))
    println("OK: recepción 2/2, lectura manuscrita/impresa, Minería general sin subtemas forzados")
}
