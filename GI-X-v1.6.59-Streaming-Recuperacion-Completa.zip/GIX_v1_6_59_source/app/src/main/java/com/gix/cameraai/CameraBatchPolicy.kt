package com.gix.cameraai

/** Firmware nuevo: una ráfaga completa contiene 2 fotos de 3 MP. */
internal object CameraBatchPolicy {
    const val MAX_IMAGES = 2
    // Las 2 fotos comparten requestId; un cambio de ID separa documentos.
    private const val IDENTIFIED_IDLE_MS = 15_000L
    // Firmware sin id: permitir breves demoras Wi-Fi entre capturas.
    private const val UNIDENTIFIED_IDLE_MS = 10_000L
    // Respaldo amplio: el firmware envía cada JPEG SECUENCIALMENTE y reintenta hasta 45 s.
    // La inactividad cierra 1-3 imágenes pronto; este techo no debe partir 4 entregas lentas.
    private const val MAX_BATCH_LIFETIME_MS = 90_000L

    fun mustSplit(currentRequestId: String?, incomingRequestId: String?): Boolean {
        val current = currentRequestId?.trim().orEmpty()
        val incoming = incomingRequestId?.trim().orEmpty()
        // Mantener conservador: un cambio entre con/sin id también marca lote nuevo.
        return (current.isNotEmpty() || incoming.isNotEmpty()) && current != incoming
    }

    fun idleDelayMs(requestId: String?, elapsedMs: Long): Long {
        val idle = if (requestId.isNullOrBlank()) UNIDENTIFIED_IDLE_MS else IDENTIFIED_IDLE_MS
        val remaining = (MAX_BATCH_LIFETIME_MS - elapsedMs.coerceAtLeast(0L)).coerceAtLeast(0L)
        return minOf(idle, remaining)
    }
}
