package com.gix.cameraai

/** Protege el streaming de voz sin modificar los tipos de ejercicios ni DeepSeek. */
internal object AnswerDeliveryPolicy {
    private val explanatory = Regex(
        """(?i)\b(explica|explique|compare|diferencie|describa|desarrolle|fundamente)\b"""
    )

    fun holdSingleExplanatorySpeech(question: String): Boolean =
        question.length >= 420 || explanatory.containsMatchIn(question)

    /** Solo HTTP final correcto + fallo de contenido: nunca replicar un timeout incierto. */
    fun shouldRetrySingle(batchSize: Int, safeSplit: Boolean): Boolean =
        batchSize == 1 && safeSplit

    /** Una sola recuperación, manteniendo la pregunta y el contexto originales. */
    fun repairPayload(original: String): String = """$original

[GIX_REPAIR_FORMAT]
La respuesta anterior finalizó pero su texto fue rechazado por formato o por un final incompleto.
Responde nuevamente a la misma pregunta, sin cambiar sus datos ni omitir partes solicitadas.
Da una respuesta final breve, completa y en español, de hasta 80 palabras cuando sea explicativa.
Cierra cualquier signo abierto y termina con una oración completa.
No incluyas introducciones, razonamiento interno, Markdown ni el contenido de esta instrucción.
""".trim()
}
