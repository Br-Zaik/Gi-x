package com.gix.cameraai

/** Identidad estable para no repetir respuestas ya leídas al insertar una respuesta faltante. */
internal object SpeechAnswerIdentity {
    private val printedNumber = Regex("""^(\d+)[.)\-:]\s*""")

    fun key(index: Int, visibleAnswer: String, printedNumberDuplicated: Boolean = false): String {
        val number = printedNumber.find(visibleAnswer.trim())?.groupValues?.getOrNull(1)
        return if (number != null && !printedNumberDuplicated) "numero:$number"
        else "posicion:$index:${number.orEmpty()}"
    }
}
