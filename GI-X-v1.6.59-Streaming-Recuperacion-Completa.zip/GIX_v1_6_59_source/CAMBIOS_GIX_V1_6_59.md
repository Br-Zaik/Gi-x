# GI-X v1.6.59: recuperación y streaming conservado

- Respuesta vía streaming SSE y TTS progresivo SIN cambios para V/F, alternativas, completar y preguntas sencillas.
- Las preguntas explicativas aisladas se verbalizan únicamente tras la validación del resultado final; no leen fragmentos que luego se rechazan.
- Recuperación máxima de una consulta individual con `GIX_SAFE_SPLIT` y HTTP ya finalizado, sin reintentar por timeout.
- Al insertar la respuesta recuperada (p. ej. pregunta 3) la identidad numérica estable evita repetir las preguntas 4, 5, etc. ya pronunciadas.
- Cuando una recuperación falla, la voz avisa qué pregunta quedó pendiente en lugar de terminar en silencio.
- Ningún cambio a lectura visual, dos fotografías, selección general de Minería, velocidad de voz, APIs o firmware.
- Pruebas locales Kotlin nuevas. NO se ha hecho prueba real de API ni compilación Android.

IMPORTANTE: una respuesta depende de la disponibilidad de la API. Si la segunda consulta vuelve a fallar, GI-X indica la pregunta faltante en vez de inventar respuesta. La recuperación adicional puede tener costo.
