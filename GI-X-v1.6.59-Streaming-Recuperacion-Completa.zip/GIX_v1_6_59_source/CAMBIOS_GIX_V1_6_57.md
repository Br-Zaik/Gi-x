# GI-X v1.6.57 corregida — 2 fotos, lectura fiel y contexto minero GENERAL

## Mejoras de la versión, conservadas
1. Lotes automáticos de **2 imágenes** desde Timer Camera X; envío a visión solo con ambos JPEG preparados. El modo manual permite hasta 4 imágenes como antes.
2. Lectura visual por API para texto **manuscrito, escrito con lápiz o impreso**, separando enunciados de respuestas ya escritas y conservando V/F, alternativas, completar, cálculos y tablas.
3. El modo de contexto seleccionado (`AUTO`, `GENERAL` o `MINERÍA`) llega al proveedor visual para interpretar términos ambiguos.
4. Segunda lectura visual ante `[ilegible]` o ausencia de preguntas y protección contra revisiones que pierdan números de pregunta.
5. Se mantienen DeepSeek FLASH/PRO, voz, historial, interfaz y resto del funcionamiento anterior.

## Corrección solicitada
- **MINERÍA es un contexto general**, no un tema concreto añadido a las preguntas.
- Se restauró **exactamente** `AiContextPolicy.kt` de v1.6.56, antes de las ampliaciones temáticas no solicitadas.
- Se retiraron del prompt visual las listas de materias y siglas impuestas y los ejemplos basados en un examen concreto; el documento visible determina de qué trata la pregunta.
- La segunda lectura ya no se activa por expresiones temáticas predefinidas, sino por evidencia de lectura incompleta.
- No se modifica el firmware OTA, ni los formatos de exámenes, ni la configuración de los proveedores de respuestas.

## Verificación y límites
- Pruebas locales con `kotlinc` para políticas de lectura, contexto y lote; pruebas de extracción y formatos.
- Pendiente la compilación Android en GitHub Actions y prueba con cámara y APIs reales.
- Este ZIP es el proyecto Android; `camera_firmware/` permanece solo como referencia heredada, no sustituye al proyecto OTA de cámara.
