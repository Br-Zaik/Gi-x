package com.gix.cameraai

import java.text.Normalizer
import kotlin.math.max

/**
 * Fusiona OCR de varias fotos del MISMO documento.
 *
 * Objetivos de v1.6.4:
 * - conservar contexto/lecturas/tablas aunque aparezcan solo en una foto;
 * - fusionar preguntas repetidas usando su número impreso;
 * - elegir la lectura más completa cuando la misma pregunta aparece en varias fotos;
 * - ordenar las preguntas por numeración y detectar huecos antes de usar la API;
 * - no inventar contenido que no apareció en ninguna captura.
 */
object MultiImageDocumentMerger {

    data class MergeResult(
        val combinedRaw: String,
        val combinedDisplay: String,
        val questions: List<String>,
        val documentContext: String,
        val missingQuestionNumbers: List<Int>,
        val duplicateQuestionNumbersResolved: Int,
        val usableImageCount: Int,
    ) {
        val hasQuestions: Boolean get() = questions.isNotEmpty()
        val looksComplete: Boolean get() = missingQuestionNumbers.isEmpty()
    }

    private data class QuestionCandidate(
        val text: String,
        val imageIndex: Int,
        val score: Int,
    )

    private val visibleNumber = Regex("^\\s*(\\d{1,2})\\s*[\\.)\\-:]\\s*")
    private val technicalMarker = Regex("^\\[GIX_[A-Z0-9_]+]$")

    fun merge(rawTexts: List<String>, sourceQualityScores: List<Double> = emptyList()): MergeResult {
        val usable = rawTexts.mapIndexedNotNull { index, raw ->
            raw.trim().takeIf { it.isNotBlank() }?.let { clean ->
                Triple(clean, index, sourceQualityScores.getOrNull(index) ?: 0.0)
            }
        }
        if (usable.isEmpty()) {
            return MergeResult("", "", emptyList(), "", emptyList(), 0, 0)
        }

        val numbered = linkedMapOf<Int, MutableList<QuestionCandidate>>()
        val unnumbered = mutableListOf<QuestionCandidate>()
        var duplicateResolved = 0

        usable.forEach { (raw, imageIndex, qualityScore) ->
            OcrQuestionExtractor.extractQuestions(raw).forEach questionLoop@{ question ->
                val clean = normalizeVisibleQuestion(question)
                if (clean.isBlank()) return@questionLoop
                val qualityBonus = qualityScore.coerceIn(-40.0, 80.0).toInt()
                val candidate = QuestionCandidate(clean, imageIndex, questionQuality(clean) + qualityBonus)
                val number = OcrQuestionExtractor.questionNumber(clean)
                if (number != null) {
                    val list = numbered.getOrPut(number) { mutableListOf() }
                    if (list.isNotEmpty()) duplicateResolved++
                    list += candidate
                } else {
                    val similarIndex = unnumbered.indexOfFirst { existing ->
                        semanticSimilarity(existing.text, clean) >= 0.82
                    }
                    if (similarIndex >= 0) {
                        duplicateResolved++
                        if (candidate.score > unnumbered[similarIndex].score) {
                            unnumbered[similarIndex] = candidate
                        }
                    } else {
                        unnumbered += candidate
                    }
                }
            }
        }

        val selectedNumbers = selectPrimaryQuestionNumbers(numbered.keys.toList())
        val mergedNumbered = numbered
            .toSortedMap()
            .filterKeys { key -> selectedNumbers.isEmpty() || key in selectedNumbers }
            .map { (_, candidates) -> chooseBestQuestion(candidates) }

        // En documentos numerados, las preguntas sin número suelen ser fragmentos de
        // una lectura repetida. Solo las añadimos si de verdad parecen preguntas y no
        // son casi iguales a una ya numerada.
        val mergedUnnumbered = unnumbered
            .sortedBy { it.imageIndex }
            .map { sanitizeQuestionText(it.text) }
            .filter { q ->
                mergedNumbered.none { numberedQ -> semanticSimilarity(numberedQ, q) >= 0.78 }
            }

        val questions = (mergedNumbered + mergedUnnumbered)
            .map { sanitizeQuestionText(it).trim() }
            .filter { it.isNotBlank() }
            .distinctBy { normalizeForCompare(it) }
            .take(40)

        val contexts = usable
            .sortedBy { (raw, _, _) ->
                OcrQuestionExtractor.extractQuestions(raw)
                    .mapNotNull(OcrQuestionExtractor::questionNumber)
                    .minOrNull() ?: 0
            }
            .map { (raw, _, _) -> OcrQuestionExtractor.extractDocumentContext(raw) }
            .filter { it.isNotBlank() }
        val context = mergeContexts(contexts)

        val missing = detectMissingQuestionNumbers(questions)
        val combinedRaw = buildCombinedRaw(context, questions)
        val display = buildDisplay(context, questions, missing, usable.size)

        return MergeResult(
            combinedRaw = combinedRaw,
            combinedDisplay = display,
            questions = questions,
            documentContext = context,
            missingQuestionNumbers = missing,
            duplicateQuestionNumbersResolved = duplicateResolved,
            usableImageCount = usable.size,
        )
    }

    private fun chooseBestQuestion(candidates: List<QuestionCandidate>): String {
        if (candidates.size == 1) return sanitizeQuestionText(candidates.first().text)
        // Si dos lecturas son cercanas, gana la más completa/limpia. Si difieren mucho,
        // seguimos prefiriendo la de mayor calidad en vez de mezclar palabras y crear
        // una pregunta que nunca existió en la hoja.
        return candidates.maxWithOrNull(
            compareBy<QuestionCandidate> { it.score }
                .thenBy { it.text.length }
                .thenByDescending { it.imageIndex }
        )?.text?.let(::sanitizeQuestionText).orEmpty()
    }

    private fun questionQuality(raw: String): Int {
        val text = raw.trim()
        if (text.isBlank()) return Int.MIN_VALUE
        val letters = text.count { it.isLetter() }
        val digits = text.count { it.isDigit() }
        val weird = text.count { ch ->
            !ch.isLetterOrDigit() && !ch.isWhitespace() && ch !in "¿?¡!.,;:()[]{}%/+×÷=\u00b0_-–—'\"\$"
        }
        val optionCount = Regex("(?im)(?:^|\\n)\\s*[A-H][\\)\\].:-]\\s+").findAll(text).count()
        val tableBonus = if (text.contains(OcrTableFormatter.TABLE_START)) 90 else 0
        val questionBonus = if ('?' in text || '¿' in text) 35 else 0
        val completionBonus = if ("___" in text || "....." in text) 10 else 0
        val truncationPenalty = if (text.endsWith("-") || text.endsWith("…")) 18 else 0
        val extraPromptPenalty = extraQuestionPrompts(text) * 24
        return letters * 2 + digits + optionCount * 28 + tableBonus + questionBonus + completionBonus - weird * 10 - truncationPenalty - extraPromptPenalty
    }

    private fun mergeContexts(contexts: List<String>): String {
        if (contexts.isEmpty()) return ""

        val structuredTables = mutableListOf<String>()
        val plainChunks = mutableListOf<String>()

        contexts.forEach { context ->
            val tables = extractTableBlocksLoose(context)
            structuredTables += tables
            val base = removeTableBlocksLoose(context).trim()
            if (base.isNotBlank()) plainChunks += base
        }

        // Dedupe por líneas/frases, preservando el orden aproximado de aparición de
        // las fotos. Es conservador: ante duda mantiene información en vez de borrarla.
        val kept = mutableListOf<String>()
        plainChunks.forEach { chunk ->
            chunk.lines()
                .map { it.replace(Regex("[ \\t]+"), " ").trim() }
                .filter { it.isNotBlank() && !technicalMarker.matches(it) }
                .forEach { line ->
                    val duplicate = kept.any { previous ->
                        val sim = semanticSimilarity(previous, line)
                        sim >= 0.90 || containsMeaningfully(previous, line)
                    }
                    if (!duplicate) kept += line
                }
        }

        val uniqueTables = mutableListOf<String>()
        structuredTables.forEach { table ->
            val duplicate = uniqueTables.any { existing -> semanticSimilarity(existing, table) >= 0.88 }
            if (!duplicate) uniqueTables += table
        }

        return buildString {
            if (kept.isNotEmpty()) append(kept.joinToString("\n"))
            if (uniqueTables.isNotEmpty()) {
                if (isNotEmpty()) append("\n\n")
                append(OcrTableFormatter.STRUCTURED_TABLES_HEADER).append('\n')
                uniqueTables.forEachIndexed { index, table ->
                    if (index > 0) append('\n')
                    append(table.trim()).append('\n')
                }
            }
        }.trim().take(9000)
    }

    private fun extractTableBlocksLoose(raw: String): List<String> {
        val regex = Regex(
            Regex.escape(OcrTableFormatter.TABLE_START) + "(.*?)" + Regex.escape(OcrTableFormatter.TABLE_END),
            setOf(RegexOption.DOT_MATCHES_ALL)
        )
        return regex.findAll(raw).map { match ->
            OcrTableFormatter.TABLE_START + "\n" + match.groupValues[1].trim() + "\n" + OcrTableFormatter.TABLE_END
        }.toList()
    }

    private fun removeTableBlocksLoose(raw: String): String {
        val regex = Regex(
            Regex.escape(OcrTableFormatter.TABLE_START) + ".*?" + Regex.escape(OcrTableFormatter.TABLE_END),
            setOf(RegexOption.DOT_MATCHES_ALL)
        )
        return raw
            .replace(regex, "")
            .replace(OcrTableFormatter.STRUCTURED_TABLES_HEADER, "")
            .trim()
    }

    private fun detectMissingQuestionNumbers(questions: List<String>): List<Int> {
        val ids = questions.mapNotNull(OcrQuestionExtractor::questionNumber).distinct().sorted()
        if (ids.size < 2) return emptyList()

        val primary = selectPrimaryQuestionNumbers(ids)
        if (primary.isEmpty()) return emptyList()
        val ordered = primary.sorted()
        val expectedStart = when {
            ordered.first() == 1 -> 1
            ordered.first() in 2..10 -> 1
            else -> ordered.first()
        }
        val maxId = ordered.last()
        if (maxId - expectedStart > 39) return emptyList()
        val present = ordered.toSet()
        return (expectedStart..maxId).filterNot { it in present }
    }

    private fun buildCombinedRaw(context: String, questions: List<String>): String {
        // Los metadatos de tabla SIEMPRE van al final. OcrTableFormatter usa el
        // encabezado como separador; si una tabla quedara antes de las preguntas,
        // esas preguntas desaparecerían al reconstruir el texto normal.
        val plainContext = OcrTableFormatter.removeStructuredTables(context).trim()
        val tables = OcrTableFormatter.parseStructuredTables(context)
        return buildString {
            append("DOCUMENTO COMBINADO DE VARIAS IMÁGENES")
            if (plainContext.isNotBlank()) {
                append("\n\nCONTEXTO DEL DOCUMENTO\n")
                append(plainContext)
            }
            if (questions.isNotEmpty()) {
                append("\n\nPreguntas:\n")
                append(questions.joinToString("\n\n"))
            }
            if (tables.isNotEmpty()) {
                append("\n\n").append(OcrTableFormatter.STRUCTURED_TABLES_HEADER).append('\n')
                tables.forEachIndexed { index, table ->
                    if (index > 0) append('\n')
                    append(table.trim()).append('\n')
                }
            }
        }.trim()
    }

    private fun buildDisplay(
        context: String,
        questions: List<String>,
        missing: List<Int>,
        imageCount: Int,
    ): String {
        val cleanContext = OcrTableFormatter.toDisplayText(context)
        return buildString {
            append("DOCUMENTO COMBINADO · ").append(imageCount).append(" IMAGEN(ES)")
            if (missing.isNotEmpty()) {
                append("\n⚠ Posibles preguntas faltantes: ")
                append(missing.joinToString(", "))
            }
            if (cleanContext.isNotBlank()) {
                append("\n\nCONTEXTO / DATOS\n")
                append(cleanContext.trim())
            }
            if (questions.isNotEmpty()) {
                append("\n\nPREGUNTAS ORDENADAS\n")
                append(questions.joinToString("\n\n"))
            }
        }.trim()
    }


    private fun extraQuestionPrompts(text: String): Int {
        val body = text.replace(visibleNumber, "").trim()
        if (body.isBlank()) return 0
        val pattern = Regex("""(?i)(?:^|[.\n])\s*(?:¿)?(?:qué|que|cuál|cual|cómo|como|por qué|por que|dónde|donde|menciona|explica|escribe|indica|define|completa|responde|calcula|señala|redacta|describe)\b""")
        val matches = pattern.findAll(body).count()
        return (matches - 1).coerceAtLeast(0)
    }
    private fun selectPrimaryQuestionNumbers(numbers: List<Int>): Set<Int> {
        val sorted = numbers.distinct().sorted()
        if (sorted.isEmpty()) return emptySet()
        data class Segment(val values: MutableList<Int>)
        val segments = mutableListOf<Segment>()
        var current = Segment(mutableListOf(sorted.first()))
        for (i in 1 until sorted.size) {
            val value = sorted[i]
            val prev = current.values.last()
            if (value - prev <= 3) {
                current.values += value
            } else {
                segments += current
                current = Segment(mutableListOf(value))
            }
        }
        segments += current

        val best = segments.maxWithOrNull(
            compareBy<Segment> { segment ->
                val values = segment.values
                val start = values.first()
                val end = values.last()
                val span = (end - start + 1).coerceAtLeast(1)
                val density = values.size.toDouble() / span.toDouble()
                density * 1000 + values.size
            }.thenByDescending { segment ->
                val start = segment.values.first()
                when {
                    start == 1 -> 1000
                    start in 2..10 -> 500 - start
                    else -> -start
                }
            }
        ) ?: return sorted.toSet()
        return best.values.toSet()
    }

    private fun sanitizeQuestionText(raw: String): String {
        var text = raw.trim().replace(Regex("""\n{3,}"""), "\n\n")
        val number = OcrQuestionExtractor.questionNumber(text)
        val body = text.replace(visibleNumber, "").trim()
        if (number != null && isLikelyTableResidue(number, body)) return ""

        if (body.contains('?')) {
            val firstQuestion = body.indexOf('?')
            if (firstQuestion >= 0 && firstQuestion < body.lastIndex) {
                val tail = body.substring(firstQuestion + 1).trim()
                val optionLine = Regex("""(?i)^\s*[A-H][\)\].:-]\s+.+$""")
                val tailLooksLikeOptions = tail.lines().all { line ->
                    line.isBlank() || optionLine.matches(line.trim())
                }
                if (tail.isNotBlank() && !tailLooksLikeOptions) {
                    val trimmedBody = body.substring(0, firstQuestion + 1).trim()
                    text = (number?.let { "$it. " } ?: "") + trimmedBody
                }
            }
        }

        return text
            .replace(Regex("""\s+"""), " ")
            .replace(Regex("""\s*\n\s*"""), "\n")
            .trim()
    }

    private fun isLikelyTableResidue(number: Int, body: String): Boolean {
        val clean = body.trim()
        if (clean.isBlank()) return true
        if (clean.contains('?') || clean.contains('¿')) return false
        val tokens = clean.split(Regex("""\s+|\|"""))
            .map { it.trim(' ', ',', ';') }
            .filter { it.isNotBlank() }
        val shortAlphaNum = Regex("""^[A-Za-z]-?\d+""")
        val numericLike = tokens.count { token -> token.count(Char::isDigit) >= 1 }
        val letterCount = clean.count { it.isLetter() }
        val hasTablePunctuation = '|' in clean || clean.contains("[VAC")
        if (number > 40 && tokens.size <= 4) return true
        if (tokens.size <= 3 && tokens.any { shortAlphaNum.containsMatchIn(it) } && letterCount <= 6) return true
        if (hasTablePunctuation && numericLike >= 2) return true
        return false
    }
    private fun normalizeVisibleQuestion(raw: String): String {
        return raw
            .replace("\r", "")
            .replace(Regex("[ \\t]+"), " ")
            .replace(Regex("\\n{3,}"), "\n\n")
            .trim()
    }

    private fun containsMeaningfully(a: String, b: String): Boolean {
        val na = normalizeForCompare(a)
        val nb = normalizeForCompare(b)
        if (na.length < 18 || nb.length < 18) return false
        val short = if (na.length <= nb.length) na else nb
        val long = if (na.length > nb.length) na else nb
        return short.length >= (long.length * 0.72).toInt() && long.contains(short)
    }

    private fun semanticSimilarity(a: String, b: String): Double {
        val na = normalizeForCompare(a)
        val nb = normalizeForCompare(b)
        if (na.isBlank() || nb.isBlank()) return 0.0
        if (na == nb) return 1.0
        if (na.length >= 18 && nb.length >= 18 && (na.contains(nb) || nb.contains(na))) {
            val ratio = minOf(na.length, nb.length).toDouble() / max(na.length, nb.length).toDouble()
            if (ratio >= 0.72) return 0.93
        }
        val ta = na.split(' ').filter { it.length >= 2 }.toSet()
        val tb = nb.split(' ').filter { it.length >= 2 }.toSet()
        if (ta.isEmpty() || tb.isEmpty()) return 0.0
        val intersection = ta.intersect(tb).size.toDouble()
        val union = ta.union(tb).size.toDouble().coerceAtLeast(1.0)
        return intersection / union
    }

    private fun normalizeForCompare(raw: String): String {
        val noNumber = raw.replace(visibleNumber, "")
        val decomposed = Normalizer.normalize(noNumber.lowercase(), Normalizer.Form.NFD)
        return decomposed
            .replace(Regex("\\p{M}+"), "")
            .replace(OcrTableFormatter.TABLE_START.lowercase(), " ")
            .replace(OcrTableFormatter.TABLE_END.lowercase(), " ")
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()
            .replace(Regex("\\s+"), " ")
    }
}
