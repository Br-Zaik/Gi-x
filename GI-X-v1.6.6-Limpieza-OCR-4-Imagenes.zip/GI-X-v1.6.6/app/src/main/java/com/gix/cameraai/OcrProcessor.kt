package com.gix.cameraai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.util.Log
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.paddle.ocr.EngineConfig
import com.paddle.ocr.PaddleOCR
import com.paddle.ocr.PaddleOCRConfig
import com.paddle.ocr.util.OpenCVUtils
import kotlinx.coroutines.runBlocking
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * OCR híbrido local de GI-X v1.6.4.
 *
 * PP-OCRv6 Small es el motor principal para texto difícil/manuscrito y ML Kit se
 * mantiene como segunda lectura, especialmente valiosa por su geometría para tablas.
 * OpenCV hace una preparación conservadora del documento. Si Paddle/OpenCV fallan,
 * ML Kit sigue funcionando: una mejora nueva nunca debe dejar al usuario sin OCR.
 */
class OcrProcessor(context: Context) {
    data class ImageQualityReport(
        val brightness: Double,
        val contrast: Double,
        val sharpness: Double,
        val looksDark: Boolean,
        val looksLowContrast: Boolean,
        val looksBlurry: Boolean,
    ) {
        val acceptableForDocument: Boolean
            get() = !looksBlurry && !looksDark && !looksLowContrast

        /** Bonus acotado para desempatar dos lecturas de la misma pregunta. */
        fun selectionScore(): Double {
            val sharp = (sharpness.coerceIn(0.0, 400.0) / 8.0)
            val contrastPart = (contrast.coerceIn(0.0, 80.0) / 4.0)
            val penalties = (if (looksBlurry) 28.0 else 0.0) +
                (if (looksDark) 18.0 else 0.0) +
                (if (looksLowContrast) 14.0 else 0.0)
            return (sharp + contrastPart - penalties).coerceIn(-40.0, 80.0)
        }

        fun shortLabel(): String = when {
            looksBlurry -> "borrosa"
            looksDark -> "oscura"
            looksLowContrast -> "poco contraste"
            else -> "buena"
        }
    }

    private val appContext = context.applicationContext
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val prepExecutor = Executors.newSingleThreadExecutor()
    private val closed = AtomicBoolean(false)
    private val paddleLock = Any()

    @Volatile private var paddle: PaddleOCR? = null
    @Volatile private var paddleInitAttempted = false
    @Volatile private var openCvReady = false

    private data class PaddleCandidate(
        val text: String,
        val averageConfidence: Float,
        val weakLineRatio: Float,
        val minimumConfidence: Float,
        val lineCount: Int,
    )

    fun process(bitmap: Bitmap, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        if (closed.get()) {
            onError("El motor OCR ya fue cerrado")
            return
        }

        prepExecutor.execute {
            var baseRef: Bitmap? = null
            var enhancedRef: Bitmap? = null
            var rescueRef: Bitmap? = null
            var normalizedRef: Bitmap? = null
            try {
                val normalizedBitmap = normalizeForOcr(bitmap)
                normalizedRef = normalizedBitmap
                openCvReady = ensureOpenCv()

                val corrected = if (openCvReady) {
                    OpenCvDocumentPreprocessor.correctPerspectiveIfSafe(normalizedBitmap)
                } else null
                val baseBitmap = corrected ?: normalizedBitmap
                baseRef = baseBitmap
                if (corrected != null && normalizedBitmap !== corrected && !normalizedBitmap.isRecycled) {
                    normalizedBitmap.recycle()
                    normalizedRef = null
                }

                val quality = if (openCvReady) {
                    OpenCvDocumentPreprocessor.quality(baseBitmap)
                } else {
                    OpenCvDocumentPreprocessor.Quality(128.0, 64.0, 100.0)
                }

                val enhancedBitmap = if (openCvReady) {
                    OpenCvDocumentPreprocessor.enhanceForText(baseBitmap) ?: enhanceFallback(baseBitmap)
                } else {
                    enhanceFallback(baseBitmap)
                }
                enhancedRef = enhancedBitmap

                val mlFirst = recognizeMlBlocking(baseBitmap)
                val mlSecond = recognizeMlBlocking(enhancedBitmap)
                var mlBest = chooseBestMl(mlFirst, mlSecond, baseBitmap.width)
                var mlText = formatMl(mlBest, baseBitmap.width)

                var paddleBest = recognizePaddle(baseBitmap)
                // Una segunda pasada PP-OCRv6 se activa cuando la foto o la estructura
                // lo merece. La confianza se vigila también por líneas: un promedio alto
                // ya no oculta una respuesta manuscrita concreta con confianza baja.
                val firstPaddleSuspicious = paddleBest?.let {
                    isStructurallyWeak(it.text) || it.weakLineRatio >= 0.20f || it.averageConfidence < 0.74f
                } ?: true
                if (enhancedBitmap !== baseBitmap && (quality.needsExtraPass || firstPaddleSuspicious)) {
                    val second = recognizePaddle(enhancedBitmap)
                    paddleBest = chooseBestPaddle(paddleBest, second)
                }

                // Tercera variante SOLO de rescate: lápiz, manuscrito, sombras o líneas
                // con confianza débil. Así no penalizamos documentos impresos limpios.
                val paddleSnapshot = paddleBest
                val needsHandwritingRescue = quality.needsExtraPass ||
                    paddleSnapshot == null ||
                    paddleSnapshot.averageConfidence < 0.78f ||
                    paddleSnapshot.weakLineRatio >= 0.16f ||
                    isStructurallyWeak(mlText) ||
                    (paddleSnapshot?.text?.let { isStructurallyWeak(it) } ?: true)

                if (openCvReady && needsHandwritingRescue) {
                    val rescueBitmap = OpenCvDocumentPreprocessor.enhanceForHandwriting(baseBitmap)
                    if (rescueBitmap != null) {
                        rescueRef = rescueBitmap
                        val mlRescue = recognizeMlBlocking(rescueBitmap)
                        mlBest = chooseBestMl(mlBest, mlRescue, baseBitmap.width)
                        mlText = formatMl(mlBest, baseBitmap.width)

                        val paddleRescue = recognizePaddle(rescueBitmap)
                        paddleBest = chooseBestPaddle(paddleBest, paddleRescue)
                    }
                }

                val output = chooseHybrid(mlText, paddleBest).trim()
                if (output.isNotBlank()) {
                    Log.d(
                        "GIX-OCR",
                        "OCR OK ml=${mlText.length} paddle=${paddleBest?.text?.length ?: 0} " +
                            "conf=${paddleBest?.averageConfidence ?: 0f} weak=${paddleBest?.weakLineRatio ?: 0f} " +
                            "dark=${quality.looksDark} blur=${quality.looksBlurry}",
                    )
                    onSuccess(output)
                } else {
                    onSuccess("")
                }
            } catch (t: Throwable) {
                Log.e("GIX-OCR", "OCR pipeline failed", t)
                onError(t.message ?: "No se pudo preparar la imagen para OCR")
            } finally {
                // Nunca reciclamos el bitmap original que mantiene la vista previa.
                val rescueBitmap = rescueRef
                val enhancedBitmap = enhancedRef
                val baseBitmap = baseRef
                val normalizedBitmap = normalizedRef
                if (rescueBitmap != null && rescueBitmap !== bitmap && rescueBitmap !== baseBitmap && rescueBitmap !== enhancedBitmap && !rescueBitmap.isRecycled) rescueBitmap.recycle()
                if (enhancedBitmap != null && enhancedBitmap !== bitmap && enhancedBitmap !== baseBitmap && !enhancedBitmap.isRecycled) enhancedBitmap.recycle()
                if (baseBitmap != null && baseBitmap !== bitmap && !baseBitmap.isRecycled) baseBitmap.recycle()
                if (normalizedBitmap != null && normalizedBitmap !== bitmap && normalizedBitmap !== baseBitmap && !normalizedBitmap.isRecycled) normalizedBitmap.recycle()
            }
        }
    }

    /** Medición local y barata para comparar fotos de un mismo documento. */
    fun assessQuality(bitmap: Bitmap): ImageQualityReport {
        if (!ensureOpenCv()) {
            return ImageQualityReport(128.0, 64.0, 100.0, false, false, false)
        }
        val q = OpenCvDocumentPreprocessor.quality(bitmap)
        return ImageQualityReport(
            brightness = q.brightness,
            contrast = q.contrast,
            sharpness = q.sharpness,
            looksDark = q.looksDark,
            looksLowContrast = q.looksLowContrast,
            looksBlurry = q.looksBlurry,
        )
    }

    private fun ensureOpenCv(): Boolean {
        if (openCvReady) return true
        return runCatching { OpenCVUtils.init(appContext) }
            .onFailure { Log.w("GIX-OCR", "OpenCV no disponible: ${it.message}") }
            .getOrDefault(false)
    }

    private fun getPaddle(): PaddleOCR? {
        paddle?.let { return it }
        synchronized(paddleLock) {
            paddle?.let { return it }
            if (paddleInitAttempted || closed.get()) return null
            paddleInitAttempted = true
            if (!ensureOpenCv()) return null
            return try {
                runBlocking {
                    PaddleOCR.create(
                        context = appContext,
                        config = PaddleOCRConfig(
                            detThresh = 0.20f,
                            detBoxThresh = 0.45f,
                            detUnclipRatio = 1.40f,
                            recScoreThresh = 0.05f,
                            recBatchSize = 1,
                        ),
                        engineConfig = EngineConfig(numThreads = 4),
                        detModelAssetPath = "models/det/inference.onnx",
                        recModelAssetPath = "models/rec/inference.onnx",
                        recConfigAssetPath = "models/rec/inference.yml",
                    )
                }.also { paddle = it }
            } catch (t: Throwable) {
                Log.e("GIX-OCR", "PP-OCRv6 no pudo inicializar; ML Kit seguirá activo", t)
                null
            }
        }
    }

    private fun recognizePaddle(bitmap: Bitmap): PaddleCandidate? {
        val engine = getPaddle() ?: return null
        return try {
            val result = runBlocking { engine.recognize(bitmap) }
            val items = result.results
                .filter { it.text.isNotBlank() }
            if (items.isEmpty()) return null
            val text = cleanText(items.joinToString("\n") { it.text.trim() })
            val confidences = items.map { it.confidence.coerceIn(0f, 1f) }
            val confidence = confidences.average().toFloat()
            val weakRatio = confidences.count { it < 0.58f }.toFloat() / confidences.size.coerceAtLeast(1)
            val minimum = confidences.minOrNull() ?: 0f
            PaddleCandidate(text, confidence, weakRatio, minimum, items.size)
        } catch (t: Throwable) {
            Log.w("GIX-OCR", "PP-OCRv6 pass failed: ${t.message}")
            null
        }
    }

    private fun recognizeMlBlocking(bitmap: Bitmap): Text? {
        if (closed.get()) return null
        return try {
            val image = InputImage.fromBitmap(bitmap, 0)
            Tasks.await(recognizer.process(image), 20, TimeUnit.SECONDS)
        } catch (t: Throwable) {
            Log.w("GIX-OCR", "ML Kit pass failed: ${t.message}")
            null
        }
    }

    private fun normalizeForOcr(source: Bitmap): Bitmap {
        val width = source.width.coerceAtLeast(1)
        val height = source.height.coerceAtLeast(1)
        val longSide = max(width, height)

        // OCR de documentos: suficiente detalle sin disparar memoria en equipos modestos.
        val desiredLongSide = when {
            longSide < 1200 -> 1800
            longSide > 2600 -> 2300
            else -> longSide
        }
        val scale = desiredLongSide.toFloat() / longSide.toFloat()
        val targetW = max(1, (width * scale).roundToInt())
        val targetH = max(1, (height * scale).roundToInt())
        return if (targetW == width && targetH == height) {
            source.copy(Bitmap.Config.ARGB_8888, false)
        } else {
            Bitmap.createScaledBitmap(source, targetW, targetH, true)
        }
    }

    private fun enhanceFallback(source: Bitmap): Bitmap {
        val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val gray = ColorMatrix().apply { setSaturation(0f) }
        val contrast = 1.28f
        val translate = (-0.5f * contrast + 0.5f) * 255f
        val boost = ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, translate,
                0f, contrast, 0f, 0f, translate,
                0f, 0f, contrast, 0f, translate,
                0f, 0f, 0f, 1f, 0f,
            ),
        )
        gray.postConcat(boost)
        paint.colorFilter = ColorMatrixColorFilter(gray)
        canvas.drawBitmap(source, 0f, 0f, paint)
        return output
    }

    private fun formatMl(result: Text?, imageWidth: Int): String {
        return if (result != null && result.text.isNotBlank()) {
            cleanText(OcrTableFormatter.formatDocument(result, imageWidth))
        } else ""
    }

    private fun chooseBestMl(first: Text?, second: Text?, imageWidth: Int): Text? {
        if (first == null) return second
        if (second == null) return first
        val a = cleanText(first.text)
        val b = cleanText(second.text)
        if (a.isBlank()) return second
        if (b.isBlank()) return first
        val scoreA = score(a) + structureScoreMl(first, imageWidth)
        val scoreB = score(b) + structureScoreMl(second, imageWidth)
        return if (scoreB > scoreA + 6) second else first
    }

    private fun chooseBestPaddle(a: PaddleCandidate?, b: PaddleCandidate?): PaddleCandidate? {
        if (a == null) return b
        if (b == null) return a
        val scoreA = paddleCandidateScore(a)
        val scoreB = paddleCandidateScore(b)
        return if (scoreB > scoreA + 8) b else a
    }

    private fun paddleCandidateScore(candidate: PaddleCandidate): Int {
        val confidenceBonus = (candidate.averageConfidence * 150).toInt()
        val weakPenalty = (candidate.weakLineRatio * 180).toInt()
        val minimumPenalty = if (candidate.lineCount >= 2 && candidate.minimumConfidence < 0.30f) 35 else 0
        return score(candidate.text) + structureScoreText(candidate.text) +
            confidenceBonus - weakPenalty - minimumPenalty
    }

    private fun chooseHybrid(mlText: String, paddleCandidate: PaddleCandidate?): String {
        val paddleText = paddleCandidate?.text.orEmpty()
        if (mlText.isBlank()) return paddleText
        if (paddleText.isBlank()) return mlText

        val mlQuestions = safeQuestions(mlText)
        val paddleQuestions = safeQuestions(paddleText)
        val mlSuspiciousBeforeMerge = mlQuestions.isNotEmpty() && OcrQuestionExtractor.hasSuspiciousNumbering(mlQuestions)

        // Si ML Kit reconstruyó una tabla válida, se prioriza ANTES de fusionar
        // preguntas. En v1.6.2 la fusión podía devolver solo 1..8 y perder la tabla,
        // lectura o datos que estaban arriba de las preguntas.
        if (mlText.contains(OcrTableFormatter.TABLE_START) && !mlSuspiciousBeforeMerge) return mlText

        // Fusiona pregunta por pregunta, pero preservando también el contexto de la
        // hoja (lectura/datos/instrucciones) para que la API pueda responder preguntas
        // que dependan de ese material.
        mergeNumberedQuestions(mlText, paddleText)?.let { return it }

        val mlSuspicious = mlQuestions.isNotEmpty() && OcrQuestionExtractor.hasSuspiciousNumbering(mlQuestions)
        val paddleSuspicious = paddleQuestions.isNotEmpty() && OcrQuestionExtractor.hasSuspiciousNumbering(paddleQuestions)

        if (!paddleSuspicious && mlSuspicious && paddleQuestions.isNotEmpty()) return paddleText
        if (!mlSuspicious && paddleSuspicious && mlQuestions.isNotEmpty()) return mlText

        if (!paddleSuspicious && paddleQuestions.size > mlQuestions.size && paddleQuestions.size >= 2) return paddleText
        if (!mlSuspicious && mlQuestions.size > paddleQuestions.size && mlQuestions.size >= 2) return mlText

        val mlScore = score(mlText) + structureScoreText(mlText)
        val paddleScore = score(paddleText) + structureScoreText(paddleText) +
            ((paddleCandidate?.averageConfidence ?: 0f) * 100).toInt()
        return if (paddleScore > mlScore + 20) paddleText else mlText
    }

    private fun mergeNumberedQuestions(mlText: String, paddleText: String): String? {
        val mlQuestions = safeQuestions(mlText)
        val paddleQuestions = safeQuestions(paddleText)
        if (mlQuestions.isEmpty() || paddleQuestions.isEmpty()) return null

        val mlMap = mlQuestions.mapNotNull { q -> OcrQuestionExtractor.questionNumber(q)?.let { it to q } }.toMap()
        val paddleMap = paddleQuestions.mapNotNull { q -> OcrQuestionExtractor.questionNumber(q)?.let { it to q } }.toMap()
        if (mlMap.isEmpty() || paddleMap.isEmpty()) return null

        val ids = (mlMap.keys + paddleMap.keys).distinct().sorted()
        if (ids.size < 2 || ids.zipWithNext().any { (a, b) -> b != a + 1 }) return null

        val merged = ids.mapNotNull { id ->
            val ml = mlMap[id]
            val pp = paddleMap[id]
            when {
                ml == null -> pp
                pp == null -> ml
                ml.contains(OcrTableFormatter.TABLE_START) -> ml
                questionScore(pp) > questionScore(ml) + 35 -> pp
                else -> ml
            }
        }
        if (merged.size != ids.size) return null
        val mergedQuestions = merged.joinToString("\n\n")

        // Conserva el contexto más rico. Preferimos ML Kit porque mantiene orden
        // geométrico; si no tiene contexto útil, usamos el de Paddle.
        val mlContext = OcrQuestionExtractor.extractDocumentContext(mlText)
        val paddleContext = OcrQuestionExtractor.extractDocumentContext(paddleText)
        val context = when {
            mlContext.length >= 20 -> mlContext
            paddleContext.length >= 20 -> paddleContext
            else -> ""
        }
        return if (context.isBlank()) {
            mergedQuestions
        } else {
            "$context\n\nPreguntas:\n$mergedQuestions"
        }
    }

    private fun safeQuestions(text: String): List<String> {
        return try { OcrQuestionExtractor.extractQuestions(text) } catch (_: Throwable) { emptyList() }
    }

    private fun questionScore(question: String): Int {
        var value = score(question)
        if (Regex("(?i)\\b(?:Fe|Pb|Ag|Au|Cu|Zn|H2O|CO2|EPP|GPS|GNSS|USB)\\b").containsMatchIn(question)) value += 40
        if (question.contains(".....") || question.contains("___")) value += 20
        if (question.contains(OcrTableFormatter.TABLE_START)) value += 200
        return value
    }

    private fun isStructurallyWeak(text: String): Boolean {
        val questions = safeQuestions(text)
        if (text.length < 18) return true
        if (questions.size >= 2 && OcrQuestionExtractor.hasSuspiciousNumbering(questions)) return true
        return false
    }

    private fun structureScoreMl(result: Text, imageWidth: Int): Int {
        return try {
            structureScoreText(OcrTableFormatter.formatDocument(result, imageWidth))
        } catch (_: Throwable) {
            0
        }
    }

    private fun structureScoreText(text: String): Int {
        return try {
            val questions = OcrQuestionExtractor.extractQuestions(text)
            var value = questions.size * 90
            if (questions.size >= 3 && !OcrQuestionExtractor.hasSuspiciousNumbering(questions)) value += 180
            if (OcrQuestionExtractor.hasSuspiciousNumbering(questions)) value -= 420
            if (text.contains(OcrTableFormatter.TABLE_START)) value += 80
            val ids = questions.mapNotNull { OcrQuestionExtractor.questionNumber(it) }
            if (ids.size >= 3 && ids.zipWithNext().all { (x, y) -> y == x + 1 }) value += 220
            value
        } catch (_: Throwable) {
            0
        }
    }

    private fun score(text: String): Int {
        val trimmed = text.trim()
        if (trimmed.isBlank()) return Int.MIN_VALUE
        val chars = trimmed.length
        val useful = trimmed.count { it.isLetterOrDigit() || it in "¿?¡!.,:;()[]%-+/=_" }
        val letters = trimmed.count { it.isLetterOrDigit() }
        val weird = trimmed.count { it == '\uFFFD' || it == '�' }
        val words = trimmed.split(Regex("\\s+")).count { it.length >= 2 }
        val lines = trimmed.lines().count { it.trim().length >= 2 }
        val questionBonus = if ('?' in trimmed || '¿' in trimmed) 18 else 0
        val lineList = trimmed.lines()
        val optionBonus = lineList.count { Regex("^\\s*[A-Ha-h][\\)\\].:-]\\s+.+").matches(it) } * 4
        val numberedQuestionBonus = lineList.count {
            Regex("^\\s*\\d{1,2}\\s*[\\.)\\-:]\\s*.*$").matches(it)
        } * 10
        val shortDataBonus = lineList.count {
            val line = it.trim()
            Regex("^[A-Z][a-z]?$|^[A-Z][A-Za-z0-9₀-₉]{1,7}$").matches(line)
        } * 4
        val ratio = if (chars == 0) 0 else (useful * 100 / chars)
        val noisePenalty = max(0, 65 - ratio) * 2 + weird * 20
        return min(chars, 2600) + letters / 2 + words * 3 + min(lines, 24) * 2 +
            questionBonus + optionBonus + numberedQuestionBonus + shortDataBonus - noisePenalty
    }

    private fun cleanText(raw: String): String {
        return raw
            .replace("\r\n", "\n")
            .replace('\r', '\n')
            .lines()
            .map { line -> line.replace(Regex("[ \\t]+"), " ").trimEnd() }
            .dropWhile { it.isBlank() }
            .dropLastWhile { it.isBlank() }
            .joinToString("\n")
            .replace(Regex("\n{3,}"), "\n\n")
            .trim()
    }

    fun close() {
        if (!closed.compareAndSet(false, true)) return
        val instance = paddle
        paddle = null
        if (instance != null) {
            runCatching { runBlocking { instance.release() } }
        }
        prepExecutor.shutdownNow()
        recognizer.close()
    }
}
