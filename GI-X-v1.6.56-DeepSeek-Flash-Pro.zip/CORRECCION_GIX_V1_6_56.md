# GI X v1.6.56 — FLASH / PRO

Se añadió un selector de modelo de respuestas a la pantalla **API de GI X** sin cambiar el flujo existente.

- `FLASH · rápido` -> `deepseek-v4-flash` (predeterminado).
- `PRO · razonamiento` -> `deepseek-v4-pro`.
- Ambos usan la misma clave Cheaper Inference y `/v1/chat/completions`.
- La selección se guarda junto con la configuración cifrada existente.
- Cambiar modelo no borra ni reemplaza la API key.
- Visión IA continúa independiente y sin cambios.
- Streaming, TTS, lotes, AUTO/GENERAL/MINERÍA, Cámara/Manual y pantalla apagada permanecen sin cambios.
- FLASH conserva `reasoning_effort=minimal`; PRO deja el razonamiento del modelo en su valor predeterminado.
- No existe fallback automático PRO→FLASH ni FLASH→PRO para evitar dobles consultas/cobros inesperados.
