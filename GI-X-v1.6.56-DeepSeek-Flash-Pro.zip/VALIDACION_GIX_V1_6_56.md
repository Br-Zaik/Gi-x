# Validación GI X v1.6.56

Checklist estático:
- versionCode 81 / versionName 1.6.56.
- `NetApiConfig.clean()` conserva únicamente `deepseek-v4-flash` o `deepseek-v4-pro`; valores desconocidos migran a FLASH.
- El diálogo API muestra selector FLASH/PRO y recupera la selección guardada.
- Guardar con el campo de clave vacío reutiliza la clave ya guardada.
- El `model` seleccionado llega a `buildChatBody()` sin cambiar endpoint ni streaming.
- `reasoning_effort=minimal` se envía solo con FLASH; PRO no lo fuerza.
- No se modificó `VISION_MODEL`.
- No hay fallback automático entre modelos.
- El chip principal de API muestra FLASH/PRO activo.
