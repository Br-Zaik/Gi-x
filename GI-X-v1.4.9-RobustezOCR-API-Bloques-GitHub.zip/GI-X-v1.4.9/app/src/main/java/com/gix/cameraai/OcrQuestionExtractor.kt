package com.gix.cameraai

object OcrQuestionExtractor {
    const val MULTI_PROMPT_HEADER = "[GIX_MULTI_QUESTIONS]"
    const val TRUE_FALSE_BATCH_HEADER = "[GIX_TRUE_FALSE_BATCH]"

    private val numberedLine = Regex("^\\s*(\\d{1,2})\\s*[\\.)\\-:]\\s*(.*)$")
    private val bareNumberLine = Regex("^\\s*(\\d{1,2})\\s*$")
    private val optionStart = Regex("(?i)(?:^|\\s)([A-H])[\\)\\].:-]\\s*")
    private val standaloneOption = Regex("(?i)^\\s*([A-H])[\\)\\].:-]\\s*(.+)$")
    private val junkOnly = Regex("^[\\W_]+$")

    private data class Draft(
        val number: String?,
        var body: String
    )

    private data class SplitQuestion(
        val question: String,
        val options: MutableList<Pair<Char, String>>
    )

    fun extract(raw: String): String {
        val questions = extractQuestions(raw)
        return if (questions.isNotEmpty()) questions.joinToString("\n\n") else extractFallback(raw)
    }

    fun extractQuestions(raw: String): List<String> {
        val structuredTables = OcrTableFormatter.parseStructuredTables(raw)
        val baseRaw = OcrTableFormatter.removeStructuredTables(raw)
        val lines = baseRaw.lines()
            .map { cleanLine(it) }
            .map { stripDocumentNoise(it) }
            .filter { it.length >= 2 && !junkOnly.matches(it) }

        if (lines.isEmpty()) {
            return structuredTables.mapIndexed { index, table -> "Tabla ${index + 1}:\n${table.trim()}" }
        }

        val drafts = mutableListOf<Draft>()
        var current: Draft? = null

        fun pushCurrent() {
            val item = current ?: return
            item.body = normalizeBody(stripDocumentNoise(item.body))
            if (item.body.isNotBlank() && (item.number != null || !isPureHeading(item.body))) drafts += item
            current = null
        }

        for (line in lines) {
            val numbered = numberedLine.find(line)
            val bareNumber = if (numbered == null) bareNumberLine.find(line) else null
            if (numbered != null || bareNumber != null) {
                pushCurrent()
                val number = numbered?.groupValues?.get(1) ?: bareNumber!!.groupValues[1]
                val body = numbered?.groupValues?.getOrNull(2).orEmpty()
                    .let { stripDocumentNoise(it).trim() }
                // ML Kit puede separar visualmente "1." del enunciado. Conservamos el
                // número aunque esta línea todavía no tenga texto y unimos las líneas
                // siguientes hasta encontrar la próxima pregunta numerada.
                current = Draft(number, body)
                continue
            }

            if (isInstructionHeading(line)) continue

            val startsNewUnnumberedQuestion = startsLikeQuestion(line) ||
                looksLikeTrueFalse(line) || looksLikeCompletion(line)

            if (isPureHeading(line) && !shouldKeepAsQuestionData(line, current)) continue

            if (current == null) {
                if (startsNewUnnumberedQuestion) {
                    current = Draft(null, line)
                }
                continue
            }

            // Si estamos leyendo una hoja sin numeración y aparece otra línea que
            // claramente inicia una nueva pregunta, cerramos la anterior. Antes,
            // dos preguntas consecutivas sin 1., 2., 3. podían terminar unidas.
            if (current!!.number == null && startsNewUnnumberedQuestion) {
                pushCurrent()
                current = Draft(null, line)
                continue
            }

            current!!.body = normalizeBody(current!!.body + " " + line)
        }
        pushCurrent()

        if (drafts.isEmpty()) {
            return structuredTables.mapIndexed { index, table -> "Tabla ${index + 1}:\n${table.trim()}" }
        }

        // ML Kit a veces devuelve la opción A de la siguiente pregunta justo antes
        // de la línea numerada. Reparación: si una pregunta que NO es de alternativas
        // termina en A)/B)/... y la siguiente sí es de alternativas, movemos esas
        // opciones a la siguiente pregunta.
        val split = drafts.map { draft -> splitQuestionAndOptions(draft.body) }.toMutableList()
        val pendingForNext = mutableListOf<Pair<Char, String>>()

        for (i in split.indices) {
            val currentSplit = split[i]
            val alternative = isAlternativeQuestion(currentSplit.question)

            if (pendingForNext.isNotEmpty() && alternative) {
                val merged = (pendingForNext + currentSplit.options)
                    .distinctBy { it.first.uppercaseChar() }
                    .sortedBy { it.first.uppercaseChar() }
                currentSplit.options.clear()
                currentSplit.options.addAll(merged)
                pendingForNext.clear()
            }

            if (!alternative && currentSplit.options.isNotEmpty()) {
                val nextAlternative = split.getOrNull(i + 1)?.let { isAlternativeQuestion(it.question) } == true
                if (nextAlternative) {
                    pendingForNext += currentSplit.options
                    currentSplit.options.clear()
                }
            }
        }

        val result = mutableListOf<String>()
        for (i in drafts.indices) {
            val draft = drafts[i]
            val item = split[i]
            val questionText = normalizeBody(stripDocumentNoise(item.question))
            if (questionText.isBlank() || (draft.number == null && isPureHeading(questionText))) continue

            val options = if (isAlternativeQuestion(questionText)) {
                item.options
                    .map { it.first.uppercaseChar() to normalizeBody(stripDocumentNoise(it.second)) }
                    .filter { it.second.isNotBlank() }
                    .distinctBy { it.first }
                    .sortedBy { it.first }
            } else {
                emptyList()
            }

            val body = buildString {
                append(questionText)
                if (options.isNotEmpty()) {
                    options.forEach { (letter, text) ->
                        append("\n")
                        append(letter)
                        append(") ")
                        append(text)
                    }
                }
            }.trim()

            val prefix = draft.number?.let { "$it. " } ?: ""
            result += prefix + body
        }

        val cleanedResult = result
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
            .toMutableList()

        attachStructuredTables(cleanedResult, structuredTables)

        return cleanedResult
            .filter { it.isNotBlank() }
            .distinct()
            .take(30)
    }

    fun buildQueryPayload(questions: List<String>, forceBatch: Boolean = false): String {
        if (questions.isEmpty()) return ""
        if (!forceBatch && questions.size == 1 && !questions.first().contains(OcrTableFormatter.TABLE_START)) {
            return questions.first()
        }

        val numbered = questions.mapIndexed { index, raw ->
            val body = raw.replace(Regex("^\\s*\\d{1,2}\\s*[\\.)\\-:]\\s*"), "").trim()
            "${index + 1}. $body"
        }.joinToString("\n")
        val trueFalseMarker = if (isLikelyTrueFalseBatch(questions)) {
            "$TRUE_FALSE_BATCH_HEADER\n"
        } else {
            ""
        }

        // Las reglas detalladas viven en OnlineAnswerProvider. Mantener este payload
        // pequeño reduce tokens de entrada y evita que el proveedor desperdicie salida
        // repitiendo instrucciones y enunciados completos.
        return buildString {
            append(MULTI_PROMPT_HEADER).append('\n')
            if (trueFalseMarker.isNotBlank()) append(trueFalseMarker)
            append("Preguntas:").append('\n')
            append(numbered)
        }.trim()
    }

    private fun attachStructuredTables(result: MutableList<String>, tables: List<String>) {
        if (tables.isEmpty()) return

        val candidateIndexes = result.indices.filter { index -> looksLikeTableQuestion(result[index]) }.toMutableList()
        var candidateCursor = 0

        tables.forEachIndexed { tableIndex, table ->
            val normalizedTable = table.trim()
            if (normalizedTable.isBlank()) return@forEachIndexed

            val targetIndex = when {
                candidateCursor < candidateIndexes.size -> candidateIndexes[candidateCursor++]
                else -> -1
            }

            if (targetIndex >= 0) {
                result[targetIndex] = result[targetIndex].trim() + "\n" + normalizedTable
            } else {
                result += "Tabla ${tableIndex + 1}:\n$normalizedTable"
            }
        }
    }

    private fun looksLikeTableQuestion(raw: String): Boolean {
        val clean = raw.lowercase()
        return listOf(
            "tabla", "cuadro", "complete la funcion", "complete la función",
            "completa la funcion", "completa la función", "funcion que corresponda",
            "función que corresponda", "relacione", "relaciona", "columnas", "filas"
        ).any { clean.contains(it) }
    }

    private fun shouldKeepAsQuestionData(line: String, current: Draft?): Boolean {
        if (current == null) return false
        val clean = line.trim()
        if (clean.isBlank()) return false
        if (current.number != null && current.body.isBlank()) return true

        // Símbolos químicos, fórmulas, unidades, abreviaturas y etiquetas cortas pueden
        // aparecer solos debajo de una pregunta (Fe, Pb, Ag, Au, H2O, CO2, cm, %, Sin:, Epi:).
        // No deben confundirse con títulos solo por ser cortos o empezar con mayúscula.
        if (looksLikeScientificOrShortData(clean)) return true
        if (clean.length <= 16 && clean.endsWith(":")) return true
        return false
    }

    private fun looksLikeScientificOrShortData(raw: String): Boolean {
        val clean = raw.trim().trim(',', ';')
        if (clean.isBlank() || clean.length > 18) return false

        val elementSymbols = setOf(
            "H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne", "Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar",
            "K", "Ca", "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn", "Ga", "Ge", "As", "Se", "Br", "Kr",
            "Rb", "Sr", "Y", "Zr", "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn", "Sb", "Te", "I", "Xe",
            "Cs", "Ba", "La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb", "Lu",
            "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg", "Tl", "Pb", "Bi", "Po", "At", "Rn", "Fr", "Ra",
            "Ac", "Th", "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm", "Md", "No", "Lr", "Rf", "Db",
            "Sg", "Bh", "Hs", "Mt", "Ds", "Rg", "Cn", "Nh", "Fl", "Mc", "Lv", "Ts", "Og"
        )
        if (clean in elementSymbols) return true

        val compact = clean.replace(" ", "")
        if (Regex("^[A-Z][a-z]?(?:[0-9₀-₉]+)?(?:[A-Z][a-z]?[0-9₀-₉]*)+$").matches(compact)) return true
        if (Regex("^[A-Za-z]{1,4}[0-9₀-₉²³/%°.-]*$").matches(compact) && compact.any { it.isDigit() }) return true

        val units = setOf(
            "m", "cm", "mm", "km", "m2", "m²", "m3", "m³", "kg", "g", "mg", "t", "ton", "%", "°", "°c", "pa", "kpa", "mpa"
        )
        return compact.lowercase() in units || compact.lowercase() in setOf("sin", "epi") || Regex("^[A-Z]{2,5}$").matches(compact)
    }

    private fun isInstructionHeading(raw: String): Boolean {
        val clean = raw.lowercase().replace(Regex("\\s+"), " ").trim().trimEnd(':')
        return clean.startsWith("complete con las palabras que corresponda") ||
            clean.startsWith("complete con la palabra que corresponda") ||
            clean.startsWith("completa con las palabras que correspondan") ||
            clean.startsWith("ponga si es verdadero") ||
            clean.startsWith("marque verdadero o falso")
    }

    private fun isLikelyTrueFalseBatch(questions: List<String>): Boolean {
        if (questions.size < 3) return false
        val emptyAnswerParens = Regex("\\(\\s*\\)\\s*[.?!]*\\s*$")
        val explicit = questions.count { q ->
            val normalized = q.lowercase()
            normalized.contains("verdadero o falso") || normalized.contains("v/f") ||
                emptyAnswerParens.containsMatchIn(q.trim())
        }
        return explicit * 100 / questions.size >= 60
    }

    private fun splitQuestionAndOptions(raw: String): SplitQuestion {
        val body = normalizeBody(stripDocumentNoise(raw))
        val matches = optionStart.findAll(body).toList()
        if (matches.isEmpty()) return SplitQuestion(body, mutableListOf())

        val question = body.substring(0, matches.first().range.first).trim()
        val options = mutableListOf<Pair<Char, String>>()
        for (index in matches.indices) {
            val match = matches[index]
            val letter = match.groupValues[1].first().uppercaseChar()
            val start = match.range.last + 1
            val end = matches.getOrNull(index + 1)?.range?.first ?: body.length
            val optionBody = body.substring(start, end).trim(' ', ',', ';', '-')
            if (optionBody.isNotBlank()) options += letter to optionBody
        }
        return SplitQuestion(question.ifBlank { body }, options)
    }

    private fun stripDocumentNoise(raw: String): String {
        var text = raw
        val patterns = listOf(
            Regex("(?i)PR[ÁA]CTICA\\s*\\d+\\s*[-–—]\\s*MINER[ÍI]A"),
            Regex("(?i)HOJA\\s+DE\\s+PRUEBA\\s+OCR\\s*\\d*\\s*[-–—]?\\s*MINER[ÍI]A"),
            Regex("(?i)Instituto\\s*/\\s*Universidad\\s*[-–—]\\s*Hoja\\s+de\\s+preguntas"),
            Regex("(?i)Preguntas\\s+mixtas\\s*:\\s*normales.*?completar\\s+frase"),
            Regex("(?i)Documento\\s+de\\s+pr[áa]ctica\\s+acad[ée]mica\\s+para\\s+prueba\\s+de\\s+OCR\\.?"),
            Regex("(?i)Prueba\\s+diseñada\\s+para\\s+verificar\\s+OCR.*?respuestas\\s+cortas\\.?")
        )
        patterns.forEach { pattern -> text = text.replace(pattern, " ") }
        return normalizeBody(text)
    }

    private fun cleanLine(raw: String): String {
        return raw
            .replace(Regex("[\\t ]+"), " ")
            .replace('•', ' ')
            .trim()
    }

    private fun normalizeBody(raw: String): String {
        return raw
            .replace(Regex("[ \\t]+"), " ")
            .replace(Regex("\\s*\\n\\s*"), "\n")
            .trim(' ', '-', ':')
    }

    private fun isPureHeading(text: String): Boolean {
        val clean = text.trim()
        if (clean.isBlank()) return true
        if (clean.contains('?') || clean.contains('¿')) return false
        if (startsLikeQuestion(clean) || looksLikeTrueFalse(clean) || looksLikeCompletion(clean)) return false
        if (standaloneOption.matches(clean)) return false
        if (Regex("(?i)^(pr[áa]ctica|hoja de prueba|instituto / universidad|preguntas mixtas|documento de pr[áa]ctica)").containsMatchIn(clean)) {
            return true
        }
        val words = clean.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.size !in 1..14) return false
        val letters = clean.replace(Regex("[^A-Za-zÁÉÍÓÚáéíóúÑñ ]"), " ").trim()
        if (letters.isBlank()) return false
        return words.all { word ->
            word.firstOrNull()?.isUpperCase() == true ||
                word.lowercase() in setOf("de", "del", "y", "e", "la", "el", "para")
        }
    }

    private fun startsLikeQuestion(line: String): Boolean {
        val clean = line
            .trim()
            .trimStart('¿', '?', '¡', '!', '-', '–', '—', ':', ';', '.', ' ')
            .lowercase()

        // Un signo de cierre es una señal fuerte incluso cuando la pregunta no
        // empieza por una palabra interrogativa, por ejemplo: "En un plano... ?".
        if (line.trim().endsWith("?") && clean.length >= 4) return true

        return listOf(
            "qué ", "que ", "cuál ", "cual ", "cuáles ", "cuales ", "cómo ", "como ",
            "por qué ", "por que ", "dónde ", "donde ", "cuándo ", "cuando ",
            "quién ", "quien ", "quiénes ", "quienes ", "cuánto ", "cuanto ",
            "menciona ", "mencione ", "mencione las ", "mencione los ",
            "explica ", "explique ", "define ", "defina ", "indica ", "indique ",
            "completa ", "complete ", "resuelve ", "resuelva ", "señala ", "señale ",
            "selecciona ", "seleccione ", "marca ", "marque ", "calcula ", "calcule ",
            "determina ", "determine ", "describe ", "describa ", "enumera ", "enumere ",
            "compara ", "compare ", "diferencia entre ", "diferencie ",
            "convertir ", "convierte ", "convierta ", "halle ", "obtenga ",
            "realice ", "desarrolle ", "responda ", "identifique ", "relacione ",
            "escriba ", "justifique ", "demuestre ", "señale la ", "señale el "
        ).any { clean.startsWith(it) }
    }

    private fun looksLikeTrueFalse(line: String): Boolean {
        val clean = line.lowercase()
        return clean.startsWith("verdadero o falso") ||
            clean.startsWith("verdadero/falso") ||
            clean.startsWith("v/f") ||
            clean.contains(" verdadero o falso") ||
            clean.endsWith(" v/f")
    }

    private fun looksLikeCompletion(line: String): Boolean {
        val clean = line.lowercase()
        return clean.startsWith("completa ") || clean.startsWith("complete ") ||
            line.contains("___") || line.contains("……") || line.contains(".....")
    }

    private fun isAlternativeQuestion(raw: String): Boolean {
        val clean = raw.lowercase()
        return clean.contains("cuál de los siguientes") ||
            clean.contains("cual de los siguientes") ||
            clean.contains("cuál de las siguientes") ||
            clean.contains("cual de las siguientes") ||
            clean.contains("de las siguientes opciones") ||
            clean.contains("de los siguientes ejemplos") ||
            clean.contains("alternativa correcta") ||
            clean.contains("opción correcta") ||
            clean.contains("opcion correcta") ||
            clean.startsWith("selecciona ") || clean.startsWith("señala ")
    }

    private fun extractFallback(raw: String): String {
        val lines = raw.lines()
            .map { stripDocumentNoise(cleanLine(it)) }
            .filter { it.length >= 2 && !junkOnly.matches(it) && !isPureHeading(it) }
        if (lines.isEmpty()) return ""
        return lines.takeLast(12).joinToString("\n").take(2200)
    }
}
