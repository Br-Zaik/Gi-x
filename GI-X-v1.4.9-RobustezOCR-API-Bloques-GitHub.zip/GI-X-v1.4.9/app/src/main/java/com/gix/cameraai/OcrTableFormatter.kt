package com.gix.cameraai

import android.graphics.Rect
import com.google.mlkit.vision.text.Text
import kotlin.math.abs
import kotlin.math.max

/**
 * Reconstrucción conservadora de tablas usando la geometría que ya entrega ML Kit.
 *
 * No intenta interpretar el contenido de la tabla. Solo conserva la relación visual
 * fila/columna para que la IA reciba algo como:
 *
 * Encabezados: APLICACIÓN | FUNCIÓN
 * Fila 1: NAVEGADOR | [VACÍO]
 *
 * Esto funciona también con 3, 4 o más columnas cuando el OCR puede ubicar sus textos.
 */
object OcrTableFormatter {
    const val STRUCTURED_TABLES_HEADER = "[GIX_STRUCTURED_TABLES]"
    const val TABLE_START = "[GIX_TABLE_START]"
    const val TABLE_END = "[GIX_TABLE_END]"
    const val EMPTY_CELL = "[VACÍO]"

    data class TableData(
        val headers: List<String>,
        val rows: List<List<String>>
    ) {
        fun toPromptText(): String = buildString {
            append(TABLE_START).append('\n')
            append("Columnas: ").append(headers.joinToString(" | ")).append('\n')
            rows.forEachIndexed { index, row ->
                append("Fila ").append(index + 1).append(": ")
                append(row.map { it.ifBlank { EMPTY_CELL } }.joinToString(" | "))
                append('\n')
            }
            append(TABLE_END)
        }
    }

    private data class Atom(
        val text: String,
        val box: Rect
    ) {
        val left: Int get() = box.left
        val right: Int get() = box.right
        val top: Int get() = box.top
        val bottom: Int get() = box.bottom
        val centerX: Float get() = (left + right) / 2f
        val centerY: Float get() = (top + bottom) / 2f
        val height: Int get() = max(1, bottom - top)
        val width: Int get() = max(1, right - left)
    }

    private data class VisualCell(
        val text: String,
        val left: Int,
        val right: Int
    ) {
        val centerX: Float get() = (left + right) / 2f
    }

    private data class VisualRow(
        val cells: List<VisualCell>,
        val top: Int,
        val bottom: Int
    ) {
        val text: String get() = cells.joinToString(" ") { it.text }
        val centerY: Float get() = (top + bottom) / 2f
        val height: Int get() = max(1, bottom - top)
    }

    fun addStructuredTables(rawText: String, result: Text, imageWidth: Int): String {
        val tables = detectTables(result, imageWidth)
        if (tables.isEmpty()) return rawText
        return buildString {
            append(rawText.trim())
            append("\n\n")
            append(STRUCTURED_TABLES_HEADER)
            append('\n')
            tables.forEachIndexed { index, table ->
                if (index > 0) append('\n')
                append(table.toPromptText())
                append('\n')
            }
        }.trim()
    }

    fun parseStructuredTables(raw: String): List<String> {
        val metadata = raw.substringAfter(STRUCTURED_TABLES_HEADER, "")
        if (metadata.isBlank()) return emptyList()
        val regex = Regex(
            Regex.escape(TABLE_START) + "(.*?)" + Regex.escape(TABLE_END),
            setOf(RegexOption.DOT_MATCHES_ALL)
        )
        return regex.findAll(metadata)
            .map { match ->
                TABLE_START + "\n" + match.groupValues[1].trim() + "\n" + TABLE_END
            }
            .toList()
    }

    fun removeStructuredTables(raw: String): String {
        return raw.substringBefore(STRUCTURED_TABLES_HEADER).trim()
    }

    private fun detectTables(result: Text, imageWidth: Int): List<TableData> {
        val atoms = result.textBlocks
            .flatMap { it.lines }
            .flatMap { it.elements }
            .mapNotNull { element ->
                val text = element.text.trim()
                val box = element.boundingBox
                if (text.isBlank() || box == null || box.width() <= 0 || box.height() <= 0) null
                else Atom(text, box)
            }

        if (atoms.size < 4) return emptyList()
        val rows = buildVisualRows(atoms, imageWidth)
        if (rows.size < 3) return emptyList()

        val tables = mutableListOf<TableData>()
        var index = 0
        while (index < rows.size) {
            val header = rows[index]
            if (!looksLikeHeader(header, rows, index)) {
                index++
                continue
            }

            val columnCount = header.cells.size
            if (columnCount !in 2..6) {
                index++
                continue
            }

            val headerAnchors = header.cells.map { it.centerX }
            val collected = mutableListOf<List<String>>()
            var cursor = index + 1
            var previous = header

            while (cursor < rows.size && collected.size < 24) {
                val row = rows[cursor]
                val gap = row.top - previous.bottom
                val typicalHeight = max(header.height, previous.height)

                if (collected.isNotEmpty() && gap > typicalHeight * 3) break
                if (row.cells.size == 1 && isDefiniteQuestionStart(row.text)) break
                if (isSectionHeading(row.text) && collected.isNotEmpty()) break
                if (row.text.length > 180 && collected.isNotEmpty()) break

                // Una fila de tabla suele ser corta. Permitimos frases algo más largas
                // para tablas académicas con "características" o descripciones.
                if (row.text.length > 240) break

                val aligned = alignRowToColumns(row, headerAnchors, columnCount)
                if (aligned.any { it.isNotBlank() }) {
                    collected += aligned
                    previous = row
                    cursor++
                } else {
                    break
                }
            }

            // Evita falsos positivos en títulos normales: exigimos al menos 2 filas.
            if (collected.size >= 2) {
                val meaningfulHeaders = header.cells.map { it.text.trim() }
                tables += TableData(meaningfulHeaders, collected)
                index = cursor
            } else {
                index++
            }
        }

        return tables.take(6)
    }

    private fun buildVisualRows(atoms: List<Atom>, imageWidth: Int): List<VisualRow> {
        val sorted = atoms.sortedWith(compareBy<Atom> { it.centerY }.thenBy { it.left })
        val groups = mutableListOf<MutableList<Atom>>()

        for (atom in sorted) {
            val target = groups.lastOrNull()
            if (target == null) {
                groups += mutableListOf(atom)
                continue
            }
            val top = target.minOf { it.top }
            val bottom = target.maxOf { it.bottom }
            val centerY = (top + bottom) / 2f
            val avgHeight = target.map { it.height }.average().toFloat().coerceAtLeast(1f)
            val tolerance = max(atom.height, avgHeight.toInt()) * 0.55f

            if (abs(atom.centerY - centerY) <= tolerance || verticalOverlap(atom, top, bottom) >= 0.45f) {
                target += atom
            } else {
                groups += mutableListOf(atom)
            }
        }

        return groups.mapNotNull { rowAtoms ->
            val ordered = rowAtoms.sortedBy { it.left }
            if (ordered.isEmpty()) return@mapNotNull null
            val charWidths = ordered.map { atom -> atom.width.toFloat() / atom.text.length.coerceAtLeast(1) }
            val medianChar = charWidths.sorted()[charWidths.size / 2].coerceAtLeast(2f)
            val minWideGap = max(imageWidth * 0.018f, medianChar * 2.8f)

            val cells = mutableListOf<VisualCell>()
            var currentText = StringBuilder(ordered.first().text)
            var currentLeft = ordered.first().left
            var currentRight = ordered.first().right

            for (i in 1 until ordered.size) {
                val atom = ordered[i]
                val gap = atom.left - currentRight
                if (gap > minWideGap) {
                    cells += VisualCell(currentText.toString().trim(), currentLeft, currentRight)
                    currentText = StringBuilder(atom.text)
                    currentLeft = atom.left
                    currentRight = atom.right
                } else {
                    if (currentText.isNotEmpty()) currentText.append(' ')
                    currentText.append(atom.text)
                    currentRight = max(currentRight, atom.right)
                }
            }
            cells += VisualCell(currentText.toString().trim(), currentLeft, currentRight)

            VisualRow(
                cells = cells.filter { it.text.isNotBlank() },
                top = ordered.minOf { it.top },
                bottom = ordered.maxOf { it.bottom }
            )
        }.filter { it.cells.isNotEmpty() }
    }

    private fun verticalOverlap(atom: Atom, top: Int, bottom: Int): Float {
        val overlap = (minOf(atom.bottom, bottom) - maxOf(atom.top, top)).coerceAtLeast(0)
        val minHeight = minOf(atom.height, max(1, bottom - top))
        return overlap.toFloat() / minHeight.toFloat()
    }

    private fun looksLikeHeader(row: VisualRow, rows: List<VisualRow>, index: Int): Boolean {
        if (row.cells.size !in 2..6) return false
        if (row.cells.any { it.text.length > 55 }) return false

        val text = row.text.trim()
        val lower = text.lowercase()
        val headerWords = setOf(
            "aplicación", "aplicacion", "función", "funcion", "característica", "caracteristicas",
            "característica", "uso", "nombre", "tipo", "concepto", "definición", "definicion",
            "mineral", "fórmula", "formula", "elemento", "símbolo", "simbolo", "ventaja", "desventaja",
            "etapa", "actividad", "ejemplo", "descripción", "descripcion", "propiedad", "resultado"
        )
        val keywordHits = lower.split(Regex("\\s+")).count { word ->
            word.trim(':', ';', ',', '.', '-', '_') in headerWords
        }

        val letters = text.filter { it.isLetter() }
        val uppercaseRatio = if (letters.isEmpty()) 0f else letters.count { it.isUpperCase() }.toFloat() / letters.length
        val previousCue = rows.subList(max(0, index - 3), index)
            .any { previous -> isExplicitTableCue(previous.text) }

        val nextRows = rows.drop(index + 1).take(4)
        val shortFollowers = nextRows.count { it.text.length in 1..120 }
        val structuralHeader = row.cells.size >= 3 &&
            uppercaseRatio >= 0.90f &&
            nextRows.take(3).count { follower -> follower.cells.size >= 2 } >= 2

        // Para 2 columnas exigimos evidencia fuerte: dos encabezados conocidos o una
        // consigna explícita de tabla/cuadro. Así una frase normal de V/F que casualmente
        // quede partida por un espacio ancho nunca se convierte en tabla.
        val strongSemanticHeader = keywordHits >= 2 || previousCue
        return shortFollowers >= 2 && (strongSemanticHeader || structuralHeader)
    }

    private fun isExplicitTableCue(raw: String): Boolean {
        val clean = raw.lowercase().replace(Regex("\\s+"), " ").trim()
        if (clean.isBlank()) return false
        return listOf(
            "complete la tabla", "completa la tabla", "complete el cuadro", "completa el cuadro",
            "en la siguiente tabla", "en el siguiente cuadro", "tabla siguiente", "cuadro siguiente",
            "complete la funcion que corresponde", "complete la función que corresponde",
            "complete la funcion que corresponda", "complete la función que corresponda",
            "relacione las columnas", "relaciona las columnas", "columnas de la tabla",
            "filas de la tabla"
        ).any { clean.contains(it) } || clean == "tabla" || clean == "cuadro"
    }

    private fun alignRowToColumns(row: VisualRow, anchors: List<Float>, columnCount: Int): List<String> {
        val output = MutableList(columnCount) { "" }
        for (cell in row.cells) {
            val nearest = anchors.indices.minByOrNull { abs(cell.centerX - anchors[it]) } ?: continue
            output[nearest] = if (output[nearest].isBlank()) {
                cell.text.trim()
            } else {
                (output[nearest] + " " + cell.text.trim()).trim()
            }
        }
        return output
    }

    private fun isDefiniteQuestionStart(text: String): Boolean {
        val clean = text.trim()
        if (Regex("^\\d{1,2}[\\.)]\\s+.+").matches(clean)) return true
        val lower = clean.trimStart('¿', '?', '-', '–', '—', ' ').lowercase()
        return listOf(
            "qué ", "que ", "cuál ", "cual ", "cómo ", "como ", "mencione ", "explique ",
            "defina ", "calcule ", "complete ", "completa ", "diferencia entre ", "convertir "
        ).any { lower.startsWith(it) }
    }

    private fun isSectionHeading(text: String): Boolean {
        val clean = text.trim()
        val words = clean.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.size !in 2..10) return false
        val letters = clean.filter { it.isLetter() }
        if (letters.length < 8) return false
        val uppercaseRatio = letters.count { it.isUpperCase() }.toFloat() / letters.length
        return uppercaseRatio >= 0.85f && clean.length > 20
    }
}
