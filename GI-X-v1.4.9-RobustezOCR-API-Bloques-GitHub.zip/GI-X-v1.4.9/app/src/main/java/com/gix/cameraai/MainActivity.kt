package com.gix.cameraai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.gix.cameraai.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener, CameraBridgeServer.Listener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: AppPrefs
    private lateinit var apiSettings: GeminiSettings
    private lateinit var onlineProvider: OnlineAnswerProvider
    private lateinit var cameraServer: CameraBridgeServer
    private lateinit var historyRepository: HistoryRepository
    private val ocrProcessor = OcrProcessor()
    private val ioExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val processing = AtomicBoolean(false)

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var autoMode = false
    private var stopped = false
    private var inputMode = InputMode.CAMERA
    private var activeCaptureRequestId: String? = null
    private var cameraStatusTicker: Runnable? = null
    private var lastExtractedQuestions: List<String> = emptyList()
    private var previewBitmap: Bitmap? = null
    private var lastDisplayedOcrText: String = ""
    private var lastSourceLabel: String = "desconocido"

    private val openPhotoLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) loadPhotoFromUri(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = AppPrefs(this)
        apiSettings = GeminiSettings(this)
        onlineProvider = OnlineAnswerProvider(this)
        historyRepository = HistoryRepository(this)
        tts = TextToSpeech(this, this)

        // Limpia estados antiguos de "espera" de la API pagada sin borrar la clave.
        apiSettings.getApiConfigs()
            .filter { it.provider == NetProvider.CHEAPER_INFERENCE }
            .forEach { apiSettings.shouldSkip(it) }

        setupButtons()
        setupInternalScroll(binding.svOcr)
        setupInternalScroll(binding.svAnswer)
        renderHistory()
        updateApiChip()
        startCameraServer()
        startCameraStatusTicker()
    }

    private fun setupButtons() {
        binding.inputModeGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            when (checkedId) {
                R.id.btnModeCamera -> setInputMode(InputMode.CAMERA)
                R.id.btnModeImage -> setInputMode(InputMode.IMAGE)
            }
        }
        binding.inputModeGroup.check(R.id.btnModeCamera)

        binding.btnCapture.setOnClickListener {
            stopped = false
            requestCameraCapture(manual = true)
        }

        binding.btnAuto.setOnClickListener {
            if (inputMode != InputMode.CAMERA) {
                binding.tvStatus.text = "El modo AUTO funciona con la cámara. Cambia a CÁMARA."
                return@setOnClickListener
            }
            autoMode = !autoMode
            stopped = false
            binding.btnAuto.text = if (autoMode) "AUTO: ON" else "AUTO: OFF"
            if (autoMode) {
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                binding.tvStatus.text = "AUTO activo: GI X repetirá foto → OCR → API → voz."
                requestCameraCapture(manual = false)
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                binding.tvStatus.text = "AUTO detenido. Enciende la cámara o pulsa PEDIR FOTO."
            }
        }

        binding.btnStop.setOnClickListener { stopCurrentCycle() }

        binding.btnChooseImage.setOnClickListener {
            stopped = false
            openPhotoLauncher.launch(arrayOf("image/*"))
        }

        binding.btnApi.setOnClickListener { showApiDialog() }
        binding.btnVoice.setOnClickListener { showVoiceDialog() }
        binding.btnCameraSettings.setOnClickListener { showCameraDialog() }
        binding.btnOpenPreview.setOnClickListener { showPreviewDialog() }
        binding.btnClearHistory.setOnClickListener { confirmClearHistory() }
    }

    private fun setInputMode(mode: InputMode) {
        if (inputMode == mode && binding.cameraActions.visibility == if (mode == InputMode.CAMERA) View.VISIBLE else View.GONE) {
            return
        }
        inputMode = mode
        when (mode) {
            InputMode.CAMERA -> {
                binding.cameraActions.visibility = View.VISIBLE
                binding.btnChooseImage.visibility = View.GONE
                binding.tvStatus.text = "Modo CÁMARA. Activa tu Zona Wi-Fi y enciende la Timer Camera X; GI X recibirá la foto."
            }
            InputMode.IMAGE -> {
                autoMode = false
                binding.btnAuto.text = "AUTO: OFF"
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                cameraServer.cancelCapture()
                activeCaptureRequestId = null
                binding.cameraActions.visibility = View.GONE
                binding.btnChooseImage.visibility = View.VISIBLE
                binding.tvStatus.text = "Modo IMAGEN MANUAL. Pulsa ELEGIR IMAGEN y GI X hará OCR → API → voz."
            }
        }
    }

    private fun startCameraServer() {
        cameraServer = CameraBridgeServer(
            CameraBridgeServer.DEFAULT_PORT,
            tokenProvider = { prefs.pairingToken },
            listener = this
        )
        cameraServer.start()
    }

    private fun startCameraStatusTicker() {
        val ticker = object : Runnable {
            override fun run() {
                updateCameraChip()
                mainHandler.postDelayed(this, 2_000L)
            }
        }
        cameraStatusTicker = ticker
        mainHandler.post(ticker)
    }

    private fun requestCameraCapture(manual: Boolean) {
        if (processing.get()) {
            binding.tvStatus.text = "Espera: GI X todavía está procesando la foto anterior."
            return
        }
        if (activeCaptureRequestId != null) {
            binding.tvStatus.text = "Ya hay una foto solicitada. Esperando a la cámara..."
            return
        }

        val requestId = cameraServer.requestCapture()
        activeCaptureRequestId = requestId
        binding.tvStatus.text = if (cameraServer.isCameraConnected()) {
            "Orden enviada. Esperando la foto de Timer Camera X..."
        } else {
            "Orden preparada. Enciende la cámara y verifica que esté conectada a tu Zona Wi-Fi."
        }

        mainHandler.postDelayed({
            if (activeCaptureRequestId == requestId) {
                cameraServer.cancelCapture()
                activeCaptureRequestId = null
                if (!processing.get()) {
                    binding.tvStatus.text = if (manual) {
                        "La cámara no respondió. Revisa Zona Wi-Fi, cámara y clave de enlace."
                    } else {
                        "Auto: cámara sin respuesta. Reintentaré cuando vuelva a estar disponible."
                    }
                }
            }
        }, 25_000L)
    }

    private fun stopCurrentCycle() {
        stopped = true
        autoMode = false
        binding.btnAuto.text = "AUTO: OFF"
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        cameraServer.cancelCapture()
        activeCaptureRequestId = null
        onlineProvider.cancelActiveRequest()
        tts?.stop()
        processing.set(false)
        binding.tvStatus.text = if (inputMode == InputMode.CAMERA) {
            "Detenido. Enciende la cámara o pulsa PEDIR FOTO."
        } else {
            "Detenido. Pulsa ELEGIR IMAGEN cuando quieras continuar."
        }
    }

    override fun onServerStarted(port: Int) {
        runOnUiThread {
            if (inputMode == InputMode.CAMERA) {
                binding.tvStatus.text = "GI X listo. Activa tu Zona Wi-Fi y enciende la cámara; recibirá la foto por el puerto $port."
            }
        }
    }

    override fun onServerError(message: String) {
        runOnUiThread {
            binding.tvStatus.text = "Error del enlace con cámara: $message"
            binding.tvCameraChip.text = "Cámara: error"
        }
    }

    override fun onCameraSeen() {
        runOnUiThread { updateCameraChip() }
    }

    override fun onPhotoReceived(jpeg: ByteArray, requestId: String?) {
        activeCaptureRequestId = null
        if (inputMode != InputMode.CAMERA) {
            runOnUiThread {
                binding.tvStatus.text = "Llegó una foto de la cámara, pero GI X está en modo IMAGEN MANUAL."
            }
            return
        }
        val bitmap = BitmapFactory.decodeByteArray(
            jpeg,
            0,
            jpeg.size,
            BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
        )
        if (bitmap == null) {
            runOnUiThread { binding.tvStatus.text = "La cámara envió una imagen que Android no pudo abrir." }
            return
        }
        runOnUiThread { processBitmap(bitmap, source = "cámara") }
    }

    private fun loadPhotoFromUri(uri: Uri) {
        binding.tvStatus.text = "Abriendo imagen y corrigiendo orientación..."
        ioExecutor.execute {
            val bitmap = runCatching { ImageLoader.load(this, uri) }.getOrNull()
            runOnUiThread {
                if (bitmap == null) {
                    binding.tvStatus.text = "No pude abrir esa imagen. Prueba con JPG, PNG, WEBP o una foto normal."
                    return@runOnUiThread
                }
                processBitmap(bitmap, source = "imagen manual")
            }
        }
    }

    private fun processBitmap(bitmap: Bitmap, source: String) {
        if (!processing.compareAndSet(false, true)) {
            binding.tvStatus.text = "Ya estoy procesando otra foto."
            return
        }
        stopped = false
        lastExtractedQuestions = emptyList()
        lastDisplayedOcrText = ""
        lastSourceLabel = source
        previewBitmap = bitmap
        binding.ivPreview.setImageBitmap(bitmap)
        binding.tvPreviewPlaceholder.visibility = View.GONE
        binding.tvStatus.text = "Imagen recibida ($source). OCR mejorado: preparando y leyendo texto..."
        binding.tvOcr.text = "Procesando OCR..."
        binding.tvAnswer.text = "Esperando texto..."

        ocrProcessor.process(
            bitmap,
            onSuccess = { rawText ->
                runOnUiThread { handleOcrResult(rawText) }
            },
            onError = { error ->
                runOnUiThread {
                    processing.set(false)
                    binding.tvStatus.text = "OCR falló: $error"
                    binding.tvOcr.text = "No se pudo detectar texto."
                    binding.tvAnswer.text = "Acerca la cámara, mejora la luz y vuelve a intentarlo."
                    scheduleNextAutoIfNeeded()
                }
            }
        )
    }

    private fun handleOcrResult(rawText: String) {
        if (stopped) {
            processing.set(false)
            return
        }
        val cleanRaw = rawText.trim()
        if (cleanRaw.isBlank()) {
            processing.set(false)
            binding.tvStatus.text = "OCR terminado, pero no encontró texto legible."
            binding.tvOcr.text = "Sin texto detectado."
            binding.tvAnswer.text = "Prueba con más luz, menos inclinación y enfoca mejor la pregunta."
            scheduleNextAutoIfNeeded()
            return
        }

        val questions = OcrQuestionExtractor.extractQuestions(cleanRaw)
        lastExtractedQuestions = questions
        val extractedText = if (questions.isNotEmpty()) {
            questions.joinToString("\n\n")
        } else {
            OcrQuestionExtractor.extract(cleanRaw).ifBlank { cleanRaw.take(2600) }
        }
        lastDisplayedOcrText = extractedText
        binding.tvOcr.text = extractedText
        scrollTextToTop(binding.tvOcr)

        if (questions.isEmpty()) {
            processing.set(false)
            binding.tvStatus.text = "Se leyó texto, pero no pude identificar preguntas claras."
            binding.tvAnswer.text = "Centra mejor el texto y vuelve a intentarlo."
            scheduleNextAutoIfNeeded()
            return
        }

        val batches = questions.chunked(API_BATCH_SIZE)
        binding.tvStatus.text = if (questions.size == 1) {
            "Pregunta detectada. Consultando la API..."
        } else if (batches.size == 1) {
            "${questions.size} preguntas detectadas. Consultando la API..."
        } else {
            "${questions.size} preguntas detectadas. Se resolverán en ${batches.size} bloques para evitar respuestas cortadas."
        }
        binding.tvAnswer.text = "Consultando IA..."
        ioExecutor.execute {
            val completed = mutableListOf<String>()
            var failedAnswer: String? = null
            var completedQuestions = 0

            for ((batchIndex, batch) in batches.withIndex()) {
                if (stopped) {
                    processing.set(false)
                    return@execute
                }

                if (batches.size > 1) {
                    mainHandler.post {
                        if (!stopped) {
                            binding.tvStatus.text = "Consultando IA: bloque ${batchIndex + 1} de ${batches.size}..."
                        }
                    }
                }

                val payload = OcrQuestionExtractor.buildQueryPayload(batch, forceBatch = questions.size > 1)
                val answer = onlineProvider.fetchShortAnswer(payload).trim()
                if (answer.startsWith(OnlineAnswerProvider.API_ERROR_PREFIX)) {
                    failedAnswer = answer
                    break
                }

                val globalAnswer = renumberBatchAnswer(answer, completedQuestions)
                completed += globalAnswer
                completedQuestions += batch.size
            }

            runOnUiThread {
                if (stopped) {
                    processing.set(false)
                    return@runOnUiThread
                }
                if (failedAnswer != null) {
                    handleChunkedApiFailure(completed.joinToString("\n\n"), failedAnswer!!, completedQuestions, questions.size)
                } else {
                    handleAnswer(completed.joinToString("\n\n"))
                }
            }
        }
    }

    private fun renumberBatchAnswer(answer: String, offset: Int): String {
        if (offset <= 0) return answer.trim()
        val numberedLine = Regex("^(\\s*)(?:(Pregunta)\\s+)?(\\d{1,2})([\\.):])\\s*(.*)$", RegexOption.IGNORE_CASE)
        return answer.lines().joinToString("\n") { line ->
            val match = numberedLine.find(line) ?: return@joinToString line
            val prefix = match.groupValues[1]
            val questionWord = match.groupValues[2]
            val localNumber = match.groupValues[3].toIntOrNull() ?: return@joinToString line
            val separator = match.groupValues[4]
            val tail = match.groupValues[5]
            val globalNumber = localNumber + offset
            if (questionWord.isNotBlank()) {
                "$prefix$questionWord $globalNumber$separator $tail".trimEnd()
            } else {
                "$prefix$globalNumber$separator $tail".trimEnd()
            }
        }.trim()
    }

    private fun handleChunkedApiFailure(partial: String, rawError: String, completed: Int, total: Int) {
        processing.set(false)
        val error = rawError.removePrefix(OnlineAnswerProvider.API_ERROR_PREFIX).trim()
        val visible = buildString {
            if (partial.isNotBlank()) {
                append(partial.trim())
                append("\n\n")
            }
            append("No se pudieron completar las preguntas restantes ($completed de $total respondidas).\n")
            append(error.ifBlank { "La API no devolvió una respuesta válida." })
        }
        binding.tvAnswer.text = visible
        scrollTextToTop(binding.tvAnswer)
        saveToHistory(visible)
        updateApiChip()
        binding.tvStatus.text = "La API no completó todos los bloques. Las respuestas ya recibidas se conservaron."
        scheduleNextAutoIfNeeded()
    }

    private fun handleAnswer(answer: String) {
        processing.set(false)
        val clean = answer.trim().ifBlank { "La API no devolvió una respuesta." }
        val displayText = when {
            lastExtractedQuestions.size == 1 && !clean.contains("Respuesta:", ignoreCase = true) -> {
                "${lastExtractedQuestions.first()}\nRespuesta: $clean"
            }
            else -> clean
        }
        val apiError = clean.startsWith(OnlineAnswerProvider.API_ERROR_PREFIX)
        val visibleText = if (apiError) clean.removePrefix(OnlineAnswerProvider.API_ERROR_PREFIX).trim() else displayText
        binding.tvAnswer.text = visibleText
        scrollTextToTop(binding.tvAnswer)
        saveToHistory(visibleText)
        updateApiChip()

        if (apiError) {
            binding.tvStatus.text = "La API no respondió correctamente. Revisa el detalle abajo."
            scheduleNextAutoIfNeeded()
            return
        }

        binding.tvStatus.text = "Respuesta lista. Reproduciendo voz..."

        if (ttsReady) {
            tts?.setSpeechRate(prefs.speechRate)
            val spokenText = VoiceQuestionNormalizer.prepareForTts(displayText)
            tts?.speak(spokenText, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ANSWER)
        } else {
            binding.tvStatus.text = "Respuesta lista. El motor de voz todavía no está disponible."
            scheduleNextAutoIfNeeded()
        }
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) {
            ttsReady = false
            return
        }
        val engine = tts ?: return
        val result = engine.setLanguage(Locale("es", "PE"))
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.language = Locale("es", "ES")
        }
        engine.setSpeechRate(prefs.speechRate)
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit
            override fun onDone(utteranceId: String?) {
                if (utteranceId == UTTERANCE_ANSWER) {
                    runOnUiThread {
                        binding.tvStatus.text = if (autoMode) {
                            "Respuesta terminada. Preparando la siguiente foto..."
                        } else {
                            "Listo. Puedes pedir otra foto o elegir otra imagen."
                        }
                        scheduleNextAutoIfNeeded()
                    }
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                if (utteranceId == UTTERANCE_ANSWER) runOnUiThread { scheduleNextAutoIfNeeded() }
            }
        })
        ttsReady = true
    }

    private fun scheduleNextAutoIfNeeded() {
        if (!autoMode || stopped || inputMode != InputMode.CAMERA) return
        mainHandler.postDelayed({
            if (autoMode && !stopped && !processing.get() && activeCaptureRequestId == null) {
                requestCameraCapture(manual = false)
            }
        }, AUTO_NEXT_DELAY_MS)
    }

    private fun updateCameraChip() {
        binding.tvCameraChip.text = if (cameraServer.isCameraConnected()) {
            "Cámara: conectada"
        } else {
            "Cámara: esperando"
        }
    }

    private fun updateApiChip() {
        val config = apiSettings.getApiConfigs()
            .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }

        if (config == null) {
            binding.tvApiChip.text = "API: sin configurar"
            binding.tvApiDetail.text = "DeepSeek · SIN CONFIGURAR"
            return
        }

        val status = apiSettings.getStatus(config)
        val message = apiSettings.getMessage(config).trim()
        binding.tvApiChip.text = "API: DeepSeek"
        binding.tvApiDetail.text = when (status) {
            "ready" -> "DeepSeek · ACTIVA ✓ · CLAVE GUARDADA · ${config.model}"
            "error" -> "DeepSeek · GUARDADA · ERROR: ${message.ifBlank { "revisa clave, saldo o modelo" }}"
            "limit" -> "DeepSeek · GUARDADA · SIN CRÉDITOS / LÍMITE: ${message.ifBlank { "revisa tu cuenta" }}"
            else -> if (message.isBlank() || message.startsWith("Sin probar", ignoreCase = true)) {
                "DeepSeek · GUARDADA · SIN PROBAR · ${config.model}"
            } else {
                "DeepSeek · GUARDADA · ÚLTIMO ESTADO: $message"
            }
        }
    }

    private fun showVoiceDialog() {
        val labels = arrayOf("0.25x", "0.50x", "0.75x", "1.00x", "1.25x", "1.50x", "1.75x", "2.00x")
        val values = floatArrayOf(0.25f, 0.50f, 0.75f, 1.00f, 1.25f, 1.50f, 1.75f, 2.00f)
        val current = values.indices.minByOrNull { abs(values[it] - prefs.speechRate) } ?: 3
        AlertDialog.Builder(this)
            .setTitle("Velocidad de voz")
            .setSingleChoiceItems(labels, current) { dialog, which ->
                prefs.speechRate = values[which]
                tts?.setSpeechRate(values[which])
                Toast.makeText(this, "Voz ${labels[which]}", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showCameraDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(4))
        }
        val info = TextView(this).apply {
            text = "La cámara se conectará solo a la Zona Wi-Fi configurada en su firmware y enviará las fotos a GI X por el puerto ${CameraBridgeServer.DEFAULT_PORT}. La misma clave debe quedar grabada en la Timer Camera X."
            textSize = 14f
        }
        val tokenInput = EditText(this).apply {
            hint = "Clave de enlace"
            setText(prefs.pairingToken)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            maxLines = 1
        }
        val note = TextView(this).apply {
            text = "No cambies esta clave después de programar la cámara, salvo que vuelvas a grabar el firmware con la misma clave."
            textSize = 12f
        }
        box.addView(info)
        box.addView(tokenInput, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) })
        box.addView(note, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        val dialog = AlertDialog.Builder(this)
            .setTitle("Enlace con Timer Camera X")
            .setView(box)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                prefs.pairingToken = tokenInput.text?.toString().orEmpty()
                tokenInput.setText(prefs.pairingToken)
                binding.tvStatus.text = "Clave de cámara guardada. Debe coincidir con el firmware."
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun normalizeCheaperKey(raw: String): String {
        val cleaned = raw
            .trim()
            .removePrefix("Bearer ")
            .removePrefix("bearer ")
            .trim('\"', '\'')
            .replace("​", "")
            .replace("‌", "")
            .replace("‍", "")
            .replace("⁠", "")
            .replace("﻿", "")
            .replace(Regex("[\r\n\t ]+"), "")

        val embedded = Regex("(ir_live_[A-Za-z0-9._-]+|ci_live_[A-Za-z0-9._-]+)", RegexOption.IGNORE_CASE)
            .find(cleaned)
            ?.value
        return embedded ?: cleaned
    }

    private fun showApiDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }

        val title = TextView(this).apply {
            text = "CHEAPER INFERENCE · DEEPSEEK"
            textStyleBold()
            textSize = 15f
        }
        val info = TextView(this).apply {
            text = "GI X usará únicamente esta API de pago con DeepSeek V4 Flash. La clave queda guardada en el celular. Los fallos temporales no la bloquean y la app muestra el motivo real si no responde."
            textSize = 12f
            setPadding(0, dp(4), 0, dp(8))
        }

        val saved = apiSettings.getApiConfigs()
            .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }
        val keyInput = EditText(this).apply {
            hint = if (saved == null) "Clave Cheaper Inference (ir_live_… / ci_live_…)" else "Clave guardada. Pega otra solo para reemplazarla"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            maxLines = 1
        }
        val modelInput = EditText(this).apply {
            hint = "Modelo fijo"
            setText(NetProvider.CHEAPER_INFERENCE.defaultModel)
            isEnabled = false
            maxLines = 1
        }
        val statusText = TextView(this).apply {
            textSize = 12f
            setPadding(0, dp(8), 0, dp(6))
        }
        val saveTest = Button(this).apply { text = "GUARDAR Y PROBAR DEEPSEEK" }
        val testSaved = Button(this).apply { text = "PROBAR API GUARDADA" }
        val delete = Button(this).apply { text = "BORRAR API GUARDADA" }
        val close = Button(this).apply { text = "CERRAR" }

        fun refresh(message: String? = null) {
            val config = apiSettings.getApiConfigs()
                .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }
            val storedStatus = if (config == null) {
                "DeepSeek: SIN CONFIGURAR"
            } else {
                val state = apiSettings.getStatus(config)
                val detail = apiSettings.getMessage(config).trim()
                when (state) {
                    "ready" -> "DeepSeek: ACTIVA ✓ · ${config.model} · clave guardada"
                    "error" -> "DeepSeek: GUARDADA · ERROR · ${detail.ifBlank { "revisa clave, saldo o modelo" }}"
                    "limit" -> "DeepSeek: GUARDADA · SIN CRÉDITOS / LÍMITE · ${detail.ifBlank { "revisa tu cuenta" }}"
                    else -> if (detail.isBlank() || detail.startsWith("Sin probar", ignoreCase = true)) {
                        "DeepSeek: GUARDADA · SIN PROBAR · ${config.model}"
                    } else {
                        "DeepSeek: GUARDADA · ${detail}"
                    }
                }
            }
            statusText.text = listOfNotNull(message?.takeIf { it.isNotBlank() }, storedStatus).joinToString("\n")
            updateApiChip()
        }

        box.addView(title)
        box.addView(info)
        box.addView(keyInput, LinearLayout.LayoutParams(-1, dp(54)))
        box.addView(modelInput, LinearLayout.LayoutParams(-1, dp(54)))
        box.addView(saveTest, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(6) })
        box.addView(testSaved, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4) })
        box.addView(statusText, LinearLayout.LayoutParams(-1, -2))
        box.addView(delete, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4) })
        box.addView(close, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4) })

        val dialog = AlertDialog.Builder(this)
            .setTitle("API de GI X")
            .setView(box)
            .create()

        saveTest.setOnClickListener {
            val typed = normalizeCheaperKey(keyInput.text?.toString().orEmpty())
            val current = apiSettings.getApiConfigs()
                .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }
            val key = typed.ifBlank { normalizeCheaperKey(current?.apiKey.orEmpty()) }
            if (key.isBlank()) {
                keyInput.error = "Pega tu clave ir_live_… o ci_live_…"
                return@setOnClickListener
            }
            val model = modelInput.text?.toString().orEmpty().trim()
                .ifBlank { NetProvider.CHEAPER_INFERENCE.defaultModel }
            val config = NetApiConfig(
                name = "DeepSeek Pago",
                provider = NetProvider.CHEAPER_INFERENCE,
                apiKey = key,
                model = model
            ).clean(0)

            // Esta versión usa una sola API: al guardar, elimina configuraciones de respaldo.
            apiSettings.saveApiConfigs(listOf(config))
            saveTest.isEnabled = false
            testSaved.isEnabled = false
            statusText.text = "DeepSeek: GUARDADA · probando conexión…"
            ioExecutor.execute {
                val result = onlineProvider.testApiConfig(config)
                runOnUiThread {
                    saveTest.isEnabled = true
                    testSaved.isEnabled = true
                    if (result.first) keyInput.text?.clear()
                    refresh(result.second)
                }
            }
        }

        testSaved.setOnClickListener {
            val config = apiSettings.getApiConfigs()
                .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }
            if (config == null) {
                refresh("No hay una API guardada todavía.")
                return@setOnClickListener
            }
            testSaved.isEnabled = false
            statusText.text = "DeepSeek: probando API guardada…"
            ioExecutor.execute {
                val result = onlineProvider.testApiConfig(config)
                runOnUiThread {
                    testSaved.isEnabled = true
                    refresh(result.second)
                }
            }
        }

        delete.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Borrar API")
                .setMessage("¿Quieres borrar la clave DeepSeek guardada en este celular?")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Borrar") { _, _ ->
                    apiSettings.saveApiConfigs(emptyList())
                    refresh("API borrada.")
                }
                .show()
        }

        close.setOnClickListener { dialog.dismiss() }
        dialog.setOnDismissListener { updateApiChip() }
        refresh()
        dialog.show()
    }

    private fun setupInternalScroll(scroll: ScrollView) {
        scroll.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> view.parent?.requestDisallowInterceptTouchEvent(true)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.parent?.requestDisallowInterceptTouchEvent(false)
            }
            false
        }
    }

    private fun showPreviewDialog() {
        val bitmap = previewBitmap
        if (bitmap == null) {
            Toast.makeText(this, "Todavía no hay imagen para abrir.", Toast.LENGTH_SHORT).show()
            return
        }

        val imageView = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setImageBitmap(bitmap)
            setBackgroundColor(0xFF0B1726.toInt())
        }
        val vertical = ScrollView(this)
        val horizontal = HorizontalScrollView(this)
        horizontal.addView(imageView, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        vertical.addView(horizontal, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val dialog = AlertDialog.Builder(this)
            .setTitle("Imagen completa")
            .setView(vertical)
            .setPositiveButton("Cerrar", null)
            .create()
        dialog.show()
        dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
    }

    private fun saveToHistory(answerText: String) {
        if (lastDisplayedOcrText.isBlank() || answerText.isBlank()) return
        val entry = HistoryEntry(
            id = System.currentTimeMillis().toString(),
            timestamp = System.currentTimeMillis(),
            source = lastSourceLabel,
            questionCount = lastExtractedQuestions.size.coerceAtLeast(1),
            ocrText = lastDisplayedOcrText,
            answerText = answerText
        )
        historyRepository.add(entry)
        renderHistory()
    }

    private fun renderHistory() {
        val items = historyRepository.getAll()
        binding.historyContainer.removeAllViews()
        binding.tvHistoryEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        items.forEach { entry ->
            binding.historyContainer.addView(createHistoryCard(entry))
        }
    }

    private fun createHistoryCard(entry: HistoryEntry): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = getDrawable(R.drawable.card_bg)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(8)
        }
        card.layoutParams = params

        val title = TextView(this).apply {
            text = "${formatHistoryDate(entry.timestamp)} · ${entry.source} · ${entry.questionCount} pregunta(s)"
            textSize = 13f
            textStyleBold()
        }
        val preview = TextView(this).apply {
            text = entry.ocrText.replace("\n", " ").take(120).ifBlank { "Sin texto OCR" }
            textSize = 12f
            setPadding(0, dp(4), 0, dp(2))
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
        }
        val open = Button(this).apply { text = "ABRIR" }
        val delete = Button(this).apply { text = "BORRAR" }
        row.addView(open, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(4) })
        row.addView(delete, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(4) })

        open.setOnClickListener { showHistoryEntryDialog(entry) }
        delete.setOnClickListener {
            historyRepository.delete(entry.id)
            renderHistory()
            Toast.makeText(this, "Registro borrado.", Toast.LENGTH_SHORT).show()
        }

        card.addView(title)
        card.addView(preview)
        card.addView(row)
        return card
    }

    private fun showHistoryEntryDialog(entry: HistoryEntry) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(8))
        }
        root.addView(TextView(this).apply {
            text = "${formatHistoryDate(entry.timestamp)} · ${entry.source} · ${entry.questionCount} pregunta(s)"
            textSize = 13f
            textStyleBold()
        })
        root.addView(TextView(this).apply {
            text = "Preguntas extraídas"
            textSize = 13f
            textStyleBold()
            setPadding(0, dp(10), 0, dp(4))
        })
        val ocrScroll = ScrollView(this)
        ocrScroll.addView(TextView(this).apply {
            text = entry.ocrText
            textSize = 14f
            setTextIsSelectable(true)
            setPadding(dp(10), dp(10), dp(10), dp(10))
        })
        root.addView(ocrScroll, LinearLayout.LayoutParams(-1, dp(180)))

        root.addView(TextView(this).apply {
            text = "Respuestas"
            textSize = 13f
            textStyleBold()
            setPadding(0, dp(10), 0, dp(4))
        })
        val answerScroll = ScrollView(this)
        answerScroll.addView(TextView(this).apply {
            text = entry.answerText
            textSize = 14f
            setTextIsSelectable(true)
            setPadding(dp(10), dp(10), dp(10), dp(10))
        })
        root.addView(answerScroll, LinearLayout.LayoutParams(-1, dp(240)))

        AlertDialog.Builder(this)
            .setTitle("Historial GI X")
            .setView(root)
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun confirmClearHistory() {
        if (historyRepository.getAll().isEmpty()) {
            Toast.makeText(this, "No hay historial para borrar.", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Borrar historial")
            .setMessage("¿Quieres borrar todo el historial guardado de preguntas y respuestas?")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Borrar") { _, _ ->
                historyRepository.clear()
                renderHistory()
                Toast.makeText(this, "Historial borrado.", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun formatHistoryDate(time: Long): String {
        return try {
            SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("es", "PE")).format(Date(time))
        } catch (_: Exception) {
            Date(time).toString()
        }
    }

    private fun TextView.textStyleBold() {
        setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun scrollTextToTop(view: TextView) {
        view.post {
            view.scrollTo(0, 0)
            (view.parent as? ScrollView)?.scrollTo(0, 0)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        cameraStatusTicker?.let { mainHandler.removeCallbacks(it) }
        mainHandler.removeCallbacksAndMessages(null)
        onlineProvider.cancelActiveRequest()
        cameraServer.stop()
        ocrProcessor.close()
        tts?.stop()
        tts?.shutdown()
        ioExecutor.shutdownNow()
        super.onDestroy()
    }

    private enum class InputMode {
        CAMERA,
        IMAGE
    }

    companion object {
        private const val API_BATCH_SIZE = 5
        private const val UTTERANCE_ANSWER = "gix_answer"
        private const val AUTO_NEXT_DELAY_MS = 3_500L
    }
}
