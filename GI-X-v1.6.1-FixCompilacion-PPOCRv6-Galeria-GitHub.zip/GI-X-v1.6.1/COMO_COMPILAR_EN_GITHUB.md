# Compilar GI X en GitHub

GI X incluye dos formas de compilar:

## Opción A — proyecto extraído
1. Descomprime el ZIP.
2. Sube **el contenido de la carpeta GI-X-v1.2** al repositorio.
3. En la raíz deben verse `app/`, `.github/`, `build.gradle`, `settings.gradle` y `gradle.properties`.
4. Abre **Actions → Build GI X APK → Run workflow**.
5. Descarga el artefacto **GI-X-debug-apk**.

## Opción B — repo que compila ZIPs como Geo Susu
Si tu repositorio ya tiene un workflow que compila el ZIP que subes, puedes subir este ZIP tal cual. También se incluye `.github/workflows/compilar_zip.yml` por si quieres conservar ese sistema en un repositorio ya preparado.

El APK generado se llama `app-debug.apk` dentro del artefacto `GI-X-debug-apk`.

Si GitHub da error, guarda o captura el log completo de **Compilar APK** para corregir exactamente la línea que falle.


## PP-OCRv6 Small (v1.6.1)
Los workflows ejecutan automáticamente `scripts/prepare_ppocrv6.sh` antes de Gradle. El script descarga el SDK Android oficial PaddleOCR v3.7.0 y los modelos oficiales PP-OCRv6 Small, verifica sus hashes y luego compila el APK. La primera compilación puede tardar más por la descarga de ~31 MB de modelos. No hace falta subir modelos manualmente al repositorio.
