# GI X v1.6.1

Aplicación Android personal para trabajar con una M5Stack Timer Camera X y también con imágenes elegidas manualmente desde el celular.

## Flujo principal

### Modo CÁMARA
1. Activa la Zona Wi‑Fi del celular y abre GI X.
2. Enciende la Timer Camera X con PWR.
3. El firmware preparado conecta solo a la red Wi‑Fi configurada, toma una foto, la envía a GI X y trata de apagarse automáticamente cuando trabaja con batería.
4. GI X hace OCR local mejorado, extrae la pregunta, consulta una API configurada, muestra la respuesta y la lee en voz alta.

También queda el botón **PEDIR FOTO A LA CÁMARA** para dejar una orden pendiente, útil si la cámara ya está activa o para pruebas.

### Modo IMAGEN MANUAL
1. Selecciona **IMAGEN MANUAL**.
2. Pulsa **ELEGIR IMAGEN DEL CELULAR**.
3. GI X corrige la orientación EXIF, prepara la imagen, hace OCR, consulta la API y lee la respuesta.

## OCR híbrido local v1.6.1

GI X usa dos motores OCR locales, sin Google Cloud ni cobro por página:
- **PP-OCRv6 Small (PaddleOCR 3.7.0)** como motor reforzado para texto difícil, manuscrito y documentos reales;
- **Google ML Kit Text Recognition v2** como segunda lectura y como fuente de geometría para reconstruir tablas;
- **OpenCV** para corregir perspectiva solo cuando se detecta de forma segura, medir oscuridad/desenfoque y generar una variante CLAHE para iluminación irregular.

GI X compara las lecturas, valida la numeración y puede fusionar preguntas numeradas entre ambos motores. Si PP-OCRv6 u OpenCV no inicializan por algún problema del dispositivo, ML Kit queda como respaldo y el flujo no se cae.

Los modelos PP-OCRv6 Small se incorporan al APK durante la compilación de GitHub Actions desde fuentes oficiales de PaddlePaddle. Una vez instalado el APK, el OCR funciona localmente y no necesita descargar esos modelos en cada uso.

Ningún OCR puede garantizar 0 errores. La iluminación, enfoque, distancia, inclinación y tamaño de las letras siguen importando.

## APIs

Se conserva el sistema de varias APIs de la base anterior: Gemini, OpenRouter, Mistral y Cohere. Las claves se configuran desde el botón **API** y se guardan localmente en preferencias de Android.

## Cámara

Archivo preparado: `camera_firmware/TimerCameraX_GIX.ino`

Antes de grabarlo en la Timer Camera X hay que cambiar solo:
- `WIFI_NAME`
- `WIFI_PASSWORD`
- `GIX_TOKEN`

El token debe coincidir con **GI X > CÁMARA**.

La configuración de cámara está orientada a OCR: JPEG, UXGA 1600x1200 y varias tomas descartadas al inicio para estabilizar exposición/balance de blancos antes de enviar la foto útil.

## Compilar en GitHub

El ZIP incluye `.github/workflows/build-apk.yml`.

Al subir el contenido a un repositorio GitHub en `main` o `master`, GitHub Actions intentará compilar `app-debug.apk`. También puede ejecutarse manualmente desde **Actions > Build GI X APK > Run workflow**.

El APK generado queda como artefacto llamado `GI-X-debug-apk`.

## Versión

- applicationId: `com.gix.cameraai`
- versionCode: `25`
- versionName: `1.6.1`
- minSdk: 26
- targetSdk: 34

## Cheaper Inference / DeepSeek
GI X incluye un espacio dedicado para la API pagada de Cheaper Inference, que funciona como intermediario compatible con OpenAI. Acepta claves `ir_live_...` y `ci_live_...`, usa por defecto `deepseek-v4-flash`, prueba la conexión antes de marcarla como disponible y la deja como API principal cuando funciona. Las demás APIs quedan disponibles como respaldo. La clave se guarda localmente en las preferencias privadas de la app.

## v1.2.2
Corrección de compilación en `MainActivity.kt`: parámetros de layout del `ScrollView` corregidos para Android/Kotlin. Sin cambios en el funcionamiento previsto.


## Cheaper Inference / DeepSeek (v1.2.2)

GI X trata Cheaper Inference como un intermediario compatible con OpenAI, no como la API oficial de DeepSeek.
La conexion usa `https://api.cheaperinference.com/v1/chat/completions`, `Authorization: Bearer <clave>` y el modelo predeterminado `deepseek-v4-flash`.
Se admiten claves `ir_live_...` de cuentas anteriores y claves `ci_live_...` documentadas actualmente. Al pegar una clave, GI X elimina espacios, comillas envolventes y caracteres invisibles comunes antes de guardarla y probarla.
La clave real del usuario NO esta incluida en el proyecto ni en GitHub.


## v1.2.4
- Varias preguntas en una sola foto.
- Una llamada a la API para toda la hoja.
- Respuesta con formato pregunta + respuesta.


## v1.3.0
- Vista previa se puede abrir completa.
- Cuadros OCR y Respuesta con VER TODO / OCULTAR.
- Historial local con abrir, borrar y borrar todo.
- Velocidades de voz de 0.25x a 2.00x.

## v1.3.1
- Corregido error de compilación en MainActivity.kt.
- Corregida concatenación de pregunta + respuesta.
- Corregido patrón de validación de clave del intermediario.


## v1.4.0
- OCR y Respuesta quedan en cuadros de tamaño fijo con desplazamiento interno por dedo.
- API simplificada a una sola Cheaper Inference / DeepSeek de pago.
- La clave queda guardada y el estado se muestra permanentemente en la pantalla principal.
- Eliminado el bloqueo de "EN ESPERA" del flujo principal: los errores temporales no desactivan la API.
- Hasta 3 intentos automáticos por consulta ante fallos temporales/conexión/límite transitorio.
- Tiempos de espera de red ampliados para hojas con varias preguntas.
- Mejor separación OCR de alternativas A-E, títulos y subtítulos.
- Formatos mejorados para alternativas, verdadero/falso y completar frases.


## v1.4.1
- Consulta real a DeepSeek: una sola solicitud, sin 3 envíos repetidos.
- Timeout simple: 180 s; hojas múltiples/consultas complejas: 240 s.
- Conexión: hasta 20 s.
- Eliminados mensajes antiguos de "espera" y "cambiar a otra API" en errores de red.
- La API pagada permanece guardada aunque una consulta falle por tiempo o conexión.


## v1.4.2
- Corrección crítica del validador de respuestas múltiples.
- Hojas mixtas se validan como lote completo y no como un único ejercicio.


## v1.4.5
- Cheaper Inference sigue usando la misma API Key y el mismo endpoint.
- Modelo fijo cambiado de `deepseek-v4-pro` a `deepseek-v4-flash`.
- Las configuraciones anteriores guardadas con V4 Pro se migran automáticamente a V4 Flash.
- Se conserva OCR, respuestas múltiples, historial, voz, cámara y validadores de v1.4.4.


## v1.4.9
GI X añade reconstrucción conservadora de tablas usando la geometría del OCR de ML Kit. Puede conservar encabezados, filas, columnas y celdas vacías para tablas de 2 a 6 columnas y enviar esa estructura ordenada a la IA. La mejora es general y no está limitada a una tabla específica.


## v1.5.0
- OCR reconstruido por geometría real de ML Kit: ordena arriba→abajo y une números aislados con su enunciado.
- Los números de una sola cifra ya no se eliminan antes de formar preguntas.
- Acepta numeración donde ML Kit pierde el punto, por ejemplo `4 Cuales son...`.
- Preguntas de completar con `.....`/`____` se conservan como ejercicios.
- Símbolos y datos cortos como Fe, Pb, Ag, Au, Cu, Zn, fórmulas y unidades siguen protegidos.
- Las regiones de tablas reales se retiran del texto normal antes de extraer preguntas, evitando que palabras como NAVEGADOR o REDES SOCIALES se peguen a otra pregunta.
- Tablas reales permanecen estructuradas con encabezados, filas, columnas y celdas vacías.
- Verdadero/Falso reconoce también afirmaciones que terminan en `( )`.
- Lotes normales reducidos a 3 preguntas; V/F usa hasta 5; tablas se consultan por separado.
- Más margen de tokens de salida.
- Si un lote falla o alcanza el límite de salida, GI X lo recupera pregunta por pregunta y conserva todas las respuestas que sí consiga.
- Un bloque que llega a MAX_TOKENS ya no se reintenta idéntico dos veces: se divide inmediatamente.


## v1.5.1
- Conserva siempre la numeración original del examen al enviar preguntas a DeepSeek y al mostrar respuestas.
- Reconstruye afirmaciones V/F fusionadas cuando faltan números intermedios pero los cierres `( )` permiten recuperarlas (por ejemplo 7+8+9 antes de 10).
- Si todavía queda un salto de numeración, GI X no envía una estructura corrupta a la API.
- Alternativas A/B/C/D/E ya no se descartan por parecer títulos cortos.
- Más margen de salida para DeepSeek, especialmente V/F, completar y preguntas individuales.
- Una respuesta individual completa se conserva aunque el proveedor marque `finish_reason=length`.
- Hasta 3 intentos para consultas individuales ante fallos temporales.
- Si un lote se corta, se recupera de inmediato pregunta por pregunta; el mensaje ya no promete una acción futura que no se ejecuta.
- Para completar frases, el prompt pide el término específico que encaja con la definición y los ejemplos.

## v1.5.3
- Cámara preparada específicamente para M5Stack TimerCamera-X U082-X: encender -> una foto útil -> reintento del mismo JPEG -> envío a GI X -> apagado.
- La cámara puede enviar la foto al arrancar sin necesidad de pulsar PEDIR FOTO; el botón queda disponible para pruebas/solicitudes pendientes.
- Añadida guía `camera_firmware/LEEME_PRIMERO_U082_X.txt` para facilitar la programación desde PC.
- Todas las rutas con respuestas válidas pasan por una única salida TTS: respuesta normal y respuestas parciales recuperadas también se leen.
- Las respuestas largas se trocean automáticamente por debajo del máximo de Android TTS y se reproducen en cola.
- Si la respuesta llega antes de que TTS esté listo, se guarda y se reproduce al terminar la inicialización.
- Si TTS falla durante la reproducción, GI X reinicia el motor una vez y reintenta la respuesta.
- Los mensajes técnicos de error de API no se mandan a voz; solo se leen las respuestas obtenidas.
- En modo automático, GI X no solicita el siguiente ciclo mientras haya voz pendiente o reproduciéndose.
- versionCode 22 / versionName 1.5.2.


## v1.5.3 - Respuestas por tipo de ejercicio
- Verdadero/Falso: salida mínima `N. Verdadero.` / `N. Falso.`.
- Alternativas: `N. B) texto de la opción`, sin explicación innecesaria.
- Completar frases: solo la palabra o frase exacta que falta.
- Preguntas normales: respuesta breve; se amplía solo para explicar, comparar o diferenciar.
- Preguntas sin numeración reciben las mismas reglas.
- Siglas inequívocas: se responde su expansión exacta cuando la pregunta pide su significado (ej.: EPP = Equipo de Protección Personal).
- Tablas, fórmulas, símbolos y reglas de OCR/cámara de v1.5.2 se mantienen.


## Uso rápido con TimerCamera-X
- Deja la clave de enlace por defecto: `GIX2026CAM`.
- En la cámara, normalmente solo necesitas grabar una vez tu `WIFI_NAME` y `WIFI_PASSWORD`.
- Cada encendido de la cámara toma una sola foto útil, la envía a GI-X y luego se apaga.
- Para una nueva hoja, vuelve a encender la cámara.


## v1.6.1 - OCR local reforzado + Galería
- Integra **PP-OCRv6 Small** mediante el SDK Android oficial de PaddleOCR 3.7.0/ONNX Runtime.
- Mantiene ML Kit como segundo motor y respaldo automático.
- OpenCV realiza preprocesado conservador: perspectiva solo con un contorno de página confiable, CLAHE y señales de calidad.
- Fusiona lecturas por numeración cuando ambos motores aportan partes útiles y conserva la estructura de tablas de ML Kit.
- Cada JPEG único recibido desde la TimerCamera-X se guarda automáticamente en **Galería > Pictures > GI-X** antes del OCR.
- Los reintentos del mismo JPEG no crean duplicados ni repiten OCR/API/voz.
- Si llega una nueva foto mientras GI X todavía procesa o habla, se guarda y queda en una cola corta para procesarla al terminar.
- Una foto física de la TimerCamera activa automáticamente el modo CÁMARA, aunque la pantalla hubiese quedado en modo manual.
- Se conserva el protocolo ya grabado en la TimerCamera-X: puerto `8765` y token `GIX2026CAM`; no hace falta volver a programar la cámara por esta actualización.
- `minSdk` pasa a 26 porque es el mínimo del SDK Android oficial PP-OCRv6.


## v1.6.1 - Corrección de compilación PaddleOCR
- El SDK oficial PP-OCRv6 ya no se agrega como subproyecto Gradle `:ppocr-sdk`.
- GitHub Actions copia sus fuentes directamente a `:app` antes de compilar.
- Esto elimina el error `Could not resolve project :ppocr-sdk / None of the consumable configurations have attributes`.
- Se mantienen PP-OCRv6 Small, ML Kit, OpenCV, guardado en Galería y deduplicación de fotos.
