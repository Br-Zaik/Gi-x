package com.gix.cameraai

import android.graphics.Bitmap
import android.util.Log
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.core.MatOfDouble
import org.opencv.core.Point
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Preprocesado conservador de documentos para GI-X.
 *
 * - Solo corrige perspectiva cuando encuentra un cuadrilátero grande y claro que
 *   cubre la mayor parte de la imagen (evita recortar una tabla o un cuadro interno).
 * - Genera una variante CLAHE para iluminación desigual sin destruir el color de
 *   la imagen original; PP-OCRv6 siempre prueba primero la imagen a color.
 * - Calcula señales de oscuridad/desenfoque para decidir cuándo vale la pena una
 *   segunda pasada, pero nunca bloquea una foto solo por una métrica imperfecta.
 */
object OpenCvDocumentPreprocessor {

    data class Quality(
        val brightness: Double,
        val contrast: Double,
        val sharpness: Double,
    ) {
        val looksDark: Boolean get() = brightness < 52.0
        val looksLowContrast: Boolean get() = contrast < 28.0
        val looksBlurry: Boolean get() = sharpness < 55.0
        val needsExtraPass: Boolean get() = looksDark || looksLowContrast || looksBlurry
    }

    fun correctPerspectiveIfSafe(source: Bitmap): Bitmap? {
        val rgba = Mat()
        val gray = Mat()
        val blurred = Mat()
        val edges = Mat()
        val hierarchy = Mat()
        val contours = mutableListOf<MatOfPoint>()
        try {
            Utils.bitmapToMat(source, rgba)
            Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
            Imgproc.GaussianBlur(gray, blurred, Size(5.0, 5.0), 0.0)
            Imgproc.Canny(blurred, edges, 60.0, 180.0)
            Imgproc.findContours(edges, contours, hierarchy, Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE)

            val imageArea = source.width.toDouble() * source.height.toDouble()
            var best: Array<Point>? = null
            var bestArea = 0.0

            for (contour in contours) {
                val area = Imgproc.contourArea(contour)
                if (area < imageArea * 0.55 || area <= bestArea) continue
                val curve = MatOfPoint2f(*contour.toArray())
                val approx = MatOfPoint2f()
                try {
                    val perimeter = Imgproc.arcLength(curve, true)
                    Imgproc.approxPolyDP(curve, approx, 0.02 * perimeter, true)
                    if (approx.total() == 4L) {
                        val approxInt = MatOfPoint(*approx.toArray())
                        try {
                            if (Imgproc.isContourConvex(approxInt)) {
                                best = approx.toArray()
                                bestArea = area
                            }
                        } finally {
                            approxInt.release()
                        }
                    }
                } finally {
                    curve.release()
                    approx.release()
                }
            }

            val points = best ?: return null
            val ordered = orderPoints(points)
            val tl = ordered[0]
            val tr = ordered[1]
            val br = ordered[2]
            val bl = ordered[3]

            val widthTop = distance(tl, tr)
            val widthBottom = distance(bl, br)
            val heightLeft = distance(tl, bl)
            val heightRight = distance(tr, br)
            val targetW = max(widthTop, widthBottom).toInt().coerceAtLeast(1)
            val targetH = max(heightLeft, heightRight).toInt().coerceAtLeast(1)

            // Evita transformaciones extremas o falsos positivos.
            if (targetW < source.width * 0.45 || targetH < source.height * 0.45) return null
            val originalRatio = source.width.toDouble() / source.height.toDouble()
            val targetRatio = targetW.toDouble() / targetH.toDouble()
            val ratioChange = max(originalRatio / targetRatio, targetRatio / originalRatio)
            if (ratioChange > 1.75) return null

            val srcPoints = MatOfPoint2f(tl, tr, br, bl)
            val dstPoints = MatOfPoint2f(
                Point(0.0, 0.0),
                Point((targetW - 1).toDouble(), 0.0),
                Point((targetW - 1).toDouble(), (targetH - 1).toDouble()),
                Point(0.0, (targetH - 1).toDouble()),
            )
            val transform = Imgproc.getPerspectiveTransform(srcPoints, dstPoints)
            val warped = Mat()
            try {
                Imgproc.warpPerspective(
                    rgba,
                    warped,
                    transform,
                    Size(targetW.toDouble(), targetH.toDouble()),
                    Imgproc.INTER_CUBIC,
                )
                val output = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
                Utils.matToBitmap(warped, output)
                return output
            } finally {
                srcPoints.release()
                dstPoints.release()
                transform.release()
                warped.release()
            }
        } catch (t: Throwable) {
            Log.w("GIX-OCR", "Perspective correction skipped: ${t.message}")
            return null
        } finally {
            contours.forEach { it.release() }
            rgba.release()
            gray.release()
            blurred.release()
            edges.release()
            hierarchy.release()
        }
    }

    fun enhanceForText(source: Bitmap): Bitmap? {
        val rgba = Mat()
        val gray = Mat()
        val enhanced = Mat()
        val out = Mat()
        return try {
            Utils.bitmapToMat(source, rgba)
            Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
            val clahe = Imgproc.createCLAHE(2.2, Size(8.0, 8.0))
            try {
                clahe.apply(gray, enhanced)
            } finally {
                clahe.collectGarbage()
            }
            Imgproc.cvtColor(enhanced, out, Imgproc.COLOR_GRAY2RGBA)
            Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888).also {
                Utils.matToBitmap(out, it)
            }
        } catch (t: Throwable) {
            Log.w("GIX-OCR", "OpenCV enhancement skipped: ${t.message}")
            null
        } finally {
            rgba.release()
            gray.release()
            enhanced.release()
            out.release()
        }
    }

    fun quality(source: Bitmap): Quality {
        val rgba = Mat()
        val gray = Mat()
        val laplacian = Mat()
        val mean = MatOfDouble()
        val stddev = MatOfDouble()
        return try {
            Utils.bitmapToMat(source, rgba)
            Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
            val brightness = Core.mean(gray).`val`[0]
            Core.meanStdDev(gray, mean, stddev)
            val contrast = stddev.toArray().firstOrNull() ?: 0.0

            Imgproc.Laplacian(gray, laplacian, CvType.CV_64F)
            val lapMean = MatOfDouble()
            val lapStd = MatOfDouble()
            try {
                Core.meanStdDev(laplacian, lapMean, lapStd)
                val sigma = lapStd.toArray().firstOrNull() ?: 0.0
                Quality(brightness, contrast, sigma.pow(2))
            } finally {
                lapMean.release()
                lapStd.release()
            }
        } catch (_: Throwable) {
            Quality(128.0, 64.0, 100.0)
        } finally {
            rgba.release()
            gray.release()
            laplacian.release()
            mean.release()
            stddev.release()
        }
    }

    private fun orderPoints(points: Array<Point>): Array<Point> {
        val topLeft = points.minByOrNull { it.x + it.y } ?: points[0]
        val bottomRight = points.maxByOrNull { it.x + it.y } ?: points[2]
        val topRight = points.maxByOrNull { it.x - it.y } ?: points[1]
        val bottomLeft = points.minByOrNull { it.x - it.y } ?: points[3]
        return arrayOf(topLeft, topRight, bottomRight, bottomLeft)
    }

    private fun distance(a: Point, b: Point): Double {
        return sqrt((a.x - b.x).pow(2) + (a.y - b.y).pow(2))
    }
}
