package com.gix.cameraai

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.gix.cameraai.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener, CameraBridgeServer.Listener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: AppPrefs
    private lateinit var apiSettings: GeminiSettings
    private lateinit var onlineProvider: OnlineAnswerProvider
    private lateinit var cameraServer: CameraBridgeServer
    private lateinit var historyRepository: HistoryRepository
    private lateinit var ocrProcessor: OcrProcessor
    private val ioExecutor = Executors.newSingleThreadExecutor()
    private val cameraIoExecutor = Executors.newSingleThreadExecutor()
    private val recentPhotoDeduper = RecentPhotoDeduper()
    private val pendingCameraPhotos = ArrayDeque<QueuedCameraPhoto>()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val processing = AtomicBoolean(false)

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsInitializing = false
    private var pendingSpeechText: String? = null
    private var activeSpeechText: String? = null
    private var activeSpeechFinalId: String? = null
    private var speechRetryCount = 0
    private var speechSessionId = 0L
    private var speechRecoveryInProgress = false
    private var isSpeakingAnswer = false
    private var autoMode = false
    private var stopped = false
    private var inputMode = InputMode.CAMERA
    private var activeCaptureRequestId: String? = null
    private var cameraStatusTicker: Runnable? = null
    private var lastExtractedQuestions: List<String> = emptyList()
    private var previewBitmap: Bitmap? = null
    private var lastDisplayedOcrText: String = ""
    private var lastSourceLabel: String = "desconocido"

    private data class QueuedCameraPhoto(
        val jpeg: ByteArray,
        val source: String,
    )

    private val openPhotoLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) loadPhotoFromUri(uri)
    }

    private val legacyGalleryPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (::binding.isInitialized && !granted) {
            binding.tvStatus.text = "GI X seguirá funcionando, pero Android no permitió guardar fotos en Galería."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = AppPrefs(this)
        apiSettings = GeminiSettings(this)
        onlineProvider = OnlineAnswerProvider(this)
        historyRepository = HistoryRepository(this)
        ocrProcessor = OcrProcessor(this)
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            legacyGalleryPermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        ttsInitializing = true
        tts = TextToSpeech(this, this)

        // Limpia estados antiguos de "espera" de la API pagada sin borrar la clave.
        apiSettings.getApiConfigs()
            .filter { it.provider == NetProvider.CHEAPER_INFERENCE }
            .forEach { apiSettings.shouldSkip(it) }

        setupButtons()
        setupInternalScroll(binding.svOcr)
        setupInternalScroll(binding.svAnswer)
        renderHistory()
        updateApiChip()
        startCameraServer()
        startCameraStatusTicker()
    }

    private fun setupButtons() {
        binding.inputModeGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            when (checkedId) {
                R.id.btnModeCamera -> setInputMode(InputMode.CAMERA)
                R.id.btnModeImage -> setInputMode(InputMode.IMAGE)
            }
        }
        binding.inputModeGroup.check(R.id.btnModeCamera)

        binding.btnCapture.setOnClickListener {
            stopped = false
            requestCameraCapture(manual = true)
        }

        binding.btnAuto.setOnClickListener {
            if (inputMode != InputMode.CAMERA) {
                binding.tvStatus.text = "El modo AUTO funciona con la cámara. Cambia a CÁMARA."
                return@setOnClickListener
            }
            autoMode = !autoMode
            stopped = false
            binding.btnAuto.text = if (autoMode) "AUTO: ON" else "AUTO: OFF"
            if (autoMode) {
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                binding.tvStatus.text = "AUTO activo: GI X quedará listo para recibir la cámara. Cada encendido enviará 1 foto → OCR → API → voz."
                requestCameraCapture(manual = false)
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                binding.tvStatus.text = "AUTO detenido. Cuando quieras otra foto, vuelve a encender la cámara."
            }
        }

        binding.btnStop.setOnClickListener { stopCurrentCycle() }

        binding.btnChooseImage.setOnClickListener {
            stopped = false
            openPhotoLauncher.launch(arrayOf("image/*"))
        }

        binding.btnApi.setOnClickListener { showApiDialog() }
        binding.btnVoice.setOnClickListener { showVoiceDialog() }
        binding.btnCameraSettings.setOnClickListener { showCameraDialog() }
        binding.btnOpenPreview.setOnClickListener { showPreviewDialog() }
        binding.btnClearHistory.setOnClickListener { confirmClearHistory() }
    }

    private fun setInputMode(mode: InputMode) {
        if (inputMode == mode && binding.cameraActions.visibility == if (mode == InputMode.CAMERA) View.VISIBLE else View.GONE) {
            return
        }
        inputMode = mode
        when (mode) {
            InputMode.CAMERA -> {
                binding.cameraActions.visibility = View.VISIBLE
                binding.btnChooseImage.visibility = View.GONE
                binding.tvStatus.text = "Modo CÁMARA. Activa tu Zona Wi-Fi y deja GI X abierto. Cada vez que enciendas la Timer Camera X, enviará una sola foto automáticamente."
            }
            InputMode.IMAGE -> {
                autoMode = false
                binding.btnAuto.text = "AUTO: OFF"
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                cameraServer.cancelCapture()
                activeCaptureRequestId = null
                binding.cameraActions.visibility = View.GONE
                binding.btnChooseImage.visibility = View.VISIBLE
                binding.tvStatus.text = "Modo IMAGEN MANUAL. Pulsa ELEGIR IMAGEN y GI X hará OCR → API → voz."
            }
        }
    }

    private fun startCameraServer() {
        cameraServer = CameraBridgeServer(
            CameraBridgeServer.DEFAULT_PORT,
            tokenProvider = { prefs.pairingToken },
            listener = this
        )
        cameraServer.start()
    }

    private fun startCameraStatusTicker() {
        val ticker = object : Runnable {
            override fun run() {
                updateCameraChip()
                mainHandler.postDelayed(this, 2_000L)
            }
        }
        cameraStatusTicker = ticker
        mainHandler.post(ticker)
    }

    private fun requestCameraCapture(manual: Boolean) {
        if (processing.get()) {
            binding.tvStatus.text = "Espera: GI X todavía está procesando la foto anterior."
            return
        }
        if (activeCaptureRequestId != null) {
            binding.tvStatus.text = "Ya hay una foto solicitada. Esperando a la cámara..."
            return
        }

        val requestId = cameraServer.requestCapture()
        activeCaptureRequestId = requestId
        binding.tvStatus.text = if (cameraServer.isCameraConnected()) {
            "Orden enviada. Esperando la foto de Timer Camera X..."
        } else {
            "Orden preparada. Enciende la cámara y verifica que esté conectada a tu Zona Wi-Fi."
        }

        mainHandler.postDelayed({
            if (activeCaptureRequestId == requestId) {
                cameraServer.cancelCapture()
                activeCaptureRequestId = null
                if (!processing.get()) {
                    binding.tvStatus.text = if (manual) {
                        "La cámara no respondió. Revisa Zona Wi-Fi, cámara y clave de enlace."
                    } else {
                        "Auto: cámara sin respuesta. Reintentaré cuando vuelva a estar disponible."
                    }
                }
            }
        }, 25_000L)
    }

    private fun stopCurrentCycle() {
        stopped = true
        autoMode = false
        binding.btnAuto.text = "AUTO: OFF"
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        cameraServer.cancelCapture()
        activeCaptureRequestId = null
        onlineProvider.cancelActiveRequest()
        tts?.stop()
        pendingSpeechText = null
        activeSpeechText = null
        activeSpeechFinalId = null
        isSpeakingAnswer = false
        speechRetryCount = 0
        speechRecoveryInProgress = false
        ttsInitializing = false
        processing.set(false)
        binding.tvStatus.text = if (inputMode == InputMode.CAMERA) {
            "Detenido. Vuelve a encender la cámara cuando quieras otra foto."
        } else {
            "Detenido. Pulsa ELEGIR IMAGEN cuando quieras continuar."
        }
    }

    override fun onServerStarted(port: Int) {
        runOnUiThread {
            if (inputMode == InputMode.CAMERA) {
                binding.tvStatus.text = "GI X listo. Activa tu Zona Wi-Fi y enciende la cámara; recibirá la foto por el puerto $port."
            }
        }
    }

    override fun onServerError(message: String) {
        runOnUiThread {
            binding.tvStatus.text = "Error del enlace con cámara: $message"
            binding.tvCameraChip.text = "Cámara: error"
        }
    }

    override fun onCameraSeen() {
        runOnUiThread { updateCameraChip() }
    }

    override fun onPhotoReceived(jpeg: ByteArray, requestId: String?) {
        activeCaptureRequestId = null

        // La cámara reintenta el MISMO JPEG si la red falla. Lo confirmamos al servidor,
        // pero no lo guardamos dos veces ni repetimos OCR/API/voz.
        if (recentPhotoDeduper.isDuplicate(jpeg)) {
            runOnUiThread {
                binding.tvStatus.text = "La cámara reenvió la misma foto. GI X evitó procesarla dos veces."
            }
            return
        }

        cameraIoExecutor.execute {
            val saved = CameraPhotoStore.save(this, jpeg)
            val bitmap = BitmapFactory.decodeByteArray(
                jpeg,
                0,
                jpeg.size,
                BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 },
            )

            runOnUiThread {
                if (bitmap == null) {
                    binding.tvStatus.text = "La cámara envió una imagen que Android no pudo abrir."
                    return@runOnUiThread
                }

                // Una foto física de la TimerCamera siempre tiene prioridad y activa el
                // modo CÁMARA aunque el usuario hubiera dejado la pantalla en MANUAL.
                if (inputMode != InputMode.CAMERA) {
                    binding.inputModeGroup.check(R.id.btnModeCamera)
                }

                val source = if (saved.saved) {
                    "cámara · guardada en Galería"
                } else {
                    "cámara"
                }

                if (processing.get() || isSpeakingAnswer || !pendingSpeechText.isNullOrBlank()) {
                    // Guardamos el JPEG comprimido, no el Bitmap completo: así la cola
                    // puede esperar varias fotos sin consumir decenas de MB de RAM.
                    if (!bitmap.isRecycled) bitmap.recycle()
                    while (pendingCameraPhotos.size >= MAX_PENDING_CAMERA_PHOTOS) {
                        pendingCameraPhotos.pollFirst()
                    }
                    pendingCameraPhotos.addLast(QueuedCameraPhoto(jpeg.copyOf(), source))
                    binding.tvStatus.text = if (saved.saved) {
                        "Foto guardada en ${saved.displayPath}. GI X la procesará al terminar la respuesta actual."
                    } else {
                        "Foto recibida. GI X la procesará al terminar la respuesta actual."
                    }
                    return@runOnUiThread
                }

                processBitmap(bitmap, source = source)
            }
        }
    }

    private fun loadPhotoFromUri(uri: Uri) {
        binding.tvStatus.text = "Abriendo imagen y corrigiendo orientación..."
        ioExecutor.execute {
            val bitmap = runCatching { ImageLoader.load(this, uri) }.getOrNull()
            runOnUiThread {
                if (bitmap == null) {
                    binding.tvStatus.text = "No pude abrir esa imagen. Prueba con JPG, PNG, WEBP o una foto normal."
                    return@runOnUiThread
                }
                processBitmap(bitmap, source = "imagen manual")
            }
        }
    }

    private fun processBitmap(bitmap: Bitmap, source: String) {
        if (!processing.compareAndSet(false, true)) {
            binding.tvStatus.text = "Ya estoy procesando otra foto."
            return
        }
        stopped = false
        lastExtractedQuestions = emptyList()
        lastDisplayedOcrText = ""
        lastSourceLabel = source
        previewBitmap = bitmap
        binding.ivPreview.setImageBitmap(bitmap)
        binding.tvPreviewPlaceholder.visibility = View.GONE
        binding.tvStatus.text = "Imagen recibida ($source). OCR local reforzado: PP-OCRv6 + ML Kit..."
        binding.tvOcr.text = "Procesando OCR..."
        binding.tvAnswer.text = "Esperando texto..."

        ocrProcessor.process(
            bitmap,
            onSuccess = { rawText ->
                runOnUiThread { handleOcrResult(rawText) }
            },
            onError = { error ->
                runOnUiThread {
                    processing.set(false)
                    binding.tvStatus.text = "OCR falló: $error"
                    binding.tvOcr.text = "No se pudo detectar texto."
                    binding.tvAnswer.text = "Acerca la cámara, mejora la luz y vuelve a intentarlo."
                    scheduleNextAutoIfNeeded()
                }
            }
        )
    }

    private fun handleOcrResult(rawText: String) {
        if (stopped) {
            processing.set(false)
            return
        }
        val cleanRaw = rawText.trim()
        if (cleanRaw.isBlank()) {
            processing.set(false)
            binding.tvStatus.text = "OCR terminado, pero no encontró texto legible."
            binding.tvOcr.text = "Sin texto detectado."
            binding.tvAnswer.text = "Prueba con más luz, menos inclinación y enfoca mejor la pregunta."
            scheduleNextAutoIfNeeded()
            return
        }

        val questions = OcrQuestionExtractor.extractQuestions(cleanRaw)
        lastExtractedQuestions = questions
        val extractedText = if (questions.isNotEmpty()) {
            questions.joinToString("\n\n")
        } else {
            OcrQuestionExtractor.extract(cleanRaw).ifBlank { cleanRaw.take(2600) }
        }
        lastDisplayedOcrText = extractedText
        binding.tvOcr.text = extractedText
        scrollTextToTop(binding.tvOcr)

        if (questions.isEmpty()) {
            processing.set(false)
            binding.tvStatus.text = "Se leyó texto, pero no pude identificar preguntas claras."
            binding.tvAnswer.text = "Centra mejor el texto y vuelve a intentarlo."
            scheduleNextAutoIfNeeded()
            return
        }

        // Barrera de seguridad: si una hoja numerada todavía tiene saltos, duplicados
        // o números fuera de orden, no enviamos una estructura corrupta a DeepSeek.
        // Es preferible pedir otra lectura a responder 18 preguntas como si fueran 20.
        if (OcrQuestionExtractor.hasSuspiciousNumbering(questions)) {
            processing.set(false)
            binding.tvStatus.text = "La numeración del examen quedó incompleta. No se envió una hoja mal reconstruida a la API."
            binding.tvAnswer.text = "GI X detectó un salto en la numeración. Vuelve a procesar la misma imagen; si persiste, mejora ligeramente el encuadre o la nitidez."
            scrollTextToTop(binding.tvAnswer)
            scheduleNextAutoIfNeeded()
            return
        }

        val batches = buildApiBatches(questions)
        binding.tvStatus.text = if (questions.size == 1) {
            "Pregunta detectada. Consultando la API..."
        } else if (batches.size == 1) {
            "${questions.size} preguntas detectadas. Consultando la API..."
        } else {
            "${questions.size} preguntas detectadas. Se resolverán en ${batches.size} bloques seguros."
        }
        binding.tvAnswer.text = "Consultando IA..."
        ioExecutor.execute {
            val completed = mutableListOf<String>()
            val failedNumbers = mutableListOf<Int>()
            val failureDetails = mutableListOf<String>()
            var completedQuestions = 0
            var globalOffset = 0

            for ((batchIndex, batch) in batches.withIndex()) {
                if (stopped) {
                    processing.set(false)
                    return@execute
                }

                if (batches.size > 1) {
                    mainHandler.post {
                        if (!stopped) {
                            binding.tvStatus.text = "Consultando IA: bloque ${batchIndex + 1} de ${batches.size}..."
                        }
                    }
                }

                val payload = OcrQuestionExtractor.buildQueryPayload(batch, forceBatch = batch.size > 1)
                val answer = onlineProvider.fetchShortAnswer(payload).trim()

                if (!answer.startsWith(OnlineAnswerProvider.API_ERROR_PREFIX)) {
                    // Si las preguntas ya traen numeración impresa (11,12,...), la
                    // conservamos exactamente. Solo renumeramos lotes de preguntas
                    // realmente sin número para evitar IDs locales repetidos.
                    completed += normalizeBatchAnswerNumbers(answer, batch, globalOffset)
                    completedQuestions += batch.size
                    globalOffset += batch.size
                    continue
                }

                // Si un lote fue rechazado, quedó incompleto o alcanzó MAX_TOKENS,
                // no perdemos el examen: recuperamos ese lote pregunta por pregunta.
                // Esto también evita que un fallo de una sola pregunta borre respuestas
                // de otros bloques.
                if (batch.size > 1) {
                    for ((localIndex, question) in batch.withIndex()) {
                        if (stopped) {
                            processing.set(false)
                            return@execute
                        }
                        val globalNumber = OcrQuestionExtractor.questionNumber(question)
                            ?: (globalOffset + localIndex + 1)
                        mainHandler.post {
                            if (!stopped) {
                                binding.tvStatus.text = "Recuperando pregunta $globalNumber de ${questions.size}..."
                            }
                        }

                        val singlePayload = OcrQuestionExtractor.buildQueryPayload(listOf(question), forceBatch = false)
                        val singleAnswer = onlineProvider.fetchShortAnswer(singlePayload).trim()
                        if (singleAnswer.startsWith(OnlineAnswerProvider.API_ERROR_PREFIX)) {
                            failedNumbers += globalNumber
                            failureDetails += singleAnswer
                                .removePrefix(OnlineAnswerProvider.API_ERROR_PREFIX)
                                .trim()
                                .ifBlank { "La API no devolvió una respuesta válida." }
                        } else {
                            completed += formatRecoveredSingleAnswer(globalNumber, question, singleAnswer)
                            completedQuestions += 1
                        }
                    }
                } else {
                    val globalNumber = OcrQuestionExtractor.questionNumber(batch.first())
                        ?: (globalOffset + 1)
                    failedNumbers += globalNumber
                    failureDetails += answer
                        .removePrefix(OnlineAnswerProvider.API_ERROR_PREFIX)
                        .trim()
                        .ifBlank { "La API no devolvió una respuesta válida." }
                }

                globalOffset += batch.size
            }

            runOnUiThread {
                if (stopped) {
                    processing.set(false)
                    return@runOnUiThread
                }
                val finalText = completed.joinToString("\n\n").trim()
                if (failedNumbers.isNotEmpty()) {
                    handleRecoveredApiFailure(
                        partial = finalText,
                        completed = completedQuestions,
                        total = questions.size,
                        failedNumbers = failedNumbers,
                        details = failureDetails
                    )
                } else {
                    handleAnswer(finalText)
                }
            }
        }
    }

    private fun buildApiBatches(questions: List<String>): List<List<String>> {
        if (questions.isEmpty()) return emptyList()
        val batchLimit = if (OcrQuestionExtractor.isLikelyTrueFalseQuestions(questions)) {
            TRUE_FALSE_API_BATCH_SIZE
        } else {
            STANDARD_API_BATCH_SIZE
        }

        val output = mutableListOf<List<String>>()
        val pending = mutableListOf<String>()
        fun flushPending() {
            if (pending.isNotEmpty()) {
                output += pending.toList()
                pending.clear()
            }
        }

        questions.forEach { question ->
            // Una tabla puede necesitar una respuesta por fila. La aislamos para que no
            // compita por tokens con otras preguntas del examen.
            if (question.contains(OcrTableFormatter.TABLE_START)) {
                flushPending()
                output += listOf(question)
            } else {
                pending += question
                if (pending.size >= batchLimit) flushPending()
            }
        }
        flushPending()
        return output
    }

    private fun formatRecoveredSingleAnswer(number: Int, question: String, answer: String): String {
        val clean = answer
            .replace(Regex("^\\s*(?:Pregunta\\s+)?\\d{1,2}\\s*[\\.):\\-]\\s*", RegexOption.IGNORE_CASE), "")
            .trim()
        val canonical = OnlineAnswerProvider.canonicalizeAnswerForQuestion(question, clean).trim()
        val normalizedQuestion = ResponseRepository.normalize(question)
        val rawLower = question.lowercase()
        val isTrueFalse = normalizedQuestion.contains("verdadero o falso") ||
            normalizedQuestion.contains("verdadero falso") || rawLower.contains("v/f") ||
            Regex("\\(\\s*\\)\\s*[.?!]*\\s*$").containsMatchIn(question.trim())
        val isMultipleChoice = Regex("(?i)(?:^|\\s)[A-H][\\)\\].:-]\\s+").findAll(question).count() >= 2 ||
            normalizedQuestion.contains("cual de los siguientes") ||
            normalizedQuestion.contains("cual de las siguientes") ||
            normalizedQuestion.contains("alternativa correcta") ||
            normalizedQuestion.contains("opcion correcta")
        val isCompletion = VoiceQuestionNormalizer.isCompletionExercise(question) ||
            question.contains("___") || question.contains(".....")

        return when {
            isTrueFalse -> "$number. ${canonical.removeSuffix(".")}."
            isMultipleChoice -> "$number. $canonical"
            isCompletion -> "$number. $canonical"
            '\n' in canonical -> "$number. Respuesta:\n$canonical"
            else -> "$number. Respuesta: $canonical"
        }
    }

    private fun handleRecoveredApiFailure(
        partial: String,
        completed: Int,
        total: Int,
        failedNumbers: List<Int>,
        details: List<String>
    ) {
        processing.set(false)
        val uniqueDetail = details.firstOrNull().orEmpty()
        val visible = buildString {
            if (partial.isNotBlank()) {
                append(partial.trim())
                append("\n\n")
            }
            append("Se respondieron $completed de $total preguntas.")
            if (failedNumbers.isNotEmpty()) {
                append(" Faltaron: ")
                append(failedNumbers.distinct().sorted().joinToString(", "))
                append(".")
            }
            if (uniqueDetail.isNotBlank()) {
                append("\n")
                append(uniqueDetail)
            }
        }
        binding.tvAnswer.text = visible
        scrollTextToTop(binding.tvAnswer)
        saveToHistory(visible)
        updateApiChip()
        binding.tvStatus.text = if (completed > 0) {
            "La API respondió parcialmente; GI X conservó todas las respuestas obtenidas."
        } else {
            "La API no respondió esta vez. El OCR y las preguntas se conservaron."
        }
        if (partial.isNotBlank()) {
            requestAnswerSpeech(partial)
        } else {
            scheduleNextAutoIfNeeded()
        }
    }

    private fun normalizeBatchAnswerNumbers(
        answer: String,
        batch: List<String>,
        globalOffset: Int
    ): String {
        val printedNumbers = batch.map { OcrQuestionExtractor.questionNumber(it) }
        // Si existe numeración real, el payload ya la conserva y no debemos tocarla.
        if (printedNumbers.any { it != null }) return answer.trim()

        // Preguntas sin numeración: el proveedor responde 1..N dentro de cada lote.
        // Aquí las convertimos a una secuencia global solo para que la pantalla no
        // muestre 1,2,3 otra vez en el siguiente lote.
        if (globalOffset <= 0) return answer.trim()
        val numberedLine = Regex("^(\\s*)(?:(Pregunta)\\s+)?(\\d{1,2})([\\.):])\\s*(.*)$", RegexOption.IGNORE_CASE)
        return answer.lines().joinToString("\n") { line ->
            val match = numberedLine.find(line) ?: return@joinToString line
            val prefix = match.groupValues[1]
            val questionWord = match.groupValues[2]
            val localNumber = match.groupValues[3].toIntOrNull() ?: return@joinToString line
            val separator = match.groupValues[4]
            val tail = match.groupValues[5]
            val globalNumber = localNumber + globalOffset
            if (questionWord.isNotBlank()) {
                "$prefix$questionWord $globalNumber$separator $tail".trimEnd()
            } else {
                "$prefix$globalNumber$separator $tail".trimEnd()
            }
        }.trim()
    }

    private fun handleChunkedApiFailure(partial: String, rawError: String, completed: Int, total: Int) {
        processing.set(false)
        val error = rawError.removePrefix(OnlineAnswerProvider.API_ERROR_PREFIX).trim()
        val visible = buildString {
            if (partial.isNotBlank()) {
                append(partial.trim())
                append("\n\n")
            }
            append("No se pudieron completar las preguntas restantes ($completed de $total respondidas).\n")
            append(error.ifBlank { "La API no devolvió una respuesta válida." })
        }
        binding.tvAnswer.text = visible
        scrollTextToTop(binding.tvAnswer)
        saveToHistory(visible)
        updateApiChip()
        binding.tvStatus.text = "La API no completó todos los bloques. Las respuestas ya recibidas se conservaron."
        if (partial.isNotBlank()) {
            requestAnswerSpeech(partial)
        } else {
            scheduleNextAutoIfNeeded()
        }
    }

    private fun handleAnswer(answer: String) {
        processing.set(false)
        val clean = answer.trim().ifBlank { "La API no devolvió una respuesta." }
        val displayText = when {
            lastExtractedQuestions.size == 1 && !clean.contains("Respuesta:", ignoreCase = true) -> {
                "${lastExtractedQuestions.first()}\nRespuesta: $clean"
            }
            else -> clean
        }
        val apiError = clean.startsWith(OnlineAnswerProvider.API_ERROR_PREFIX)
        val visibleText = if (apiError) clean.removePrefix(OnlineAnswerProvider.API_ERROR_PREFIX).trim() else displayText
        binding.tvAnswer.text = visibleText
        scrollTextToTop(binding.tvAnswer)
        saveToHistory(visibleText)
        updateApiChip()

        if (apiError) {
            binding.tvStatus.text = "La API no respondió correctamente. Revisa el detalle abajo."
            scheduleNextAutoIfNeeded()
            return
        }

        requestAnswerSpeech(displayText)
    }

    /**
     * Punto único de salida de voz de GI X. Toda respuesta válida (normal o recuperada)
     * pasa por aquí, para que no existan rutas que muestren texto pero olviden hablar.
     */
    private fun requestAnswerSpeech(text: String) {
        val spokenText = prepareSpokenAnswer(text)
        if (spokenText.isBlank()) {
            binding.tvStatus.text = "Respuesta lista."
            scheduleNextAutoIfNeeded()
            return
        }

        speechRetryCount = 0
        speechRecoveryInProgress = false
        activeSpeechText = spokenText
        pendingSpeechText = spokenText
        binding.tvStatus.text = if (ttsReady) {
            "Respuesta lista. Reproduciendo voz..."
        } else {
            "Respuesta lista. Preparando voz..."
        }

        if (ttsReady) {
            startPendingSpeech()
        } else if (!ttsInitializing) {
            // Si el motor ya había fallado antes de recibir esta respuesta, no dejamos
            // el texto esperando indefinidamente: iniciamos una nueva instancia ahora.
            ttsInitializing = true
            reinitializeTts()
        }
    }

    private fun prepareSpokenAnswer(text: String): String {
        val withoutInternalMarkers = text.lineSequence()
            .filterNot { line ->
                val trimmed = line.trim()
                trimmed.startsWith("[GIX_", ignoreCase = true) ||
                    trimmed.startsWith("Columnas:", ignoreCase = true) ||
                    trimmed.startsWith("Fila ", ignoreCase = true)
            }
            .joinToString("\n")
            .replace("|", ", ")
        return VoiceQuestionNormalizer.prepareForTts(withoutInternalMarkers).trim()
    }

    private fun startPendingSpeech() {
        if (!ttsReady || stopped) return
        val text = pendingSpeechText?.trim().orEmpty()
        if (text.isBlank()) return

        val engine = tts ?: run {
            handleSpeechFailure()
            return
        }
        val chunks = splitForTts(text)
        if (chunks.isEmpty()) {
            pendingSpeechText = null
            activeSpeechText = null
            binding.tvStatus.text = "Respuesta lista."
            scheduleNextAutoIfNeeded()
            return
        }

        engine.stop()
        engine.setSpeechRate(prefs.speechRate)
        speechSessionId += 1
        val session = speechSessionId
        activeSpeechText = text
        pendingSpeechText = null
        isSpeakingAnswer = true
        activeSpeechFinalId = "${UTTERANCE_ANSWER}_${session}_${chunks.lastIndex}"
        binding.tvStatus.text = "Respuesta lista. Reproduciendo voz..."

        for ((index, chunk) in chunks.withIndex()) {
            val utteranceId = "${UTTERANCE_ANSWER}_${session}_${index}"
            val queueMode = if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            val result = engine.speak(chunk, queueMode, null, utteranceId)
            if (result == TextToSpeech.ERROR) {
                handleSpeechFailure()
                return
            }
        }
    }

    private fun splitForTts(text: String): List<String> {
        val platformMax = runCatching { TextToSpeech.getMaxSpeechInputLength() }.getOrDefault(4000)
        // Dejamos margen respecto al máximo del motor. 3000 también evita problemas
        // de motores que anuncian un límite mayor pero fallan con textos muy largos.
        val maxChars = minOf((platformMax - 200).coerceAtLeast(500), 3000)
        val pieces = text
            .replace("\r", "")
            .split(Regex("(?<=[.!?])\\s+|\\n+"))
            .map { it.trim() }
            .filter { it.isNotBlank() }

        val result = mutableListOf<String>()
        var current = StringBuilder()

        fun flush() {
            val value = current.toString().trim()
            if (value.isNotBlank()) result += value
            current = StringBuilder()
        }

        fun addLongPiece(piece: String) {
            val words = piece.split(Regex("\\s+")).filter { it.isNotBlank() }
            for (word in words) {
                if (word.length > maxChars) {
                    flush()
                    word.chunked(maxChars).forEach { result += it }
                    continue
                }
                val extra = if (current.isEmpty()) word.length else word.length + 1
                if (current.length + extra > maxChars) flush()
                if (current.isNotEmpty()) current.append(' ')
                current.append(word)
            }
        }

        for (piece in pieces) {
            if (piece.length > maxChars) {
                flush()
                addLongPiece(piece)
                flush()
                continue
            }
            val extra = if (current.isEmpty()) piece.length else piece.length + 1
            if (current.length + extra > maxChars) flush()
            if (current.isNotEmpty()) current.append(' ')
            current.append(piece)
        }
        flush()
        return result
    }

    override fun onInit(status: Int) {
        ttsInitializing = false
        speechRecoveryInProgress = false
        if (status != TextToSpeech.SUCCESS) {
            ttsReady = false
            if (!pendingSpeechText.isNullOrBlank() && speechRetryCount < MAX_TTS_RETRIES) {
                speechRetryCount += 1
                binding.tvStatus.text = "Respuesta lista. Reintentando el motor de voz..."
                mainHandler.postDelayed({ reinitializeTts() }, TTS_RETRY_DELAY_MS)
            } else if (!pendingSpeechText.isNullOrBlank()) {
                pendingSpeechText = null
                activeSpeechText = null
                binding.tvStatus.text = "Respuesta lista. No se pudo iniciar la voz esta vez."
                scheduleNextAutoIfNeeded()
            }
            return
        }
        val engine = tts ?: return
        val result = engine.setLanguage(Locale("es", "PE"))
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.language = Locale("es", "ES")
        }
        engine.setSpeechRate(prefs.speechRate)
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit

            override fun onDone(utteranceId: String?) {
                if (utteranceId == activeSpeechFinalId) {
                    runOnUiThread {
                        isSpeakingAnswer = false
                        activeSpeechFinalId = null
                        activeSpeechText = null
                        pendingSpeechText = null
                        speechRetryCount = 0
                        binding.tvStatus.text = if (autoMode) {
                            "Respuesta terminada. Preparando la siguiente foto..."
                        } else {
                            "Listo. Puedes pedir otra foto o elegir otra imagen."
                        }
                        scheduleNextAutoIfNeeded()
                    }
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                runOnUiThread { handleSpeechFailure() }
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                runOnUiThread { handleSpeechFailure() }
            }
        })
        ttsReady = true
        if (!pendingSpeechText.isNullOrBlank()) startPendingSpeech()
    }

    private fun handleSpeechFailure() {
        if (stopped || speechRecoveryInProgress) return
        val text = activeSpeechText ?: pendingSpeechText
        isSpeakingAnswer = false
        activeSpeechFinalId = null

        if (text.isNullOrBlank()) {
            scheduleNextAutoIfNeeded()
            return
        }

        if (speechRetryCount < MAX_TTS_RETRIES) {
            speechRetryCount += 1
            speechRecoveryInProgress = true
            pendingSpeechText = text
            activeSpeechText = text
            binding.tvStatus.text = "La respuesta está lista. Reiniciando voz..."
            reinitializeTts()
        } else {
            pendingSpeechText = null
            activeSpeechText = null
            binding.tvStatus.text = "Respuesta lista. La voz falló esta vez; el texto quedó guardado."
            scheduleNextAutoIfNeeded()
        }
    }

    private fun reinitializeTts() {
        runCatching { tts?.stop() }
        runCatching { tts?.shutdown() }
        ttsReady = false
        ttsInitializing = true
        tts = TextToSpeech(this, this)
    }

    private fun processNextQueuedCameraPhotoIfReady(): Boolean {
        if (stopped || processing.get() || isSpeakingAnswer || !pendingSpeechText.isNullOrBlank()) return false
        while (pendingCameraPhotos.isNotEmpty()) {
            val next = pendingCameraPhotos.pollFirst() ?: return false
            val bitmap = BitmapFactory.decodeByteArray(
                next.jpeg,
                0,
                next.jpeg.size,
                BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 },
            ) ?: continue
            processBitmap(bitmap, source = next.source)
            return true
        }
        return false
    }

    private fun scheduleNextAutoIfNeeded() {
        if (processNextQueuedCameraPhotoIfReady()) return
        if (!autoMode || stopped || inputMode != InputMode.CAMERA) return
        if (isSpeakingAnswer || !pendingSpeechText.isNullOrBlank()) return
        mainHandler.postDelayed({
            if (autoMode && !stopped && !processing.get() && activeCaptureRequestId == null &&
                !isSpeakingAnswer && pendingSpeechText.isNullOrBlank()) {
                requestCameraCapture(manual = false)
            }
        }, AUTO_NEXT_DELAY_MS)
    }

    private fun updateCameraChip() {
        binding.tvCameraChip.text = if (cameraServer.isCameraConnected()) {
            "Cámara: conectada"
        } else {
            "Cámara: esperando"
        }
    }

    private fun updateApiChip() {
        val config = apiSettings.getApiConfigs()
            .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }

        if (config == null) {
            binding.tvApiChip.text = "API: sin configurar"
            binding.tvApiDetail.text = "DeepSeek · SIN CONFIGURAR"
            return
        }

        val status = apiSettings.getStatus(config)
        val message = apiSettings.getMessage(config).trim()
        binding.tvApiChip.text = "API: DeepSeek"
        binding.tvApiDetail.text = when (status) {
            "ready" -> "DeepSeek · ACTIVA ✓ · CLAVE GUARDADA · ${config.model}"
            "error" -> "DeepSeek · GUARDADA · ERROR: ${message.ifBlank { "revisa clave, saldo o modelo" }}"
            "limit" -> "DeepSeek · GUARDADA · SIN CRÉDITOS / LÍMITE: ${message.ifBlank { "revisa tu cuenta" }}"
            else -> if (message.isBlank() || message.startsWith("Sin probar", ignoreCase = true)) {
                "DeepSeek · GUARDADA · SIN PROBAR · ${config.model}"
            } else {
                "DeepSeek · GUARDADA · ÚLTIMO ESTADO: $message"
            }
        }
    }

    private fun showVoiceDialog() {
        val labels = arrayOf("0.25x", "0.50x", "0.75x", "1.00x", "1.25x", "1.50x", "1.75x", "2.00x")
        val values = floatArrayOf(0.25f, 0.50f, 0.75f, 1.00f, 1.25f, 1.50f, 1.75f, 2.00f)
        val current = values.indices.minByOrNull { abs(values[it] - prefs.speechRate) } ?: 3
        AlertDialog.Builder(this)
            .setTitle("Velocidad de voz")
            .setSingleChoiceItems(labels, current) { dialog, which ->
                prefs.speechRate = values[which]
                tts?.setSpeechRate(values[which])
                Toast.makeText(this, "Voz ${labels[which]}", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showCameraDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(4))
        }
        val info = TextView(this).apply {
            text = "TimerCamera-X U082-X: al encenderse se conecta a la Zona Wi-Fi configurada, toma una sola foto útil y la envía a GI X por el puerto ${CameraBridgeServer.DEFAULT_PORT}. No necesitas pulsar PEDIR FOTO. Si dejas la clave por defecto GIX2026CAM, la app ya queda lista para recibir la cámara."
            textSize = 14f
        }
        val tokenInput = EditText(this).apply {
            hint = "Clave de enlace"
            setText(prefs.pairingToken)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            maxLines = 1
        }
        val note = TextView(this).apply {
            text = "Firmware incluido: camera_firmware/TimerCameraX_GIX.ino. Recomendado: deja fija la clave GIX2026CAM y cambia solo nombre Wi-Fi y contraseña Wi-Fi. Si cambias la clave, debe coincidir exactamente con la app."
            textSize = 12f
        }
        box.addView(info)
        box.addView(tokenInput, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) })
        box.addView(note, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        val dialog = AlertDialog.Builder(this)
            .setTitle("Enlace con Timer Camera X")
            .setView(box)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                prefs.pairingToken = tokenInput.text?.toString().orEmpty()
                tokenInput.setText(prefs.pairingToken)
                binding.tvStatus.text = "Clave de cámara guardada. Debe coincidir con el firmware."
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun normalizeCheaperKey(raw: String): String {
        val cleaned = raw
            .trim()
            .removePrefix("Bearer ")
            .removePrefix("bearer ")
            .trim('\"', '\'')
            .replace("​", "")
            .replace("‌", "")
            .replace("‍", "")
            .replace("⁠", "")
            .replace("﻿", "")
            .replace(Regex("[\r\n\t ]+"), "")

        val embedded = Regex("(ir_live_[A-Za-z0-9._-]+|ci_live_[A-Za-z0-9._-]+)", RegexOption.IGNORE_CASE)
            .find(cleaned)
            ?.value
        return embedded ?: cleaned
    }

    private fun showApiDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }

        val title = TextView(this).apply {
            text = "CHEAPER INFERENCE · DEEPSEEK"
            textStyleBold()
            textSize = 15f
        }
        val info = TextView(this).apply {
            text = "GI X usará únicamente esta API de pago con DeepSeek V4 Flash. La clave queda guardada en el celular. Los fallos temporales no la bloquean y la app muestra el motivo real si no responde."
            textSize = 12f
            setPadding(0, dp(4), 0, dp(8))
        }

        val saved = apiSettings.getApiConfigs()
            .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }
        val keyInput = EditText(this).apply {
            hint = if (saved == null) "Clave Cheaper Inference (ir_live_… / ci_live_…)" else "Clave guardada. Pega otra solo para reemplazarla"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            maxLines = 1
        }
        val modelInput = EditText(this).apply {
            hint = "Modelo fijo"
            setText(NetProvider.CHEAPER_INFERENCE.defaultModel)
            isEnabled = false
            maxLines = 1
        }
        val statusText = TextView(this).apply {
            textSize = 12f
            setPadding(0, dp(8), 0, dp(6))
        }
        val saveTest = Button(this).apply { text = "GUARDAR Y PROBAR DEEPSEEK" }
        val testSaved = Button(this).apply { text = "PROBAR API GUARDADA" }
        val delete = Button(this).apply { text = "BORRAR API GUARDADA" }
        val close = Button(this).apply { text = "CERRAR" }

        fun refresh(message: String? = null) {
            val config = apiSettings.getApiConfigs()
                .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }
            val storedStatus = if (config == null) {
                "DeepSeek: SIN CONFIGURAR"
            } else {
                val state = apiSettings.getStatus(config)
                val detail = apiSettings.getMessage(config).trim()
                when (state) {
                    "ready" -> "DeepSeek: ACTIVA ✓ · ${config.model} · clave guardada"
                    "error" -> "DeepSeek: GUARDADA · ERROR · ${detail.ifBlank { "revisa clave, saldo o modelo" }}"
                    "limit" -> "DeepSeek: GUARDADA · SIN CRÉDITOS / LÍMITE · ${detail.ifBlank { "revisa tu cuenta" }}"
                    else -> if (detail.isBlank() || detail.startsWith("Sin probar", ignoreCase = true)) {
                        "DeepSeek: GUARDADA · SIN PROBAR · ${config.model}"
                    } else {
                        "DeepSeek: GUARDADA · ${detail}"
                    }
                }
            }
            statusText.text = listOfNotNull(message?.takeIf { it.isNotBlank() }, storedStatus).joinToString("\n")
            updateApiChip()
        }

        box.addView(title)
        box.addView(info)
        box.addView(keyInput, LinearLayout.LayoutParams(-1, dp(54)))
        box.addView(modelInput, LinearLayout.LayoutParams(-1, dp(54)))
        box.addView(saveTest, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(6) })
        box.addView(testSaved, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4) })
        box.addView(statusText, LinearLayout.LayoutParams(-1, -2))
        box.addView(delete, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4) })
        box.addView(close, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4) })

        val dialog = AlertDialog.Builder(this)
            .setTitle("API de GI X")
            .setView(box)
            .create()

        saveTest.setOnClickListener {
            val typed = normalizeCheaperKey(keyInput.text?.toString().orEmpty())
            val current = apiSettings.getApiConfigs()
                .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }
            val key = typed.ifBlank { normalizeCheaperKey(current?.apiKey.orEmpty()) }
            if (key.isBlank()) {
                keyInput.error = "Pega tu clave ir_live_… o ci_live_…"
                return@setOnClickListener
            }
            val model = modelInput.text?.toString().orEmpty().trim()
                .ifBlank { NetProvider.CHEAPER_INFERENCE.defaultModel }
            val config = NetApiConfig(
                name = "DeepSeek Pago",
                provider = NetProvider.CHEAPER_INFERENCE,
                apiKey = key,
                model = model
            ).clean(0)

            // Esta versión usa una sola API: al guardar, elimina configuraciones de respaldo.
            apiSettings.saveApiConfigs(listOf(config))
            saveTest.isEnabled = false
            testSaved.isEnabled = false
            statusText.text = "DeepSeek: GUARDADA · probando conexión…"
            ioExecutor.execute {
                val result = onlineProvider.testApiConfig(config)
                runOnUiThread {
                    saveTest.isEnabled = true
                    testSaved.isEnabled = true
                    if (result.first) keyInput.text?.clear()
                    refresh(result.second)
                }
            }
        }

        testSaved.setOnClickListener {
            val config = apiSettings.getApiConfigs()
                .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }
            if (config == null) {
                refresh("No hay una API guardada todavía.")
                return@setOnClickListener
            }
            testSaved.isEnabled = false
            statusText.text = "DeepSeek: probando API guardada…"
            ioExecutor.execute {
                val result = onlineProvider.testApiConfig(config)
                runOnUiThread {
                    testSaved.isEnabled = true
                    refresh(result.second)
                }
            }
        }

        delete.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Borrar API")
                .setMessage("¿Quieres borrar la clave DeepSeek guardada en este celular?")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Borrar") { _, _ ->
                    apiSettings.saveApiConfigs(emptyList())
                    refresh("API borrada.")
                }
                .show()
        }

        close.setOnClickListener { dialog.dismiss() }
        dialog.setOnDismissListener { updateApiChip() }
        refresh()
        dialog.show()
    }

    private fun setupInternalScroll(scroll: ScrollView) {
        scroll.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> view.parent?.requestDisallowInterceptTouchEvent(true)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.parent?.requestDisallowInterceptTouchEvent(false)
            }
            false
        }
    }

    private fun showPreviewDialog() {
        val bitmap = previewBitmap
        if (bitmap == null) {
            Toast.makeText(this, "Todavía no hay imagen para abrir.", Toast.LENGTH_SHORT).show()
            return
        }

        val imageView = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setImageBitmap(bitmap)
            setBackgroundColor(0xFF0B1726.toInt())
        }
        val vertical = ScrollView(this)
        val horizontal = HorizontalScrollView(this)
        horizontal.addView(imageView, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        vertical.addView(horizontal, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val dialog = AlertDialog.Builder(this)
            .setTitle("Imagen completa")
            .setView(vertical)
            .setPositiveButton("Cerrar", null)
            .create()
        dialog.show()
        dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
    }

    private fun saveToHistory(answerText: String) {
        if (lastDisplayedOcrText.isBlank() || answerText.isBlank()) return
        val entry = HistoryEntry(
            id = System.currentTimeMillis().toString(),
            timestamp = System.currentTimeMillis(),
            source = lastSourceLabel,
            questionCount = lastExtractedQuestions.size.coerceAtLeast(1),
            ocrText = lastDisplayedOcrText,
            answerText = answerText
        )
        historyRepository.add(entry)
        renderHistory()
    }

    private fun renderHistory() {
        val items = historyRepository.getAll()
        binding.historyContainer.removeAllViews()
        binding.tvHistoryEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        items.forEach { entry ->
            binding.historyContainer.addView(createHistoryCard(entry))
        }
    }

    private fun createHistoryCard(entry: HistoryEntry): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = getDrawable(R.drawable.card_bg)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(8)
        }
        card.layoutParams = params

        val title = TextView(this).apply {
            text = "${formatHistoryDate(entry.timestamp)} · ${entry.source} · ${entry.questionCount} pregunta(s)"
            textSize = 13f
            textStyleBold()
        }
        val preview = TextView(this).apply {
            text = entry.ocrText.replace("\n", " ").take(120).ifBlank { "Sin texto OCR" }
            textSize = 12f
            setPadding(0, dp(4), 0, dp(2))
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
        }
        val open = Button(this).apply { text = "ABRIR" }
        val delete = Button(this).apply { text = "BORRAR" }
        row.addView(open, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(4) })
        row.addView(delete, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(4) })

        open.setOnClickListener { showHistoryEntryDialog(entry) }
        delete.setOnClickListener {
            historyRepository.delete(entry.id)
            renderHistory()
            Toast.makeText(this, "Registro borrado.", Toast.LENGTH_SHORT).show()
        }

        card.addView(title)
        card.addView(preview)
        card.addView(row)
        return card
    }

    private fun showHistoryEntryDialog(entry: HistoryEntry) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(8))
        }
        root.addView(TextView(this).apply {
            text = "${formatHistoryDate(entry.timestamp)} · ${entry.source} · ${entry.questionCount} pregunta(s)"
            textSize = 13f
            textStyleBold()
        })
        root.addView(TextView(this).apply {
            text = "Preguntas extraídas"
            textSize = 13f
            textStyleBold()
            setPadding(0, dp(10), 0, dp(4))
        })
        val ocrScroll = ScrollView(this)
        ocrScroll.addView(TextView(this).apply {
            text = entry.ocrText
            textSize = 14f
            setTextIsSelectable(true)
            setPadding(dp(10), dp(10), dp(10), dp(10))
        })
        root.addView(ocrScroll, LinearLayout.LayoutParams(-1, dp(180)))

        root.addView(TextView(this).apply {
            text = "Respuestas"
            textSize = 13f
            textStyleBold()
            setPadding(0, dp(10), 0, dp(4))
        })
        val answerScroll = ScrollView(this)
        answerScroll.addView(TextView(this).apply {
            text = entry.answerText
            textSize = 14f
            setTextIsSelectable(true)
            setPadding(dp(10), dp(10), dp(10), dp(10))
        })
        root.addView(answerScroll, LinearLayout.LayoutParams(-1, dp(240)))

        AlertDialog.Builder(this)
            .setTitle("Historial GI X")
            .setView(root)
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun confirmClearHistory() {
        if (historyRepository.getAll().isEmpty()) {
            Toast.makeText(this, "No hay historial para borrar.", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Borrar historial")
            .setMessage("¿Quieres borrar todo el historial guardado de preguntas y respuestas?")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Borrar") { _, _ ->
                historyRepository.clear()
                renderHistory()
                Toast.makeText(this, "Historial borrado.", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun formatHistoryDate(time: Long): String {
        return try {
            SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("es", "PE")).format(Date(time))
        } catch (_: Exception) {
            Date(time).toString()
        }
    }

    private fun TextView.textStyleBold() {
        setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun scrollTextToTop(view: TextView) {
        view.post {
            view.scrollTo(0, 0)
            (view.parent as? ScrollView)?.scrollTo(0, 0)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        cameraStatusTicker?.let { mainHandler.removeCallbacks(it) }
        mainHandler.removeCallbacksAndMessages(null)
        onlineProvider.cancelActiveRequest()
        cameraServer.stop()
        pendingCameraPhotos.clear()
        ocrProcessor.close()
        pendingSpeechText = null
        activeSpeechText = null
        activeSpeechFinalId = null
        isSpeakingAnswer = false
        tts?.stop()
        tts?.shutdown()
        ioExecutor.shutdownNow()
        cameraIoExecutor.shutdownNow()
        super.onDestroy()
    }

    private enum class InputMode {
        CAMERA,
        IMAGE
    }

    companion object {
        private const val STANDARD_API_BATCH_SIZE = 3
        private const val MAX_PENDING_CAMERA_PHOTOS = 12
        private const val TRUE_FALSE_API_BATCH_SIZE = 5
        private const val UTTERANCE_ANSWER = "gix_answer"
        private const val MAX_TTS_RETRIES = 1
        private const val TTS_RETRY_DELAY_MS = 700L
        private const val AUTO_NEXT_DELAY_MS = 3_500L
    }
}
