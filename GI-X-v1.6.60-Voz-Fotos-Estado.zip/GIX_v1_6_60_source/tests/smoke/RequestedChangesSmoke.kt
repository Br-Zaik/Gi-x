package com.gix.cameraai

import kotlin.math.*

fun main() {
    val hz = 16000
    val pcm = ShortArray(hz) { (sin(2 * PI * 220 * it / hz) * 12000).toInt().toShort() }
    val original = pcm.copyOf()
    for (rate in SpeechTempo.rates) {
        var samples = 0
        var crossings = 0
        var last: Short = 0
        SpeechTempo.render(pcm, hz, 1, { rate }, { false }) { block, count ->
            for (i in 0 until count) {
                if (last < 0 && block[i] >= 0) crossings++
                last = block[i]
            }
            samples += count
            check(count <= hz / 50)
        }
        val expected = hz / rate.toDouble()
        check(abs(samples - expected) <= 2) { "$rate: $samples vs $expected" }
        val measuredHz = crossings * hz.toDouble() / samples
        check(abs(measuredHz - 220) < 15) { "Pitch changed at $rate: $measuredHz" }
        println("Tempo ${rate}x: ${samples.toDouble() / hz}s; pitch ${measuredHz.roundToInt()}Hz")
    }
    check(original.contentEquals(pcm))
    var blocks = 0
    SpeechTempo.render(pcm, hz, 1, { 0.05f }, { blocks == 3 }) { _, _ -> blocks++ }
    check(blocks == 3) // New input/close can interrupt very slow playback promptly.
    var dynamicSamples = 0
    SpeechTempo.render(pcm, hz, 1, { if (dynamicSamples < hz) 0.1f else 2f }, { false }) { _, n -> dynamicSamples += n }
    check(dynamicSamples in 23000..23500) // Rate change reaches current audio, not just the next text.
    val stereo = ShortArray(hz * 2) { pcm[it / 2] }
    var stereoCount = 0
    SpeechTempo.render(stereo, hz, 2, { 0.25f }, { false }) { b, n ->
        for (i in 0 until n step 2) check(b[i] == b[i + 1])
        stereoCount += n
    }
    check(stereoCount == hz * 8)

    val w = 256; val h = 128
    val image = IntArray(w * h) { i ->
        val grey = 135 + (i % w) * 70 / w
        -0x1000000 or (grey shl 16) or (grey shl 8) or grey
    }
    val colours = intArrayOf(0xff302e2c.toInt(), 0xffa43c42.toInt(), 0xff3d4b9a.toInt(), 0xff537958.toInt())
    for (c in colours.indices) for (y in 50..52) for (x in 20 + c * 55..45 + c * 55) image[y * w + x] = colours[c]
    val copy = image.copyOf()
    val result = DocumentPhotoEnhancer.enhance(image, w, h)
    check(image.contentEquals(copy))
    check(result.size == image.size)
    for (c in colours.indices) {
        val x = 30 + c * 55
        val pixel = result[51 * w + x]
        val r = (pixel ushr 16) and 255; val g = (pixel ushr 8) and 255; val b = pixel and 255
        when (c) {
            0 -> check(maxOf(r, g, b) < 100)
            1 -> check(r > g * 1.5 && r > b * 1.5)
            2 -> check(b > r * 1.5 && b > g * 1.3)
            3 -> check(g > r && g > b)
        }
    }
    check(DocumentPhotoEnhancer.enhance(intArrayOf(-1), 1, 1)[0] == -1)
    check(runCatching { DocumentPhotoEnhancer.enhance(image, w, h) { true } }.isFailure)
    check(VisionReadingPolicy.needsSecondPass("PREGUNTAS DETECTADAS\n1. Uno\n3. Tres", AiContextMode.AUTO))
    check(!VisionReadingPolicy.needsSecondPass("PREGUNTAS DETECTADAS\n5. Cinco\n6. Seis", AiContextMode.AUTO))
    println("OK: all speeds, live rate, cancellation, stereo, coloured ink, originals and missing-question review")
}
