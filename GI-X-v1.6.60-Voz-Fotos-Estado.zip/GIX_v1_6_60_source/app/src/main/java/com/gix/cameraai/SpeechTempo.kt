package com.gix.cameraai

import kotlin.math.*

/** PCM time stretching with overlap-add and waveform alignment. No engine rate clamp.
 * Emits small blocks; even 0.05x never allocates a 20-times-larger recording.
 * The logical input cursor is independent of alignment, so slow speeds cannot stall.
 */
internal object SpeechTempo {
    val rates = floatArrayOf(0.05f, 0.10f, 0.15f, 0.25f, 0.50f, 0.75f, 1f, 1.25f, 1.50f, 1.75f, 2f)

    fun render(
        input: ShortArray, sampleRate: Int, channels: Int,
        rate: () -> Float, cancelled: () -> Boolean,
        emit: (ShortArray, Int) -> Unit,
    ) {
        require(sampleRate > 0 && channels in 1..2)
        val frames = input.size / channels
        if (frames == 0) return
        val hop = (sampleRate / 50).coerceAtLeast(16) // 20 ms
        val radius = (sampleRate / 200).coerceAtLeast(1) // ±5 ms
        val tail = ShortArray(hop * channels)
        val block = ShortArray(hop * channels)
        var cursor = 0.0
        var first = true
        fun sample(frame: Int, channel: Int): Short =
            if (frame in 0 until frames) input[frame * channels + channel] else 0

        while (cursor < frames - 0.0001 && !cancelled()) {
            val speed = rate().takeIf { it.isFinite() }?.coerceIn(0.05f, 2f) ?: 1f
            val count = min(hop, ceil((frames - cursor) / speed - 0.0001).toInt().coerceAtLeast(1))
            val expected = cursor.roundToInt().coerceIn(0, frames - 1)
            var chosen = expected
            if (!first && abs(speed - 1f) > 0.0001f) {
                var best = -Double.MAX_VALUE
                // Coarse alignment is bounded work, independent of total output length.
                for (candidate in max(0, expected - radius)..min(frames - 1, expected + radius) step 4) {
                    var dot = 0.0
                    var energy = 1.0
                    var tailEnergy = 1.0
                    for (f in 0 until hop step 8) {
                        val a = tail[f * channels].toDouble()
                        val b = sample(candidate + f, 0).toDouble()
                        dot += a * b
                        energy += b * b
                        tailEnergy += a * a
                    }
                    val score = dot / sqrt(energy * tailEnergy) - abs(candidate - expected) * 0.000001
                    if (score > best) { best = score; chosen = candidate }
                }
            }
            for (f in 0 until hop) {
                val blend = f.toFloat() / hop
                for (c in 0 until channels) {
                    val i = f * channels + c
                    val fresh = sample(chosen + f, c)
                    block[i] = if (first) fresh else
                        (tail[i] * (1f - blend) + fresh * blend).roundToInt().coerceIn(-32768, 32767).toShort()
                    tail[i] = sample(chosen + hop + f, c)
                }
            }
            emit(block, count * channels)
            cursor += count * speed.toDouble()
            first = false
        }
    }
}
