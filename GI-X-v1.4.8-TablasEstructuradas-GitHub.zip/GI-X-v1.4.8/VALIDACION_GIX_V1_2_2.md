# Validacion GI X v1.2.2

- versionCode: 5
- versionName: 1.2.2
- Cheaper Inference se identifica como intermediario compatible con OpenAI.
- Endpoint: https://api.cheaperinference.com/v1/chat/completions
- Modelo predeterminado: deepseek-v4-pro
- Admite claves ir_live_... y ci_live_...
- Se elimino la validacion excesivamente estricta que causaba “API con caracteres no validos”.
- Se limpian espacios, comillas envolventes y caracteres invisibles comunes al pegar la clave.
- La clave real del usuario no se incluye en el ZIP.
- La prueba hace una solicitud real y solo marca DISPONIBLE si recibe una respuesta valida.
- Se mantienen Camara, Imagen manual, OCR ML Kit, APIs de respaldo, TTS y workflows de GitHub.

La compilacion Android final se valida en GitHub Actions.
