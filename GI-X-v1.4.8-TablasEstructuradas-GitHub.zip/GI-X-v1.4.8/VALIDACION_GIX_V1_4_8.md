# GI X v1.4.8
- versionCode: 18
- versionName: 1.4.8
- Mejora principal: soporte general reforzado para tablas detectadas por OCR.
- El OCR usa las posiciones de palabras de ML Kit para reconstruir filas y columnas cuando la estructura visual indica una tabla.
- Soporta tablas de 2, 3, 4 o más columnas (hasta 6 columnas detectadas de forma conservadora).
- Conserva encabezados y organiza cada fila con separadores de columna.
- Las celdas sin texto se marcan internamente como [VACÍO] para que la IA pueda completar tablas sin perder la posición de la celda.
- La IA recibe instrucciones específicas para no mezclar columnas, respetar encabezados y responder por fila cuando la consigna pide completar, relacionar, clasificar o interpretar una tabla.
- Si no se detecta una tabla con suficiente confianza, GI X mantiene el flujo OCR normal para evitar alterar preguntas comunes.
- Se conservaron las mejoras de v1.4.7: preguntas sin numeración y normalización de MAYÚSCULAS solo para la voz.
- No se modificaron respuestas predefinidas ni el resto de la lógica principal de la aplicación.

## Pruebas de lógica realizadas
- Tabla de 2 columnas con segunda columna vacía: reconstrucción correcta de encabezados, filas y [VACÍO].
- Tabla de 3 columnas con datos en todas las columnas: reconstrucción correcta por fila y columna.
- Integración con el extractor: la tabla estructurada se adjunta a la pregunta de tipo "COMPLETE LA FUNCIÓN QUE CORRESPONDE" y se incluye en el prompt enviado a la IA.
- Los archivos Kotlin modificados se validaron sintácticamente con stubs compatibles con las APIs utilizadas.
