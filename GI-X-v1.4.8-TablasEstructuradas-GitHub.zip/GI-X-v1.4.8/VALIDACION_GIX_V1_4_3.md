# GI X v1.4.3

- versionCode: 13
- versionName: 1.4.3
- DeepSeek/Cheaper Inference: razonamiento minimal para priorizar respuesta final.
- Hojas múltiples: presupuesto de salida 2200–4000 tokens (8 preguntas ≈ 2980).
- X-CI-Concise activado en consultas reales.
- Detección explícita de finish_reason length/MAX_TOKENS.
- Parser Chat Completions tolera message.content, message.text y choices[].text.
- Se mantiene una sola solicitud real por consulta y timeout largo.
