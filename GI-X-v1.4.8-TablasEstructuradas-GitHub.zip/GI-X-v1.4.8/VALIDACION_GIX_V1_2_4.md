# GI X v1.2.4
- versionCode: 7
- versionName: 1.2.4
- OCR ahora extrae varias preguntas de una sola hoja.
- Manual y cámara usan el mismo flujo: una sola llamada para todas las preguntas.
- La respuesta puede incluir pregunta + respuesta por cada item.
- Ajuste de límites para respuestas múltiples y lectura por voz.
