# GI X v1.3.1
- versionCode: 9
- versionName: 1.3.1
- Corregidos errores de compilación detectados en GitHub Actions.
