# GI X v1.4.5
- versionCode: 15
- versionName: 1.4.5
- API: Cheaper Inference, mismo endpoint y misma clave guardada.
- Modelo fijo: deepseek-v4-flash.
- Migración automática desde configuraciones guardadas con deepseek-v4-pro.
- Sin cambios en OCR, historial, cámara, voz ni formato de respuestas de v1.4.4.
