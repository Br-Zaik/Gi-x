# GI X v1.4.6
- versionCode: 16
- versionName: 1.4.6
- Corrección puntual: las líneas numeradas se conservan como preguntas aunque estén completamente en mayúsculas o no tengan signos de interrogación.
- Ejemplos reparados: 6.- DIFERENCIA ENTRE... y 7.- CONVERTIR: EL AZIMUT...
