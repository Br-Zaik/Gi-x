#include "M5TimerCAM.h"
#include <WiFi.h>
#include <HTTPClient.h>

// ========= CAMBIA SOLO ESTOS 3 DATOS =========
const char* WIFI_NAME = "TU_ZONA_WIFI";
const char* WIFI_PASSWORD = "TU_CLAVE_WIFI";
const char* GIX_TOKEN = "GIX2026CAM";   // Debe coincidir con GI X > CÁMARA
// ==============================================

const uint16_t GIX_PORT = 8765;
const uint32_t WIFI_TIMEOUT_MS = 30000;
const uint32_t APP_RETRY_WINDOW_MS = 45000;

String phoneBaseUrl() {
  IPAddress gateway = WiFi.gatewayIP();
  return String("http://") + gateway.toString() + ":" + String(GIX_PORT);
}

bool connectWifi() {
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(WIFI_NAME, WIFI_PASSWORD);

  Serial.print("Conectando a la Zona Wi-Fi");
  unsigned long started = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - started < WIFI_TIMEOUT_MS) {
    delay(400);
    Serial.print(".");
  }
  Serial.println();

  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("No se pudo conectar a la Zona Wi-Fi.");
    return false;
  }

  Serial.print("Conectada. IP camara: ");
  Serial.println(WiFi.localIP());
  Serial.print("Celular/gateway: ");
  Serial.println(WiFi.gatewayIP());
  return true;
}

String getPendingRequestId() {
  if (WiFi.status() != WL_CONNECTED) return "";

  HTTPClient http;
  http.setTimeout(4500);
  String url = phoneBaseUrl() + "/camera/poll?token=" + String(GIX_TOKEN);
  http.begin(url);
  int code = http.GET();
  String result = "";
  if (code == 200) {
    String body = http.getString();
    body.trim();
    if (body.startsWith("CAPTURE|")) {
      result = body.substring(8);
      result.trim();
    }
  }
  http.end();
  return result;
}

void warmUpCamera() {
  // Descarta algunas tomas iniciales para dar tiempo a exposición/balance de blancos.
  for (int i = 0; i < 3; i++) {
    if (TimerCAM.Camera.get()) {
      TimerCAM.Camera.free();
    }
    delay(220);
  }
}

bool sendPhoto(const String& requestId) {
  if (WiFi.status() != WL_CONNECTED) return false;
  if (!TimerCAM.Camera.get()) {
    Serial.println("No se pudo capturar foto");
    return false;
  }

  String url = phoneBaseUrl() + "/camera/photo?token=" + String(GIX_TOKEN);
  if (requestId.length() > 0) {
    url += "&requestId=" + requestId;
  }

  bool ok = false;
  for (int attempt = 0; attempt < 3 && !ok; attempt++) {
    HTTPClient http;
    http.setTimeout(15000);
    http.begin(url);
    http.addHeader("Content-Type", "image/jpeg");
    int code = http.POST(TimerCAM.Camera.fb->buf, TimerCAM.Camera.fb->len);
    String response = code > 0 ? http.getString() : "";
    http.end();

    if (code == 200) {
      ok = true;
      Serial.println("Foto enviada a GI X");
    } else {
      Serial.printf("Fallo enviando foto. HTTP %d %s\n", code, response.c_str());
      delay(800);
    }
  }

  TimerCAM.Camera.free();
  return ok;
}

void powerDown() {
  Serial.println("Apagando Timer Camera X...");
  TimerCAM.Power.setLed(0);
  WiFi.disconnect(true);
  WiFi.mode(WIFI_OFF);
  delay(250);
  TimerCAM.Power.powerOff();

  // Con batería debería apagarse. Si está alimentada por USB externo,
  // M5Stack indica que puede permanecer energizada; no repetimos fotos.
  while (true) delay(1000);
}

void setup() {
  Serial.begin(115200);
  delay(250);

  TimerCAM.begin();
  TimerCAM.Power.begin();
  TimerCAM.Power.setLed(40);

  if (!TimerCAM.Camera.begin()) {
    Serial.println("ERROR: no se pudo iniciar OV3660");
    delay(2500);
    powerDown();
  }

  TimerCAM.Camera.sensor->set_pixformat(TimerCAM.Camera.sensor, PIXFORMAT_JPEG);
  // 1600x1200 da bastante más detalle que SVGA para OCR y sigue siendo estable con PSRAM.
  TimerCAM.Camera.sensor->set_framesize(TimerCAM.Camera.sensor, FRAMESIZE_UXGA);
  TimerCAM.Camera.sensor->set_quality(TimerCAM.Camera.sensor, 8);
  TimerCAM.Camera.sensor->set_vflip(TimerCAM.Camera.sensor, 1);
  TimerCAM.Camera.sensor->set_hmirror(TimerCAM.Camera.sensor, 0);

  if (!connectWifi()) {
    delay(1500);
    powerDown();
  }

  // La cámara queda lista para funcionar como un disparador físico:
  // encender PWR -> conectar a la Zona Wi-Fi -> tomar 1 foto -> enviarla -> apagarse.
  // Si GI X había dejado una orden pendiente, conserva ese ID; si no, manda la foto igual.
  warmUpCamera();

  unsigned long started = millis();
  bool sent = false;
  while (!sent && millis() - started < APP_RETRY_WINDOW_MS) {
    String requestId = getPendingRequestId();
    sent = sendPhoto(requestId);
    if (!sent) delay(1800);
  }

  if (!sent) {
    Serial.println("No se pudo entregar la foto a GI X dentro del tiempo de espera.");
  }
  powerDown();
}

void loop() {
  delay(1000);
}
