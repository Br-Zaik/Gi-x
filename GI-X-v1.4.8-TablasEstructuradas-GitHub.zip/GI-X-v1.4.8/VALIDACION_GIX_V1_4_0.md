# GI X v1.4.0

- versionCode: 10
- versionName: 1.4.0
- Cámara e imagen manual usan el mismo flujo OCR -> una llamada API -> respuestas -> voz.
- Cuadros OCR y Respuesta fijos con scroll interno.
- DeepSeek/Cheaper Inference como única API del flujo principal.
- Sin bloqueo temporal por "EN ESPERA" en el flujo principal.
- 3 intentos automáticos para fallos temporales.
- Estado permanente de API guardada/activa/error.
- Extractor reparado para asociar A-E a la pregunta correcta e ignorar encabezados.
