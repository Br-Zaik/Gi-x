# Validación estática GI X 1.1

## Cambios incluidos
- Dos entradas separadas: CÁMARA e IMAGEN MANUAL.
- Selector visible de modo.
- Imagen manual desde almacenamiento mediante Storage Access Framework, sin permiso de almacenamiento.
- Corrección de orientación EXIF.
- OCR local ML Kit con normalización de resolución y doble lectura (normal + contraste/escala de grises).
- Selección heurística conservadora del resultado OCR más legible.
- Flujo compartido OCR -> extracción de pregunta -> API -> respuesta -> TTS.
- Firmware Timer Camera X actualizado para flujo PWR -> Wi‑Fi -> foto -> envío -> powerOff.
- Cámara configurada en UXGA 1600x1200 para mejorar detalle de texto.
- Workflow GitHub Actions para compilar APK debug.
- versionCode 2 / versionName 1.1.0.

## Revisiones hechas en este entorno
- Estructura de proyecto revisada.
- XML de recursos validado como XML bien formado.
- Referencias de IDs entre layout y MainActivity revisadas.
- Clases Kotlin puras (`CameraBridgeServer`, `OcrQuestionExtractor`, `ResponseRepository`, `VoiceQuestionNormalizer`) compiladas con `kotlinc`.
- Prueba local del protocolo: `GET /camera/poll` devolvió `CAPTURE|ID` y `POST /camera/photo` recibió el JPEG y respondió HTTP 200.
- Firmware contrastado con la API pública de `M5TimerCAM.h` / `Power_Class.h` para `TimerCAM.Power.powerOff()`.
- No se modificó el ZIP original de Geo Susu.

## Limitación
Este entorno no contiene el Android SDK/Gradle completo necesario para ejecutar una compilación Android final local. El proyecto incluye un workflow de GitHub Actions precisamente para compilarlo en un entorno Android real. La prueba definitiva sigue siendo instalar el APK y hacer una prueba física con fotos y, después, con la Timer Camera X.


## Cambios v1.2
- Se agregó `NetProvider.CHEAPER_INFERENCE`.
- Endpoint: `https://api.cheaperinference.com/v1/chat/completions`.
- Autenticación Bearer con clave `ci_live_...`.
- Modelo predeterminado: `deepseek-v4-pro`.
- Espacio dedicado en el diálogo API con guardado, prueba y estado DISPONIBLE / SIN PROBAR / ERROR / EN ESPERA.
- Cheaper Inference se guarda como primer proveedor y, si la prueba funciona, queda seleccionado como API activa; las otras APIs siguen como respaldo.
