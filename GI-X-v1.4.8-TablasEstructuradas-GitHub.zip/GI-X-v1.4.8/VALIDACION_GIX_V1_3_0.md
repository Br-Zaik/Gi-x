# GI X v1.3.0
- versionCode: 8
- versionName: 1.3.0
- Imagen se puede abrir completa para revisar el OCR.
- Cuadro OCR y Respuesta expandibles.
- Historial local con registros de preguntas y respuestas.
- Velocidades de voz: 0.25x, 0.50x, 0.75x, 1.00x, 1.25x, 1.50x, 1.75x, 2.00x.
- Aplicado a cámara e imagen manual.
