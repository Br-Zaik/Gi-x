# GI X v1.4.2

- versionCode: 12
- versionName: 1.4.2
- Corrige el rechazo falso de respuestas cuando una hoja contiene varias preguntas mixtas.
- El lote ya no se clasifica como si fuera una sola pregunta de completar/VF/alternativa.
- Acepta 1., 1), Pregunta 1: y etiquetas Respuesta:.
- La palabra Pregunta: ya no se considera fuga interna.
- Mayor margen de tamaño para respuestas de varias preguntas.
- La API de pago permanece ACTIVA si respondió pero el formato local no coincidió.
