# GI X — protocolo de cámara

GI X puede recibir fotos desde una M5Stack Timer Camera X conectada a la Zona Wi‑Fi del mismo celular.

## Flujo recomendado (botón PWR como disparador)

1. El celular activa su Zona Wi‑Fi y mantiene GI X abierto en modo **CÁMARA**.
2. El usuario enciende la Timer Camera X con PWR.
3. La cámara se conecta únicamente al SSID/contraseña grabados en su firmware.
4. Obtiene la IP del celular mediante el gateway de la Zona Wi‑Fi.
5. Consulta una vez si GI X dejó una orden pendiente:
   `GET /camera/poll?token=CLAVE`
6. La cámara estabiliza exposición/balance de blancos y toma una foto JPEG.
7. Envía la foto a:
   `POST /camera/photo?token=CLAVE[&requestId=ID]`
   con `Content-Type: image/jpeg`.
8. GI X responde `RECEIVED` y continúa con OCR -> API -> respuesta -> voz.
9. Tras un envío correcto, el firmware llama `TimerCAM.Power.powerOff()`.

Con batería, la intención es: **PWR -> una foto -> envío -> apagado**. Con alimentación USB externa la cámara puede seguir energizada físicamente, por lo que el firmware entra en espera y no repite fotos.

## Botón PEDIR FOTO

GI X también puede dejar una orden pendiente con un ID. Al encenderse, la cámara consulta `/camera/poll`; si encuentra `CAPTURE|ID`, adjunta ese ID al envío. Si no hay orden, la foto de arranque se envía igualmente.

## Seguridad

- La cámara solo conoce el SSID y contraseña grabados en su firmware.
- GI X exige además una clave de enlace (token). Por defecto: `GIX2026CAM`.
- Si cambias la clave desde **GI X > CÁMARA**, también debes cambiar `GIX_TOKEN` en el firmware.
- El servidor local rechaza fotos mayores de 8 MB.

## Firmware incluido

`camera_firmware/TimerCameraX_GIX.ino`

Antes de grabarlo hay que cambiar:
- `WIFI_NAME`
- `WIFI_PASSWORD`
- `GIX_TOKEN` si cambiaste la clave en la app

El sketch usa la librería oficial `TimerCam-arduino` (`M5TimerCAM.h`).
