# GI X v1.4.4
- versionCode: 14
- versionName: 1.4.4
- Corrección puntual del validador de respuestas múltiples.
- Los marcadores 1), 2), A), B), C), etc. ya no se consideran paréntesis desbalanceados.
- La comprobación de paréntesis reales sigue activa.
- No se modificó timeout, OCR, API, historial ni lógica de una sola solicitud.
