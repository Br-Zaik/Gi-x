# GI X v1.4.1
- versionCode: 11
- versionName: 1.4.1
- RUNTIME_MAX_ATTEMPTS = 1 (una sola solicitud por consulta).
- READ_TIMEOUT_MS = 180000 (3 minutos).
- COMPLEX_READ_TIMEOUT_MS = 240000 (4 minutos para hoja múltiple/consulta compleja).
- CONNECT_TIMEOUT_MS = 20000.
- Sin bloqueo/espera de la API por timeout.
