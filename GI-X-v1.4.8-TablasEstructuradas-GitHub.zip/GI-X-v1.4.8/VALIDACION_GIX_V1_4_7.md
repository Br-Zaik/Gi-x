# GI X v1.4.7
- versionCode: 17
- versionName: 1.4.7
- Mejora 1: el TTS normaliza palabras comunes escritas completamente en MAYÚSCULAS para evitar que se deletreen.
- La normalización afecta solo a la voz; el texto visible y el OCR se conservan sin cambios.
- Siglas técnicas comunes (GPS, GNSS, USB, OCR, PDF, API, IA, etc.) se conservan como siglas.
- Mejora 2: detección reforzada de preguntas sin numeración.
- Se reconocen preguntas con signos ¿?, interrogativas y órdenes como EXPLIQUE, DEFINA, DIFERENCIA ENTRE, CONVERTIR, CALCULE, DETERMINE, MENCIONE, DESCRIBA, entre otras.
- Varias preguntas consecutivas sin 1., 2., 3. se separan en preguntas independientes cuando cada línea inicia claramente una nueva pregunta.
- No se modificó el contenido de las respuestas ni otras funciones de GI X.
