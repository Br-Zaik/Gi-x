# GI X v1.2.3
- versionCode: 6
- versionName: 1.2.3
- UI desplazable y cuadros más grandes.
- Mejor limpieza de claves Cheaper Inference.
