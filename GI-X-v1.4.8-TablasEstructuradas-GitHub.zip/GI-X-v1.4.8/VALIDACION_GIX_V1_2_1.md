# GI X v1.2.1 — corrección de compilación

Corrección aplicada a partir del error real de GitHub Actions de v1.2.0:

- `MainActivity.kt:600:37 Unresolved reference: LayoutParams`
- Se reemplazó `ScrollView.LayoutParams(...)` por `android.widget.FrameLayout.LayoutParams(...)`, que es el tipo de parámetros de layout correcto para un hijo directo de `ScrollView`.
- `versionCode`: 4
- `versionName`: 1.2.1

Se mantuvieron sin cambios funcionales:

- Modo CÁMARA.
- Modo IMAGEN MANUAL.
- OCR con ML Kit y preprocesamiento/doble lectura.
- Cheaper Inference / DeepSeek como proveedor dedicado.
- Gemini, OpenRouter, Mistral y Cohere como proveedores adicionales.
- TTS y flujo OCR → API → respuesta → voz.
- Firmware de Timer Camera X y protocolo Wi‑Fi.

Nota: el entorno local de generación no dispone del Android SDK ni acceso de red para ejecutar una compilación Android completa. La verificación definitiva se realiza con GitHub Actions. Esta versión corrige específicamente el único error Kotlin reportado por la compilación real mostrada por el usuario.
