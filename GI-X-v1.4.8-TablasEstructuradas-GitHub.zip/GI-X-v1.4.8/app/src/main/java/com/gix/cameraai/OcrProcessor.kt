package com.gix.cameraai

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * OCR local mejorado para GI X.
 *
 * Estrategia:
 * 1) normaliza la resolución para que el texto no llegue demasiado pequeño ni enorme;
 * 2) ejecuta ML Kit Text Recognition sobre la imagen normalizada;
 * 3) crea una segunda versión en escala de grises con contraste reforzado;
 * 4) vuelve a reconocer y escoge el resultado más legible mediante una puntuación conservadora.
 *
 * Todo el preprocesado pesado se hace fuera del hilo principal.
 */
class OcrProcessor {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val prepExecutor = Executors.newSingleThreadExecutor()
    private val closed = AtomicBoolean(false)

    fun process(bitmap: Bitmap, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        if (closed.get()) {
            onError("El motor OCR ya fue cerrado")
            return
        }

        prepExecutor.execute {
            try {
                val base = normalizeForOcr(bitmap)
                val enhanced = enhanceForText(base)
                recognize(base) { firstResult, firstError ->
                    recognize(enhanced) { secondResult, secondError ->
                        val best = chooseBest(firstResult, secondResult)
                        val bestText = best?.text.orEmpty()
                        val output = if (best != null && bestText.isNotBlank()) {
                            OcrTableFormatter.addStructuredTables(
                                rawText = cleanText(bestText),
                                result = best,
                                imageWidth = base.width
                            )
                        } else {
                            ""
                        }

                        if (base !== bitmap && !base.isRecycled) base.recycle()
                        if (!enhanced.isRecycled) enhanced.recycle()

                        when {
                            output.isNotBlank() -> onSuccess(output)
                            firstError != null || secondError != null -> {
                                onError(secondError?.message ?: firstError?.message ?: "No se pudo leer el texto")
                            }
                            else -> onSuccess("")
                        }
                    }
                }
            } catch (t: Throwable) {
                onError(t.message ?: "No se pudo preparar la imagen para OCR")
            }
        }
    }

    private fun recognize(bitmap: Bitmap, done: (Text?, Exception?) -> Unit) {
        if (closed.get()) {
            done(null, IllegalStateException("OCR cerrado"))
            return
        }
        val image = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(image)
            .addOnSuccessListener { result -> done(result, null) }
            .addOnFailureListener { error -> done(null, error) }
    }

    private fun normalizeForOcr(source: Bitmap): Bitmap {
        val width = source.width.coerceAtLeast(1)
        val height = source.height.coerceAtLeast(1)
        val longSide = max(width, height)

        // Para texto fotografiado, ~1800-2200 px en el lado largo es un buen equilibrio
        // entre detalle y memoria en teléfonos modestos.
        val desiredLongSide = when {
            longSide < 1200 -> 1800
            longSide > 2400 -> 2200
            else -> longSide
        }
        val scale = desiredLongSide.toFloat() / longSide.toFloat()
        val targetW = max(1, (width * scale).roundToInt())
        val targetH = max(1, (height * scale).roundToInt())

        return if (targetW == width && targetH == height) {
            source.copy(Bitmap.Config.ARGB_8888, false)
        } else {
            Bitmap.createScaledBitmap(source, targetW, targetH, true)
        }
    }

    private fun enhanceForText(source: Bitmap): Bitmap {
        val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        val gray = ColorMatrix().apply { setSaturation(0f) }
        val contrast = 1.32f
        val translate = (-0.5f * contrast + 0.5f) * 255f
        val boost = ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, translate,
                0f, contrast, 0f, 0f, translate,
                0f, 0f, contrast, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            )
        )
        gray.postConcat(boost)
        paint.colorFilter = ColorMatrixColorFilter(gray)
        canvas.drawBitmap(source, 0f, 0f, paint)
        return output
    }

    private fun chooseBest(first: Text?, second: Text?): Text? {
        val a = cleanText(first?.text.orEmpty())
        val b = cleanText(second?.text.orEmpty())
        if (a.isBlank()) return second
        if (b.isBlank()) return first

        val scoreA = score(a)
        val scoreB = score(b)
        return if (scoreB > scoreA + 6) second else first
    }

    private fun score(text: String): Int {
        val trimmed = text.trim()
        if (trimmed.isBlank()) return Int.MIN_VALUE
        val chars = trimmed.length
        val useful = trimmed.count { it.isLetterOrDigit() || it in "¿?¡!.,:;()[]%-+/=" }
        val letters = trimmed.count { it.isLetterOrDigit() }
        val weird = trimmed.count { it == '\uFFFD' || it == '�' }
        val words = trimmed.split(Regex("\\s+")).count { it.length >= 2 }
        val lines = trimmed.lines().count { it.trim().length >= 2 }
        val questionBonus = if ('?' in trimmed || '¿' in trimmed) 18 else 0
        val optionBonus = trimmed.lines().count { Regex("^\\s*(?:[A-Ha-h]|[1-9])[\\)\\].:-]\\s+.+").matches(it) } * 4
        val ratio = if (chars == 0) 0 else (useful * 100 / chars)
        val noisePenalty = max(0, 65 - ratio) * 2 + weird * 20
        return min(chars, 2400) + letters / 2 + words * 3 + min(lines, 20) * 2 + questionBonus + optionBonus - noisePenalty
    }

    private fun cleanText(raw: String): String {
        return raw
            .replace("\r\n", "\n")
            .replace('\r', '\n')
            .lines()
            .map { line -> line.replace(Regex("[ \\t]+"), " ").trimEnd() }
            .dropWhile { it.isBlank() }
            .dropLastWhile { it.isBlank() }
            .joinToString("\n")
            .replace(Regex("\n{3,}"), "\n\n")
            .trim()
    }

    fun close() {
        if (!closed.compareAndSet(false, true)) return
        prepExecutor.shutdownNow()
        recognizer.close()
    }
}
