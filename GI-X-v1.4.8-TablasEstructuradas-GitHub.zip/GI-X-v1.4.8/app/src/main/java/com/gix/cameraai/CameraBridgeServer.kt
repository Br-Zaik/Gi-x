package com.gix.cameraai

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class CameraBridgeServer(
    private val port: Int,
    private val tokenProvider: () -> String,
    private val listener: Listener
) {
    interface Listener {
        fun onServerStarted(port: Int)
        fun onServerError(message: String)
        fun onCameraSeen()
        fun onPhotoReceived(jpeg: ByteArray, requestId: String?)
    }

    private data class CaptureCommand(
        val id: String,
        var delivered: Boolean = false
    )

    private val running = AtomicBoolean(false)
    private val clientPool = Executors.newCachedThreadPool()
    private val commandLock = Any()
    @Volatile private var serverSocket: ServerSocket? = null
    @Volatile private var pendingCapture: CaptureCommand? = null
    @Volatile var lastCameraSeenAt: Long = 0L
        private set

    fun start() {
        if (!running.compareAndSet(false, true)) return
        Thread({
            try {
                val server = ServerSocket(port)
                server.reuseAddress = true
                serverSocket = server
                listener.onServerStarted(port)
                while (running.get()) {
                    val socket = try {
                        server.accept()
                    } catch (_: Exception) {
                        if (!running.get()) break else continue
                    }
                    clientPool.execute { handleClient(socket) }
                }
            } catch (e: Exception) {
                if (running.get()) listener.onServerError(e.message ?: "No se pudo iniciar el servidor local")
            } finally {
                running.set(false)
            }
        }, "gix-camera-server").apply { isDaemon = true }.start()
    }

    fun stop() {
        running.set(false)
        runCatching { serverSocket?.close() }
        serverSocket = null
        clientPool.shutdownNow()
    }

    fun requestCapture(): String {
        val id = UUID.randomUUID().toString().replace("-", "").take(10)
        synchronized(commandLock) {
            pendingCapture = CaptureCommand(id)
        }
        return id
    }

    fun cancelCapture() {
        synchronized(commandLock) { pendingCapture = null }
    }

    fun isCameraConnected(maxAgeMs: Long = 8_000L): Boolean {
        val seen = lastCameraSeenAt
        return seen > 0L && System.currentTimeMillis() - seen <= maxAgeMs
    }

    private fun handleClient(socket: Socket) {
        socket.use { client ->
            client.soTimeout = 12_000
            val input = BufferedInputStream(client.getInputStream())
            val output = BufferedOutputStream(client.getOutputStream())
            try {
                val requestLine = readLine(input) ?: return
                val parts = requestLine.split(" ")
                if (parts.size < 2) {
                    send(output, 400, "text/plain", "BAD REQUEST".toByteArray())
                    return
                }
                val method = parts[0].uppercase()
                val target = parts[1]
                val headers = linkedMapOf<String, String>()
                while (true) {
                    val line = readLine(input) ?: break
                    if (line.isEmpty()) break
                    val colon = line.indexOf(':')
                    if (colon > 0) {
                        headers[line.substring(0, colon).trim().lowercase()] = line.substring(colon + 1).trim()
                    }
                }

                val path = target.substringBefore('?')
                val query = parseQuery(target.substringAfter('?', ""))
                val token = query["token"].orEmpty()

                if (path == "/health") {
                    send(output, 200, "text/plain", "GI X OK".toByteArray())
                    return
                }

                if (!secureEquals(token, tokenProvider().trim())) {
                    send(output, 403, "text/plain", "FORBIDDEN".toByteArray())
                    return
                }

                when {
                    method == "GET" && path == "/camera/poll" -> {
                        markCameraSeen()
                        val response = synchronized(commandLock) {
                            val cmd = pendingCapture
                            if (cmd != null && !cmd.delivered) {
                                cmd.delivered = true
                                "CAPTURE|${cmd.id}"
                            } else {
                                "WAIT"
                            }
                        }
                        send(output, 200, "text/plain", response.toByteArray(StandardCharsets.UTF_8))
                    }

                    method == "POST" && path == "/camera/register" -> {
                        markCameraSeen()
                        consumeBody(input, headers)
                        send(output, 200, "text/plain", "OK".toByteArray())
                    }

                    method == "POST" && path == "/camera/photo" -> {
                        markCameraSeen()
                        val contentLength = headers["content-length"]?.toIntOrNull() ?: 0
                        if (contentLength <= 0) {
                            send(output, 411, "text/plain", "CONTENT LENGTH REQUIRED".toByteArray())
                            return
                        }
                        if (contentLength > MAX_JPEG_BYTES) {
                            send(output, 413, "text/plain", "PHOTO TOO LARGE".toByteArray())
                            return
                        }
                        val jpeg = readExactly(input, contentLength)
                        if (jpeg.size != contentLength) {
                            send(output, 400, "text/plain", "INCOMPLETE PHOTO".toByteArray())
                            return
                        }
                        val requestId = query["requestId"]
                        synchronized(commandLock) {
                            if (requestId != null && pendingCapture?.id == requestId) {
                                pendingCapture = null
                            }
                        }
                        send(output, 200, "text/plain", "RECEIVED".toByteArray())
                        listener.onPhotoReceived(jpeg, requestId)
                    }

                    else -> send(output, 404, "text/plain", "NOT FOUND".toByteArray())
                }
            } catch (e: Exception) {
                runCatching { send(output, 500, "text/plain", "ERROR".toByteArray()) }
            }
        }
    }

    private fun markCameraSeen() {
        lastCameraSeenAt = System.currentTimeMillis()
        listener.onCameraSeen()
    }

    private fun consumeBody(input: BufferedInputStream, headers: Map<String, String>) {
        val length = headers["content-length"]?.toIntOrNull()?.coerceIn(0, 4096) ?: return
        if (length > 0) readExactly(input, length)
    }

    private fun readExactly(input: BufferedInputStream, length: Int): ByteArray {
        val result = ByteArray(length)
        var offset = 0
        while (offset < length) {
            val count = input.read(result, offset, length - offset)
            if (count <= 0) break
            offset += count
        }
        return if (offset == length) result else result.copyOf(offset)
    }

    private fun readLine(input: BufferedInputStream): String? {
        val bytes = ArrayList<Byte>(128)
        while (bytes.size < 8192) {
            val value = input.read()
            if (value == -1) {
                if (bytes.isEmpty()) return null
                break
            }
            if (value == '\n'.code) break
            if (value != '\r'.code) bytes.add(value.toByte())
        }
        return bytes.toByteArray().toString(StandardCharsets.UTF_8)
    }

    private fun parseQuery(raw: String): Map<String, String> {
        if (raw.isBlank()) return emptyMap()
        return raw.split('&').mapNotNull { part ->
            val key = part.substringBefore('=', "").trim()
            if (key.isBlank()) return@mapNotNull null
            val value = part.substringAfter('=', "")
            decode(key) to decode(value)
        }.toMap()
    }

    private fun decode(value: String): String = runCatching {
        URLDecoder.decode(value, StandardCharsets.UTF_8.name())
    }.getOrDefault(value)

    private fun secureEquals(a: String, b: String): Boolean {
        if (a.length != b.length || a.isEmpty()) return false
        var diff = 0
        for (i in a.indices) diff = diff or (a[i].code xor b[i].code)
        return diff == 0
    }

    private fun send(output: BufferedOutputStream, code: Int, contentType: String, body: ByteArray) {
        val reason = when (code) {
            200 -> "OK"
            400 -> "Bad Request"
            403 -> "Forbidden"
            404 -> "Not Found"
            411 -> "Length Required"
            413 -> "Payload Too Large"
            else -> "Server Error"
        }
        val header = buildString {
            append("HTTP/1.1 $code $reason\r\n")
            append("Content-Type: $contentType; charset=utf-8\r\n")
            append("Content-Length: ${body.size}\r\n")
            append("Connection: close\r\n")
            append("Cache-Control: no-store\r\n\r\n")
        }.toByteArray(StandardCharsets.UTF_8)
        output.write(header)
        output.write(body)
        output.flush()
    }

    companion object {
        const val DEFAULT_PORT = 8765
        private const val MAX_JPEG_BYTES = 8 * 1024 * 1024
    }
}
