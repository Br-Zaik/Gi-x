package com.gix.cameraai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class HistoryEntry(
    val id: String,
    val timestamp: Long,
    val source: String,
    val questionCount: Int,
    val ocrText: String,
    val answerText: String
)

class HistoryRepository(context: Context) {
    private val prefs = context.getSharedPreferences("gix_history", Context.MODE_PRIVATE)

    fun getAll(): List<HistoryEntry> {
        val raw = prefs.getString(KEY_HISTORY, "[]").orEmpty()
        return runCatching {
            val array = JSONArray(raw)
            val items = mutableListOf<HistoryEntry>()
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                items += HistoryEntry(
                    id = obj.optString("id", System.currentTimeMillis().toString()),
                    timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                    source = obj.optString("source", "desconocido"),
                    questionCount = obj.optInt("questionCount", 0),
                    ocrText = obj.optString("ocrText"),
                    answerText = obj.optString("answerText")
                )
            }
            items.sortedByDescending { it.timestamp }
        }.getOrElse { emptyList() }
    }

    fun add(entry: HistoryEntry) {
        val list = getAll().toMutableList()
        list.add(0, entry)
        save(list.take(MAX_ITEMS))
    }

    fun delete(id: String) {
        save(getAll().filterNot { it.id == id })
    }

    fun clear() {
        prefs.edit().putString(KEY_HISTORY, "[]").apply()
    }

    private fun save(entries: List<HistoryEntry>) {
        val array = JSONArray()
        entries.forEach { entry ->
            array.put(
                JSONObject().apply {
                    put("id", entry.id)
                    put("timestamp", entry.timestamp)
                    put("source", entry.source)
                    put("questionCount", entry.questionCount)
                    put("ocrText", entry.ocrText)
                    put("answerText", entry.answerText)
                }
            )
        }
        prefs.edit().putString(KEY_HISTORY, array.toString()).apply()
    }

    companion object {
        private const val KEY_HISTORY = "history_entries"
        private const val MAX_ITEMS = 40
    }
}
