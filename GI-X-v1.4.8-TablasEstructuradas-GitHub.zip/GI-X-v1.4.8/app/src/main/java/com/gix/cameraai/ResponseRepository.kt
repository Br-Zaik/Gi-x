package com.gix.cameraai

import java.text.Normalizer

class ResponseRepository private constructor() {
    companion object {
        fun normalize(text: String): String {
            return Normalizer.normalize(text.lowercase(), Normalizer.Form.NFD)
                .replace("\\p{InCombiningDiacriticalMarks}+".toRegex(), "")
                .replace("[^a-z0-9ñ ]".toRegex(), " ")
                .replace("\\s+".toRegex(), " ")
                .trim()
        }
    }
}
