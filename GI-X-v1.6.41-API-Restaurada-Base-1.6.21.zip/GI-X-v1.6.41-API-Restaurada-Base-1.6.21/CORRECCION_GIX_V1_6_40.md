# GI X v1.6.40 — prueba API sin falso timeout

## Causa hallada en v1.6.39
La prueba de API tenía `readTimeout = 15000 ms`, 2 intentos y `max_tokens = 64` con DeepSeek V4 Flash, un modelo de razonamiento. También reservaba la ruta `reasoning_effort=minimal` / `ranking=speed` solo para consultas normales, no para la prueba. Así se podía rechazar una clave válida por una prueba excesivamente corta, sin recibir nunca un código HTTP.

## Correcciones limitadas a la prueba / proveedor
- Conservar clave, endpoint y modelo actual.
- Aplicar ruta rápida y razonamiento mínimo también en la prueba.
- Dar margen real a modelo de razonamiento: 512 tokens de salida en prueba, 90 segundos de espera de lectura por socket (no es espera obligatoria: si responde pronto termina de inmediato).
- Una sola prueba por toque para no cobrar múltiples veces automáticamente; la app no bloquea ni borra clave ante timeout.
- También se corrigen falsos timeout de respuestas reales (45s → 90s y consultas complejas 60s → 120s). Estos límites no son esperas obligatorias: termina al recibir datos.
- Diferenciar timeout sin HTTP de 5xx recibido; no afirmar saturación del servidor sin evidencia.
- Versión visible v1.6.40, code 65.

## No se tocó
Cámara, identificador de lote, visión IA, OCR secundario, reproducción de voz, velocidad, bloqueo, colas, ni el protocolo de firmware.

## Verificación necesaria
No se hizo consulta con la clave privada ni prueba física del hotspot/datos móviles. Compilar en GitHub Actions y hacer prueba de API guardada. Si sigue fallando, diagnosticar la ruta de datos móviles sin compartir la clave en capturas.
