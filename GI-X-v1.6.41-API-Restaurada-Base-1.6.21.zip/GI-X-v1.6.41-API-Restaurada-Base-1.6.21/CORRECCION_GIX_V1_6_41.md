# GI X v1.6.41 — API restaurada desde la base funcional v1.6.21

Se comparó directamente `GI-X-v1.6.21-Fix-Compilacion-Vision` (reportada como funcional) contra v1.6.40.

Regresiones encontradas y revertidas en la capa API:

1. Se había sustituido `url.openConnection()` por una selección manual de `Network.openConnection()` para datos móviles. Se restaura el enrutamiento normal de Android usado en v1.6.21.
2. Se había añadido `ranking: speed` a las solicitudes de Cheaper Inference y también `reasoning_effort` durante la prueba de API. Esos campos no estaban en la versión funcional. Se restaura el cuerpo de solicitud de v1.6.21.
3. Se había eliminado el encabezado `X-CI-Concise: 1` de las consultas reales. Se restaura tal como estaba en v1.6.21.
4. Se había habilitado transporte SSE/streaming para respuestas de Cheaper Inference. Se vuelve a JSON normal (`stream=false`) para priorizar estabilidad. La interfaz sigue aceptando el callback, pero la respuesta se entrega al finalizar la llamada.
5. La prueba había cambiado de 64 a 512 tokens y de 15 s a 90 s. Se restauran los valores de la versión funcional: 64 tokens, 15 s por intento y 2 intentos.
6. Los tiempos de lectura normales vuelven a 45 s / 60 s, como en v1.6.21, para no dejar la interfaz esperando durante 90–120 s por una solicitud rota.

No se revirtieron las mejoras posteriores de cámara, lote 1–4, contexto/preguntas, bloqueo ni voz.
