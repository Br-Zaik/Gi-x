# GI X v1.6.43 — Últimas imágenes tienen prioridad

Cambios solicitados para cámara y modo manual:

- Se eliminan las colas de documentos. El último lote de imágenes sustituye al anterior.
- Una entrada nueva cancela la espera de API, invalida OCR/resultados antiguos y detiene el TTS anterior.
- Cada trabajo usa un `workId`; cualquier respuesta tardía de un trabajo cancelado se descarta y nunca se muestra ni se reproduce.
- El ejecutor de API permite iniciar el trabajo nuevo aunque el socket anterior todavía esté terminando de liberarse.
- En cámara, las 1–4 fotos del mismo `requestId` siguen formando un único documento; el primer JPEG de un documento nuevo cancela el ciclo anterior.
- En manual, elegir nuevas imágenes cancela el ciclo anterior antes de empezar.
- Se refuerza la visión para considerar afirmaciones V/F, ítems numerados, casillas y alternativas como preguntas aunque parezcan texto normal.
- El extractor incorpora un rescate para exámenes que el modelo coloque por error en `CONTEXTO DETECTADO`; si hay estructura evaluativa, GI X no los descarta como simple texto.
- No se cambian clave/modelo API, bloqueo, configuración de voz ni firmware de la cámara.

Versión Android: `1.6.43` (`versionCode 68`).
