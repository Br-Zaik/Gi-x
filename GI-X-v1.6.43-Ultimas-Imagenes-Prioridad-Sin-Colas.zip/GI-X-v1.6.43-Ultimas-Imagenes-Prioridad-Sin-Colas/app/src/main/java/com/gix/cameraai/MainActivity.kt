package com.gix.cameraai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.gix.cameraai.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.Executors
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener, CameraBridgeServer.Listener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: AppPrefs
    private lateinit var apiSettings: GeminiSettings
    private lateinit var onlineProvider: OnlineAnswerProvider
    private val cameraServer: CameraBridgeServer?
        get() = CameraLinkService.currentServer()
    private lateinit var cameraJournal: CameraPhotoJournal
    private var activeCameraPhotoIds: List<String> = emptyList()
    // No borrar una fotografía hasta tener una respuesta COMPLETA y voz finalizada.
    private var cameraAnswerComplete = false
    private val observedJournalIds = mutableSetOf<String>()
    private val completedCameraPhotoIds = java.util.Collections.synchronizedSet(linkedSetOf<String>())
    private var lastJournalSweepAtMs = 0L
    private var lastSevereThermal = false
    private lateinit var historyRepository: HistoryRepository
    private lateinit var ocrProcessor: OcrProcessor
    // v1.6.43: varios workers permiten que un lote NUEVO empiece aunque una llamada
    // antigua tarde en liberar su socket. Los resultados viejos se invalidan por workId.
    private val ioExecutor = Executors.newFixedThreadPool(3)
    private val cameraIoExecutor = Executors.newSingleThreadExecutor()
    private val galleryExecutor = ThreadPoolExecutor(
        1,
        1,
        0L,
        TimeUnit.MILLISECONDS,
        ArrayBlockingQueue<Runnable>(4),
        ThreadPoolExecutor.DiscardOldestPolicy(),
    )
    private val recentPhotoDeduper = RecentPhotoDeduper()
    private val cameraBatchCollector = ArrayDeque<QueuedCameraPhoto>()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val processing = AtomicBoolean(false)
    // "Último lote gana": cada entrada nueva invalida inmediatamente cualquier OCR/API/voz anterior.
    private val workGeneration = AtomicLong(0L)
    private var cameraCollectorWorkId: Long = 0L
    private var latestThermalCameraBatch: QueuedCameraBatch? = null

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsInitializing = false
    private var pendingSpeechText: String? = null
    private var activeSpeechText: String? = null
    private var activeSpeechFinalId: String? = null
    private var speechRetryCount = 0
    private var speechSessionId = 0L
    private var speechRecoveryInProgress = false
    private var isSpeakingAnswer = false
    private var autoMode = true
    private var stopped = false
    @Volatile private var destroyedForAsync = false
    private var inputMode = InputMode.CAMERA
    @Volatile private var activeCaptureRequestId: String? = null
    private var cameraStatusTicker: Runnable? = null
    private var lastExtractedQuestions: List<String> = emptyList()
    private var previewBitmap: Bitmap? = null
    private var batchPreviewBitmaps: List<Bitmap> = emptyList()
    private var lastDisplayedOcrText: String = ""
    private var lastSourceLabel: String = "desconocido"
    private var pendingOcrDisplayOverride: String? = null
    private var pendingDocumentContext: String? = null
    private var pendingReview: PreparedAnswerRequest? = null

    private data class PreparedAnswerRequest(
        val workId: Long,
        val questions: List<String>,
        val context: String,
        val batchInfo: String?,
        val missingNumbers: List<Int>,
        val coverageNote: String?,
    )
    private var pendingBatchInfo: String? = null
    private var pendingMissingQuestionNumbers: List<Int> = emptyList()
    private var pendingCoverageNote: String? = null
    private var lockAppOnScreen = false
    private var touchGuard: View? = null
    private var protectedCameraView: TextView? = null
    private var protectedProcessView: TextView? = null
    private var protectedQuestionsView: TextView? = null
    private var protectedAnswersView: TextView? = null
    private var protectedPreviewView: ImageView? = null
    private var protectedPreviewBitmap: Bitmap? = null
    private var receivedCameraPhotoCount = 0
    private var lastCameraPhotoAtMs = 0L
    private var unlockTapCount = 0
    private var lastUnlockTapAtMs = 0L
    // Guardar lo ya pronunciado de cada respuesta progresiva; solo leer la parte nueva.
    private val liveSpokenAnswers = linkedMapOf<String, String>()
    private var liveAnswerSpeechUsed = false
    // La última frase provisional puede terminar ANTES que el streaming de la API.
    // Solo una respuesta final y audio completado confirman el lote de cámara.
    private var answerPipelineFinished = false
    private var speechFailedForCurrentDocument = false
    private var backPressCount = 0
    private var lastBackPressAtMs = 0L
    private var cameraBatchFinalizeRunnable: Runnable? = null
    private var cameraBatchOpenedAtMs: Long = 0L

    private data class QueuedCameraPhoto(
        val jpeg: ByteArray,
        val source: String,
        val requestId: String? = null,
        val journalId: String? = null,
    )

    private data class QueuedCameraBatch(
        val photos: List<QueuedCameraPhoto>,
        val label: String,
        val workId: Long,
    )

    private data class ManualBatchOcrItem(
        val rawText: String,
        val quality: OcrProcessor.ImageQualityReport,
    )

    private val openPhotosLauncher = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isEmpty()) return@registerForActivityResult
        loadPhotosFromUris(uris)
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* Si deniega, Android aún permite FGS, pero podría ocultar la notificación. */ }

    private val legacyGalleryPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (::binding.isInitialized && !granted) {
            binding.tvStatus.text = "GI X seguirá funcionando, pero Android no permitió guardar fotos en Galería."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        // Use the installed APK's actual version, never a stale XML label.
        binding.tvVersion.text = "v${packageManager.getPackageInfo(packageName, 0).versionName}"

        prefs = AppPrefs(this)
        cameraJournal = CameraPhotoJournal(this)
        apiSettings = GeminiSettings(this)
        onlineProvider = OnlineAnswerProvider(this)
        historyRepository = HistoryRepository(this)
        ocrProcessor = OcrProcessor(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            legacyGalleryPermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        ttsInitializing = true
        tts = TextToSpeech(this, this)

        // Limpia estados antiguos de "espera" de la API pagada sin borrar la clave.
        apiSettings.getApiConfigs()
            .filter { it.provider == NetProvider.CHEAPER_INFERENCE }
            .forEach { apiSettings.shouldSkip(it) }

        setupButtons()
        setupInternalScroll(binding.svOcr)
        setupInternalScroll(binding.svAnswer)
        renderHistory()
        updateApiChip()
        startCameraServer()
        startCameraStatusTicker()
        // Si Android recreó la UI, recuperar originales guardados por el servicio.
        mainHandler.postDelayed({ if (!stopped) restoreJournaledCameraPhotos() }, 1_000L)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun setupButtons() {
        binding.inputModeGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            when (checkedId) {
                R.id.btnModeCamera -> setInputMode(InputMode.CAMERA)
                R.id.btnModeImage -> setInputMode(InputMode.IMAGE)
            }
        }
        binding.inputModeGroup.check(R.id.btnModeCamera)

        // La TimerCamera-X sube su JPEG al encender, sin solicitarlo desde el móvil.
        // La app ya está escuchando desde startCameraServer(), incluso si está resolviendo
        // otra foto: una entrada nueva reemplaza de inmediato el trabajo anterior; no hay cola de documentos.
        binding.btnCapture.visibility = View.GONE
        binding.btnAuto.text = "🔒 BLOQUEAR GI X"
        binding.btnAuto.setOnClickListener {
            if (lockAppOnScreen) requestUnlockTouchGuard() else enableTouchGuard()
        }
        binding.btnStop.visibility = View.GONE
        binding.btnStop.setOnClickListener { confirmExitApp() }

        binding.btnChooseImage.setOnClickListener {
            stopped = false
            openPhotosLauncher.launch(arrayOf("image/*"))
        }

        binding.btnApi.setOnClickListener { showApiDialog() }
        binding.btnVoice.setOnClickListener { showVoiceDialog() }
        binding.btnCameraSettings.setOnClickListener { showCameraDialog() }
        binding.btnOpenPreview.setOnClickListener { showPreviewDialog() }
        binding.btnClearHistory.setOnClickListener { confirmClearHistory() }
        // GI X funciona sin confirmaciones: el documento visible es una vista informativa,
        // no una barrera. La preferencia antigua de revisión no debe pausar cámara ni manual.
        binding.cbReviewBeforeApi.isChecked = false
        binding.cbReviewBeforeApi.visibility = View.GONE
        binding.reviewActions.visibility = View.GONE
        binding.btnApproveOcr.setOnClickListener {
            if (lockAppOnScreen) return@setOnClickListener
            val request = pendingReview ?: return@setOnClickListener
            pendingReview = null
            binding.reviewActions.visibility = View.GONE
            sendPreparedDocumentToApi(request)
        }
        binding.btnDiscardOcr.setOnClickListener {
            if (lockAppOnScreen) return@setOnClickListener
            pendingReview = null
            binding.reviewActions.visibility = View.GONE
            processing.set(false)
            binding.tvStatus.text = "Consulta descartada. No se hizo una llamada de respuestas a la API."
            binding.tvAnswer.text = "Revisión cancelada; GI X sigue listo para nuevas fotos."
            scheduleNextAutoIfNeeded()
        }
        binding.btnEditOcr.setOnClickListener {
            if (!lockAppOnScreen) editPendingDocument()
        }
        binding.btnToggleOcr.visibility = View.VISIBLE
        binding.btnToggleOcr.setOnClickListener {
            if (!lockAppOnScreen) showFullDocumentPreview()
        }

        // La protección nueva se activa desde BLOQUEAR TOQUES y cubre la pantalla.
        binding.cbLockApp.visibility = View.GONE
    }

    private fun setInputMode(mode: InputMode) {
        if (inputMode == mode && binding.cameraActions.visibility == if (mode == InputMode.CAMERA) View.VISIBLE else View.GONE) {
            return
        }
        inputMode = mode
        when (mode) {
            InputMode.CAMERA -> {
                binding.cameraActions.visibility = View.VISIBLE
                binding.btnAuto.visibility = View.VISIBLE
                binding.btnStop.visibility = View.GONE
                binding.btnChooseImage.visibility = View.GONE
                autoMode = true
                stopped = false
                // Espera automática de fotografías en cuanto el modo CÁMARA está activo.
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                binding.tvStatus.text = "Cámara automática: esperando foto. Activa tu Zona Wi-Fi y deja GI X abierto."
            }
            InputMode.IMAGE -> {
                autoMode = false
                releaseScreenAwakeIfAllowed()
                cameraServer?.cancelCapture()
                activeCaptureRequestId = null
                binding.cameraActions.visibility = View.GONE
                binding.btnChooseImage.visibility = View.VISIBLE
                binding.tvStatus.text = "Modo IMAGEN MANUAL. Puedes elegir de 1 a 4 imágenes del mismo documento. GI X las une, ordena y evita duplicados."
            }
        }
    }

    private fun startCameraServer() {
        CameraLinkService.attach(this)
        // Se inicia desde Activity visible (cumple restricciones de inicio en Android 12+).
        ContextCompat.startForegroundService(this, Intent(this, CameraLinkService::class.java))
    }

    private fun restoreJournaledCameraPhotos(): Boolean {
        // Leer solo 4 JPEG por ciclo: nunca cargar 150 MB al mismo tiempo en UI.
        val toRestore = cameraJournal.pendingIds()
            .filterNot { it in observedJournalIds }.take(MAX_CAMERA_BATCH_IMAGES)
        if (toRestore.isEmpty()) return false
        for (id in toRestore) {
            val entry = cameraJournal.read(id) ?: continue
            observedJournalIds.add(id)
            // La entrega puede haber ocurrido hace segundos antes de recrearse la UI.
            if (recentPhotoDeduper.isDuplicate(entry.jpeg)) continue
            enqueueCameraPhotoForBatch(QueuedCameraPhoto(entry.jpeg, "cámara recuperada", entry.requestId, entry.id))
        }
        return true
    }

    private fun isThermallySevere(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        val power = getSystemService(Context.POWER_SERVICE) as PowerManager
        return power.currentThermalStatus >= PowerManager.THERMAL_STATUS_SEVERE
    }

    private fun startCameraStatusTicker() {
        val ticker = object : Runnable {
            override fun run() {
                updateCameraChip()
                refreshProtectedScreen()
                val now = System.currentTimeMillis()
                if (!stopped && inputMode == InputMode.CAMERA &&
                    now - lastJournalSweepAtMs >= 10_000L &&
                    !processing.get() && !isSpeakingAnswer &&
                    pendingSpeechText.isNullOrBlank() &&
                    cameraBatchCollector.isEmpty() && latestThermalCameraBatch == null) {
                    lastJournalSweepAtMs = now
                    restoreJournaledCameraPhotos()
                }
                val severe = isThermallySevere()
                if (severe != lastSevereThermal) {
                    lastSevereThermal = severe
                    binding.tvStatus.text = if (severe) {
                        "Temperatura elevada: guardando fotos y pausando tareas nuevas hasta enfriarse."
                    } else "Temperatura normal. GI X continúa con fotos pendientes."
                    if (!severe) scheduleNextAutoIfNeeded()
                }
                mainHandler.postDelayed(this, 2_000L)
            }
        }
        cameraStatusTicker = ticker
        mainHandler.post(ticker)
    }

    private fun requestCameraCapture(manual: Boolean) {
        if (processing.get()) {
            binding.tvStatus.text = "Espera: GI X todavía está procesando la foto anterior."
            return
        }
        if (activeCaptureRequestId != null) {
            binding.tvStatus.text = "Ya hay una foto solicitada. Esperando a la cámara..."
            return
        }

        val server = cameraServer ?: run {
            binding.tvStatus.text = "Servidor reiniciando, espera unos segundos."
            return
        }
        val requestId = server.requestCapture()
        activeCaptureRequestId = requestId
        binding.tvStatus.text = if (cameraServer?.isCameraConnected() == true) {
            "Orden enviada. Esperando la foto de Timer Camera X..."
        } else {
            "Orden preparada. Enciende la cámara y verifica que esté conectada a tu Zona Wi-Fi."
        }

        mainHandler.postDelayed({
            if (activeCaptureRequestId == requestId) {
                cameraServer?.cancelCapture()
                activeCaptureRequestId = null
                if (!processing.get()) {
                    binding.tvStatus.text = if (manual) {
                        "La cámara no respondió. Revisa Zona Wi-Fi, cámara y clave de enlace."
                    } else {
                        "Auto: cámara sin respuesta. Reintentaré cuando vuelva a estar disponible."
                    }
                }
            }
        }, 25_000L)
    }

    private fun isWorkCurrent(workId: Long): Boolean {
        return workId > 0L && workGeneration.get() == workId && !stopped && !destroyedForAsync
    }

    private fun finishProcessingIfCurrent(workId: Long) {
        if (workGeneration.get() == workId) processing.set(false)
    }

    private fun discardCameraCollector() {
        cameraBatchFinalizeRunnable?.let { mainHandler.removeCallbacks(it) }
        cameraBatchFinalizeRunnable = null
        val ids = cameraBatchCollector.mapNotNull { it.journalId }
        if (ids.isNotEmpty()) {
            cameraJournal.acknowledge(ids)
            observedJournalIds.removeAll(ids.toSet())
        }
        cameraBatchCollector.clear()
        cameraBatchOpenedAtMs = 0L
        cameraCollectorWorkId = 0L
    }

    /**
     * v1.6.43 - política "último lote gana".
     * Una entrada nueva corta API/voz/trabajo anterior y NO se guarda detrás de una cola.
     */
    private fun beginLatestInput(source: String): Long {
        stopped = false
        val workId = workGeneration.incrementAndGet()

        // Cortar de inmediato cualquier POST/espera antigua. Si el proveedor ya recibió
        // la petición podría terminarla por su lado, pero GI X jamás mostrará su respuesta.
        onlineProvider.cancelActiveRequest()
        runCatching { tts?.stop() }
        speechSessionId += 1L
        pendingSpeechText = null
        activeSpeechText = null
        activeSpeechFinalId = null
        isSpeakingAnswer = false
        speechRetryCount = 0
        speechRecoveryInProgress = false
        answerPipelineFinished = false
        speechFailedForCurrentDocument = false
        resetLiveAnswerSpeech()

        // El lote anterior de cámara queda abandonado por decisión del usuario/nueva toma.
        val oldIds = activeCameraPhotoIds
        if (oldIds.isNotEmpty()) {
            cameraJournal.acknowledge(oldIds)
            observedJournalIds.removeAll(oldIds.toSet())
        }
        activeCameraPhotoIds = emptyList()
        cameraAnswerComplete = false

        // No hay cola: también se descarta cualquier lote aún en agrupación.
        discardCameraCollector()
        latestThermalCameraBatch = null

        processing.set(false)
        pendingOcrDisplayOverride = null
        pendingDocumentContext = null
        pendingReview = null
        binding.reviewActions.visibility = View.GONE
        pendingBatchInfo = null
        pendingMissingQuestionNumbers = emptyList()
        pendingCoverageNote = null

        binding.tvStatus.text = "Nuevas imágenes ($source): cancelando lo anterior y dando prioridad al lote nuevo..."
        return workId
    }

    private fun stopCurrentCycle() {
        stopped = true
        workGeneration.incrementAndGet()
        autoMode = false
        // La salida confirmada cancela el ciclo y permite descansar la pantalla.
        if (!lockAppOnScreen) window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        cameraServer?.cancelCapture()
        activeCaptureRequestId = null
        onlineProvider.cancelActiveRequest()
        tts?.stop()
        pendingSpeechText = null
        activeSpeechText = null
        activeSpeechFinalId = null
        isSpeakingAnswer = false
        speechRetryCount = 0
        speechRecoveryInProgress = false
        ttsInitializing = false
        processing.set(false)
        pendingOcrDisplayOverride = null
        pendingDocumentContext = null
        pendingReview = null
        binding.reviewActions.visibility = View.GONE
        pendingBatchInfo = null
        pendingMissingQuestionNumbers = emptyList()
        pendingCoverageNote = null
        activeCameraPhotoIds = emptyList()
        cameraBatchCollector.clear()
        cameraBatchFinalizeRunnable?.let { mainHandler.removeCallbacks(it) }
        cameraBatchFinalizeRunnable = null
        // Solo SALIR explícito termina el servicio: no hacerlo en onDestroy accidental.
        stopService(Intent(this, CameraLinkService::class.java))
        binding.tvStatus.text = if (inputMode == InputMode.CAMERA) {
            "Detenido. Vuelve a encender la cámara cuando quieras otra foto."
        } else {
            "Detenido. Pulsa ELEGIR 1–4 IMÁGENES cuando quieras continuar."
        }
    }

    override fun onServerStarted(port: Int) {
        runOnUiThread {
            if (inputMode == InputMode.CAMERA) {
                binding.tvStatus.text = "GI X listo. Activa tu Zona Wi-Fi y enciende la cámara; recibirá la foto por el puerto $port."
            }
        }
    }

    override fun onServerError(message: String) {
        runOnUiThread {
            binding.tvStatus.text = "Error del enlace con cámara: $message"
            binding.tvCameraChip.text = "Cámara: error"
        }
    }

    override fun onCameraSeen() {
        runOnUiThread { updateCameraChip() }
    }

    override fun onPhotoReceived(jpeg: ByteArray, requestId: String?) {
        activeCaptureRequestId = null

        // La cámara puede reenviar el MISMO JPEG si la red falla. Lo confirmamos,
        // pero no repetimos OCR/API/voz si el contenido es idéntico.
        if (recentPhotoDeduper.isDuplicate(jpeg)) {
            // Si ya terminó el audio y se confirmó el lote, un reenvío Wi-Fi
            // no debe dejar en disco una foto nueva que nadie consumirá.
            val id = cameraJournal.idFor(jpeg)
            if (completedCameraPhotoIds.contains(id)) cameraJournal.acknowledge(listOf(id))
            runOnUiThread {
                if (!destroyedForAsync) binding.tvStatus.text =
                    "Foto reenviada por Wi-Fi: GI X evitó duplicar la consulta."
            }
            return
        }

        cameraIoExecutor.execute {
            // Validación de dimensiones SIN expandir el JPEG completo a memoria. La v1.6.8
            // hacía aquí una decodificación ARGB_8888 completa antes incluso de encolar.
            val info = CameraJpegDecoder.inspect(jpeg)
            if (info == null) {
                runOnUiThread {
                    binding.tvStatus.text = "La cámara envió una imagen JPEG inválida o demasiado grande."
                }
                return@execute
            }

            // El guardado en Galería ya no bloquea la recepción del siguiente JPEG ni el
            // inicio del OCR. El ByteArray recibido es propio de esta petición; no hace
            // falta duplicarlo con copyOf(), ahorrando memoria cuando llegan varias fotos.
            runCatching {
                galleryExecutor.execute {
                    CameraPhotoStore.save(this, jpeg)
                }
            }

            runOnUiThread {
                // Una foto física de la TimerCamera siempre tiene prioridad y activa el
                // modo CÁMARA aunque el usuario hubiera dejado la pantalla en MANUAL.
                if (inputMode != InputMode.CAMERA) {
                    binding.inputModeGroup.check(R.id.btnModeCamera)
                }

                val journalId = cameraJournal.idFor(jpeg)
                observedJournalIds.add(journalId)
                receivedCameraPhotoCount++
                lastCameraPhotoAtMs = System.currentTimeMillis()
                refreshProtectedScreen()
                enqueueCameraPhotoForBatch(
                    QueuedCameraPhoto(jpeg, "cámara", requestId, journalId)
                )
            }
        }
    }

    private fun enqueueCameraPhotoForBatch(photo: QueuedCameraPhoto) {
        val incomingRequestId = photo.requestId?.trim().orEmpty()
        val currentRequestId = cameraBatchCollector.firstOrNull()?.requestId?.trim().orEmpty()

        // La primera foto de un documento NUEVO toma prioridad al instante. Si ya había
        // OCR/API/voz del documento anterior, se corta en este momento, no al finalizar 4 fotos.
        val startsNewDocument = cameraBatchCollector.isEmpty() ||
            CameraBatchPolicy.mustSplit(currentRequestId, incomingRequestId)

        if (startsNewDocument) {
            cameraCollectorWorkId = beginLatestInput("cámara")
            cameraBatchOpenedAtMs = System.currentTimeMillis()
        }

        // Protocolo GI X: máximo cuatro imágenes por documento. Una quinta toma se considera
        // una entrada nueva y reemplaza completamente el trabajo anterior.
        if (cameraBatchCollector.size >= MAX_CAMERA_BATCH_IMAGES) {
            cameraCollectorWorkId = beginLatestInput("cámara")
            cameraBatchOpenedAtMs = System.currentTimeMillis()
        }

        cameraBatchCollector.addLast(photo)
        val received = cameraBatchCollector.size
        binding.tvStatus.text = if (received < MAX_CAMERA_BATCH_IMAGES) {
            "Cámara: $received imagen(es) nueva(s). El trabajo anterior ya fue cancelado; " +
                "agrupando únicamente este documento."
        } else {
            "Cámara: 4 imágenes nuevas recibidas. Procesando este documento ahora."
        }

        cameraBatchFinalizeRunnable?.let { mainHandler.removeCallbacks(it) }
        cameraBatchFinalizeRunnable = Runnable {
            cameraBatchFinalizeRunnable = null
            finalizeCameraCollector()
        }

        if (received >= MAX_CAMERA_BATCH_IMAGES) {
            mainHandler.post(cameraBatchFinalizeRunnable!!)
        } else {
            val elapsedMs = System.currentTimeMillis() - cameraBatchOpenedAtMs
            val idleMs = CameraBatchPolicy.idleDelayMs(incomingRequestId, elapsedMs)
            mainHandler.postDelayed(cameraBatchFinalizeRunnable!!, idleMs)
        }
    }

    private fun finalizeCameraCollector() {
        cameraBatchFinalizeRunnable?.let { mainHandler.removeCallbacks(it) }
        cameraBatchFinalizeRunnable = null
        if (cameraBatchCollector.isEmpty()) return

        val workId = cameraCollectorWorkId
        val photos = buildList {
            while (cameraBatchCollector.isNotEmpty()) add(cameraBatchCollector.removeFirst())
        }
        cameraBatchOpenedAtMs = 0L
        cameraCollectorWorkId = 0L

        if (!isWorkCurrent(workId)) {
            val ids = photos.mapNotNull { it.journalId }
            if (ids.isNotEmpty()) {
                cameraJournal.acknowledge(ids)
                observedJournalIds.removeAll(ids.toSet())
            }
            return
        }

        val label = if (photos.size > 1) {
            "lote cámara · ${photos.size} imágenes"
        } else {
            photos.first().source
        }
        val batch = QueuedCameraBatch(photos, label, workId)

        // No existe cola. Si Android reporta temperatura severa se conserva SOLO el
        // lote más reciente y se procesa cuando baje la temperatura.
        if (isThermallySevere()) {
            latestThermalCameraBatch = batch
            binding.tvStatus.text = "Temperatura elevada: conservando únicamente las imágenes más recientes."
            return
        }

        processCameraBatch(batch)
    }

    private fun processCameraBatch(batch: QueuedCameraBatch) {
        if (!isWorkCurrent(batch.workId)) return
        if (isThermallySevere()) {
            latestThermalCameraBatch = batch
            binding.tvStatus.text = "Temperatura elevada: conservando únicamente el lote más reciente."
            return
        }

        activeCameraPhotoIds = batch.photos.mapNotNull { it.journalId }
        cameraAnswerComplete = false
        // Cámara = receptor automático: visión (si hay API), extracción visible,
        // respuesta y voz. Una nueva entrada cancelará este ciclo inmediatamente.
        if (apiSettings.hasApiKey()) {
            processVisionCameraBatch(batch)
        } else {
            binding.tvStatus.text = "Sin API configurada. Reconociendo texto localmente..."
            processCameraImageBatch(batch)
        }
    }

    private fun processVisionCameraBatch(batch: QueuedCameraBatch) {
        val workId = batch.workId
        if (!isWorkCurrent(workId)) return
        processing.set(true)

        if (!apiSettings.hasApiKey()) {
            finishProcessingIfCurrent(workId)
            if (isWorkCurrent(workId)) {
                binding.tvStatus.text = "Visión IA no disponible. Activando OCR local de respaldo..."
                processCameraImageBatch(batch)
            }
            return
        }

        lastExtractedQuestions = emptyList()
        lastDisplayedOcrText = ""
        lastSourceLabel = batch.label
        pendingOcrDisplayOverride = null
        pendingDocumentContext = null
        pendingReview = null
        binding.reviewActions.visibility = View.GONE
        pendingBatchInfo = null
        pendingMissingQuestionNumbers = emptyList()
        pendingCoverageNote = null
        clearAllPreviews()
        binding.tvOcr.text = "Enviando ${batch.photos.size} imagen(es) originales a la IA para compararlas..."
        binding.tvAnswer.text = "Esperando lectura visual..."
        binding.tvStatus.text = "Visión IA: analizando únicamente el lote más reciente."

        ioExecutor.execute {
            if (!isWorkCurrent(workId)) return@execute

            val payloads = batch.photos.take(MAX_MANUAL_BATCH_IMAGES).map { photo ->
                VisionImagePayload(photo.jpeg, "image/jpeg")
            }

            val previews = batch.photos.take(MAX_MANUAL_BATCH_IMAGES).mapNotNull { photo ->
                if (!isWorkCurrent(workId)) return@mapNotNull null
                val decoded = CameraJpegDecoder.decodeForOcr(photo.jpeg) ?: return@mapNotNull null
                val thumb = makePreviewThumbnail(decoded)
                if (!decoded.isRecycled) decoded.recycle()
                thumb
            }

            if (isWorkCurrent(workId)) runOnUiThread {
                if (!isWorkCurrent(workId)) {
                    previews.forEach { if (!it.isRecycled) it.recycle() }
                    return@runOnUiThread
                }
                batchPreviewBitmaps = previews
                previewBitmap = batchPreviewBitmaps.firstOrNull()
                previewBitmap?.let {
                    binding.ivPreview.setImageBitmap(it)
                    binding.tvPreviewPlaceholder.visibility = View.GONE
                }
            } else {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                return@execute
            }

            val result = onlineProvider.extractQuestionsFromImages(payloads).trim()
            if (!isWorkCurrent(workId)) return@execute

            runOnUiThread {
                if (!isWorkCurrent(workId)) return@runOnUiThread

                val visionQuestions = if (result.startsWith(OnlineAnswerProvider.API_ERROR_PREFIX)) {
                    emptyList()
                } else {
                    runCatching { OcrQuestionExtractor.extractQuestions(result) }.getOrDefault(emptyList())
                }

                if (result.startsWith(OnlineAnswerProvider.API_ERROR_PREFIX) || visionQuestions.isEmpty()) {
                    finishProcessingIfCurrent(workId)
                    if (!isWorkCurrent(workId)) return@runOnUiThread
                    val detail = result.removePrefix(OnlineAnswerProvider.API_ERROR_PREFIX).trim()
                    binding.tvStatus.text = if (visionQuestions.isEmpty() && !result.startsWith(OnlineAnswerProvider.API_ERROR_PREFIX)) {
                        "La visión devolvió texto sin separar bien el ejercicio. Recuperando preguntas con OCR local..."
                    } else {
                        "Visión IA no pudo reconstruir preguntas. Activando OCR local de respaldo..."
                    }
                    binding.tvAnswer.text = if (detail.isBlank() || detail == result) {
                        "Usando OCR local de respaldo."
                    } else {
                        "Visión IA falló; GI X continuará con OCR local."
                    }
                    processCameraImageBatch(batch)
                    return@runOnUiThread
                }

                pendingBatchInfo = "Visión IA · ${payloads.size} imagen(es) comparadas"
                binding.tvStatus.text = "Visión IA terminó la lectura. Organizando y respondiendo..."
                handleOcrResult(result, workId)
            }
        }
    }

    private fun processCameraImageBatch(batch: QueuedCameraBatch) {
        val workId = batch.workId
        if (!isWorkCurrent(workId)) return
        processing.set(true)
        lastExtractedQuestions = emptyList()
        lastDisplayedOcrText = ""
        lastSourceLabel = batch.label
        pendingOcrDisplayOverride = null
        pendingDocumentContext = null
        pendingReview = null
        binding.reviewActions.visibility = View.GONE
        pendingBatchInfo = null
        pendingMissingQuestionNumbers = emptyList()
        pendingCoverageNote = null
        clearAllPreviews()
        binding.tvOcr.text = "Procesando lote de ${batch.photos.size} imágenes de cámara..."
        binding.tvAnswer.text = "Leyendo preguntas..."
        binding.tvStatus.text = "Lote cámara: preparando imagen 1 de ${batch.photos.size}."

        val items = mutableListOf<ManualBatchOcrItem>()
        val previews = mutableListOf<Bitmap>()
        var failedImages = 0
        var heavyPasses = 0

        fun finishBatch() {
            if (!isWorkCurrent(workId)) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                finishProcessingIfCurrent(workId)
                return
            }
            val rawTexts = items.map { it.rawText }
            if (rawTexts.none { it.isNotBlank() }) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                finishProcessingIfCurrent(workId)
                binding.tvStatus.text = "No pude identificar preguntas legibles en las imágenes de cámara."
                binding.tvOcr.text = "No se detectaron preguntas."
                binding.tvAnswer.text = "Acerca la cámara, mejora la luz y vuelve a intentarlo."
                scheduleNextAutoIfNeeded()
                return
            }

            batchPreviewBitmaps = previews.toList()
            previewBitmap = batchPreviewBitmaps.firstOrNull()
            previewBitmap?.let {
                binding.ivPreview.setImageBitmap(it)
                binding.tvPreviewPlaceholder.visibility = View.GONE
            }

            val merge = MultiImageDocumentMerger.merge(
                rawTexts,
                items.map { it.quality.selectionScore() }
            )
            pendingMissingQuestionNumbers = merge.missingQuestionNumbers
            pendingCoverageNote = merge.coverageNote.takeIf { it.isNotBlank() }
            pendingDocumentContext = merge.documentContext
            pendingOcrDisplayOverride = merge.combinedDisplay

            pendingBatchInfo = null

            if (merge.combinedRaw.isBlank()) {
                finishProcessingIfCurrent(workId)
                binding.tvStatus.text = "El lote de cámara llegó, pero no pude reconstruir texto útil."
                binding.tvOcr.text = pendingOcrDisplayOverride.orEmpty()
                binding.tvAnswer.text = "Vuelve a tomar la hoja con mejor luz o mayor solapamiento."
                pendingOcrDisplayOverride = null
                pendingBatchInfo = null
                pendingMissingQuestionNumbers = emptyList()
        pendingCoverageNote = null
                scheduleNextAutoIfNeeded()
                return
            }

            handleOcrResult(merge.combinedRaw, workId)
        }

        fun rescueAt(order: List<Int>, position: Int) {
            if (position >= order.size) {
                finishBatch()
                return
            }
            if (!isWorkCurrent(workId)) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                finishProcessingIfCurrent(workId)
                return
            }

            // Para máxima precisión hacemos rescate fuerte sobre TODAS las imágenes
            // del lote, de forma secuencial y controlada. Es algo más lento que
            // cortar antes, pero mejora la recuperación de preguntas finales borrosas
            // y reduce casos donde una foto buena tapa una pregunta que otra sí aporta.

            val imageIndex = order[position]
            binding.tvStatus.text = "Analizando imagen ${position + 1} de ${order.size}..."
            ioExecutor.execute {
                if (!isWorkCurrent(workId)) return@execute
                val photo = batch.photos[imageIndex]
                val bitmap = CameraJpegDecoder.decodeForOcr(photo.jpeg)
                if (bitmap == null) {
                    if (isWorkCurrent(workId)) runOnUiThread { if (isWorkCurrent(workId)) rescueAt(order, position + 1) }
                    return@execute
                }
                ocrProcessor.process(
                    bitmap,
                    onSuccess = { raw ->
                        heavyPasses++
                        if (raw.isNotBlank()) {
                            val better = chooseBetterBatchOcr(items[imageIndex].rawText, raw.trim())
                            items[imageIndex] = ManualBatchOcrItem(better, items[imageIndex].quality)
                        } else {
                            failedImages++
                        }
                        if (!bitmap.isRecycled) bitmap.recycle()
                        if (isWorkCurrent(workId)) runOnUiThread { if (isWorkCurrent(workId)) rescueAt(order, position + 1) }
                    },
                    onError = {
                        failedImages++
                        if (!bitmap.isRecycled) bitmap.recycle()
                        if (isWorkCurrent(workId)) runOnUiThread { if (isWorkCurrent(workId)) rescueAt(order, position + 1) }
                    }
                )
            }
        }

        fun startAdaptiveRescue() {
            val order = buildAdaptiveRescueOrder(items)
            if (order.isEmpty()) {
                finishBatch()
                return
            }
            rescueAt(order, 0)
        }

        fun processAt(index: Int) {
            if (index >= batch.photos.size) {
                startAdaptiveRescue()
                return
            }
            if (!isWorkCurrent(workId)) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                finishProcessingIfCurrent(workId)
                return
            }

            binding.tvStatus.text = "Preparando imagen ${index + 1} de ${batch.photos.size}..."
            ioExecutor.execute {
                if (!isWorkCurrent(workId)) return@execute
                val photo = batch.photos[index]
                val bitmap = CameraJpegDecoder.decodeForOcr(photo.jpeg)
                if (bitmap == null) {
                    failedImages++
                    items += ManualBatchOcrItem(
                        "",
                        OcrProcessor.ImageQualityReport(128.0, 64.0, 0.0, false, false, true)
                    )
                    if (isWorkCurrent(workId)) runOnUiThread { if (isWorkCurrent(workId)) processAt(index + 1) }
                    return@execute
                }

                val quality = runCatching { ocrProcessor.assessQuality(bitmap) }
                    .getOrElse { OcrProcessor.ImageQualityReport(128.0, 64.0, 100.0, false, false, false) }
                val thumb = makePreviewThumbnail(bitmap)
                previews += thumb

                // Aquí NO hacemos OCR. Primero preparamos/medimos todas las capturas y
                // luego el pipeline completo las procesa de una en una en un orden único.
                items += ManualBatchOcrItem("", quality)
                if (!bitmap.isRecycled) bitmap.recycle()
                if (isWorkCurrent(workId)) runOnUiThread { if (isWorkCurrent(workId)) processAt(index + 1) }
            }
        }

        processAt(0)
    }

    private fun loadPhotosFromUris(uris: List<Uri>) {
        if (uris.size > MAX_MANUAL_BATCH_IMAGES) {
            binding.tvStatus.text = "Seleccionaste ${uris.size} imágenes. GI X acepta hasta $MAX_MANUAL_BATCH_IMAGES por lote."
            Toast.makeText(this, "Elige máximo $MAX_MANUAL_BATCH_IMAGES imágenes.", Toast.LENGTH_LONG).show()
            return
        }

        // Manual también usa "último lote gana": jamás se pone detrás de voz/OCR/API anterior.
        val workId = beginLatestInput("manual")
        if (apiSettings.hasApiKey()) {
            processVisionUriBatch(uris, workId)
        } else {
            binding.tvStatus.text = "Sin API configurada. Reconociendo texto localmente..."
            processManualImageBatch(uris, workId)
        }
    }

    private fun processVisionUriBatch(uris: List<Uri>, workId: Long) {
        if (uris.isEmpty() || !isWorkCurrent(workId)) return
        processing.set(true)

        if (!apiSettings.hasApiKey()) {
            finishProcessingIfCurrent(workId)
            if (isWorkCurrent(workId)) {
                binding.tvStatus.text = "Visión IA no disponible. Activando OCR local de respaldo..."
                processManualImageBatch(uris, workId)
            }
            return
        }

        activeCameraPhotoIds = emptyList()
        lastExtractedQuestions = emptyList()
        lastDisplayedOcrText = ""
        lastSourceLabel = "visión IA manual · ${uris.size} imagen(es)"
        pendingOcrDisplayOverride = null
        pendingDocumentContext = null
        pendingReview = null
        binding.reviewActions.visibility = View.GONE
        pendingBatchInfo = null
        pendingMissingQuestionNumbers = emptyList()
        pendingCoverageNote = null
        clearAllPreviews()
        binding.tvOcr.text = "Enviando ${uris.size} imagen(es) originales a la IA..."
        binding.tvAnswer.text = "Esperando lectura visual..."
        binding.tvStatus.text = "Visión IA: procesando únicamente el lote manual más reciente."

        ioExecutor.execute {
            if (!isWorkCurrent(workId)) return@execute

            val payloads = mutableListOf<VisionImagePayload>()
            val previews = mutableListOf<Bitmap>()
            var readError: String? = null

            uris.take(MAX_MANUAL_BATCH_IMAGES).forEachIndexed { index, uri ->
                if (!isWorkCurrent(workId) || readError != null) return@forEachIndexed
                val mime = normalizeVisionMime(contentResolver.getType(uri), uri)
                if (mime == null) {
                    readError = "La imagen ${index + 1} no es JPG, PNG o WEBP compatible."
                    return@forEachIndexed
                }
                val bytes = runCatching {
                    contentResolver.openInputStream(uri)?.use { it.readBytes() }
                }.getOrNull()
                if (bytes == null || bytes.isEmpty()) {
                    readError = "No pude abrir la imagen ${index + 1}."
                    return@forEachIndexed
                }
                payloads += VisionImagePayload(bytes, mime)

                val bitmap = runCatching { ImageLoader.load(this, uri) }.getOrNull()
                if (bitmap != null) {
                    previews += makePreviewThumbnail(bitmap)
                    if (!bitmap.isRecycled) bitmap.recycle()
                }
            }

            if (!isWorkCurrent(workId)) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                return@execute
            }

            if (readError != null || payloads.isEmpty()) {
                runOnUiThread {
                    if (!isWorkCurrent(workId)) return@runOnUiThread
                    previews.forEach { if (!it.isRecycled) it.recycle() }
                    finishProcessingIfCurrent(workId)
                    binding.tvStatus.text = "No pude preparar el lote para visión IA. Probando OCR local..."
                    binding.tvAnswer.text = "Usando OCR local de respaldo."
                    processManualImageBatch(uris, workId)
                }
                return@execute
            }

            runOnUiThread {
                if (!isWorkCurrent(workId)) {
                    previews.forEach { if (!it.isRecycled) it.recycle() }
                    return@runOnUiThread
                }
                batchPreviewBitmaps = previews.toList()
                previewBitmap = batchPreviewBitmaps.firstOrNull()
                previewBitmap?.let {
                    binding.ivPreview.setImageBitmap(it)
                    binding.tvPreviewPlaceholder.visibility = View.GONE
                }
                binding.tvStatus.text = "Visión IA: comparando ${payloads.size} imagen(es) del lote nuevo..."
            }

            val result = onlineProvider.extractQuestionsFromImages(payloads).trim()
            if (!isWorkCurrent(workId)) return@execute

            runOnUiThread {
                if (!isWorkCurrent(workId)) return@runOnUiThread

                val visionQuestions = if (result.startsWith(OnlineAnswerProvider.API_ERROR_PREFIX)) {
                    emptyList()
                } else {
                    runCatching { OcrQuestionExtractor.extractQuestions(result) }.getOrDefault(emptyList())
                }

                if (result.startsWith(OnlineAnswerProvider.API_ERROR_PREFIX) || visionQuestions.isEmpty()) {
                    finishProcessingIfCurrent(workId)
                    if (!isWorkCurrent(workId)) return@runOnUiThread
                    binding.tvStatus.text = if (visionQuestions.isEmpty() && !result.startsWith(OnlineAnswerProvider.API_ERROR_PREFIX)) {
                        "La visión devolvió texto sin separar bien el ejercicio. Recuperando preguntas con OCR local..."
                    } else {
                        "Visión IA no pudo reconstruir preguntas. Activando OCR local de respaldo..."
                    }
                    binding.tvAnswer.text = "Usando OCR local de respaldo."
                    processManualImageBatch(uris, workId)
                    return@runOnUiThread
                }

                pendingBatchInfo = "Visión IA · ${payloads.size} imagen(es) comparadas"
                binding.tvStatus.text = "Visión IA terminó la lectura. Organizando y respondiendo..."
                handleOcrResult(result, workId)
            }
        }
    }

    private fun normalizeVisionMime(rawMime: String?, uri: Uri): String? {
        val mime = rawMime.orEmpty().lowercase(Locale.ROOT).substringBefore(';').trim()
        if (mime == "image/jpeg" || mime == "image/png" || mime == "image/webp") return mime
        val name = uri.toString().lowercase(Locale.ROOT).substringBefore('?')
        return when {
            name.endsWith(".jpg") || name.endsWith(".jpeg") -> "image/jpeg"
            name.endsWith(".png") -> "image/png"
            name.endsWith(".webp") -> "image/webp"
            else -> null
        }
    }

    private fun processManualImageBatch(uris: List<Uri>, workId: Long) {
        if (!isWorkCurrent(workId)) return
        processing.set(true)
        activeCameraPhotoIds = emptyList()
        lastExtractedQuestions = emptyList()
        lastDisplayedOcrText = ""
        lastSourceLabel = "lote manual · ${uris.size} imágenes"
        pendingOcrDisplayOverride = null
        pendingDocumentContext = null
        pendingReview = null
        binding.reviewActions.visibility = View.GONE
        pendingBatchInfo = null
        pendingMissingQuestionNumbers = emptyList()
        pendingCoverageNote = null
        clearAllPreviews()
        binding.tvOcr.text = "Procesando lote de ${uris.size} imágenes..."
        binding.tvAnswer.text = "Leyendo preguntas..."
        binding.tvStatus.text = "Lote manual: preparando imagen 1 de ${uris.size}."

        val items = mutableListOf<ManualBatchOcrItem>()
        val previews = mutableListOf<Bitmap>()
        var failedImages = 0
        var heavyPasses = 0

        fun finishBatch() {
            if (!isWorkCurrent(workId)) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                finishProcessingIfCurrent(workId)
                return
            }
            val rawTexts = items.map { it.rawText }
            if (rawTexts.none { it.isNotBlank() }) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                finishProcessingIfCurrent(workId)
                binding.tvStatus.text = "No pude identificar preguntas legibles en las imágenes."
                binding.tvOcr.text = "No se detectaron preguntas."
                binding.tvAnswer.text = "Prueba con fotos más cercanas, nítidas y con mejor iluminación."
                return
            }

            batchPreviewBitmaps = previews.toList()
            previewBitmap = batchPreviewBitmaps.firstOrNull()
            previewBitmap?.let {
                binding.ivPreview.setImageBitmap(it)
                binding.tvPreviewPlaceholder.visibility = View.GONE
            }

            val merge = MultiImageDocumentMerger.merge(
                rawTexts,
                items.map { it.quality.selectionScore() }
            )
            pendingMissingQuestionNumbers = merge.missingQuestionNumbers
            pendingCoverageNote = merge.coverageNote.takeIf { it.isNotBlank() }
            pendingDocumentContext = merge.documentContext
            pendingOcrDisplayOverride = merge.combinedDisplay

            pendingBatchInfo = null

            if (merge.combinedRaw.isBlank()) {
                finishProcessingIfCurrent(workId)
                binding.tvStatus.text = "El lote llegó, pero no pude reconstruir texto útil."
                binding.tvOcr.text = pendingOcrDisplayOverride.orEmpty()
                binding.tvAnswer.text = "Vuelve a tomar las zonas con más solapamiento."
                pendingOcrDisplayOverride = null
                pendingBatchInfo = null
                pendingMissingQuestionNumbers = emptyList()
        pendingCoverageNote = null
                return
            }

            // handleOcrResult conserva el mismo flujo probado de validación/API/voz,
            // pero recibe UN documento ya fusionado en vez de cuatro consultas.
            handleOcrResult(merge.combinedRaw, workId)
        }

        fun rescueAt(order: List<Int>, position: Int) {
            if (position >= order.size) {
                finishBatch()
                return
            }
            if (!isWorkCurrent(workId)) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                finishProcessingIfCurrent(workId)
                return
            }

            // Para máxima precisión hacemos rescate fuerte sobre TODAS las imágenes
            // del lote, de forma secuencial y controlada. Es algo más lento que
            // cortar antes, pero mejora la recuperación de preguntas finales borrosas
            // y reduce casos donde una foto buena tapa una pregunta que otra sí aporta.

            val imageIndex = order[position]
            binding.tvStatus.text = "Analizando imagen ${position + 1} de ${order.size}..."
            ioExecutor.execute {
                if (!isWorkCurrent(workId)) return@execute
                val bitmap = runCatching { ImageLoader.load(this, uris[imageIndex]) }.getOrNull()
                if (bitmap == null) {
                    if (isWorkCurrent(workId)) runOnUiThread { if (isWorkCurrent(workId)) rescueAt(order, position + 1) }
                    return@execute
                }
                ocrProcessor.process(
                    bitmap,
                    onSuccess = { raw ->
                        heavyPasses++
                        if (raw.isNotBlank()) {
                            val better = chooseBetterBatchOcr(items[imageIndex].rawText, raw.trim())
                            items[imageIndex] = ManualBatchOcrItem(better, items[imageIndex].quality)
                        } else {
                            failedImages++
                        }
                        if (!bitmap.isRecycled) bitmap.recycle()
                        if (isWorkCurrent(workId)) runOnUiThread { if (isWorkCurrent(workId)) rescueAt(order, position + 1) }
                    },
                    onError = {
                        failedImages++
                        if (!bitmap.isRecycled) bitmap.recycle()
                        if (isWorkCurrent(workId)) runOnUiThread { if (isWorkCurrent(workId)) rescueAt(order, position + 1) }
                    }
                )
            }
        }

        fun startAdaptiveRescue() {
            val order = buildAdaptiveRescueOrder(items)
            if (order.isEmpty()) {
                finishBatch()
                return
            }
            rescueAt(order, 0)
        }

        fun processAt(index: Int) {
            if (index >= uris.size) {
                startAdaptiveRescue()
                return
            }
            if (!isWorkCurrent(workId)) {
                previews.forEach { if (!it.isRecycled) it.recycle() }
                finishProcessingIfCurrent(workId)
                return
            }

            binding.tvStatus.text = "Preparando imagen ${index + 1} de ${uris.size}..."
            ioExecutor.execute {
                if (!isWorkCurrent(workId)) return@execute
                val bitmap = runCatching { ImageLoader.load(this, uris[index]) }.getOrNull()
                if (bitmap == null) {
                    failedImages++
                    items += ManualBatchOcrItem(
                        "",
                        OcrProcessor.ImageQualityReport(128.0, 64.0, 0.0, false, false, true)
                    )
                    if (isWorkCurrent(workId)) runOnUiThread { if (isWorkCurrent(workId)) processAt(index + 1) }
                    return@execute
                }

                val quality = runCatching { ocrProcessor.assessQuality(bitmap) }
                    .getOrElse { OcrProcessor.ImageQualityReport(128.0, 64.0, 100.0, false, false, false) }
                val thumb = makePreviewThumbnail(bitmap)
                previews += thumb

                // Sin OCR duplicado: el OCR completo empieza después y procesa cada
                // captura secuencialmente con OpenCV -> Paddle -> verificación ML Kit.
                items += ManualBatchOcrItem("", quality)
                if (!bitmap.isRecycled) bitmap.recycle()
                if (isWorkCurrent(workId)) runOnUiThread { if (isWorkCurrent(workId)) processAt(index + 1) }
            }
        }

        processAt(0)
    }

    private fun chooseBetterBatchOcr(existing: String, candidate: String): String {
        fun localScore(text: String): Int {
            if (text.isBlank()) return Int.MIN_VALUE
            val questions = runCatching { OcrQuestionExtractor.extractQuestions(text) }
                .getOrDefault(emptyList())
            val numbered = questions.mapNotNull(OcrQuestionExtractor::questionNumber).distinct().size
            val incomplete = questions.count(::looksLikeIncompleteBatchQuestion)
            val suspicious = if (questions.size >= 3 && OcrQuestionExtractor.hasSuspiciousNumbering(questions)) 1 else 0
            val table = if (text.contains(OcrTableFormatter.TABLE_START)) 1 else 0
            return numbered * 140 + questions.size * 70 + table * 90 -
                incomplete * 220 - suspicious * 320 + minOf(text.length, 3000) / 30
        }
        return if (localScore(candidate) >= localScore(existing)) candidate else existing
    }

    private fun looksLikeIncompleteBatchQuestion(raw: String): Boolean {
        val clean = raw
            .replace(Regex("""^\s*\d{1,2}\s*[\.)\-:]\s*"""), "")
            .trim()
        if (clean.length < 10) return true

        val lower = clean.lowercase(Locale.ROOT).trimEnd('.', ',', ';', ':', '-', '–', '—')
        val dangling = listOf(
            " entre", " de", " del", " la", " el", " los", " las", " y", " o",
            " con", " sin", " para", " por", " en", " según", " segun", " desde", " hasta"
        ).any { lower.endsWith(it) }
        if (dangling) return true

        val interrogative = listOf(
            "qué ", "que ", "cuál ", "cual ", "cuáles ", "cuales ", "cómo ", "como ",
            "por qué ", "por que ", "dónde ", "donde ", "cuándo ", "cuando ",
            "quién ", "quien ", "cuánto ", "cuanto "
        ).any { lower.trimStart('¿', '?', ' ').startsWith(it) }
        if (interrogative && !clean.contains('?') && clean.length < 150) return true
        return false
    }

    private fun buildAdaptiveRescueOrder(items: List<ManualBatchOcrItem>): List<Int> {
        if (items.isEmpty()) return emptyList()
        // Ya no existe una lectura OCR rápida previa. Procesamos primero la captura de
        // mejor calidad para obtener pronto una base fiable y después las complementarias.
        // No asumimos una cantidad fija de preguntas: sirve igual para 2, 6 o 30 ítems.
        return items.indices.sortedWith(
            compareByDescending<Int> { index -> items[index].quality.selectionScore() }
                .thenBy { it }
        )
    }

    private fun makePreviewThumbnail(source: Bitmap): Bitmap {
        val maxSide = maxOf(source.width, source.height).coerceAtLeast(1)
        val target = 1100
        if (maxSide <= target) return source.copy(Bitmap.Config.ARGB_8888, false)
        val scale = target.toFloat() / maxSide.toFloat()
        return Bitmap.createScaledBitmap(
            source,
            (source.width * scale).toInt().coerceAtLeast(1),
            (source.height * scale).toInt().coerceAtLeast(1),
            true,
        )
    }

    private fun clearAllPreviews() {
        binding.ivPreview.setImageDrawable(null)
        batchPreviewBitmaps.forEach { bitmap ->
            if (!bitmap.isRecycled) bitmap.recycle()
        }
        val current = previewBitmap
        if (current != null && !current.isRecycled) current.recycle()
        batchPreviewBitmaps = emptyList()
        previewBitmap = null
        binding.tvPreviewPlaceholder.visibility = View.VISIBLE
    }

    /**
     * onDestroy no debe reciclar bitmaps que un worker pueda seguir usando. Al soltar
     * solo las referencias de UI, el GC los recupera cuando el último pipeline termine.
     */
    private fun dropPreviewReferencesForDestroy() {
        if (::binding.isInitialized) binding.ivPreview.setImageDrawable(null)
        batchPreviewBitmaps = emptyList()
        previewBitmap = null
    }

    private fun handleOcrResult(rawText: String, workId: Long) {
        if (!isWorkCurrent(workId)) return
        val cleanRaw = rawText.trim()
        if (cleanRaw.isBlank()) {
            finishProcessingIfCurrent(workId)
            binding.tvStatus.text = "No se encontraron preguntas legibles."
            binding.tvOcr.text = "No se detectaron preguntas."
            binding.tvAnswer.text = "Prueba con más luz, menos inclinación y enfoca mejor la pregunta."
            scheduleNextAutoIfNeeded()
            return
        }

        val extractedQuestions = OcrQuestionExtractor.extractQuestions(cleanRaw)
        // Último rescate: si la IA devolvió una hoja claramente evaluativa como "texto"
        // (por ejemplo V/F sin signos de interrogación), no la descartamos. Se envía el
        // documento completo como una tarea única para que la API lo resuelva.
        val questions = if (extractedQuestions.isEmpty() &&
            OcrQuestionExtractor.looksLikeAnswerableDocument(cleanRaw)
        ) {
            binding.tvStatus.text = "Estructura de examen detectada. Respondiendo aunque la lectura haya llegado como texto."
            listOf(cleanRaw)
        } else {
            extractedQuestions
        }
        val normalizedQuestions = questions.map(QuestionTextNormalizer::normalize)
        lastExtractedQuestions = normalizedQuestions

        // UNA sola fuente de verdad para vista previa, historial y todas las consultas.
        // En 1-4 fotos el fusionador ya obtuvo el contexto de TODAS las capturas;
        // para visión/foto suelta lo extraemos del documento íntegro.
        val documentContext = OcrQuestionExtractor.normalizeDocumentContext(
            pendingDocumentContext ?: OcrQuestionExtractor.extractDocumentContext(cleanRaw)
        )
        pendingDocumentContext = null
        val batchInfo = pendingBatchInfo.also { pendingBatchInfo = null }
        val batchMissing = pendingMissingQuestionNumbers.also { pendingMissingQuestionNumbers = emptyList() }
        val coverageNote = pendingCoverageNote.also { pendingCoverageNote = null }
        pendingOcrDisplayOverride = null
        val fullDisplayText = OcrQuestionExtractor.renderDocumentPreview(documentContext, normalizedQuestions)
        lastDisplayedOcrText = fullDisplayText
        binding.tvOcr.text = fullDisplayText
        scrollTextToTop(binding.tvOcr)

        if (questions.isEmpty()) {
            finishProcessingIfCurrent(workId)
            binding.tvStatus.text = "Se leyó texto, pero no parece contener un ejercicio o pregunta para responder."
            binding.tvAnswer.text = "Si es un examen, procura incluir también la instrucción, numeración o alternativas."
            scheduleNextAutoIfNeeded()
            return
        }

        // v1.6.16: un hueco en la numeración YA NO cancela la consulta. Si la hoja no
        // se fotografió completa, GI X responde las preguntas que sí identificó y avisa
        // cuáles faltan. Antes se quedaba sin respuestas por faltar la pregunta 1.
        val missingWarning = if (batchMissing.isEmpty()) {
            ""
        } else {
            "Falta(n) ${batchMissing.joinToString(", ")}: se responden solo las detectadas."
        }
        // Barrera de seguridad: solo se cancela cuando la numeración está CORRUPTA
        // (repetida o fuera de orden), porque eso significa que la reconstrucción del
        // documento falló y las respuestas quedarían asignadas a la pregunta incorrecta.
        if (OcrQuestionExtractor.hasCorruptNumbering(normalizedQuestions)) {
            // Nunca asignar respuestas según números impresos repetidos: consultar
            // por separado y emparejar por posición técnica estable. No bloquear
            // TODA la hoja por una numeración OCR defectuosa como en v1.6.34.
            binding.tvStatus.text = "Numeración OCR dudosa: consultando preguntas por separado."
        }

        // Permite probar SOLO el OCR sin gastar API. Antes, una prueba sin clave
        // terminaba mostrando "0 de N respondidas", aunque el OCR sí hubiera leído
        // correctamente la hoja, lo que confundía el diagnóstico.
        if (!apiSettings.hasApiKey()) {
            finishProcessingIfCurrent(workId)
            binding.tvStatus.text = buildString {
                append("${normalizedQuestions.size} pregunta(s) detectada(s).")
                if (!batchInfo.isNullOrBlank()) append(" · ").append(batchInfo)
            }
            binding.tvAnswer.text = "Preguntas listas. Configura una API para obtener respuestas."
            scrollTextToTop(binding.tvAnswer)
            scheduleNextAutoIfNeeded()
            return
        }

        val request = PreparedAnswerRequest(
            workId, normalizedQuestions, documentContext, batchInfo, batchMissing, coverageNote
        )
        // El mismo contexto y las mismas preguntas que se ven arriba se envían ya.
        // No esperar botones, tanto en MANUAL como en CÁMARA, bloqueado o desbloqueado.
        sendPreparedDocumentToApi(request)
    }

    private fun sendPreparedDocumentToApi(request: PreparedAnswerRequest) {
        val workId = request.workId
        if (!isWorkCurrent(workId) || !processing.get()) return
        binding.reviewActions.visibility = View.GONE
        val normalizedQuestions = request.questions
        val questions = request.questions
        val documentContext = request.context
        val batchInfo = request.batchInfo
        val coverageNote = request.coverageNote
        val missingWarning = if (request.missingNumbers.isEmpty()) "" else
            "Falta(n) ${request.missingNumbers.joinToString(", ")}: se responden solo las detectadas."
        val batches = buildApiBatches(normalizedQuestions)
        val apiStatus = if (normalizedQuestions.size == 1) {
            "Pregunta detectada. Consultando la API..."
        } else if (batches.size == 1) {
            "${normalizedQuestions.size} preguntas detectadas. Consultando la API..."
        } else {
            "${normalizedQuestions.size} preguntas detectadas. Se resolverán en ${batches.size} bloques seguros."
        }
        binding.tvStatus.text = buildString {
            append(apiStatus)
            if (OcrQuestionExtractor.hasCorruptNumbering(normalizedQuestions)) {
                append(" · numeración OCR dudosa: emparejando cada respuesta por posición")
            }
            if (!batchInfo.isNullOrBlank()) append(" · ").append(batchInfo)
            if (missingWarning.isNotBlank()) append(" · ").append(missingWarning)
        }
        binding.tvAnswer.text = buildString {
            if (missingWarning.isNotBlank()) {
                if (!coverageNote.isNullOrBlank()) append(coverageNote).append("\n")
                append(missingWarning).append("\n\n")
            }
            append("Consultando IA...")
        }
        resetLiveAnswerSpeech()
        ioExecutor.execute {
            if (!isWorkCurrent(workId)) return@execute
            val completed = mutableListOf<String>()
            val failedNumbers = mutableListOf<Int>()
            val failureDetails = mutableListOf<String>()
            var completedQuestions = 0
            var globalOffset = 0

            for ((batchIndex, batch) in batches.withIndex()) {
                if (!isWorkCurrent(workId)) return@execute

                if (batches.size > 1) {
                    mainHandler.post {
                        if (isWorkCurrent(workId)) {
                            binding.tvStatus.text = "Consultando IA: bloque ${batchIndex + 1} de ${batches.size}..."
                        }
                    }
                }

                val payload = OcrQuestionExtractor.buildQueryPayload(
                    batch,
                    forceBatch = batch.size > 1,
                    documentContext = documentContext,
                )

                // v1.6.25: Cheaper Inference permite streaming. En lotes de varias
                // preguntas mostramos las líneas completas apenas llegan; ya no se espera
                // a que termine todo el bloque para que aparezca la primera respuesta.
                var streamedStableNormalized = ""
                val answer = onlineProvider.fetchShortAnswer(payload) { partial ->
                    if (!isWorkCurrent(workId)) return@fetchShortAnswer
                    val stable = if (batch.size > 1) {
                        stableStreamingAnswerPrefix(partial)
                    } else {
                        stableSingleStreamingAnswerPrefix(partial)
                    }
                    if (stable.isNotBlank()) {
                        val normalizedStable = if (batch.size > 1) {
                            normalizeBatchAnswerNumbers(stable, batch, globalOffset)
                        } else {
                            val question = batch.first()
                            val technicalId = answerTechnicalId(question, globalOffset, normalizedQuestions)
                            formatRecoveredSingleAnswer(technicalId, question, stable)
                        }
                        if (normalizedStable.isNotBlank() && normalizedStable != streamedStableNormalized) {
                            streamedStableNormalized = normalizedStable
                            val progressiveRaw = (completed + normalizedStable)
                                .joinToString("\n\n")
                                .trim()
                            publishProgressiveAnswers(
                                rawAnswers = progressiveRaw,
                                total = normalizedQuestions.size,
                                missingWarning = missingWarning,
                                coverageNote = coverageNote,
                                workId = workId,
                            )
                        }
                    }
                }.trim()

                // Si entró un lote nuevo mientras el proveedor terminaba, esta respuesta
                // queda descartada y NO inicia recuperaciones/reintentos del documento viejo.
                if (!isWorkCurrent(workId)) return@execute

                if (!answer.startsWith(OnlineAnswerProvider.API_ERROR_PREFIX)) {
                    // Para una consulta individual guardamos un identificador interno
                    // estable. En pantalla se retirará si la pregunta original no tenía
                    // numeración. En lotes normales conservamos los números del examen.
                    if (batch.size == 1) {
                        val question = batch.first()
                        val technicalId = answerTechnicalId(question, globalOffset, normalizedQuestions)
                        completed += formatRecoveredSingleAnswer(technicalId, question, answer)
                    } else {
                        completed += normalizeBatchAnswerNumbers(answer, batch, globalOffset)
                    }
                    completedQuestions += batch.size
                    publishProgressiveAnswers(
                        rawAnswers = completed.joinToString("\n\n").trim(),
                        total = normalizedQuestions.size,
                        missingWarning = missingWarning,
                        coverageNote = coverageNote,
                        workId = workId,
                    )
                    globalOffset += batch.size
                    continue
                }

                // Si el stream se cortó después de entregar respuestas completas, las
                // conservamos y recuperamos únicamente las preguntas que realmente faltan.
                val streamedIds = mutableSetOf<Int>()
                if (batch.size > 1 && streamedStableNormalized.isNotBlank()) {
                    val streamedBlocks = splitNumberedAnswerBlocks(streamedStableNormalized)
                    batch.forEachIndexed { localIndex, question ->
                        val globalNumber = answerTechnicalId(
                            question,
                            globalOffset + localIndex,
                            normalizedQuestions,
                        )
                        val body = streamedBlocks[globalNumber]?.trim().orEmpty()
                        if (body.isNotBlank()) {
                            val canonical = OnlineAnswerProvider
                                .canonicalizeAnswerForQuestion(question, body)
                                .trim()
                            completed += "$globalNumber. $canonical"
                            completedQuestions += 1
                            streamedIds += globalNumber
                        }
                    }
                    publishProgressiveAnswers(
                        rawAnswers = completed.joinToString("\n\n").trim(),
                        total = normalizedQuestions.size,
                        missingWarning = missingWarning,
                        coverageNote = coverageNote,
                        workId = workId,
                    )
                }

                // Si un lote fue rechazado, quedó incompleto o alcanzó MAX_TOKENS,
                // no perdemos el examen: recuperamos ese lote pregunta por pregunta.
                // Esto también evita que un fallo de una sola pregunta borre respuestas
                // de otros bloques.
                if (batch.size > 1) {
                    for ((localIndex, question) in batch.withIndex()) {
                        if (!isWorkCurrent(workId)) return@execute
                        val globalNumber = answerTechnicalId(
                            question,
                            globalOffset + localIndex,
                            normalizedQuestions,
                        )
                        if (globalNumber in streamedIds) continue
                        val printedNumber = OcrQuestionExtractor.questionNumber(question)
                        mainHandler.post {
                            if (isWorkCurrent(workId)) {
                                binding.tvStatus.text = if (printedNumber != null) {
                                    "Recuperando pregunta $printedNumber de ${normalizedQuestions.size}..."
                                } else {
                                    "Recuperando una pregunta sin número..."
                                }
                            }
                        }

                        val singlePayload = OcrQuestionExtractor.buildQueryPayload(
                            listOf(question),
                            forceBatch = false,
                            documentContext = documentContext,
                        )
                        val singleAnswer = onlineProvider.fetchShortAnswer(singlePayload).trim()
                        if (!isWorkCurrent(workId)) return@execute
                        if (singleAnswer.startsWith(OnlineAnswerProvider.API_ERROR_PREFIX)) {
                            failedNumbers += globalNumber
                            failureDetails += singleAnswer
                                .removePrefix(OnlineAnswerProvider.API_ERROR_PREFIX)
                                .trim()
                                .ifBlank { "La API no devolvió una respuesta válida." }
                        } else {
                            completed += formatRecoveredSingleAnswer(globalNumber, question, singleAnswer)
                            completedQuestions += 1
                            publishProgressiveAnswers(
                                rawAnswers = completed.joinToString("\n\n").trim(),
                                total = normalizedQuestions.size,
                                missingWarning = missingWarning,
                                coverageNote = coverageNote,
                                workId = workId,
                            )
                        }
                    }
                } else {
                    val globalNumber = answerTechnicalId(
                        batch.first(),
                        globalOffset,
                        normalizedQuestions,
                    )
                    failedNumbers += globalNumber
                    failureDetails += answer
                        .removePrefix(OnlineAnswerProvider.API_ERROR_PREFIX)
                        .trim()
                        .ifBlank { "La API no devolvió una respuesta válida." }
                }

                globalOffset += batch.size
            }

            runOnUiThread {
                if (!isWorkCurrent(workId)) return@runOnUiThread
                val finalText = completed.joinToString("\n\n").trim()
                if (failedNumbers.isNotEmpty()) {
                    handleRecoveredApiFailure(
                        partial = finalText,
                        completed = completedQuestions,
                        total = questions.size,
                        failedNumbers = failedNumbers,
                        details = failureDetails,
                        workId = workId
                    )
                } else {
                    handleAnswer(finalText, workId)
                }
            }
        }
    }

    private fun showFullDocumentPreview() {
        val value = lastDisplayedOcrText.ifBlank { binding.tvOcr.text.toString() }
        val view = ScrollView(this)
        view.addView(TextView(this).apply {
            text = value
            textSize = 15f
            setTextIsSelectable(true)
            setPadding(dp(18), dp(12), dp(18), dp(16))
        })
        AlertDialog.Builder(this)
            .setTitle("Documento detectado completo")
            .setView(view)
            .setPositiveButton("Cerrar", null)
            .show()
    }

    /** Revisión local: no toca la API ni cambia el modo cámara/bloqueo/voz. */
    private fun editPendingDocument() {
        val current = pendingReview ?: return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        root.addView(TextView(this).apply {
            text = "CONTEXTO / LECTURA / CUADROS"
            textStyleBold()
            textSize = 12f
        })
        val contextEdit = EditText(this).apply {
            setText(current.context)
            hint = "Texto de referencia (si existe)"
            minLines = 3
            maxLines = 9
            setHorizontallyScrolling(false)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        root.addView(contextEdit, LinearLayout.LayoutParams(-1, dp(130)))
        root.addView(TextView(this).apply {
            text = "PREGUNTAS / ALTERNATIVAS"
            textStyleBold()
            textSize = 12f
        })
        val questionsEdit = EditText(this).apply {
            setText(current.questions.joinToString("\n\n"))
            minLines = 5
            maxLines = 12
            setHorizontallyScrolling(false)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        root.addView(questionsEdit, LinearLayout.LayoutParams(-1, dp(215)))
        val scroll = ScrollView(this).apply { addView(root) }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Corregir lectura y preguntas")
            .setView(scroll)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val fixedQuestions = OcrQuestionExtractor.extractQuestions(questionsEdit.text.toString())
                    .map(QuestionTextNormalizer::normalize)
                if (fixedQuestions.isEmpty()) {
                    questionsEdit.error = "Conserva al menos una pregunta legible."
                    return@setOnClickListener
                }
                // La numeración repetida se puede mostrar y responder por separado;
                // no impedir una corrección manual por ese motivo.
                val fixedContext = OcrQuestionExtractor.normalizeDocumentContext(contextEdit.text.toString())
                val corrected = current.copy(questions = fixedQuestions, context = fixedContext)
                pendingReview = corrected
                lastExtractedQuestions = fixedQuestions
                lastDisplayedOcrText = OcrQuestionExtractor.renderDocumentPreview(fixedContext, fixedQuestions)
                binding.tvOcr.text = lastDisplayedOcrText
                scrollTextToTop(binding.tvOcr)
                binding.tvStatus.text = "Correcciones guardadas localmente. El modo automático no requiere confirmación."
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun stableStreamingAnswerPrefix(raw: String): String {
        val normalized = raw.replace("\r\n", "\n").replace('\r', '\n')
        val lastNewline = normalized.lastIndexOf('\n')
        if (lastNewline < 0) return ""
        return normalized.substring(0, lastNewline).trim()
    }

    private fun stableSingleStreamingAnswerPrefix(raw: String): String {
        val clean = raw.replace("\r\n", "\n").replace('\r', '\n').trim()
        if (clean.isBlank()) return ""
        val last = clean.lastOrNull() ?: return ""
        return if (last in ".?!:;" || clean.contains('\n')) clean else ""
    }

    private fun publishProgressiveAnswers(
        rawAnswers: String,
        total: Int,
        missingWarning: String,
        coverageNote: String?,
        workId: Long,
    ) {
        if (!isWorkCurrent(workId) || rawAnswers.isBlank()) return
        val visible = formatAnswersForDisplay(rawAnswers, includeUnanswered = false).trim()
        if (visible.isBlank()) return
        val parsedCount = splitNumberedAnswerBlocks(rawAnswers).size
        val answered = (if (parsedCount > 0) parsedCount else 1).coerceAtMost(total)

        mainHandler.post {
            if (!isWorkCurrent(workId)) return@post
            binding.tvAnswer.text = buildString {
                if (missingWarning.isNotBlank()) {
                    if (!coverageNote.isNullOrBlank()) append(coverageNote).append("\n")
                    append(missingWarning).append("\n\n")
                }
                append(visible)
            }
            speakProgressiveVisibleAnswers(visible, finalChunk = false)
            binding.tvStatus.text = if (answered >= total) {
                "$total de $total respuestas recibidas. Finalizando..."
            } else {
                "Respondiendo... $answered de $total listas. Las demás siguen llegando."
            }
        }
    }

    private fun buildApiBatches(questions: List<String>): List<List<String>> {
        if (questions.isEmpty()) return emptyList()

        // Un documento puede mezclar preguntas numeradas y preguntas sin número.
        // En ese caso las mandamos una por una: así los identificadores técnicos que
        // usa la API nunca se confunden con una numeración impresa real.
        val printedCount = questions.count { OcrQuestionExtractor.questionNumber(it) != null }
        if (OcrQuestionExtractor.hasCorruptNumbering(questions) ||
            printedCount in 1 until questions.size) {
            return questions.map { listOf(it) }
        }

        val batchLimit = if (OcrQuestionExtractor.isLikelyTrueFalseQuestions(questions)) {
            TRUE_FALSE_API_BATCH_SIZE
        } else {
            STANDARD_API_BATCH_SIZE
        }

        val output = mutableListOf<List<String>>()
        val pending = mutableListOf<String>()
        fun flushPending() {
            if (pending.isNotEmpty()) {
                output += pending.toList()
                pending.clear()
            }
        }

        questions.forEach { question ->
            // Una tabla puede necesitar una respuesta por fila. La aislamos para que no
            // compita por tokens con otras preguntas del examen.
            if (question.contains(OcrTableFormatter.TABLE_START)) {
                flushPending()
                output += listOf(question)
            } else {
                pending += question
                if (pending.size >= batchLimit) flushPending()
            }
        }
        flushPending()
        return output
    }

    private fun answerTechnicalId(question: String, globalIndex: Int, allQuestions: List<String>): Int {
        // IDs únicos aunque el OCR haya duplicado el número impreso (1,2,1...).
        // El número visible de cada pregunta se mantiene sin renumerar el examen.
        if (OcrQuestionExtractor.hasCorruptNumbering(allQuestions)) return 100 + globalIndex
        OcrQuestionExtractor.questionNumber(question)?.let { return it }
        val hasPrinted = allQuestions.any { OcrQuestionExtractor.questionNumber(it) != null }
        val hasUnnumbered = allQuestions.any { OcrQuestionExtractor.questionNumber(it) == null }
        // En documentos mixtos usamos IDs >=100 solo dentro de la app para evitar
        // chocar con números impresos 1..99. Nunca se muestran al usuario.
        return if (hasPrinted && hasUnnumbered) 100 + globalIndex else globalIndex + 1
    }

    private fun formatRecoveredSingleAnswer(number: Int, question: String, answer: String): String {
        val clean = answer
            .replace(Regex("""^\s*(?:Pregunta\s+)?\d{1,3}\s*[\.):\-]\s*""", RegexOption.IGNORE_CASE), "")
            .replace(Regex("""(?i)^Respuesta\s*:\s*"""), "")
            .trim()
        val canonical = OnlineAnswerProvider.canonicalizeAnswerForQuestion(question, clean).trim()
        // El número puede ser real o un ID técnico interno. Se usa solo para asociar
        // la respuesta; formatAnswersForDisplay() decide si debe verse.
        return "$number. $canonical".trim()
    }

    private fun handleRecoveredApiFailure(
        partial: String,
        completed: Int,
        total: Int,
        failedNumbers: List<Int>,
        details: List<String>,
        workId: Long,
    ) {
        if (!isWorkCurrent(workId)) return
        answerPipelineFinished = true
        cameraAnswerComplete = false // No confirmar fotos con respuestas incompletas.
        finishProcessingIfCurrent(workId)
        val uniqueDetail = details.firstOrNull().orEmpty()
        val pairedPartial = if (partial.isNotBlank()) formatAnswersForDisplay(partial, includeUnanswered = false) else ""
        val visible = buildString {
            if (pairedPartial.isNotBlank()) {
                append(pairedPartial)
                append("\n\n")
            }
            append("Se respondieron $completed de $total preguntas.")
            if (failedNumbers.isNotEmpty()) {
                if (OcrQuestionExtractor.hasCorruptNumbering(lastExtractedQuestions)) {
                    append(" Quedaron ${failedNumbers.distinct().size} pregunta(s) sin respuesta con numeración OCR dudosa.")
                } else {
                    val printed = lastExtractedQuestions.mapNotNull(OcrQuestionExtractor::questionNumber).toSet()
                    val visibleFailed = failedNumbers.filter { it in printed }.distinct().sorted()
                    val unnumberedFailed = failedNumbers.count { it !in printed }
                    if (visibleFailed.isNotEmpty()) {
                        append(" Faltaron: ")
                        append(visibleFailed.joinToString(", "))
                        append(".")
                    }
                    if (unnumberedFailed > 0) {
                        append(" Quedaron $unnumberedFailed pregunta(s) sin número sin respuesta.")
                    }
                }
            }
            if (uniqueDetail.isNotBlank()) {
                append("\n")
                append(uniqueDetail)
            }
        }
        binding.tvAnswer.text = visible
        scrollTextToTop(binding.tvAnswer)
        saveToHistory(visible)
        updateApiChip()
        binding.tvStatus.text = if (completed > 0) {
            "La API respondió parcialmente; GI X conservó todas las respuestas obtenidas."
        } else {
            "La API no respondió esta vez. Las preguntas se conservaron."
        }
        if (pairedPartial.isNotBlank()) {
            // El streaming puede haber leído las respuestas parciales: no repetirlas.
            if (liveAnswerSpeechUsed) {
                val added = speakProgressiveVisibleAnswers(pairedPartial, finalChunk = true)
                if (!added && !isSpeakingAnswer && pendingSpeechText.isNullOrBlank()) {
                    scheduleNextAutoIfNeeded()
                }
            } else requestAnswerSpeech(pairedPartial)
        } else {
            scheduleNextAutoIfNeeded()
        }
    }

    private fun normalizeBatchAnswerNumbers(
        answer: String,
        batch: List<String>,
        globalOffset: Int
    ): String {
        val printedNumbers = batch.map { OcrQuestionExtractor.questionNumber(it) }
        // Si existe numeración real, el payload ya la conserva y no debemos tocarla.
        if (printedNumbers.any { it != null }) return answer.trim()

        // Preguntas sin numeración: el proveedor responde 1..N dentro de cada lote.
        // Aquí las convertimos a una secuencia global solo para que la pantalla no
        // muestre 1,2,3 otra vez en el siguiente lote.
        if (globalOffset <= 0) return answer.trim()
        val numberedLine = Regex("^(\\s*)(?:(Pregunta)\\s+)?(\\d{1,2})([\\.):])\\s*(.*)$", RegexOption.IGNORE_CASE)
        return answer.lines().joinToString("\n") { line ->
            val match = numberedLine.find(line) ?: return@joinToString line
            val prefix = match.groupValues[1]
            val questionWord = match.groupValues[2]
            val localNumber = match.groupValues[3].toIntOrNull() ?: return@joinToString line
            val separator = match.groupValues[4]
            val tail = match.groupValues[5]
            val globalNumber = localNumber + globalOffset
            if (questionWord.isNotBlank()) {
                "$prefix$questionWord $globalNumber$separator $tail".trimEnd()
            } else {
                "$prefix$globalNumber$separator $tail".trimEnd()
            }
        }.trim()
    }

    private fun handleChunkedApiFailure(partial: String, rawError: String, completed: Int, total: Int) {
        answerPipelineFinished = true
        cameraAnswerComplete = false
        processing.set(false)
        val error = rawError.removePrefix(OnlineAnswerProvider.API_ERROR_PREFIX).trim()
        val pairedPartial = if (partial.isNotBlank()) formatAnswersForDisplay(partial, includeUnanswered = false) else ""
        val visible = buildString {
            if (pairedPartial.isNotBlank()) {
                append(pairedPartial)
                append("\n\n")
            }
            append("No se pudieron completar las preguntas restantes ($completed de $total respondidas).\n")
            append(error.ifBlank { "La API no devolvió una respuesta válida." })
        }
        binding.tvAnswer.text = visible
        scrollTextToTop(binding.tvAnswer)
        saveToHistory(visible)
        updateApiChip()
        binding.tvStatus.text = "La API no completó todos los bloques. Las respuestas ya recibidas se conservaron."
        if (pairedPartial.isNotBlank()) {
            if (liveAnswerSpeechUsed) {
                val added = speakProgressiveVisibleAnswers(pairedPartial, finalChunk = true)
                if (!added && !isSpeakingAnswer && pendingSpeechText.isNullOrBlank()) {
                    scheduleNextAutoIfNeeded()
                }
            } else requestAnswerSpeech(pairedPartial)
        } else {
            scheduleNextAutoIfNeeded()
        }
    }

    private fun splitNumberedAnswerBlocks(raw: String): Map<Int, String> {
        val text = raw.trim()
        if (text.isBlank()) return emptyMap()
        val marker = Regex("(?m)^\\s*(?:Pregunta\\s+)?(\\d{1,3})\\s*[\\.\\):\\-]\\s*")
        val matches = marker.findAll(text).toList()
        if (matches.isEmpty()) return emptyMap()

        val result = linkedMapOf<Int, String>()
        matches.forEachIndexed { index, match ->
            val number = match.groupValues[1].toIntOrNull() ?: return@forEachIndexed
            val start = match.range.last + 1
            val end = matches.getOrNull(index + 1)?.range?.first ?: text.length
            val body = text.substring(start, end)
                .trim()
                .replace(Regex("(?i)^Respuesta\\s*:\\s*"), "")
                .trim()
            if (body.isNotBlank() && number !in result) result[number] = body
        }
        return result
    }

    /**
     * La API puede usar números técnicos para asociar respuestas, pero la pantalla y
     * la voz muestran SOLO respuestas. Si la pregunta tenía número impreso, se conserva
     * ese número. Si no tenía número, GI X no inventa 1, 2, 3 para el usuario.
     */
    private fun formatAnswersForDisplay(rawAnswer: String, includeUnanswered: Boolean = true): String {
        val questions = lastExtractedQuestions
        val clean = rawAnswer.trim()
        if (questions.isEmpty() || clean.isBlank()) return clean

        val blocks = splitNumberedAnswerBlocks(clean)
        val answers = MutableList<String?>(questions.size) { null }
        questions.forEachIndexed { index, question ->
            val technicalId = answerTechnicalId(question, index, questions)
            answers[index] = blocks[technicalId]
        }

        // Una única pregunta puede llegar sin identificador técnico.
        if (questions.size == 1 && answers[0].isNullOrBlank()) {
            answers[0] = clean
                .replace(Regex("""(?i)^Respuesta\s*:\s*"""), "")
                .replace(Regex("""^\s*(?:Pregunta\s+)?\d{1,3}\s*[\.):\-]\s*""", RegexOption.IGNORE_CASE), "")
                .trim()
        }

        // Respaldo conservador: si el proveedor devolvió exactamente una línea por
        // pregunta pero omitió los IDs, las asociamos por orden.
        if (answers.all { it.isNullOrBlank() } && questions.size > 1) {
            val lines = clean.lines().map { it.trim() }.filter { it.isNotBlank() }
            if (lines.size == questions.size) {
                lines.forEachIndexed { index, line ->
                    answers[index] = line
                        .replace(Regex("""(?i)^Respuesta\s*:\s*"""), "")
                        .replace(Regex("""^\s*(?:Pregunta\s+)?\d{1,3}\s*[\.):\-]\s*""", RegexOption.IGNORE_CASE), "")
                        .trim()
                }
            }
        }

        val visible = questions.mapIndexedNotNull { index, question ->
            val answer = answers[index]?.trim().orEmpty()
            if (answer.isBlank() && !includeUnanswered) return@mapIndexedNotNull null
            val body = answer
                .ifBlank { "Sin respuesta." }
                .replace(Regex("""(?i)^Respuesta\s*:\s*"""), "")
                .trim()
            val printedNumber = OcrQuestionExtractor.questionNumber(question)
            if (printedNumber != null) {
                prefixVisibleAnswerNumber(printedNumber, body)
            } else {
                body
            }
        }
        return visible.joinToString("\n\n").ifBlank { clean }
    }

    private fun prefixVisibleAnswerNumber(number: Int, answer: String): String {
        val lines = answer.lines()
        if (lines.isEmpty()) return "$number."
        val first = lines.first().trim()
        val rest = lines.drop(1).joinToString("\n").trimEnd()
        return if (rest.isBlank()) {
            "$number. $first".trimEnd()
        } else {
            "$number. $first\n$rest".trimEnd()
        }
    }

    private fun handleAnswer(answer: String, workId: Long) {
        if (!isWorkCurrent(workId)) return
        answerPipelineFinished = true
        finishProcessingIfCurrent(workId)
        val clean = answer.trim().ifBlank { "La API no devolvió una respuesta." }
        val apiError = answer.isBlank() || clean.startsWith(OnlineAnswerProvider.API_ERROR_PREFIX)
        cameraAnswerComplete = !apiError && !speechFailedForCurrentDocument
        val visibleText = if (apiError) {
            clean.removePrefix(OnlineAnswerProvider.API_ERROR_PREFIX).trim()
        } else {
            formatAnswersForDisplay(clean)
        }
        binding.tvAnswer.text = visibleText
        scrollTextToTop(binding.tvAnswer)
        saveToHistory(visibleText)
        // No borrar los JPEG antes de hablar: si Android mata el proceso durante
        // la voz, se podrá recuperar la foto y repetir el ciclo al abrir GI X.
        updateApiChip()

        if (apiError) {
            binding.tvStatus.text = "La API no respondió correctamente. Revisa el detalle abajo."
            scheduleNextAutoIfNeeded()
            return
        }

        if (liveAnswerSpeechUsed) {
            val queuedNewSpeech = speakProgressiveVisibleAnswers(visibleText, finalChunk = true)
            if (!queuedNewSpeech && !isSpeakingAnswer && pendingSpeechText.isNullOrBlank()) {
                if (!speechFailedForCurrentDocument) acknowledgeSpokenCameraBatch()
                binding.tvStatus.text = if (speechFailedForCurrentDocument) {
                    "Texto listo; la voz falló y las fotos siguen guardadas."
                } else "Respuesta lista."
                scheduleNextAutoIfNeeded()
            }
        } else {
            requestAnswerSpeech(visibleText)
        }
    }

    private fun resetLiveAnswerSpeech() {
        liveSpokenAnswers.clear()
        liveAnswerSpeechUsed = false
        answerPipelineFinished = false
        speechFailedForCurrentDocument = false
    }

    private fun speakProgressiveVisibleAnswers(visibleText: String, finalChunk: Boolean): Boolean {
        val newItems = extractSpeakableAnswerItems(visibleText).mapIndexedNotNull { index, item ->
            val normalized = item.replace(Regex("""\s+"""), " ").trim()
            if (normalized.isBlank()) return@mapIndexedNotNull null
            val printed = Regex("""^\d+[.)\-:]\s*""").find(normalized)?.value.orEmpty()
            val key = "$index:$printed" // También admite números impresos duplicados.
            val spoken = liveSpokenAnswers[key]
            val next = when {
                spoken == null -> normalized
                spoken == normalized -> ""
                normalized.startsWith(spoken) -> normalized.drop(spoken.length).trim()
                finalChunk -> "Corrección: $normalized"
                else -> "" // Un cambio de contenido se verbaliza solo al finalizar.
            }
            if (next.isNotBlank()) liveSpokenAnswers[key] = normalized
            next.takeIf { part -> part.any { it.isLetterOrDigit() } }
        }
        val speechText = newItems.joinToString("\n").trim()
        if (speechText.isBlank()) return false
        liveAnswerSpeechUsed = true
        queueAnswerSpeech(speechText, finalChunk)
        return true
    }

    private fun extractSpeakableAnswerItems(visibleText: String): List<String> {
        val clean = visibleText
            .lineSequence()
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .filterNot { it.startsWith("Advertencia", ignoreCase = true) }
            .filterNot { it.startsWith("Falt", ignoreCase = true) }
            .toList()
        if (clean.isEmpty()) return emptyList()

        val items = mutableListOf<String>()
        val current = StringBuilder()
        val numbered = Regex("^\\d+[\\).:-]\\s+.+")

        fun flush() {
            val value = current.toString().trim()
            if (value.isNotBlank()) items += value
            current.clear()
        }

        for (line in clean) {
            if (numbered.containsMatchIn(line)) {
                flush()
                current.append(line)
            } else if (current.isNotEmpty()) {
                current.append(' ').append(line)
            } else {
                current.append(line)
            }
        }
        flush()
        return items
    }

    /**
     * Punto único de salida de voz de GI X. Toda respuesta válida (normal o recuperada)
     * pasa por aquí, para que no existan rutas que muestren texto pero olviden hablar.
     */
    private fun requestAnswerSpeech(text: String) {
        val spokenText = prepareSpokenAnswer(text)
        if (spokenText.isBlank()) {
            binding.tvStatus.text = "Respuesta lista; el motor de voz no tiene texto pronunciable."
            scheduleNextAutoIfNeeded()
            return
        }

        speechRetryCount = 0
        speechRecoveryInProgress = false
        activeSpeechText = spokenText
        pendingSpeechText = spokenText
        binding.tvStatus.text = if (ttsReady) {
            "Respuesta lista. Reproduciendo voz..."
        } else {
            "Respuesta lista. Preparando voz..."
        }

        if (ttsReady) {
            startPendingSpeech()
        } else if (!ttsInitializing) {
            // Si el motor ya había fallado antes de recibir esta respuesta, no dejamos
            // el texto esperando indefinidamente: iniciamos una nueva instancia ahora.
            ttsInitializing = true
            reinitializeTts()
        }
    }

    private fun queueAnswerSpeech(text: String, finalChunk: Boolean) {
        val spokenText = prepareSpokenAnswer(text)
        if (spokenText.isBlank()) return

        if (!ttsReady) {
            pendingSpeechText = listOfNotNull(pendingSpeechText, spokenText)
                .filter { it.isNotBlank() }
                .joinToString("\n")
            activeSpeechText = pendingSpeechText
            if (!ttsInitializing) {
                ttsInitializing = true
                reinitializeTts()
            }
            return
        }

        val engine = tts ?: return
        val chunks = splitForTts(spokenText)
        if (chunks.isEmpty()) return

        engine.setSpeechRate(prefs.speechRate)
        speechSessionId += 1
        val session = speechSessionId
        isSpeakingAnswer = true
        activeSpeechText = listOfNotNull(activeSpeechText, spokenText)
            .filter { it.isNotBlank() }
            .joinToString("\n")
        pendingSpeechText = null
        binding.tvStatus.text = if (finalChunk) {
            "Respuesta lista. Terminando voz..."
        } else {
            "Respuesta llegando. Leyendo lo recibido..."
        }

        for ((index, chunk) in chunks.withIndex()) {
            val utteranceId = "${UTTERANCE_ANSWER}_${session}_live_${index}"
            if (index == chunks.lastIndex) activeSpeechFinalId = utteranceId
            val result = engine.speak(chunk, TextToSpeech.QUEUE_ADD, null, utteranceId)
            if (result == TextToSpeech.ERROR) {
                handleSpeechFailure()
                return
            }
        }
    }

    private fun prepareSpokenAnswer(text: String): String {
        val withoutInternalMarkers = text.lineSequence()
            .filterNot { line ->
                val trimmed = line.trim()
                trimmed.startsWith("[GIX_", ignoreCase = true) ||
                    trimmed.startsWith("Columnas:", ignoreCase = true) ||
                    trimmed.startsWith("Fila ", ignoreCase = true)
            }
            .joinToString("\n")
            .replace("|", ", ")
        return VoiceQuestionNormalizer.prepareForTts(withoutInternalMarkers).trim()
    }

    private fun startPendingSpeech() {
        if (!ttsReady || stopped) return
        val text = pendingSpeechText?.trim().orEmpty()
        if (text.isBlank()) return

        val engine = tts ?: run {
            handleSpeechFailure()
            return
        }
        val chunks = splitForTts(text)
        if (chunks.isEmpty()) {
            pendingSpeechText = null
            activeSpeechText = null
            binding.tvStatus.text = "Respuesta lista."
            scheduleNextAutoIfNeeded()
            return
        }

        engine.stop()
        engine.setSpeechRate(prefs.speechRate)
        speechSessionId += 1
        val session = speechSessionId
        activeSpeechText = text
        pendingSpeechText = null
        isSpeakingAnswer = true
        activeSpeechFinalId = "${UTTERANCE_ANSWER}_${session}_${chunks.lastIndex}"
        binding.tvStatus.text = "Respuesta lista. Reproduciendo voz..."

        for ((index, chunk) in chunks.withIndex()) {
            val utteranceId = "${UTTERANCE_ANSWER}_${session}_${index}"
            val queueMode = if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            val result = engine.speak(chunk, queueMode, null, utteranceId)
            if (result == TextToSpeech.ERROR) {
                handleSpeechFailure()
                return
            }
        }
    }

    private fun splitForTts(text: String): List<String> {
        val platformMax = runCatching { TextToSpeech.getMaxSpeechInputLength() }.getOrDefault(4000)
        // Dejamos margen respecto al máximo del motor. 3000 también evita problemas
        // de motores que anuncian un límite mayor pero fallan con textos muy largos.
        val maxChars = minOf((platformMax - 200).coerceAtLeast(500), 3000)
        val pieces = text
            .replace("\r", "")
            .split(Regex("(?<=[.!?])\\s+|\\n+"))
            .map { it.trim() }
            .filter { it.isNotBlank() }

        val result = mutableListOf<String>()
        var current = StringBuilder()

        fun flush() {
            val value = current.toString().trim()
            if (value.isNotBlank()) result += value
            current = StringBuilder()
        }

        fun addLongPiece(piece: String) {
            val words = piece.split(Regex("\\s+")).filter { it.isNotBlank() }
            for (word in words) {
                if (word.length > maxChars) {
                    flush()
                    word.chunked(maxChars).forEach { result += it }
                    continue
                }
                val extra = if (current.isEmpty()) word.length else word.length + 1
                if (current.length + extra > maxChars) flush()
                if (current.isNotEmpty()) current.append(' ')
                current.append(word)
            }
        }

        for (piece in pieces) {
            if (piece.length > maxChars) {
                flush()
                addLongPiece(piece)
                flush()
                continue
            }
            val extra = if (current.isEmpty()) piece.length else piece.length + 1
            if (current.length + extra > maxChars) flush()
            if (current.isNotEmpty()) current.append(' ')
            current.append(piece)
        }
        flush()
        return result
    }

    override fun onInit(status: Int) {
        ttsInitializing = false
        speechRecoveryInProgress = false
        if (status != TextToSpeech.SUCCESS) {
            ttsReady = false
            if (!pendingSpeechText.isNullOrBlank() && speechRetryCount < MAX_TTS_RETRIES) {
                speechRetryCount += 1
                binding.tvStatus.text = "Respuesta lista. Reintentando el motor de voz..."
                mainHandler.postDelayed({ reinitializeTts() }, TTS_RETRY_DELAY_MS)
            } else if (!pendingSpeechText.isNullOrBlank()) {
                speechFailedForCurrentDocument = true
                cameraAnswerComplete = false
                pendingSpeechText = null
                activeSpeechText = null
                binding.tvStatus.text = "Respuesta lista. No se pudo iniciar la voz; fotos conservadas."
                scheduleNextAutoIfNeeded()
            }
            return
        }
        val engine = tts ?: return
        val result = engine.setLanguage(Locale("es", "PE"))
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.language = Locale("es", "ES")
        }
        engine.setSpeechRate(prefs.speechRate)
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit

            override fun onDone(utteranceId: String?) {
                if (utteranceId == activeSpeechFinalId) {
                    runOnUiThread {
                        if (stopped || utteranceId != activeSpeechFinalId) return@runOnUiThread
                        // La voz puede alcanzar al streaming. No declarar finalizado
                        // un documento mientras siguen llegando respuestas de la API.
                        val finished = answerPipelineFinished && !processing.get()
                        if (finished && !speechFailedForCurrentDocument) acknowledgeSpokenCameraBatch()
                        isSpeakingAnswer = false
                        activeSpeechFinalId = null
                        activeSpeechText = null
                        pendingSpeechText = null
                        speechRetryCount = 0
                        binding.tvStatus.text = when {
                            !finished -> "Leyendo respuestas recibidas; esperando las restantes de la API..."
                            autoMode -> "Respuesta terminada. Preparando la siguiente foto..."
                            else -> "Listo. Puedes pedir otra foto o elegir otra imagen."
                        }
                        if (finished) scheduleNextAutoIfNeeded()
                    }
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                runOnUiThread {
                    if (!stopped && isCurrentSpeechUtterance(utteranceId)) handleSpeechFailure()
                }
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                runOnUiThread {
                    if (!stopped && isCurrentSpeechUtterance(utteranceId)) handleSpeechFailure()
                }
            }
        })
        ttsReady = true
        if (!pendingSpeechText.isNullOrBlank()) startPendingSpeech()
    }

    private fun isCurrentSpeechUtterance(utteranceId: String?): Boolean =
        utteranceId == null || utteranceId.startsWith("${UTTERANCE_ANSWER}_${speechSessionId}_")

    private fun acknowledgeSpokenCameraBatch() {
        if (!cameraAnswerComplete) return
        val ids = activeCameraPhotoIds
        if (ids.isEmpty()) return
        cameraJournal.acknowledge(ids)
        synchronized(completedCameraPhotoIds) {
            completedCameraPhotoIds.addAll(ids)
            // Solo se usa para confirmar reenvíos Wi-Fi recientes; no crecer
            // indefinidamente durante horas con la cámara encendida.
            while (completedCameraPhotoIds.size > 64) {
                val first = completedCameraPhotoIds.firstOrNull() ?: break
                completedCameraPhotoIds.remove(first)
            }
        }
        observedJournalIds.removeAll(ids.toSet())
        activeCameraPhotoIds = emptyList()
        cameraAnswerComplete = false
    }

    private fun handleSpeechFailure() {
        if (stopped || speechRecoveryInProgress) return
        val text = activeSpeechText ?: pendingSpeechText
        isSpeakingAnswer = false
        activeSpeechFinalId = null

        if (text.isNullOrBlank()) {
            scheduleNextAutoIfNeeded()
            return
        }

        if (speechRetryCount < MAX_TTS_RETRIES) {
            speechRetryCount += 1
            speechRecoveryInProgress = true
            pendingSpeechText = text
            activeSpeechText = text
            binding.tvStatus.text = "La respuesta está lista. Reiniciando voz..."
            reinitializeTts()
        } else {
            speechFailedForCurrentDocument = true
            cameraAnswerComplete = false
            pendingSpeechText = null
            activeSpeechText = null
            binding.tvStatus.text = "Respuesta lista; falló la voz. Texto y fotos conservados."
            scheduleNextAutoIfNeeded()
        }
    }

    private fun reinitializeTts() {
        runCatching { tts?.stop() }
        runCatching { tts?.shutdown() }
        ttsReady = false
        ttsInitializing = true
        tts = TextToSpeech(this, this)
    }

    private fun processLatestThermalBatchIfReady(): Boolean {
        val batch = latestThermalCameraBatch ?: return false
        if (stopped || isThermallySevere() || processing.get() || isSpeakingAnswer ||
            !pendingSpeechText.isNullOrBlank() || !isWorkCurrent(batch.workId)
        ) {
            if (!isWorkCurrent(batch.workId)) latestThermalCameraBatch = null
            return false
        }
        latestThermalCameraBatch = null
        processCameraBatch(batch)
        return true
    }

    private fun scheduleNextAutoIfNeeded() {
        // v1.6.43: no existe cola de cámara ni manual. Solo puede quedar retenido el
        // lote MÁS RECIENTE si Android pidió una pausa térmica.
        if (processLatestThermalBatchIfReady()) return
        if (!isThermallySevere() && !processing.get() && !isSpeakingAnswer &&
            pendingSpeechText.isNullOrBlank() && cameraBatchCollector.isEmpty() &&
            latestThermalCameraBatch == null && restoreJournaledCameraPhotos()
        ) return

        // No se envían CAPTURE automáticos: TimerCamera-X entrega las fotos al encender.
        if (autoMode && !stopped && inputMode == InputMode.CAMERA &&
            !processing.get() && !isSpeakingAnswer && pendingSpeechText.isNullOrBlank() &&
            cameraBatchCollector.isEmpty()) {
            binding.tvStatus.text = "Cámara automática: esperando nuevas imágenes. Lo nuevo siempre tendrá prioridad."
        }
    }

    private fun updateCameraChip() {
        binding.tvCameraChip.text = if (cameraServer?.isCameraConnected() == true) {
            "Cámara: conectada"
        } else {
            "Cámara: esperando"
        }
    }

    private fun updateApiChip() {
        val config = apiSettings.getApiConfigs()
            .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }

        if (config == null) {
            binding.tvApiChip.text = "API: sin configurar"
            binding.tvApiDetail.text = "API lista cuando guardes tu clave"
            return
        }

        val status = apiSettings.getStatus(config)
        val message = apiSettings.getMessage(config).trim()
        binding.tvApiChip.text = "API: DeepSeek"
        binding.tvApiDetail.text = when (status) {
            "ready" -> "DeepSeek lista · ${config.model}"
            "error" -> "DeepSeek guardada · revisar API"
            "limit" -> "DeepSeek guardada · sin créditos o límite"
            else -> if (message.isBlank() || message.startsWith("Sin probar", ignoreCase = true)) {
                "DeepSeek guardada · sin probar"
            } else {
                "DeepSeek guardada · último estado disponible"
            }
        }
    }

    private fun showVoiceDialog() {
        val labels = arrayOf("0.25x", "0.50x", "0.75x", "1.00x", "1.25x", "1.50x", "1.75x", "2.00x")
        val values = floatArrayOf(0.25f, 0.50f, 0.75f, 1.00f, 1.25f, 1.50f, 1.75f, 2.00f)
        val current = values.indices.minByOrNull { abs(values[it] - prefs.speechRate) } ?: 3
        AlertDialog.Builder(this)
            .setTitle("Velocidad de voz")
            .setSingleChoiceItems(labels, current) { dialog, which ->
                prefs.speechRate = values[which]
                tts?.setSpeechRate(values[which])
                Toast.makeText(this, "Voz ${labels[which]}", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showCameraDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(4))
        }
        val info = TextView(this).apply {
            text = "TimerCamera-X U082-X: al encenderse se conecta a la Zona Wi-Fi configurada y envía sus fotos a GI X por el puerto ${CameraBridgeServer.DEFAULT_PORT}. La app ya está preparada para recibir una captura suelta o agrupar automáticamente hasta 4 imágenes del mismo documento. Si dejas la clave por defecto GIX2026CAM, el enlace queda listo."
            textSize = 14f
        }
        val tokenInput = EditText(this).apply {
            hint = "Clave de enlace"
            setText(prefs.pairingToken)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            maxLines = 1
        }
        val note = TextView(this).apply {
            text = "Firmware incluido: camera_firmware/TimerCameraX_GIX.ino. Recomendado: deja fija la clave GIX2026CAM y cambia solo nombre Wi-Fi y contraseña Wi-Fi. Si cambias la clave, debe coincidir exactamente con la app."
            textSize = 12f
        }
        box.addView(info)
        box.addView(tokenInput, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) })
        box.addView(note, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        val dialog = AlertDialog.Builder(this)
            .setTitle("Enlace con Timer Camera X")
            .setView(box)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                prefs.pairingToken = tokenInput.text?.toString().orEmpty()
                tokenInput.setText(prefs.pairingToken)
                binding.tvStatus.text = "Clave de cámara guardada. Debe coincidir con el firmware."
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun normalizeCheaperKey(raw: String): String {
        val cleaned = raw
            .trim()
            .removePrefix("Bearer ")
            .removePrefix("bearer ")
            .trim('\"', '\'')
            .replace("​", "")
            .replace("‌", "")
            .replace("‍", "")
            .replace("⁠", "")
            .replace("﻿", "")
            .replace(Regex("[\r\n\t ]+"), "")

        val embedded = Regex("(ir_live_[A-Za-z0-9._-]+|ci_live_[A-Za-z0-9._-]+)", RegexOption.IGNORE_CASE)
            .find(cleaned)
            ?.value
        return embedded ?: cleaned
    }

    private fun showApiDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }

        val title = TextView(this).apply {
            text = "CHEAPER INFERENCE · DEEPSEEK"
            textStyleBold()
            textSize = 15f
        }
        val info = TextView(this).apply {
            text = "GI X usará únicamente esta API de pago con DeepSeek V4 Flash. La clave queda guardada en el celular. Los fallos temporales no la bloquean y la app muestra el motivo real si no responde."
            textSize = 12f
            setPadding(0, dp(4), 0, dp(8))
        }

        val saved = apiSettings.getApiConfigs()
            .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }
        val keyInput = EditText(this).apply {
            hint = if (saved == null) "Clave Cheaper Inference (ir_live_… / ci_live_…)" else "Clave guardada. Pega otra solo para reemplazarla"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            maxLines = 1
        }
        val modelInput = EditText(this).apply {
            hint = "Modelo fijo"
            setText(NetProvider.CHEAPER_INFERENCE.defaultModel)
            isEnabled = false
            maxLines = 1
        }
        val statusText = TextView(this).apply {
            textSize = 12f
            setPadding(0, dp(8), 0, dp(6))
        }
        val saveTest = Button(this).apply { text = "GUARDAR Y PROBAR DEEPSEEK" }
        val testSaved = Button(this).apply { text = "PROBAR API GUARDADA" }
        val delete = Button(this).apply { text = "BORRAR API GUARDADA" }
        val close = Button(this).apply { text = "CERRAR" }

        fun refresh(message: String? = null) {
            val config = apiSettings.getApiConfigs()
                .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }
            val storedStatus = if (config == null) {
                "DeepSeek: SIN CONFIGURAR"
            } else {
                val state = apiSettings.getStatus(config)
                val detail = apiSettings.getMessage(config).trim()
                when (state) {
                    "ready" -> "DeepSeek: ACTIVA ✓ · ${config.model} · clave guardada"
                    "error" -> "DeepSeek: GUARDADA · ERROR · ${detail.ifBlank { "revisa clave, saldo o modelo" }}"
                    "limit" -> "DeepSeek: GUARDADA · SIN CRÉDITOS / LÍMITE · ${detail.ifBlank { "revisa tu cuenta" }}"
                    else -> if (detail.isBlank() || detail.startsWith("Sin probar", ignoreCase = true)) {
                        "DeepSeek: GUARDADA · SIN PROBAR · ${config.model}"
                    } else {
                        "DeepSeek: GUARDADA · ${detail}"
                    }
                }
            }
            statusText.text = listOfNotNull(message?.takeIf { it.isNotBlank() }, storedStatus).joinToString("\n")
            updateApiChip()
        }

        box.addView(title)
        box.addView(info)
        box.addView(keyInput, LinearLayout.LayoutParams(-1, dp(54)))
        box.addView(modelInput, LinearLayout.LayoutParams(-1, dp(54)))
        box.addView(saveTest, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(6) })
        box.addView(testSaved, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4) })
        box.addView(statusText, LinearLayout.LayoutParams(-1, -2))
        box.addView(delete, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4) })
        box.addView(close, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4) })

        val dialog = AlertDialog.Builder(this)
            .setTitle("API de GI X")
            .setView(box)
            .create()

        saveTest.setOnClickListener {
            val typed = normalizeCheaperKey(keyInput.text?.toString().orEmpty())
            val current = apiSettings.getApiConfigs()
                .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }
            val key = typed.ifBlank { normalizeCheaperKey(current?.apiKey.orEmpty()) }
            if (key.isBlank()) {
                keyInput.error = "Pega tu clave ir_live_… o ci_live_…"
                return@setOnClickListener
            }
            val model = modelInput.text?.toString().orEmpty().trim()
                .ifBlank { NetProvider.CHEAPER_INFERENCE.defaultModel }
            val config = NetApiConfig(
                name = "DeepSeek Pago",
                provider = NetProvider.CHEAPER_INFERENCE,
                apiKey = key,
                model = model
            ).clean(0)

            // Esta versión usa una sola API: al guardar, elimina configuraciones de respaldo.
            apiSettings.saveApiConfigs(listOf(config))
            saveTest.isEnabled = false
            testSaved.isEnabled = false
            statusText.text = "DeepSeek: GUARDADA · esperando respuesta (el proveedor puede tardar hasta 3 min)…"
            ioExecutor.execute {
                val result = onlineProvider.testApiConfig(config)
                runOnUiThread {
                    saveTest.isEnabled = true
                    testSaved.isEnabled = true
                    if (result.first) keyInput.text?.clear()
                    refresh(result.second)
                }
            }
        }

        testSaved.setOnClickListener {
            val config = apiSettings.getApiConfigs()
                .firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }
            if (config == null) {
                refresh("No hay una API guardada todavía.")
                return@setOnClickListener
            }
            testSaved.isEnabled = false
            statusText.text = "DeepSeek: probando API guardada (hasta 3 min, sin repetir)…"
            ioExecutor.execute {
                val result = onlineProvider.testApiConfig(config)
                runOnUiThread {
                    testSaved.isEnabled = true
                    refresh(result.second)
                }
            }
        }

        delete.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Borrar API")
                .setMessage("¿Quieres borrar la clave DeepSeek guardada en este celular?")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Borrar") { _, _ ->
                    apiSettings.saveApiConfigs(emptyList())
                    refresh("API borrada.")
                }
                .show()
        }

        close.setOnClickListener { dialog.dismiss() }
        dialog.setOnDismissListener { updateApiChip() }
        refresh()
        dialog.show()
    }

    private fun setupInternalScroll(scroll: ScrollView) {
        scroll.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> view.parent?.requestDisallowInterceptTouchEvent(true)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.parent?.requestDisallowInterceptTouchEvent(false)
            }
            false
        }
    }

    private fun showPreviewDialog() {
        val images = if (batchPreviewBitmaps.isNotEmpty()) {
            batchPreviewBitmaps.filter { !it.isRecycled }
        } else {
            listOfNotNull(previewBitmap).filter { !it.isRecycled }
        }
        if (images.isEmpty()) {
            Toast.makeText(this, "Todavía no hay imagen para abrir.", Toast.LENGTH_SHORT).show()
            return
        }

        var currentIndex = 0
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF050A12.toInt())
        }
        val hint = TextView(this).apply {
            setTextColor(0xFFE8EEF9.toInt())
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val imageView = ZoomableImageView(this).apply {
            setImageBitmap(images[currentIndex])
            setBackgroundColor(0xFF050A12.toInt())
        }

        fun refreshHint() {
            hint.text = if (images.size > 1) {
                "Imagen ${currentIndex + 1} de ${images.size} · zoom con dos dedos · doble toque · arrastra"
            } else {
                "Pellizca para hacer zoom · doble toque para acercar · arrastra para mover"
            }
        }
        refreshHint()

        val navigation = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(6), dp(10), 0)
            visibility = if (images.size > 1) View.VISIBLE else View.GONE
        }
        val previous = Button(this).apply { text = "← ANTERIOR" }
        val next = Button(this).apply { text = "SIGUIENTE →" }
        navigation.addView(previous, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(5) })
        navigation.addView(next, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(5) })

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(8), dp(10), dp(12))
        }
        val rotate = Button(this).apply { text = "ROTAR" }
        val reset = Button(this).apply { text = "RESTABLECER" }
        val close = Button(this).apply { text = "CERRAR" }
        controls.addView(rotate, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(4) })
        controls.addView(reset, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
            marginStart = dp(4); marginEnd = dp(4)
        })
        controls.addView(close, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(4) })

        root.addView(hint, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(imageView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(navigation, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(controls, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val dialog = android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dialog.setContentView(root)

        fun showIndex(newIndex: Int) {
            currentIndex = (newIndex + images.size) % images.size
            imageView.setImageBitmap(images[currentIndex])
            imageView.resetView()
            refreshHint()
        }
        previous.setOnClickListener { showIndex(currentIndex - 1) }
        next.setOnClickListener { showIndex(currentIndex + 1) }
        rotate.setOnClickListener { imageView.rotateClockwise() }
        reset.setOnClickListener { imageView.resetView() }
        close.setOnClickListener { dialog.dismiss() }
        dialog.setOnShowListener {
            dialog.window?.apply {
                setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                setBackgroundDrawableResource(android.R.color.black)
                addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                statusBarColor = 0xFF050A12.toInt()
                navigationBarColor = 0xFF050A12.toInt()
            }
        }
        dialog.show()
    }

    private fun saveToHistory(answerText: String) {
        if (lastDisplayedOcrText.isBlank() || answerText.isBlank()) return
        val entry = HistoryEntry(
            id = System.currentTimeMillis().toString(),
            timestamp = System.currentTimeMillis(),
            source = lastSourceLabel,
            questionCount = lastExtractedQuestions.size.coerceAtLeast(1),
            ocrText = lastDisplayedOcrText,
            answerText = answerText
        )
        historyRepository.add(entry)
        renderHistory()
    }

    private fun renderHistory() {
        val items = historyRepository.getAll()
        binding.historyContainer.removeAllViews()
        binding.tvHistoryEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        items.forEach { entry ->
            binding.historyContainer.addView(createHistoryCard(entry))
        }
    }

    private fun createHistoryCard(entry: HistoryEntry): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = getDrawable(R.drawable.card_bg)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(8)
        }
        card.layoutParams = params

        val title = TextView(this).apply {
            text = "${formatHistoryDate(entry.timestamp)} · ${entry.source} · ${entry.questionCount} pregunta(s)"
            textSize = 13f
            textStyleBold()
        }
        val preview = TextView(this).apply {
            text = entry.ocrText.replace("\n", " ").take(120).ifBlank { "Sin preguntas" }
            textSize = 12f
            setPadding(0, dp(4), 0, dp(2))
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
        }
        val open = Button(this).apply { text = "ABRIR" }
        val delete = Button(this).apply { text = "BORRAR" }
        row.addView(open, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(4) })
        row.addView(delete, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(4) })

        open.setOnClickListener {
            if (lockAppOnScreen) {
                Toast.makeText(this, "GI X bloqueado: desbloquea para abrir historial.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            showHistoryEntryDialog(entry)
        }
        delete.setOnClickListener {
            if (lockAppOnScreen) {
                Toast.makeText(this, "GI X bloqueado: desbloquea para borrar historial.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            historyRepository.delete(entry.id)
            renderHistory()
            Toast.makeText(this, "Registro borrado.", Toast.LENGTH_SHORT).show()
        }

        card.addView(title)
        card.addView(preview)
        card.addView(row)
        return card
    }

    private fun showHistoryEntryDialog(entry: HistoryEntry) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(8))
        }
        root.addView(TextView(this).apply {
            text = "${formatHistoryDate(entry.timestamp)} · ${entry.source} · ${entry.questionCount} pregunta(s)"
            textSize = 13f
            textStyleBold()
        })
        root.addView(TextView(this).apply {
            text = "Preguntas detectadas"
            textSize = 13f
            textStyleBold()
            setPadding(0, dp(10), 0, dp(4))
        })
        val ocrScroll = ScrollView(this)
        ocrScroll.addView(TextView(this).apply {
            text = entry.ocrText
            textSize = 14f
            setTextIsSelectable(true)
            setPadding(dp(10), dp(10), dp(10), dp(10))
        })
        root.addView(ocrScroll, LinearLayout.LayoutParams(-1, dp(180)))

        root.addView(TextView(this).apply {
            text = "Respuestas"
            textSize = 13f
            textStyleBold()
            setPadding(0, dp(10), 0, dp(4))
        })
        val answerScroll = ScrollView(this)
        answerScroll.addView(TextView(this).apply {
            text = entry.answerText
            textSize = 14f
            setTextIsSelectable(true)
            setPadding(dp(10), dp(10), dp(10), dp(10))
        })
        root.addView(answerScroll, LinearLayout.LayoutParams(-1, dp(240)))

        AlertDialog.Builder(this)
            .setTitle("Historial GI X")
            .setView(root)
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun confirmClearHistory() {
        if (lockAppOnScreen) {
            Toast.makeText(this, "GI X bloqueado: desbloquea para borrar historial.", Toast.LENGTH_SHORT).show()
            return
        }
        if (historyRepository.getAll().isEmpty()) {
            Toast.makeText(this, "No hay historial para borrar.", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Borrar historial")
            .setMessage("¿Quieres borrar todo el historial guardado de preguntas y respuestas?")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Borrar") { _, _ ->
                historyRepository.clear()
                renderHistory()
                Toast.makeText(this, "Historial borrado.", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun formatHistoryDate(time: Long): String {
        return try {
            SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("es", "PE")).format(Date(time))
        } catch (_: Exception) {
            Date(time).toString()
        }
    }

    private fun TextView.textStyleBold() {
        setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun scrollTextToTop(view: TextView) {
        view.post {
            view.scrollTo(0, 0)
            (view.parent as? ScrollView)?.scrollTo(0, 0)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    /**
     * v1.6.16: el celular se queda con GI X abierto todo el examen esperando las fotos
     * de la cámara. Salir por error de la app rompe el ciclo, así que ATRÁS exige
     * BACK_PRESSES_TO_EXIT pulsaciones seguidas y además una confirmación.
     */
    override fun onBackPressed() {
        if (lockAppOnScreen) {
            Toast.makeText(this, "GI X protegido: usa DESBLOQUEAR GI X en el mismo botón.", Toast.LENGTH_SHORT).show()
            return
        }
        val now = System.currentTimeMillis()
        if (now - lastBackPressAtMs > BACK_EXIT_WINDOW_MS) backPressCount = 0
        lastBackPressAtMs = now
        backPressCount++

        if (backPressCount < BACK_PRESSES_TO_EXIT) {
            val remaining = BACK_PRESSES_TO_EXIT - backPressCount
            val message = if (remaining == 1) {
                "Pulsa ATRÁS una vez más si de verdad quieres salir de GI X."
            } else {
                "Pulsa ATRÁS $remaining veces más si de verdad quieres salir de GI X."
            }
            binding.tvStatus.text = message
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            return
        }

        backPressCount = 0
        confirmExitApp()
    }

    private fun confirmExitApp() {
        if (lockAppOnScreen) {
            Toast.makeText(this, "Desbloquea GI X antes de salir.", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("¿Salir de GI X?")
            .setMessage("GI X dejará de recibir fotos y responder por voz al salir.")
            .setNegativeButton("Seguir esperando fotos", null)
            .setPositiveButton("SALIR") { _, _ ->
                stopCurrentCycle()
                finish()
            }
            .show()
    }

    /** Bloquea acciones peligrosas sin tapar la interfaz: el usuario puede seguir
     *  desplazando, mirando preguntas, respuesta e imagen, y desbloquear desde
     *  el mismo botón donde bloqueó.
     */
    private fun enableTouchGuard() {
        if (lockAppOnScreen || inputMode != InputMode.CAMERA) return
        if (pendingReview != null) {
            Toast.makeText(this, "Primero responde o descarta el documento pendiente.", Toast.LENGTH_LONG).show()
            return
        }
        lockAppOnScreen = true
        unlockTapCount = 0
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        applyTouchGuardState()
        // Android gestiona el bloqueo real de Inicio/Recientes. Puede solicitar al usuario
        // aprobar "Fijar pantalla"; una app normal no puede impedir el desfijado del sistema.
        runCatching { startLockTask() }.onFailure {
            Toast.makeText(this, "Activa Fijar pantalla en ajustes de Android para proteger Inicio y Recientes.", Toast.LENGTH_LONG).show()
        }
    }

    /** La UI original permanece visible y recibe las actualizaciones normales de cámara/IA/voz. */
    private fun refreshProtectedScreen() = Unit

    private fun requestUnlockTouchGuard() {
        val now = System.currentTimeMillis()
        if (now - lastUnlockTapAtMs > UNLOCK_TAP_WINDOW_MS) unlockTapCount = 0
        lastUnlockTapAtMs = now
        unlockTapCount++
        if (unlockTapCount >= UNLOCK_TAPS) {
            unlockTapCount = 0
            applyTouchGuardState()
            confirmUnlockTouchGuard()
        } else {
            val remaining = UNLOCK_TAPS - unlockTapCount
            binding.btnAuto.text = "🔓 DESBLOQUEAR · FALTAN $remaining"
            binding.tvStatus.text = "GI X bloqueado: toca DESBLOQUEAR $remaining vez/veces más."
        }
    }

    private fun confirmUnlockTouchGuard() {
        if (!lockAppOnScreen || isFinishing || isDestroyed) return
        AlertDialog.Builder(this)
            .setTitle("¿Desbloquear GI X?")
            .setMessage("La cámara continuará esperando. Se habilitarán los controles de la app.")
            .setNegativeButton("SEGUIR BLOQUEADO") { _, _ -> unlockTapCount = 0 }
            .setPositiveButton("DESBLOQUEAR") { _, _ -> disableTouchGuard() }
            .setOnCancelListener { unlockTapCount = 0 }
            .show()
    }

    private fun disableTouchGuard() {
        lockAppOnScreen = false
        unlockTapCount = 0
        lastUnlockTapAtMs = 0L
        touchGuard?.let { (it.parent as? ViewGroup)?.removeView(it) }
        touchGuard = null
        applyTouchGuardState()
        runCatching { stopLockTask() }
        if (inputMode == InputMode.CAMERA) {
            binding.tvStatus.text = "Cámara automática: esperando foto. ATRÁS 3 veces y confirma para salir."
        }
    }

    private fun applyTouchGuardState() {
        val locked = lockAppOnScreen
        binding.btnAuto.text = if (locked) "🔓 DESBLOQUEAR · 3 TOQUES" else "🔒 BLOQUEAR GI X"
        binding.btnAuto.isEnabled = true

        binding.btnCapture.isEnabled = !locked
        binding.btnStop.isEnabled = !locked
        binding.btnChooseImage.isEnabled = !locked
        binding.btnApi.isEnabled = !locked
        binding.btnVoice.isEnabled = !locked
        binding.btnCameraSettings.isEnabled = !locked
        binding.btnOpenPreview.isEnabled = !locked
        binding.btnClearHistory.isEnabled = !locked
        binding.cbReviewBeforeApi.isEnabled = !locked
        binding.btnApproveOcr.isEnabled = !locked
        binding.btnEditOcr.isEnabled = !locked
        binding.btnDiscardOcr.isEnabled = !locked
        binding.btnToggleOcr.isEnabled = !locked

        for (index in 0 until binding.inputModeGroup.childCount) {
            binding.inputModeGroup.getChildAt(index).isEnabled = !locked
        }

        binding.tvStatus.text = if (locked) {
            "GI X bloqueado: puedes desplazar y mirar; desbloquea con 3 toques y confirmación."
        } else if (inputMode == InputMode.CAMERA) {
            "Cámara automática: esperando foto. Activa tu Zona Wi-Fi y deja GI X abierto."
        } else {
            "Modo IMAGEN MANUAL. Puedes elegir de 1 a 4 imágenes del mismo documento."
        }
    }

    private fun releaseScreenAwakeIfAllowed() {
        // Con el bloqueo activo la pantalla se mantiene encendida a propósito.
        if (lockAppOnScreen || inputMode == InputMode.CAMERA) return
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (lockAppOnScreen) {
            Toast.makeText(this, "GI X debe quedarse abierto esperando la cámara.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        destroyedForAsync = true
        // Invalida también cualquier callback que ya hubiera salido de un worker.
        workGeneration.incrementAndGet()
        touchGuard = null
        stopped = true
        cameraStatusTicker?.let { mainHandler.removeCallbacks(it) }
        mainHandler.removeCallbacksAndMessages(null)
        onlineProvider.cancelActiveRequest()
        CameraLinkService.detach(this)
        cameraBatchCollector.clear()
        cameraBatchFinalizeRunnable?.let { mainHandler.removeCallbacks(it) }
        cameraBatchFinalizeRunnable = null
        ocrProcessor.close()
        pendingSpeechText = null
        activeSpeechText = null
        activeSpeechFinalId = null
        isSpeakingAnswer = false
        tts?.stop()
        tts?.shutdown()
        ioExecutor.shutdownNow()
        cameraIoExecutor.shutdownNow()
        galleryExecutor.shutdownNow()
        dropPreviewReferencesForDestroy()
        super.onDestroy()
    }

    private enum class InputMode {
        CAMERA,
        IMAGE
    }

    companion object {
        // Salida protegida: el examen se pierde si la app se cierra por accidente.
        private const val UNLOCK_TAPS = 3
        private const val UNLOCK_TAP_WINDOW_MS = 1_800L
        private const val BACK_PRESSES_TO_EXIT = 3
        private const val BACK_EXIT_WINDOW_MS = 6_000L

        // Un documento combinado de hasta 10 preguntas se intenta primero en UNA sola
        // llamada. Si el proveedor falla o corta la respuesta, el mecanismo existente
        // recupera solo las preguntas necesarias de forma segura.
        private const val STANDARD_API_BATCH_SIZE = 10
        private const val TRUE_FALSE_API_BATCH_SIZE = 15
        private const val MAX_MANUAL_BATCH_IMAGES = 4
        private const val MAX_CAMERA_BATCH_IMAGES = CameraBatchPolicy.MAX_IMAGES
        private const val UTTERANCE_ANSWER = "gix_answer"
        private const val MAX_TTS_RETRIES = 2
        private const val TTS_RETRY_DELAY_MS = 700L
    }
}
