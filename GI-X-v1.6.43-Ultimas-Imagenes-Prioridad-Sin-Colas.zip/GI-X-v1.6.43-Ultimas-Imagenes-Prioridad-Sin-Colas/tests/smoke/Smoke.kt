import com.gix.cameraai.*
fun main() {
  val sample = """
    LECTURA Y CUESTIONARIO – TOPOGRAFÍA
    Lectura
    La topografía mide y representa gráficamente la superficie terrestre. El GPS ubica coordenadas.
    Cuestionario
    1. ¿Qué es la topografía?
    A) Astronomía
    B) Ciencia de la superficie terrestre
    C) Minería
    D) Clima
    2. ¿Para qué sirve el GPS?
    3. Verdadero o falso: El nivel mide alturas.
    4. Complete: El GPS obtiene ________.
    5. ¿Qué es la brújula?
    6. ¿Qué instrumentos conoces?
    7. ¿Cómo se mide?
    8. Mencione dos áreas en las que se utiliza la topografía.
    1. ______________________    2. ______________________
    9. ¿Por qué es importante la información topográfica?
    10. ¿Qué diferencia hay entre el GPS y la brújula?
  """.trimIndent()
  val qs = OcrQuestionExtractor.extractQuestions(sample)
  val nums = qs.mapNotNull(OcrQuestionExtractor::questionNumber)
  println("OCR ids: $nums")
  require(nums == (1..10).toList()) { "OCR missed or re-numbered question ($nums)" }
  require(qs[7].contains("1. ___") && qs[7].contains("2. ___")) { "Subanswer lines lost: ${qs[7]}" }
  println("OCR context: " + OcrQuestionExtractor.extractDocumentContext(sample).take(120))
  val corrupted = listOf("1. Pregunta A", "2. Pregunta B", "1. Pregunta C", "4. Pregunta D")
  require(OcrQuestionExtractor.hasCorruptNumbering(corrupted))
  require(OcrQuestionExtractor.hasCorruptNumbering(listOf("1. Primero", "1. Segundo")))

  // v1.6.43: un proveedor visual puede colocar por error un examen V/F entero en
  // CONTEXTO DETECTADO y dejar vacía la sección de preguntas. Debe rescatarse.
  val vfAsContext = """
    CONTEXTO DETECTADO
    SEGUNDO EXAMEN DE APLICACIÓN DE INTERNET
    PONGA SI ES VERDADERO ( V ) Y FALSO ( F )
    1) Cloud Computing entrega servicios informáticos mediante Internet. ( )
    2) El objetivo de la nube es proporcionar servicios escalables. ( )
    3) La nube permite acceder a servidores, almacenamiento y aplicaciones. ( )
    4) Pago por uso significa pagar por los servicios utilizados. ( )
    PREGUNTAS DETECTADAS
  """.trimIndent()
  require(OcrQuestionExtractor.looksLikeAnswerableDocument(vfAsContext))
  val vfQuestions = OcrQuestionExtractor.extractQuestions(vfAsContext)
  val vfNums = vfQuestions.mapNotNull(OcrQuestionExtractor::questionNumber)
  require(vfNums == listOf(1, 2, 3, 4)) { "V/F tratado erróneamente como solo texto: $vfQuestions" }
  println("OK smoke: 10 preguntas, casillas internas, alternativas, contexto, duplicados y rescate V/F")
}
