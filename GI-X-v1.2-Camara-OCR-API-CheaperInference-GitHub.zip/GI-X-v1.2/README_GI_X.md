# GI X v1.2

Aplicación Android personal para trabajar con una M5Stack Timer Camera X y también con imágenes elegidas manualmente desde el celular.

## Flujo principal

### Modo CÁMARA
1. Activa la Zona Wi‑Fi del celular y abre GI X.
2. Enciende la Timer Camera X con PWR.
3. El firmware preparado conecta solo a la red Wi‑Fi configurada, toma una foto, la envía a GI X y trata de apagarse automáticamente cuando trabaja con batería.
4. GI X hace OCR local mejorado, extrae la pregunta, consulta una API configurada, muestra la respuesta y la lee en voz alta.

También queda el botón **PEDIR FOTO A LA CÁMARA** para dejar una orden pendiente, útil si la cámara ya está activa o para pruebas.

### Modo IMAGEN MANUAL
1. Selecciona **IMAGEN MANUAL**.
2. Pulsa **ELEGIR IMAGEN DEL CELULAR**.
3. GI X corrige la orientación EXIF, prepara la imagen, hace OCR, consulta la API y lee la respuesta.

## OCR mejorado

GI X usa Google ML Kit Text Recognition v2 en el dispositivo. Para aumentar estabilidad con fotos reales:
- limita imágenes enormes para evitar bloqueos por memoria;
- amplía imágenes pequeñas cuando conviene;
- corrige la orientación de fotos de galería usando EXIF;
- hace una lectura sobre una versión normalizada;
- hace una segunda lectura sobre una versión en escala de grises y contraste reforzado;
- compara ambos resultados y conserva el texto más legible.

Ningún OCR puede garantizar 0 errores. La iluminación, enfoque, distancia, inclinación y tamaño de las letras siguen importando.

## APIs

Se conserva el sistema de varias APIs de la base anterior: Gemini, OpenRouter, Mistral y Cohere. Las claves se configuran desde el botón **API** y se guardan localmente en preferencias de Android.

## Cámara

Archivo preparado: `camera_firmware/TimerCameraX_GIX.ino`

Antes de grabarlo en la Timer Camera X hay que cambiar solo:
- `WIFI_NAME`
- `WIFI_PASSWORD`
- `GIX_TOKEN`

El token debe coincidir con **GI X > CÁMARA**.

La configuración de cámara está orientada a OCR: JPEG, UXGA 1600x1200 y varias tomas descartadas al inicio para estabilizar exposición/balance de blancos antes de enviar la foto útil.

## Compilar en GitHub

El ZIP incluye `.github/workflows/build-apk.yml`.

Al subir el contenido a un repositorio GitHub en `main` o `master`, GitHub Actions intentará compilar `app-debug.apk`. También puede ejecutarse manualmente desde **Actions > Build GI X APK > Run workflow**.

El APK generado queda como artefacto llamado `GI-X-debug-apk`.

## Versión

- applicationId: `com.gix.cameraai`
- versionCode: `3`
- versionName: `1.2.0`
- minSdk: 24
- targetSdk: 34

## Cheaper Inference / DeepSeek
GI X incluye un espacio dedicado para la API pagada de Cheaper Inference. Acepta claves `ci_live_...`, usa por defecto `deepseek-v4-pro`, prueba la conexión antes de marcarla como disponible y la deja como API principal cuando funciona. Las demás APIs quedan disponibles como respaldo. La clave se guarda localmente en las preferencias privadas de la app.
