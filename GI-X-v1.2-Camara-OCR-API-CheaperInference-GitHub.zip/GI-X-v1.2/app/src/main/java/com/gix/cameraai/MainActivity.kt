package com.gix.cameraai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.InputType
import android.text.method.ScrollingMovementMethod
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.gix.cameraai.databinding.ActivityMainBinding
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener, CameraBridgeServer.Listener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: AppPrefs
    private lateinit var apiSettings: GeminiSettings
    private lateinit var onlineProvider: OnlineAnswerProvider
    private lateinit var cameraServer: CameraBridgeServer
    private val ocrProcessor = OcrProcessor()
    private val ioExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val processing = AtomicBoolean(false)

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var autoMode = false
    private var stopped = false
    private var inputMode = InputMode.CAMERA
    private var activeCaptureRequestId: String? = null
    private var cameraStatusTicker: Runnable? = null

    private val openPhotoLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) loadPhotoFromUri(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = AppPrefs(this)
        apiSettings = GeminiSettings(this)
        onlineProvider = OnlineAnswerProvider(this)
        tts = TextToSpeech(this, this)

        binding.tvOcr.movementMethod = ScrollingMovementMethod.getInstance()
        binding.tvAnswer.movementMethod = ScrollingMovementMethod.getInstance()

        setupButtons()
        updateApiChip()
        startCameraServer()
        startCameraStatusTicker()
    }

    private fun setupButtons() {
        binding.inputModeGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            when (checkedId) {
                R.id.btnModeCamera -> setInputMode(InputMode.CAMERA)
                R.id.btnModeImage -> setInputMode(InputMode.IMAGE)
            }
        }
        binding.inputModeGroup.check(R.id.btnModeCamera)

        binding.btnCapture.setOnClickListener {
            stopped = false
            requestCameraCapture(manual = true)
        }

        binding.btnAuto.setOnClickListener {
            if (inputMode != InputMode.CAMERA) {
                binding.tvStatus.text = "El modo AUTO funciona con la cámara. Cambia a CÁMARA."
                return@setOnClickListener
            }
            autoMode = !autoMode
            stopped = false
            binding.btnAuto.text = if (autoMode) "AUTO: ON" else "AUTO: OFF"
            if (autoMode) {
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                binding.tvStatus.text = "AUTO activo: GI X repetirá foto → OCR → API → voz."
                requestCameraCapture(manual = false)
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                binding.tvStatus.text = "AUTO detenido. Enciende la cámara o pulsa PEDIR FOTO."
            }
        }

        binding.btnStop.setOnClickListener { stopCurrentCycle() }

        binding.btnChooseImage.setOnClickListener {
            stopped = false
            openPhotoLauncher.launch(arrayOf("image/*"))
        }

        binding.btnApi.setOnClickListener { showApiDialog() }
        binding.btnVoice.setOnClickListener { showVoiceDialog() }
        binding.btnCameraSettings.setOnClickListener { showCameraDialog() }
    }

    private fun setInputMode(mode: InputMode) {
        if (inputMode == mode && binding.cameraActions.visibility == if (mode == InputMode.CAMERA) View.VISIBLE else View.GONE) {
            return
        }
        inputMode = mode
        when (mode) {
            InputMode.CAMERA -> {
                binding.cameraActions.visibility = View.VISIBLE
                binding.btnChooseImage.visibility = View.GONE
                binding.tvStatus.text = "Modo CÁMARA. Activa tu Zona Wi-Fi y enciende la Timer Camera X; GI X recibirá la foto."
            }
            InputMode.IMAGE -> {
                autoMode = false
                binding.btnAuto.text = "AUTO: OFF"
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                cameraServer.cancelCapture()
                activeCaptureRequestId = null
                binding.cameraActions.visibility = View.GONE
                binding.btnChooseImage.visibility = View.VISIBLE
                binding.tvStatus.text = "Modo IMAGEN MANUAL. Pulsa ELEGIR IMAGEN y GI X hará OCR → API → voz."
            }
        }
    }

    private fun startCameraServer() {
        cameraServer = CameraBridgeServer(
            CameraBridgeServer.DEFAULT_PORT,
            tokenProvider = { prefs.pairingToken },
            listener = this
        )
        cameraServer.start()
    }

    private fun startCameraStatusTicker() {
        val ticker = object : Runnable {
            override fun run() {
                updateCameraChip()
                mainHandler.postDelayed(this, 2_000L)
            }
        }
        cameraStatusTicker = ticker
        mainHandler.post(ticker)
    }

    private fun requestCameraCapture(manual: Boolean) {
        if (processing.get()) {
            binding.tvStatus.text = "Espera: GI X todavía está procesando la foto anterior."
            return
        }
        if (activeCaptureRequestId != null) {
            binding.tvStatus.text = "Ya hay una foto solicitada. Esperando a la cámara..."
            return
        }

        val requestId = cameraServer.requestCapture()
        activeCaptureRequestId = requestId
        binding.tvStatus.text = if (cameraServer.isCameraConnected()) {
            "Orden enviada. Esperando la foto de Timer Camera X..."
        } else {
            "Orden preparada. Enciende la cámara y verifica que esté conectada a tu Zona Wi-Fi."
        }

        mainHandler.postDelayed({
            if (activeCaptureRequestId == requestId) {
                cameraServer.cancelCapture()
                activeCaptureRequestId = null
                if (!processing.get()) {
                    binding.tvStatus.text = if (manual) {
                        "La cámara no respondió. Revisa Zona Wi-Fi, cámara y clave de enlace."
                    } else {
                        "Auto: cámara sin respuesta. Reintentaré cuando vuelva a estar disponible."
                    }
                }
            }
        }, 25_000L)
    }

    private fun stopCurrentCycle() {
        stopped = true
        autoMode = false
        binding.btnAuto.text = "AUTO: OFF"
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        cameraServer.cancelCapture()
        activeCaptureRequestId = null
        onlineProvider.cancelActiveRequest()
        tts?.stop()
        processing.set(false)
        binding.tvStatus.text = if (inputMode == InputMode.CAMERA) "Detenido. Enciende la cámara o pulsa PEDIR FOTO." else "Detenido. Pulsa ELEGIR IMAGEN cuando quieras continuar."
    }

    override fun onServerStarted(port: Int) {
        runOnUiThread {
            if (inputMode == InputMode.CAMERA) {
                binding.tvStatus.text = "GI X listo. Activa tu Zona Wi-Fi y enciende la cámara; recibirá la foto por el puerto $port."
            }
        }
    }

    override fun onServerError(message: String) {
        runOnUiThread {
            binding.tvStatus.text = "Error del enlace con cámara: $message"
            binding.tvCameraChip.text = "Cámara: error"
        }
    }

    override fun onCameraSeen() {
        runOnUiThread { updateCameraChip() }
    }

    override fun onPhotoReceived(jpeg: ByteArray, requestId: String?) {
        activeCaptureRequestId = null
        if (inputMode != InputMode.CAMERA) {
            runOnUiThread {
                binding.tvStatus.text = "Llegó una foto de la cámara, pero GI X está en modo IMAGEN MANUAL."
            }
            return
        }
        val bitmap = BitmapFactory.decodeByteArray(
            jpeg,
            0,
            jpeg.size,
            BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
        )
        if (bitmap == null) {
            runOnUiThread { binding.tvStatus.text = "La cámara envió una imagen que Android no pudo abrir." }
            return
        }
        runOnUiThread { processBitmap(bitmap, source = "cámara") }
    }

    private fun loadPhotoFromUri(uri: Uri) {
        binding.tvStatus.text = "Abriendo imagen y corrigiendo orientación..."
        ioExecutor.execute {
            val bitmap = runCatching { ImageLoader.load(this, uri) }.getOrNull()
            runOnUiThread {
                if (bitmap == null) {
                    binding.tvStatus.text = "No pude abrir esa imagen. Prueba con JPG, PNG, WEBP o una foto normal."
                    return@runOnUiThread
                }
                processBitmap(bitmap, source = "imagen manual")
            }
        }
    }

    private fun processBitmap(bitmap: Bitmap, source: String) {
        if (!processing.compareAndSet(false, true)) {
            binding.tvStatus.text = "Ya estoy procesando otra foto."
            return
        }
        stopped = false
        binding.ivPreview.setImageBitmap(bitmap)
        binding.tvPreviewPlaceholder.visibility = View.GONE
        binding.tvStatus.text = "Imagen recibida ($source). OCR mejorado: preparando y leyendo texto..."
        binding.tvOcr.text = "Procesando OCR..."
        binding.tvAnswer.text = "Esperando texto..."

        ocrProcessor.process(
            bitmap,
            onSuccess = { rawText ->
                runOnUiThread { handleOcrResult(rawText) }
            },
            onError = { error ->
                runOnUiThread {
                    processing.set(false)
                    binding.tvStatus.text = "OCR falló: $error"
                    binding.tvOcr.text = "No se pudo detectar texto."
                    binding.tvAnswer.text = "Acerca la cámara, mejora la luz y vuelve a intentarlo."
                    scheduleNextAutoIfNeeded()
                }
            }
        )
    }

    private fun handleOcrResult(rawText: String) {
        if (stopped) {
            processing.set(false)
            return
        }
        val cleanRaw = rawText.trim()
        if (cleanRaw.isBlank()) {
            processing.set(false)
            binding.tvStatus.text = "OCR terminado, pero no encontró texto legible."
            binding.tvOcr.text = "Sin texto detectado."
            binding.tvAnswer.text = "Prueba con más luz, menos inclinación y enfoca mejor la pregunta."
            scheduleNextAutoIfNeeded()
            return
        }

        val question = OcrQuestionExtractor.extract(cleanRaw)
        binding.tvOcr.text = if (question.isBlank()) cleanRaw.take(2600) else question
        scrollTextToTop(binding.tvOcr)

        if (question.isBlank()) {
            processing.set(false)
            binding.tvStatus.text = "Se leyó texto, pero no pude identificar una pregunta."
            binding.tvAnswer.text = "Centra la pregunta en la foto y vuelve a intentarlo."
            scheduleNextAutoIfNeeded()
            return
        }

        binding.tvStatus.text = "Pregunta detectada. Consultando la API..."
        binding.tvAnswer.text = "Consultando IA..."
        ioExecutor.execute {
            val answer = onlineProvider.fetchShortAnswer(question)
            runOnUiThread {
                if (stopped) {
                    processing.set(false)
                    return@runOnUiThread
                }
                handleAnswer(answer)
            }
        }
    }

    private fun handleAnswer(answer: String) {
        processing.set(false)
        val clean = answer.trim().ifBlank { "La API no devolvió una respuesta." }
        binding.tvAnswer.text = clean
        scrollTextToTop(binding.tvAnswer)
        binding.tvStatus.text = "Respuesta lista. Reproduciendo voz..."

        if (ttsReady) {
            tts?.setSpeechRate(prefs.speechRate)
            tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ANSWER)
        } else {
            binding.tvStatus.text = "Respuesta lista. El motor de voz todavía no está disponible."
            scheduleNextAutoIfNeeded()
        }
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) {
            ttsReady = false
            return
        }
        val engine = tts ?: return
        val result = engine.setLanguage(Locale("es", "PE"))
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.language = Locale("es", "ES")
        }
        engine.setSpeechRate(prefs.speechRate)
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit
            override fun onDone(utteranceId: String?) {
                if (utteranceId == UTTERANCE_ANSWER) {
                    runOnUiThread {
                        binding.tvStatus.text = if (autoMode) {
                            "Respuesta terminada. Preparando la siguiente foto..."
                        } else {
                            "Listo. Pulsa TOMAR FOTO para otra pregunta."
                        }
                        scheduleNextAutoIfNeeded()
                    }
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                if (utteranceId == UTTERANCE_ANSWER) runOnUiThread { scheduleNextAutoIfNeeded() }
            }
        })
        ttsReady = true
    }

    private fun scheduleNextAutoIfNeeded() {
        if (!autoMode || stopped || inputMode != InputMode.CAMERA) return
        mainHandler.postDelayed({
            if (autoMode && !stopped && !processing.get() && activeCaptureRequestId == null) {
                requestCameraCapture(manual = false)
            }
        }, AUTO_NEXT_DELAY_MS)
    }

    private fun updateCameraChip() {
        binding.tvCameraChip.text = if (cameraServer.isCameraConnected()) {
            "Cámara: conectada"
        } else {
            "Cámara: esperando"
        }
    }

    private fun updateApiChip() {
        val configs = apiSettings.getApiConfigs()
        if (configs.isEmpty()) {
            binding.tvApiChip.text = "API: sin configurar"
            return
        }
        configs.forEach { apiSettings.shouldSkip(it) }
        val activeIndex = apiSettings.getLastGoodIndex().coerceIn(0, configs.lastIndex)
        val active = configs.getOrNull(activeIndex)?.takeIf { apiSettings.isReady(it) }
            ?: configs.firstOrNull { apiSettings.isReady(it) }
        binding.tvApiChip.text = if (active != null) {
            if (active.provider == NetProvider.CHEAPER_INFERENCE) "API: DeepSeek ✓" else "API: ${active.provider.label} ✓"
        } else {
            "API: sin probar"
        }
    }

    private fun showVoiceDialog() {
        val labels = arrayOf("0.50x", "0.75x", "1.00x", "1.25x", "1.50x")
        val values = floatArrayOf(0.50f, 0.75f, 1.00f, 1.25f, 1.50f)
        val current = values.indices.minByOrNull { kotlin.math.abs(values[it] - prefs.speechRate) } ?: 2
        AlertDialog.Builder(this)
            .setTitle("Velocidad de voz")
            .setSingleChoiceItems(labels, current) { dialog, which ->
                prefs.speechRate = values[which]
                tts?.setSpeechRate(values[which])
                Toast.makeText(this, "Voz ${labels[which]}", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showCameraDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(4))
        }
        val info = TextView(this).apply {
            text = "La cámara se conectará solo a la Zona Wi-Fi configurada en su firmware y enviará las fotos a GI X por el puerto ${CameraBridgeServer.DEFAULT_PORT}. La misma clave debe quedar grabada en la Timer Camera X."
            textSize = 14f
        }
        val tokenInput = EditText(this).apply {
            hint = "Clave de enlace"
            setText(prefs.pairingToken)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            maxLines = 1
        }
        val note = TextView(this).apply {
            text = "No cambies esta clave después de programar la cámara, salvo que vuelvas a grabar el firmware con la misma clave."
            textSize = 12f
        }
        box.addView(info)
        box.addView(tokenInput, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) })
        box.addView(note, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        val dialog = AlertDialog.Builder(this)
            .setTitle("Enlace con Timer Camera X")
            .setView(box)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                prefs.pairingToken = tokenInput.text?.toString().orEmpty()
                tokenInput.setText(prefs.pairingToken)
                binding.tvStatus.text = "Clave de cámara guardada. Debe coincidir con el firmware."
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun showApiDialog() {
        // Cheaper Inference tiene un espacio propio porque será la API pagada/principal.
        // Las APIs gratuitas/de respaldo se siguen administrando en la sección general.
        val providers = NetProvider.entries.filter { it != NetProvider.CHEAPER_INFERENCE }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), dp(4))
        }

        val allStatus = TextView(this).apply {
            text = apiSettings.getStatusReportForConfigs()
            textSize = 12f
            setPadding(0, 0, 0, dp(8))
        }

        // ---- Espacio dedicado: Cheaper Inference / DeepSeek ----
        val cheaperTitle = TextView(this).apply {
            text = "CHEAPER INFERENCE · DEEPSEEK"
            textStyleBold()
            textSize = 14f
        }
        val cheaperInfo = TextView(this).apply {
            text = "API de pago. Pega tu clave ci_live_… y GI X la probará antes de marcarla como disponible. Modelo recomendado: deepseek-v4-pro."
            textSize = 12f
            setPadding(0, dp(3), 0, dp(4))
        }
        val savedCheaper = apiSettings.getApiConfigs().firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }
        val cheaperKeyInput = EditText(this).apply {
            hint = if (savedCheaper == null) "Clave Cheaper Inference (ci_live_…)" else "Clave guardada. Pega otra solo para reemplazarla"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            maxLines = 1
        }
        val cheaperModelInput = EditText(this).apply {
            hint = "Modelo DeepSeek"
            setText(savedCheaper?.model ?: NetProvider.CHEAPER_INFERENCE.defaultModel)
            maxLines = 1
        }
        val cheaperStatus = TextView(this).apply {
            textSize = 12f
            setPadding(0, dp(4), 0, dp(5))
        }
        val cheaperButton = Button(this).apply { text = "GUARDAR Y PROBAR DEEPSEEK" }

        fun refreshCheaperStatus(message: String? = null) {
            val configs = apiSettings.getApiConfigs()
            val index = configs.indexOfFirst { it.provider == NetProvider.CHEAPER_INFERENCE }
            val config = configs.getOrNull(index)
            val saved = if (config == null) {
                "DeepSeek: SIN CONFIGURAR"
            } else {
                apiSettings.shouldSkip(config)
                when (apiSettings.getStatus(config)) {
                    "ready" -> "DeepSeek: DISPONIBLE ✓ · ${config.model}"
                    "untested" -> "DeepSeek: SIN PROBAR · ${config.model}"
                    "limit" -> "DeepSeek: NO DISPONIBLE · sin saldo o límite temporal"
                    "wait" -> "DeepSeek: EN ESPERA · ${apiSettings.getMessage(config).ifBlank { "error temporal" }}"
                    "error" -> "DeepSeek: NO DISPONIBLE · ${apiSettings.getMessage(config).ifBlank { "revisa clave o modelo" }}"
                    else -> "DeepSeek: SIN PROBAR · ${config.model}"
                }
            }
            cheaperStatus.text = listOfNotNull(message?.takeIf { it.isNotBlank() }, saved).joinToString("\n")
            updateApiChip()
        }

        refreshCheaperStatus()
        box.addView(cheaperTitle)
        box.addView(cheaperInfo)
        box.addView(cheaperKeyInput, LinearLayout.LayoutParams(-1, dp(54)))
        box.addView(cheaperModelInput, LinearLayout.LayoutParams(-1, dp(54)))
        box.addView(cheaperButton, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(5) })
        box.addView(cheaperStatus, LinearLayout.LayoutParams(-1, -2))

        val divider = View(this).apply { setBackgroundColor(0x334F6178) }
        box.addView(divider, LinearLayout.LayoutParams(-1, dp(1)).apply {
            topMargin = dp(7)
            bottomMargin = dp(10)
        })

        // ---- APIs adicionales / respaldo ----
        box.addView(TextView(this).apply {
            text = "APIs ADICIONALES / RESPALDO"
            textStyleBold()
            textSize = 14f
        })

        val providerSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                providers.map { it.label }
            )
        }
        val keyInput = EditText(this).apply {
            hint = "API Key"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            maxLines = 1
        }
        val modelInput = EditText(this).apply {
            hint = "Modelo"
            setText(providers.first().defaultModel)
            maxLines = 1
        }
        val addButton = Button(this).apply { text = "GUARDAR Y PROBAR API" }
        val testAllButton = Button(this).apply { text = "PROBAR TODAS LAS APIs" }
        val clearButton = Button(this).apply { text = "BORRAR TODAS" }
        val closeButton = Button(this).apply { text = "CERRAR" }

        box.addView(TextView(this).apply { text = "Proveedor"; textStyleBold() })
        box.addView(providerSpinner, LinearLayout.LayoutParams(-1, dp(50)))
        box.addView(keyInput, LinearLayout.LayoutParams(-1, dp(54)))
        box.addView(modelInput, LinearLayout.LayoutParams(-1, dp(54)))
        box.addView(addButton, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(6) })
        box.addView(testAllButton, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4) })
        box.addView(clearButton, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4) })
        box.addView(allStatus, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        box.addView(closeButton, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4) })

        providerSpinner.setSelection(0)
        providerSpinner.onItemSelectedListener = SimpleItemSelectedListener { position ->
            val provider = providers[position]
            modelInput.setText(provider.defaultModel)
        }

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(box, ScrollView.LayoutParams(-1, -2))
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("APIs de GI X")
            .setView(scroll)
            .create()

        fun refreshStatus(message: String? = null) {
            val report = apiSettings.getStatusReportForConfigs()
            allStatus.text = listOfNotNull(message?.takeIf { it.isNotBlank() }, report).joinToString("\n\n")
            refreshCheaperStatus()
            updateApiChip()
        }

        cheaperButton.setOnClickListener {
            val typedKey = cheaperKeyInput.text?.toString().orEmpty().trim()
            val current = apiSettings.getApiConfigs().firstOrNull { it.provider == NetProvider.CHEAPER_INFERENCE }
            val key = typedKey.ifBlank { current?.apiKey.orEmpty() }
            if (key.isBlank()) {
                cheaperKeyInput.error = "Pega tu clave ci_live_…"
                return@setOnClickListener
            }
            val model = cheaperModelInput.text?.toString().orEmpty().trim()
                .ifBlank { NetProvider.CHEAPER_INFERENCE.defaultModel }
            val config = NetApiConfig(
                name = "Cheaper DeepSeek",
                provider = NetProvider.CHEAPER_INFERENCE,
                apiKey = key,
                model = model
            ).clean(0)

            // Solo dejamos un espacio Cheaper Inference: al guardar reemplaza el anterior.
            val remaining = apiSettings.getApiConfigs()
                .filterNot { it.provider == NetProvider.CHEAPER_INFERENCE }
            apiSettings.saveApiConfigs(listOf(config) + remaining)

            cheaperButton.isEnabled = false
            cheaperStatus.text = "Cheaper Inference: PROBANDO…"
            ioExecutor.execute {
                val result = onlineProvider.testApiConfig(config)
                runOnUiThread {
                    cheaperButton.isEnabled = true
                    if (result.first) cheaperKeyInput.text?.clear()
                    refreshStatus(result.second)
                }
            }
        }

        addButton.setOnClickListener {
            val key = keyInput.text?.toString().orEmpty().trim()
            if (key.isBlank()) {
                keyInput.error = "Escribe una API Key"
                return@setOnClickListener
            }
            val provider = providers[providerSpinner.selectedItemPosition]
            val model = modelInput.text?.toString().orEmpty().trim().ifBlank { provider.defaultModel }
            val existing = apiSettings.getApiConfigs().toMutableList()
            val config = NetApiConfig(
                name = "API ${existing.size + 1}",
                provider = provider,
                apiKey = key,
                model = model
            ).clean(existing.size)
            if (existing.none { it.provider == config.provider && it.apiKey == config.apiKey && it.model == config.model }) {
                existing += config
                apiSettings.saveApiConfigs(existing)
            }
            addButton.isEnabled = false
            allStatus.text = "Probando ${provider.label}..."
            ioExecutor.execute {
                val result = onlineProvider.testApiConfig(config)
                runOnUiThread {
                    addButton.isEnabled = true
                    refreshStatus(result.second)
                    if (result.first) keyInput.text?.clear()
                }
            }
        }

        testAllButton.setOnClickListener {
            val configs = apiSettings.getApiConfigs()
            if (configs.isEmpty()) {
                refreshStatus("No hay APIs guardadas.")
                return@setOnClickListener
            }
            testAllButton.isEnabled = false
            allStatus.text = "Probando ${configs.size} API(s)..."
            ioExecutor.execute {
                val lines = configs.map { onlineProvider.testApiConfig(it).second }
                runOnUiThread {
                    testAllButton.isEnabled = true
                    refreshStatus(lines.joinToString("\n"))
                }
            }
        }

        clearButton.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Borrar APIs")
                .setMessage("¿Quieres borrar todas las claves guardadas en GI X, incluida Cheaper Inference?")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Borrar") { _, _ ->
                    apiSettings.saveApiConfigs(emptyList())
                    refreshStatus("APIs borradas.")
                }
                .show()
        }
        closeButton.setOnClickListener { dialog.dismiss() }
        dialog.setOnDismissListener { updateApiChip() }
        dialog.show()
    }

    private fun TextView.textStyleBold() {
        setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun scrollTextToTop(view: TextView) {
        view.post { view.scrollTo(0, 0) }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        cameraStatusTicker?.let { mainHandler.removeCallbacks(it) }
        mainHandler.removeCallbacksAndMessages(null)
        onlineProvider.cancelActiveRequest()
        cameraServer.stop()
        ocrProcessor.close()
        tts?.stop()
        tts?.shutdown()
        ioExecutor.shutdownNow()
        super.onDestroy()
    }


    private enum class InputMode {
        CAMERA,
        IMAGE
    }

    companion object {
        private const val UTTERANCE_ANSWER = "gix_answer"
        private const val AUTO_NEXT_DELAY_MS = 3_500L
    }
}
