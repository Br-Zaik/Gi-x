# GI X v1.6.51 — Respuesta por lote completo

## Objetivo
Eliminar el streaming de respuestas de DeepSeek y volver a un flujo de lote completo para evitar contradicciones entre respuestas parciales y la validación final.

## Cambios
- SSE/streaming desactivado para respuestas de DeepSeek.
- MainActivity ya no pasa callback de respuestas parciales.
- GI X espera la respuesta completa del bloque antes de incorporarla a la UI y al TTS.
- V/F: tamaño de bloque reducido de 15 a 10 preguntas para disminuir omisiones/formato incompleto.
- Si un bloque termina con HTTP correcto pero la salida está incompleta o mal formateada, GI X recupera automáticamente ese bloque por preguntas individuales.
- No se hace recuperación automática ante timeout/corte de red incierto para evitar duplicar una petición que pudiera seguir procesándose en el proveedor.
- Se conserva el parser tolerante de v1.6.50: V/F numerado o por posición cuando la cantidad coincide, alternativas y respuestas por posición.
- Se conserva procesamiento nuevo para cada envío, sin caché de respuestas ni de imágenes.
- Cámara y Manual usan el mismo flujo.
- Se mantiene lectura visual por API, sin OCR local.

## Versionado
- versionName: 1.6.51
- versionCode: 76
