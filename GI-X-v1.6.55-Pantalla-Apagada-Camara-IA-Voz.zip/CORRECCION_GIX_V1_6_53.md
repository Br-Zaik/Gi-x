# GI X v1.6.53 — Limpieza de secciones y respuestas mixtas

## Objetivo
Pulir la v1.6.52 sin cambiar su arquitectura: mantener streaming rápido + TTS progresivo y eliminar errores de formato observados en una hoja con lectura, V/F, alternativas, respuesta corta y completar.

## Cambios
- Mantiene SSE real: una respuesta estable se muestra y entra a TTS apenas llega.
- Los encabezados/instrucciones A/B/C/D (V/F, Alternativas, Responder, Completar) ya no se convierten en preguntas ni se duplican si la visión devuelve variantes `A.` y `A)`.
- El prompt visual indica explícitamente separar instrucciones de las preguntas reales y deduplicar encabezados.
- El normalizador de etiquetas ya no interpreta metadatos internos del payload (`TIPO:`, `TEXTO:`, `CONTEXTO:`) como contenido de una respuesta.
- Los lotes se normalizan respuesta por respuesta contra su pregunta original antes de mostrarlos. Esto conserva reglas especiales para V/F, alternativas, completar, fórmulas, Fe/Pb/Ag y etiquetas como `Sin:`/`Epi:`.
- La pantalla limpia residuos `TIPO:`, `TEXTO:`, `Respuesta:` y numeración técnica repetida. En alternativas reales se conserva la letra correcta.
- Durante streaming, un fragmento suelto que todavía no puede asociarse a una pregunta no se muestra como respuesta independiente.
- En ejercicios de completar, si hay varios espacios se exige una respuesta por espacio y se priorizan palabras/expresiones literales del contexto cuando estén disponibles.
- Se mantienen lotes de 10 para V/F y 8 para preguntas generales; preguntas largas/tablas siguen aisladas.
- Cámara y Manual siguen usando el mismo motor. Sin OCR local y sin caché de respuestas/imágenes.

## Versión
- versionCode: 78
- versionName: 1.6.53
