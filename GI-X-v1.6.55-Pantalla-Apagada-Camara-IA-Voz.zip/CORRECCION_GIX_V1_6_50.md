# GI X v1.6.50 — streaming progresivo + recuperación por posición

Cambios realizados sobre v1.6.49:

- Se reactiva streaming SSE para Cheaper Inference cuando MainActivity entrega callback de progreso.
- Cada respuesta completa puede mostrarse y enviarse a voz sin esperar el lote entero.
- Lotes V/F aceptan `Verdadero/Falso`, `V/F`, con o sin numeración, y pueden reasignarse por posición a los IDs del lote.
- Lotes generales aceptan una respuesta por línea sin numeración cuando el número de líneas coincide con el número de preguntas; GI X agrega los IDs técnicos localmente antes de validar.
- En MainActivity, si llegan líneas sin numeración durante streaming, se vinculan por orden a las preguntas del lote, incluso si la hoja original no tenía números.
- Las preguntas sin número siguen usando identificadores internos solamente; la interfaz decide si mostrarlos.
- Se conserva la política de v1.6.48/v1.6.49: cada envío nuevo se procesa de nuevo y no se reintroducen cachés de imagen/respuesta.
- Se conservan respuestas parciales válidas si una respuesta posterior falla.
- No se añade reintento automático extra por mero problema de formato.

Versión: 1.6.50
versionCode: 75
