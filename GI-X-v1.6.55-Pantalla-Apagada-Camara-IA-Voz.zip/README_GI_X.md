# GI X v1.6.55 — visión online + streaming robusto + pantalla apagada

GI X es una app Android (`com.gix.cameraai`) para recibir 1–4 fotos desde M5Stack TimerCamera-X o elegir 1–4 imágenes manuales y resolver el documento mediante IA.

## Flujo actual

`Cámara / Manual → optimizar imagen → API visual → contexto + preguntas → API de respuestas → pantalla → TTS`

La v1.6.55 es **online-only**. Se eliminaron del APK los motores locales PP-OCR/ML Kit/ONNX/OpenCV y sus modelos. Los archivos cuyo nombre histórico contiene `Ocr` son únicamente analizadores de TEXTO ya transcrito por la IA; no reconocen píxeles ni incluyen un motor OCR.

## Prioridad: últimas imágenes

No existe una cola de documentos. Una nueva entrada manual o un nuevo lote de cámara invalida el trabajo anterior, cancela el socket de API que siga abierto, detiene TTS y descarta cualquier respuesta tardía. Las 1–4 fotos que comparten el mismo lote de cámara sí se agrupan como un único documento.

## Respuestas en tiempo real

- DeepSeek usa streaming SSE en consultas reales.
- Cada respuesta completa y asociada a una pregunta se muestra y entra a la cola TTS sin esperar al lote completo.
- V/F usa lotes de 10 y preguntas generales lotes de 8; preguntas largas/tablas se aíslan.
- Los encabezados A/B/C/D de secciones no se tratan como preguntas.
- La limpieza final elimina metadatos internos como `TIPO:`/`TEXTO:` y canonicaliza cada respuesta del lote contra su pregunta real.
- En completar, se priorizan palabras literales del contexto y se conserva el orden de varios espacios.

## Control de API

- Cada POST se envía una sola vez; un timeout incierto nunca se repite automáticamente.
- Solo un `finish_reason` explícito de límite de salida permite dividir un bloque para recuperarlo.
- La etapa visual detecta `length/MAX_TOKENS` y no responde usando una transcripción cortada.
- Se distinguen autenticación, solicitud/modelo inválido, payload demasiado grande, rate limit, servidor y timeout.
- La pantalla registra, cuando el proveedor los informa, tokens de entrada/salida/total, número de llamadas y tiempo acumulado del documento activo.
- Las claves se guardan cifradas con Android Keystore (AES-GCM), no como texto plano en SharedPreferences.

## Memoria e imágenes

Las imágenes manuales se decodifican con muestreo, se orientan y se normalizan a JPEG para visión. El lado largo se limita antes del Base64 y se controla el tamaño del payload. Esto reduce picos de RAM y evita enviar fotos innecesariamente enormes.

## Cámara y recuperación

Las fotos de cámara se conservan temporalmente en almacenamiento interno. Si la API ya terminó y Android cierra la actividad durante TTS, la respuesta final se guarda junto al lote: al volver, GI X reproduce la voz sin llamar otra vez a la API. Al finalizar correctamente la voz, se eliminan los archivos temporales.

Las fotos temporales y SharedPreferences se excluyen del backup/transferencia. El historial se guarda en `noBackupFilesDir`, con límites de cantidad y longitud.

## Compilar

Incluye dos workflows:

- `.github/workflows/build-apk.yml`: compila el proyecto que está en el repositorio.
- `.github/workflows/compilar_zip.yml`: descomprime el ZIP y compila el proyecto encontrado. La APK resultante toma automáticamente el `versionName` real; ya no usa un nombre viejo fijo.

No hay pasos de descarga/preparación de OCR local.

## Versión

- `applicationId`: `com.gix.cameraai`
- `versionCode`: `80`
- `versionName`: `1.6.55`
- `minSdk`: `26`
- `targetSdk`: `34`

No se modificó el firmware de TimerCamera-X en esta versión.


## v1.6.54 — Contexto IA AUTO / GENERAL / MINERÍA
- Nuevo selector visible de contexto académico, persistente entre aperturas.
- AUTO analiza el contexto y el conjunto completo de preguntas para detectar la materia dominante.
- MINERÍA prioriza Explotación Minera, Topografía, Geodesia, Geología y Seguridad Minera al desambiguar términos.
- GENERAL no fuerza una materia.
- La misma política se aplica a Cámara e Imagen Manual sin cambiar el streaming v1.6.53.


## v1.6.55 — trabajo con pantalla apagada
- Se mantiene el mismo motor de Cámara, visión IA, streaming, validación y TTS de v1.6.54.
- `CameraLinkService` conserva un `PARTIAL_WAKE_LOCK` mientras GI X está activo: mantiene CPU disponible sin encender la pantalla.
- Se añade `WifiLock` de alto rendimiento y `ACCESS_WIFI_STATE` para reducir suspensiones del enlace Wi-Fi al apagar la pantalla.
- Un watchdog cada 5 s verifica CPU lock, Wi-Fi lock y servidor de cámara.
- Al recibir `ACTION_SCREEN_OFF`, el servicio refuerza los locks y la notificación confirma que cámara/IA/voz siguen activas.
- Apagar la pantalla no cancela `MainActivity`: el pipeline existente sigue recibiendo la foto, consultando visión/API, mostrando internamente el resultado y enviándolo a TTS.
- Si la Activity fue cerrada realmente, el servicio no finge tener IA/TTS: guarda la foto en el journal y avisa que hay que abrir GI X.
- Force-stop, reinicio del teléfono o cierres extremos del fabricante siguen siendo decisiones del sistema y no pueden garantizarse desde una app normal.
