# Validación GI X v1.6.50

Validaciones realizadas:

- Smoke OCR/extractor: OK.
- Smoke de formato del proveedor: OK.
- Smoke de TTS progresivo: OK.
- Verificación estática: streaming se activa solo para llamadas normales con callback; pruebas API conservan JSON no-streaming.
- Verificación estática: lote V/F sin IDs puede reconstruirse por posición antes de `batchAnswerIssue`.
- Verificación estática: lote general sin IDs y con una línea por pregunta puede recibir IDs técnicos antes de validarse.
- Verificación estática: Cámara y Manual convergen en el mismo pipeline de `fetchShortAnswer`/`publishProgressiveAnswers`.

La compilación Android completa debe ejecutarse en GitHub Actions porque el ZIP no incluye Gradle Wrapper y este entorno no tiene Gradle instalado.
