# GI X v1.6.55 · Pantalla apagada sin tocar el motor estable

Base: v1.6.54.

## Cambio solicitado
Permitir que el usuario deje GI X en modo Cámara, apague físicamente la pantalla del teléfono y la app continúe recibiendo fotos, procesando la IA y hablando por TTS.

## Implementación
- `CameraLinkService` sigue siendo foreground service `connectedDevice` y `START_STICKY`.
- WakeLock cambiado a `PARTIAL_WAKE_LOCK` persistente mientras el servicio está activo. No enciende la pantalla; mantiene CPU disponible.
- Añadido `WifiManager.WifiLock` en modo `WIFI_MODE_FULL_HIGH_PERF` y permiso `ACCESS_WIFI_STATE` para proteger el enlace con TimerCamera-X/hotspot cuando la pantalla se apaga.
- Watchdog cada 5 s verifica locks y socket; si el servidor deja de escuchar, conserva la lógica de reinicio progresivo ya existente.
- Receiver de `SCREEN_OFF` / `SCREEN_ON` refuerza los locks y actualiza la notificación sin reiniciar la consulta activa.
- `stopWithTask=false`: quitar la tarea de Recientes no mata automáticamente el servicio de recepción. Si la Activity sí fue cerrada, la foto se guarda y NO se simula que IA/TTS sigue activa.
- No se cambió extracción visual, preguntas, lotes, streaming, contexto AUTO/GENERAL/MINERÍA, limpieza de respuestas ni TTS.

## Alcance real
Pantalla apagada mientras GI X sigue activo: soportado por el mismo pipeline de v1.6.54. Force-stop, reinicio del equipo o políticas extremas del fabricante no son controlables por una app normal.

Versión: `1.6.55` · versionCode `80`.
