# Validación GI X v1.6.53

- [x] `versionCode 78`, `versionName 1.6.53`.
- [x] Streaming SSE y TTS progresivo conservados.
- [x] V/F: 10 por bloque; general: 8 por bloque.
- [x] Prueba de hoja mixta: encabezados A/B/C/D duplicados no se convierten en preguntas; se recuperan únicamente 1..8.
- [x] El parser de lotes canonicaliza cada respuesta con su pregunta antes de mostrarla.
- [x] `TIPO:`/`TEXTO:`/`Respuesta:` se filtran de la salida visible.
- [x] Un fragmento progresivo sin asociación válida ya no aparece como respuesta suelta.
- [x] Completar: varios huecos -> respuestas ordenadas; preferencia por términos literales del contexto.
- [x] Reglas de Fe/Pb/Ag y `Sin:`/`Epi:` conservadas mediante canonicalización individual por pregunta.
- [x] Smoke tests Kotlin: extractor, formato y TTS progresivo: OK.
- [x] Comprobación sintáctica de los archivos Kotlin modificados: sin errores de parseo/escapes; la compilación Android completa se valida en GitHub Actions.
