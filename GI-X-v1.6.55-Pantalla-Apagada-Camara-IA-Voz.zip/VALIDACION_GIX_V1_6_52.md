# Validación GI X v1.6.52

- [x] `versionCode 77`, `versionName 1.6.52`.
- [x] SSE habilitado para respuestas reales y deshabilitado en la prueba de API.
- [x] V/F: 10 por bloque.
- [x] General: 8 por bloque; preguntas largas/tablas aisladas.
- [x] Cada línea estable puede publicarse antes del final del lote.
- [x] TTS progresivo conserva deduplicación de fragmentos ya pronunciados.
- [x] Parciales estables se conservan antes de recuperar faltantes de un lote terminado con HTTP correcto.
- [x] V/F y alternativas no aceptan `No tengo una respuesta segura` como salida.
- [x] Sin caché de respuestas ni imágenes; sin OCR local.
- [x] Smoke tests Kotlin: extractor, formato de proveedor y TTS progresivo: OK.

La compilación Android completa se valida en GitHub Actions, ya que este entorno no incluye Gradle instalado.
