# GI X v1.6.52 — Streaming progresivo robusto

## Objetivo
Recuperar la rapidez del streaming sin volver a introducir la desincronización entre respuestas parciales y la validación final observada en v1.6.50.

## Cambios
- Respuestas reales de DeepSeek vuelven a usar SSE (`stream=true`).
- Cada línea completa y estable se muestra inmediatamente y entra a la cola TTS.
- El resultado final del bloque sigue pasando por la validación completa.
- Las respuestas parciales válidas quedan conservadas; si un bloque termina incompleto con HTTP correcto, solo se recuperan los IDs faltantes.
- V/F usa lotes de 10; lotes generales usan 8.
- Preguntas largas/explicativas y tablas se aíslan para que no retrasen preguntas cortas.
- V/F y alternativas tienen obligación de elegir una respuesta final; se elimina el conflicto con `No tengo una respuesta segura` para esos tipos.
- Timeout de respuestas normales: 75 s de inactividad de lectura; preguntas largas: 150 s. En streaming, cada dato recibido reinicia el tiempo de espera de socket.
- Cada envío sigue siendo nuevo: sin caché de imágenes/respuestas y sin OCR local.
- Cámara y Manual continúan usando el mismo motor.

## Referencia histórica
Se compararon v1.6.18 y v1.6.21 para recuperar tiempos más razonables y conservar la estrategia de bloques que había funcionado mejor, sin regresar el resto de la aplicación.
