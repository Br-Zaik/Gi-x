package com.gix.cameraai

fun main() {
    val topo = AiContextPolicy.resolve(
        AiContextMode.AUTO,
        "",
        listOf(
            "2. ¿Qué es el banco de marca?",
            "3. Explique de qué manera realizamos una nivelación simple.",
            "4. ¿Qué es la escala?",
            "5. Distancia real a escala 1:1000.",
            "6. Diferencia entre levantamiento topográfico y geodésico."
        )
    )
    check(topo.visibleLabel.contains("Topografía")) { topo.visibleLabel }
    check(topo.apiContext.contains("banco de marca", ignoreCase = true))
    check(topo.apiContext.contains("[GIX_DOMAIN_HINT]"))

    val cloud = AiContextPolicy.resolve(
        AiContextMode.AUTO,
        "SEGUNDO EXAMEN DE APLICACIÓN DE INTERNET",
        listOf(
            "Cloud Computing permite acceder a recursos por Internet.",
            "¿Qué es SaaS?",
            "¿Qué es una nube pública?"
        )
    )
    check(cloud.visibleLabel.contains("Internet")) { cloud.visibleLabel }

    val mining = AiContextPolicy.resolve(
        AiContextMode.MINING,
        "",
        listOf("¿Qué es banco de marca?")
    )
    check(mining.apiContext.contains("Explotación Minera"))

    val general = AiContextPolicy.resolve(
        AiContextMode.GENERAL,
        "Texto visible",
        listOf("¿Qué es banco de marca?")
    )
    check(general.apiContext == "Texto visible")
    check(!general.apiContext.contains("GIX_DOMAIN_HINT"))

    println("AiContextPolicySmoke OK")
}
