import com.gix.cameraai.*
fun main() {
  val sample = """
    LECTURA Y CUESTIONARIO – TOPOGRAFÍA
    Lectura
    La topografía mide y representa gráficamente la superficie terrestre. El GPS ubica coordenadas.
    Cuestionario
    1. ¿Qué es la topografía?
    A) Astronomía
    B) Ciencia de la superficie terrestre
    C) Minería
    D) Clima
    2. ¿Para qué sirve el GPS?
    3. Verdadero o falso: El nivel mide alturas.
    4. Complete: El GPS obtiene ________.
    5. ¿Qué es la brújula?
    6. ¿Qué instrumentos conoces?
    7. ¿Cómo se mide?
    8. Mencione dos áreas en las que se utiliza la topografía.
    1. ______________________    2. ______________________
    9. ¿Por qué es importante la información topográfica?
    10. ¿Qué diferencia hay entre el GPS y la brújula?
  """.trimIndent()
  val qs = OcrQuestionExtractor.extractQuestions(sample)
  val nums = qs.mapNotNull(OcrQuestionExtractor::questionNumber)
  println("OCR ids: $nums")
  require(nums == (1..10).toList()) { "OCR missed or re-numbered question ($nums)" }
  require(qs[7].contains("1. ___") && qs[7].contains("2. ___")) { "Subanswer lines lost: ${qs[7]}" }
  println("OCR context: " + OcrQuestionExtractor.extractDocumentContext(sample).take(120))
  val corrupted = listOf("1. Pregunta A", "2. Pregunta B", "1. Pregunta C", "4. Pregunta D")
  require(OcrQuestionExtractor.hasCorruptNumbering(corrupted))
  require(OcrQuestionExtractor.hasCorruptNumbering(listOf("1. Primero", "1. Segundo")))

  // v1.6.43: un proveedor visual puede colocar por error un examen V/F entero en
  // CONTEXTO DETECTADO y dejar vacía la sección de preguntas. Debe rescatarse.
  val vfAsContext = """
    CONTEXTO DETECTADO
    SEGUNDO EXAMEN DE APLICACIÓN DE INTERNET
    PONGA SI ES VERDADERO ( V ) Y FALSO ( F )
    1) Cloud Computing entrega servicios informáticos mediante Internet. ( )
    2) El objetivo de la nube es proporcionar servicios escalables. ( )
    3) La nube permite acceder a servidores, almacenamiento y aplicaciones. ( )
    4) Pago por uso significa pagar por los servicios utilizados. ( )
    PREGUNTAS DETECTADAS
  """.trimIndent()
  require(OcrQuestionExtractor.looksLikeAnswerableDocument(vfAsContext))
  val vfQuestions = OcrQuestionExtractor.extractQuestions(vfAsContext)
  val vfNums = vfQuestions.mapNotNull(OcrQuestionExtractor::questionNumber)
  require(vfNums == listOf(1, 2, 3, 4)) { "V/F tratado erróneamente como solo texto: $vfQuestions" }

  // v1.6.53: encabezados/instrucciones A/B/C/D no deben convertirse en preguntas
  // ni duplicarse cuando la visión entrega variantes "A." y "A)".
  val mixedWorksheet = """
    PREGUNTAS DETECTADAS
    A. VERDADERO O FALSO (V/F) Según el texto, marque (V) si la afirmación es verdadera o (F) si es falsa.
    A) VERDADERO O FALSO (V/F) Según el texto, marque (V) si la afirmación es verdadera o (F) si es falsa.
    1. La computación en la nube permite acceder a recursos informáticos a través de Internet. ( )
    2. La nube privada es compartida entre múltiples usuarios. ( )
    B) ALTERNATIVAS (A, B, C, D) Marque la alternativa correcta.
    3. ¿Qué servicio permite usar aplicaciones listas para el usuario?
    A) IaaS
    B) PaaS
    C) SaaS
    D) Almacenamiento
    4. ¿Cuál es una ventaja de la nube híbrida?
    A) Mayor costo
    B) Mayor control
    C) Optimización de costos y flexibilidad
    D) Menor seguridad
    C) RESPONDER (Respuesta corta) Escriba su respuesta de forma clara y correcta.
    5. ¿Cuál es el principal objetivo de la computación en la nube?
    6. Mencione un ejemplo de herramienta en la nube.
    D) COMPLETAR (2 palabras) Complete los espacios en blanco con las palabras correctas.
    7. El SaaS permite utilizar ________ a través de ________.
    8. Los archivos se guardan en la ________ y se puede trabajar de forma ________.
  """.trimIndent()
  val mixedQuestions = OcrQuestionExtractor.extractQuestions(mixedWorksheet)
  val mixedNums = mixedQuestions.mapNotNull(OcrQuestionExtractor::questionNumber)
  require(mixedNums == (1..8).toList()) { "Encabezados convertidos en preguntas: $mixedQuestions" }
  require(mixedQuestions.none { it.contains("VERDADERO O FALSO", true) && OcrQuestionExtractor.questionNumber(it) == null })
  require(mixedQuestions.none { it.startsWith("ALTERNATIVAS", true) || it.startsWith("RESPONDER", true) || it.startsWith("COMPLETAR", true) })

  println("OK smoke: 10 preguntas, casillas internas, alternativas, contexto, duplicados y rescate V/F")
}
