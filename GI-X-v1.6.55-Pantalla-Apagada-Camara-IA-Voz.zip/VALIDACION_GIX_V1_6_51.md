# Validación GI X v1.6.51

Comprobaciones realizadas:

- `versionName 1.6.51` y `versionCode 76`.
- MainActivity llama `fetchShortAnswer(payload)` sin callback de parciales.
- El proveedor fuerza `streaming = false` y envía `stream=false`.
- Lotes V/F reducidos a 10 preguntas.
- Una salida incompleta con HTTP correcto queda marcada como recuperable y se divide por preguntas individuales.
- Timeout/red incierta no activa recuperación automática.
- Smoke test de extracción de 10 preguntas: OK.
- Smoke test de formato de respuestas: OK.
- Smoke test de deduplicación Cámara por requestId: OK.
- Verificación estática específica de no-streaming/recuperación: OK.

La compilación Android completa corresponde a GitHub Actions porque el ZIP no contiene Gradle Wrapper y el entorno local no tiene Gradle instalado.
