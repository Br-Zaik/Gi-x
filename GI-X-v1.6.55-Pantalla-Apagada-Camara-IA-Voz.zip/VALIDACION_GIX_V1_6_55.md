# Validación GI X v1.6.55

## Comprobaciones de fuente
- AndroidManifest XML válido.
- `ACCESS_WIFI_STATE` agregado.
- Servicio conserva `foregroundServiceType="connectedDevice"` y usa `stopWithTask="false"`.
- WakeLock: `PARTIAL_WAKE_LOCK`, no Full/Screen lock.
- Wi-Fi lock: `WIFI_MODE_FULL_HIGH_PERF`.
- Watchdog: 5 s.
- `SCREEN_OFF` no cancela API/TTS; solo refuerza recursos y actualiza notificación.
- `SCREEN_ON` no reinicia ni duplica consultas.
- Foto sigue escribiéndose al journal antes de confirmarse al firmware.
- Si no existe Activity observadora, la foto queda guardada y la notificación no promete IA/TTS inexistentes.

## Regression smoke ejecutado
- Extractor: 10/10 preguntas y casillas internas.
- Hoja mixta: V/F + alternativas + responder + completar sin convertir encabezados en preguntas.
- Formato proveedor: A-H y numeración sin falsas detecciones.
- Streaming/TTS: no repite fragmentos y conserva corrección final.
- AiContextPolicy: AUTO/GENERAL/MINERÍA.
- CameraBatchPolicy: 1–4 fotos, requestId y cierre por inactividad.

No se dispone de Android SDK/Gradle local en este entorno; la compilación APK completa debe validarse en GitHub Actions y luego en el teléfono real con pantalla apagada.
