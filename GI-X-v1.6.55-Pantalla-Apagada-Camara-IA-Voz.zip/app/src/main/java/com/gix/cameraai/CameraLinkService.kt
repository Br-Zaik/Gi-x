package com.gix.cameraai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat

/**
 * Enlace Wi-Fi de GI X independiente de la Activity.
 *
 * v1.6.55: mientras la app siga abierta y el usuario apague físicamente la pantalla,
 * este servicio mantiene CPU + Wi-Fi activos para que el pipeline que ya vive en
 * MainActivity pueda seguir recibiendo fotos, usando la API y reproduciendo TTS.
 *
 * Importante: pantalla apagada NO significa force-stop. Si el usuario fuerza la
 * detención de GI X desde Android, el sistema termina también el servicio.
 */
class CameraLinkService : Service(), CameraBridgeServer.Listener {
    private lateinit var journal: CameraPhotoJournal
    private lateinit var power: PowerManager
    private lateinit var wifiManager: WifiManager
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var screenReceiverRegistered = false
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var server: CameraBridgeServer? = null
    private var stoppedByUser = false
    private var nextRestartAt = 0L
    @Volatile private var restartDelayMs = 5_000L

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    ensureBackgroundLocks()
                    updateNotification(
                        title = "GI X · Pantalla apagada",
                        text = "Cámara, IA y voz siguen activas."
                    )
                }
                Intent.ACTION_SCREEN_ON -> {
                    ensureBackgroundLocks()
                    updateNotification(
                        title = "GI X · Cámara a la espera",
                        text = "Cámara Wi-Fi activa. Puedes volver a apagar la pantalla."
                    )
                }
            }
        }
    }

    private val health = object : Runnable {
        override fun run() {
            if (stoppedByUser) return
            // Watchdog: varios fabricantes liberan recursos agresivamente al apagar
            // la pantalla. Revalidamos ambos locks sin reiniciar trabajos de API.
            ensureBackgroundLocks()
            if (server?.isListening() != true && System.currentTimeMillis() >= nextRestartAt) {
                recreateServer()
            }
            handler.postDelayed(this, HEALTH_INTERVAL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        journal = CameraPhotoJournal(this)
        power = getSystemService(Context.POWER_SERVICE) as PowerManager
        wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        active = this

        val notifications = getSystemService(NotificationManager::class.java)
        notifications.createNotificationChannel(
            NotificationChannel(
                CHANNEL,
                "GI X · Cámara conectada",
                NotificationManager.IMPORTANCE_LOW
            )
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(
                screenReceiver,
                IntentFilter().apply {
                    addAction(Intent.ACTION_SCREEN_OFF)
                    addAction(Intent.ACTION_SCREEN_ON)
                },
                Context.RECEIVER_NOT_EXPORTED
            )
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(
                screenReceiver,
                IntentFilter().apply {
                    addAction(Intent.ACTION_SCREEN_OFF)
                    addAction(Intent.ACTION_SCREEN_ON)
                }
            )
        }
        screenReceiverRegistered = true

        val notification = buildNotification(
            title = "GI X · Cámara a la espera",
            text = "Cámara Wi-Fi activa. IA y voz continúan con la pantalla apagada."
        )
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        ensureBackgroundLocks()
        handler.post(health)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stoppedByUser = true
            stopSelf()
            return START_NOT_STICKY
        }
        stoppedByUser = false
        ensureBackgroundLocks()
        if (server?.isListening() != true) recreateServer()
        return START_STICKY
    }

    /** Mantiene el CPU disponible sin encender la pantalla y evita que el enlace Wi-Fi
     *  entre en ahorro agresivo mientras GI X está esperando/procesando cámara.
     */
    private fun ensureBackgroundLocks() {
        val cpu = wakeLock ?: power.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "GIX:CameraBackground"
        ).apply {
            setReferenceCounted(false)
        }.also { wakeLock = it }
        if (!cpu.isHeld) {
            runCatching { cpu.acquire() }
        }

        val wifi = wifiLock ?: wifiManager.createWifiLock(
            WifiManager.WIFI_MODE_FULL_HIGH_PERF,
            "GIX:CameraWifi"
        ).apply {
            setReferenceCounted(false)
        }.also { wifiLock = it }
        if (!wifi.isHeld) {
            runCatching { wifi.acquire() }
        }
    }

    private fun buildNotification(title: String, text: String): Notification {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_logo_small)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(title: String, text: String) {
        runCatching {
            getSystemService(NotificationManager::class.java)
                .notify(NOTIFICATION_ID, buildNotification(title, text))
        }
    }

    private fun recreateServer() {
        val now = System.currentTimeMillis()
        if (now < nextRestartAt) return
        server?.stop()
        server = CameraBridgeServer(
            CameraBridgeServer.DEFAULT_PORT,
            tokenProvider = { AppPrefs(this).pairingToken },
            listener = this
        )
        server?.start()
        nextRestartAt = now + restartDelayMs
        restartDelayMs = (restartDelayMs * 2).coerceAtMost(60_000L)
    }

    override fun onServerStarted(port: Int) {
        restartDelayMs = 5_000L
        observer?.onServerStarted(port)
    }

    override fun onServerError(message: String) {
        observer?.onServerError(message)
    }

    override fun onCameraSeen() {
        observer?.onCameraSeen()
    }

    override fun onPhotoReceived(jpeg: ByteArray, requestId: String?) {
        ensureBackgroundLocks()
        if (CameraJpegDecoder.inspect(jpeg) == null) {
            throw IllegalArgumentException("JPEG inválido; no se confirma recepción")
        }
        // La devolución HTTP 200 solo ocurre si este guardado se completa sin error.
        journal.save(jpeg, requestId)

        // Con pantalla apagada MainActivity permanece en memoria porque GI X sigue
        // abierto; su pipeline no se detiene en onPause/onStop. El servicio mantiene
        // proceso/CPU/red y entrega la foto exactamente por el mismo camino estable.
        val currentObserver = observer
        if (currentObserver != null) {
            runCatching { currentObserver.onPhotoReceived(jpeg, requestId) }
        } else {
            // Si el usuario realmente cerró la Activity, no fingimos que IA/TTS sigue
            // activa: el original ya quedó duradero y se recuperará al volver a abrir.
            updateNotification(
                title = "GI X · Foto guardada",
                text = "Abre GI X para procesar la foto pendiente con IA y voz."
            )
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // No interpretamos "pantalla apagada" ni un cambio accidental de task como SALIR.
        // START_STICKY + journal permiten mantener la recepción. Force-stop de Android
        // sigue siendo soberano y no puede ser burlado por una app normal.
        ensureBackgroundLocks()
        if (observer == null) {
            updateNotification(
                title = "GI X · Cámara protegida",
                text = "La cámara sigue escuchando; abre GI X para IA y voz."
            )
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        stoppedByUser = true
        handler.removeCallbacksAndMessages(null)
        server?.stop()
        server = null
        if (screenReceiverRegistered) {
            runCatching { unregisterReceiver(screenReceiver) }
            screenReceiverRegistered = false
        }
        wifiLock?.let { lock -> if (lock.isHeld) runCatching { lock.release() } }
        wifiLock = null
        wakeLock?.let { lock -> if (lock.isHeld) runCatching { lock.release() } }
        wakeLock = null
        if (active === this) active = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL = "gix_camera_monitor_v2"
        private const val NOTIFICATION_ID = 8765
        private const val HEALTH_INTERVAL_MS = 5_000L
        const val ACTION_STOP = "com.gix.cameraai.STOP_CAMERA_LINK"
        @Volatile private var active: CameraLinkService? = null
        @Volatile private var observer: CameraBridgeServer.Listener? = null

        fun attach(listener: CameraBridgeServer.Listener) {
            observer = listener
            active?.ensureBackgroundLocks()
        }

        fun detach(listener: CameraBridgeServer.Listener) {
            if (observer === listener) observer = null
        }

        fun ensureScreenOffReady() {
            active?.ensureBackgroundLocks()
        }

        fun currentServer(): CameraBridgeServer? = active?.server
    }
}
