package com.gix.cameraai

import java.text.Normalizer
import java.util.Locale

enum class AiContextMode {
    AUTO,
    GENERAL,
    MINING,
}

data class AiContextResolution(
    val visibleLabel: String,
    val apiContext: String,
)

object AiContextPolicy {
    private enum class Domain {
        MINING_TOPOGRAPHY,
        CLOUD_INTERNET,
        SAFETY,
        CHEMISTRY,
        GENERAL,
    }

    fun resolve(
        mode: AiContextMode,
        documentContext: String,
        questions: List<String>,
    ): AiContextResolution {
        val cleanContext = documentContext.trim()
        return when (mode) {
            AiContextMode.GENERAL -> AiContextResolution(
                visibleLabel = "GENERAL: sin tema forzado",
                apiContext = cleanContext,
            )

            AiContextMode.MINING -> AiContextResolution(
                visibleLabel = "MINERÍA: prioridad minera/topográfica",
                apiContext = mergeHint(
                    miningDirective(forced = true),
                    cleanContext,
                ),
            )

            AiContextMode.AUTO -> {
                val domain = detectDomain(cleanContext, questions)
                val label = when (domain) {
                    Domain.MINING_TOPOGRAPHY -> "AUTO: Topografía / Explotación Minera"
                    Domain.CLOUD_INTERNET -> "AUTO: Internet / Computación en la nube"
                    Domain.SAFETY -> "AUTO: Seguridad y salud en el trabajo"
                    Domain.CHEMISTRY -> "AUTO: Química / Minerales"
                    Domain.GENERAL -> "AUTO: contexto general del documento"
                }
                val directive = when (domain) {
                    Domain.MINING_TOPOGRAPHY -> miningDirective(forced = false)
                    Domain.CLOUD_INTERNET -> """
                        [GIX_DOMAIN_HINT]
                        Materia dominante detectada automáticamente: Internet / Computación en la nube.
                        Usa esta materia para desambiguar términos cuando una palabra admita varios significados. Prioriza el sentido académico que encaje con el conjunto completo del documento y con sus preguntas. No fuerces este tema si una pregunta indica explícitamente otra materia.
                    """.trimIndent()
                    Domain.SAFETY -> """
                        [GIX_DOMAIN_HINT]
                        Materia dominante detectada automáticamente: Seguridad y Salud en el Trabajo, con posible aplicación minera.
                        Usa este contexto para desambiguar términos técnicos como peligro, riesgo, EPP, actos/condiciones subestándar e IPERC. No fuerces este tema cuando la pregunta indique explícitamente otra materia.
                    """.trimIndent()
                    Domain.CHEMISTRY -> """
                        [GIX_DOMAIN_HINT]
                        Materia dominante detectada automáticamente: Química / minerales.
                        Interpreta símbolos, fórmulas, elementos y términos mineralógicos según este ámbito cuando sean ambiguos. No fuerces este tema si la pregunta indica explícitamente otra materia.
                    """.trimIndent()
                    Domain.GENERAL -> """
                        [GIX_DOMAIN_HINT]
                        Modo AUTO: determina el significado de cada término usando el contexto global del documento y el conjunto de preguntas. Si una palabra tiene varios significados, elige el que sea coherente con la materia dominante del examen. No cambies una pregunta clara por otra interpretación ajena al documento.
                    """.trimIndent()
                }
                AiContextResolution(
                    visibleLabel = label,
                    apiContext = mergeHint(directive, cleanContext),
                )
            }
        }
    }

    private fun miningDirective(forced: Boolean): String {
        val modeLine = if (forced) {
            "Modo MINERÍA seleccionado por el usuario."
        } else {
            "Materia dominante detectada automáticamente: Topografía / Explotación Minera."
        }
        return """
            [GIX_DOMAIN_HINT]
            $modeLine
            Para términos ambiguos, prioriza el significado usado en Explotación Minera, Topografía, Geodesia, Geología, Seguridad Minera y operaciones mineras, según lo que encaje con el resto del examen. Ejemplo crítico: en una evaluación de topografía, “banco de marca” o “BM” se interpreta como punto/banco de referencia de cota o elevación para nivelación, no como repositorio de identidad visual de una empresa. Si una pregunta es claramente de otra materia, respóndela normalmente y no la fuerces al ámbito minero.
        """.trimIndent()
    }

    private fun mergeHint(hint: String, documentContext: String): String {
        return buildString {
            if (hint.isNotBlank()) append(hint.trim())
            if (documentContext.isNotBlank()) {
                if (isNotEmpty()) append("\n\n")
                append(documentContext.trim())
            }
        }.trim()
    }

    private fun detectDomain(documentContext: String, questions: List<String>): Domain {
        val text = normalizeForMatch(
            buildString {
                append(documentContext)
                append('\n')
                append(questions.joinToString("\n"))
            }
        )

        fun score(vararg terms: String): Int = terms.sumOf { term ->
            val normalizedTerm = normalizeForMatch(term)
            if (normalizedTerm.isBlank()) 0 else Regex("(?<![a-z0-9])${Regex.escape(normalizedTerm)}(?![a-z0-9])")
                .findAll(text)
                .count()
                .coerceAtMost(3)
        }

        val miningScore = score(
            "explotacion minera", "mineria", "mina", "topografia", "topografico", "topografica",
            "geodesia", "geodesico", "nivelacion", "banco de marca", "banco de nivel", "bm",
            "cota", "mira", "estadal", "azimut", "rumbo", "utm", "levantamiento", "escala",
            "yacimiento", "mineral", "mena", "ganga", "top soil", "reservas", "talud", "voladura",
            "perforacion", "singenetico", "epigenetico"
        )
        val cloudScore = score(
            "cloud computing", "computacion en la nube", "nube publica", "nube privada", "nube hibrida",
            "iaas", "paas", "saas", "google docs", "google drive", "internet", "navegador web"
        )
        val safetyScore = score(
            "seguridad", "sst", "epp", "iperc", "peligro", "riesgo", "acto subestandar",
            "condicion subestandar", "incidente", "accidente"
        )
        val chemistryScore = score(
            "formula quimica", "simbolo quimico", "elemento", "hierro", "plomo", "plata", "oro",
            "fe", "pb", "ag", "au"
        )

        val ranked = listOf(
            Domain.MINING_TOPOGRAPHY to miningScore,
            Domain.CLOUD_INTERNET to cloudScore,
            Domain.SAFETY to safetyScore,
            Domain.CHEMISTRY to chemistryScore,
        ).sortedByDescending { it.second }

        val best = ranked.first()
        val second = ranked.getOrNull(1)?.second ?: 0
        // Evita forzar un dominio por una sola palabra aislada. Dos señales coherentes
        // o una ventaja clara sobre el segundo tema son suficientes para AUTO.
        return if (best.second >= 2 && (best.second >= second + 1 || best.second >= 4)) best.first else Domain.GENERAL
    }

    private fun normalizeForMatch(value: String): String {
        val decomposed = Normalizer.normalize(value, Normalizer.Form.NFD)
        return decomposed
            .replace(Regex("\\p{M}+"), "")
            .lowercase(Locale.ROOT)
            .replace(Regex("[^a-z0-9]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }
}
