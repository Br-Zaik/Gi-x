# GI X v1.6.54 — Contexto IA

## Objetivo
Evitar respuestas semánticamente correctas en otro dominio pero incorrectas para el examen, como interpretar “banco de marca” como branding dentro de una prueba de Topografía.

## Cambios
- Selector visible: AUTO / GENERAL / MINERÍA.
- AUTO es el valor predeterminado y persiste entre aperturas.
- AUTO usa contexto + conjunto completo de preguntas para detectar Topografía/Explotación Minera, Internet/Cloud, SST o Química cuando hay señales suficientes.
- MINERÍA prioriza significados de Explotación Minera, Topografía, Geodesia, Geología, Seguridad Minera y operaciones mineras solo cuando existe ambigüedad.
- GENERAL conserva el comportamiento neutral sin tema forzado.
- La selección afecta tanto Cámara como Imagen Manual porque se aplica en el flujo común antes de construir los payloads de respuestas.
- Se conserva streaming progresivo, TTS inmediato, limpieza mixta, sin OCR local y sin caché de respuestas.

## Regla de seguridad semántica
El modo de contexto solo desambigua; no debe cambiar una pregunta claramente perteneciente a otra materia ni inventar datos.
