# Validación GI X v1.5.3

Objetivo: reglas generales de respuesta por tipo de ejercicio, sin reglas específicas para las tres hojas de prueba.

- V/F: `1. Verdadero.` / `2. Falso.` sin explicación salvo petición.
- Alternativas: `3. B) Casco` (número + letra + texto).
- Completar: término/frase mínima, sin definición.
- Pregunta normal `¿Qué es EPP?`: debe responder `Equipo de Protección Personal.`
- Sin numeración: se aplican exactamente las mismas reglas de tipo.
- Tablas: no se modifica la reconstrucción de filas/columnas.
- Fórmulas/símbolos: no se modifica su conservación.
- Cámara U082-X y TTS robusto: se conservan sin cambios funcionales.

VersionCode: 23
VersionName: 1.5.3

Pruebas estáticas realizadas antes de empaquetar:
- Sin numeración: `¿QUE ES EPP?`, `Mencione...`, `Explique...` -> 3 preguntas separadas.
- V/F: entrada `1. Respuesta: Falso.` -> salida canónica `1. Falso.`.
- Alternativa: respuesta del proveedor `La respuesta correcta es B) Dos.` -> salida canónica `B) Dos`.
- Completar: `La palabra correcta es: Casco` -> salida canónica `Casco`.
- Restos OCR de huecos: `reservas .del depósito` y `de.. Donde` se reconocen como completar.
