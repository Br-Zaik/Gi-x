# GI X v1.5.2 — protocolo de cámara U082-X

GI X puede recibir fotos desde la **M5Stack TimerCamera-X U082-X** conectada a la Zona Wi-Fi del mismo celular.

## Flujo principal: encender = una foto útil

1. El celular activa su Zona Wi-Fi y mantiene GI X abierto en modo **CÁMARA**.
2. El usuario enciende la TimerCamera-X con PWR.
3. La cámara se conecta únicamente al SSID/contraseña grabados en su firmware.
4. Obtiene la IP del celular mediante el gateway de la Zona Wi-Fi.
5. Consulta si GI X dejó una orden pendiente con `GET /camera/poll?token=CLAVE`.
6. Estabiliza exposición/balance de blancos.
7. Captura **una única foto JPEG útil**.
8. Envía esa foto a `POST /camera/photo?token=CLAVE[&requestId=ID]`.
9. Si el celular todavía no estaba listo, reintenta el envío de **ese mismo JPEG**; no toma otra foto útil.
10. GI X responde `RECEIVED` y continúa con OCR -> API -> respuesta -> voz.
11. Después del envío, el firmware llama `TimerCAM.Power.powerOff()`.

No hace falta pulsar **PEDIR FOTO**: una foto de arranque se acepta aunque no exista una orden pendiente. El botón se conserva para pruebas o para asociar una solicitud concreta.

## Voz y siguiente ciclo

GI X espera a que termine la voz antes de iniciar el siguiente ciclo automático. Las respuestas largas se dividen en fragmentos seguros para Android TTS. Si el TTS todavía se está iniciando, la respuesta queda pendiente y se reproduce cuando el motor esté listo. Si falla la reproducción, GI X reinicia el motor una vez.

## Seguridad

- La cámara solo conoce el SSID y contraseña grabados en su firmware.
- GI X exige además una clave de enlace (token). Por defecto: `GIX2026CAM`.
- Si cambias la clave desde **GI X > CÁMARA**, también debes cambiar `GIX_TOKEN` en el firmware.
- El servidor local rechaza fotos mayores de 8 MB.
- No subas a un repositorio público el firmware después de escribir tu contraseña real de Wi-Fi.

## Firmware incluido

`camera_firmware/TimerCameraX_GIX.ino`

Antes de grabarlo cambia únicamente:
- `WIFI_NAME`
- `WIFI_PASSWORD`
- `GIX_TOKEN` si cambiaste la clave en la app

Guía rápida adicional: `camera_firmware/LEEME_PRIMERO_U082_X.txt`.
