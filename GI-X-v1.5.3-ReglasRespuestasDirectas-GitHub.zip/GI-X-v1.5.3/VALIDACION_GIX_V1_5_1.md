# GI X v1.5.1 - Validación de robustez OCR/API

- versionCode: 21
- versionName: 1.5.1

## Correcciones principales
1. Numeración original preservada de extremo a extremo.
2. Reparación conservadora de V/F fusionadas usando `( )` y el siguiente número visible.
3. Cualquier salto restante en una secuencia numerada bloquea el envío de una hoja mal reconstruida.
4. Alternativas A-H se conservan aunque sean líneas cortas en mayúscula.
5. Salida API ampliada: V/F por lote hasta 4096 tokens; lotes normales hasta 4096; preguntas individuales con margen mayor según el tipo.
6. Consultas individuales: hasta 3 intentos ante fallos temporales.
7. Si una respuesta individual ya es completa, se conserva incluso si el upstream termina con LENGTH/MAX_TOKENS.
8. Lotes incompletos se recuperan inmediatamente pregunta por pregunta.
9. Completar frases pide una palabra/frase específica, evitando categorías demasiado generales.

## Pruebas ejecutadas con las salidas reales observadas en las 3 hojas
- Verdadero/Falso: la entrada real que antes quedaba en 18 preguntas (7 contenía 8 y 9) se reconstruye como 20/20, en orden 1-20, sin saltos.
- Aplicaciones en Internet: 9/9 ejercicios; preguntas 1-8 separadas y tabla 9 conservada con sus 6 filas.
- Fundamentos de Minería: 7/7 preguntas; Fe, Pb y Ag conservados.
- Payload API de un lote 11-15 conserva exactamente 11,12,13,14,15; no se renumera como 1-5.
- Caso de salto 1,2,4 queda marcado como numeración sospechosa.
- Alternativas A/B/C/D se conservan dentro de la pregunta.
- Caso de una sola pregunta se conserva correctamente (regresión añadida).

El extractor fue compilado y ejecutado en JVM con un stub de tabla para estas regresiones. Los archivos Kotlin modificados no presentan errores sintácticos detectables por el compilador; la compilación Android completa se realiza con el workflow de GitHub incluido en el proyecto.
