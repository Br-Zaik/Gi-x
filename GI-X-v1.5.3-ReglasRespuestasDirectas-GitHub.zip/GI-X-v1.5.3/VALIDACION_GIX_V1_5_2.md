# Validación GI X v1.5.2

## Cámara U082-X
- Firmware identifica el objetivo U082-X y conserva solo 3 valores de configuración manual: SSID, contraseña y token.
- Una sola captura útil por encendido.
- Los reintentos HTTP reutilizan el mismo framebuffer JPEG; no vuelven a capturar otra foto útil.
- Foto de arranque se envía incluso sin orden pendiente de GI X.
- Puerto local: 8765. Token predeterminado: GIX2026CAM.
- Tras terminar se llama powerOff(); si USB mantiene alimentación, loop no realiza nuevas capturas.

## Voz
- handleAnswer -> requestAnswerSpeech.
- recuperación parcial -> requestAnswerSpeech(partial), sin leer el texto técnico del error.
- TTS pendiente si todavía no terminó onInit.
- fragmentación <= min(maxSpeechInputLength-200, 3000 caracteres).
- QUEUE_FLUSH para primer fragmento y QUEUE_ADD para siguientes.
- solo el último utterance finaliza el ciclo.
- un fallo TTS reinicia el motor una vez y reintenta.
- AUTO queda bloqueado mientras haya voz pendiente o activa.

## Versión
- versionCode: 22
- versionName: 1.5.2
