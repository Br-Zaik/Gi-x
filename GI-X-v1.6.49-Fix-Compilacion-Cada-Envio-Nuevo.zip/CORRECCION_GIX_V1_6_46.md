# GI X v1.6.46 — Recuperación 503 y payload visual seguro

Cambios aplicados sobre v1.6.45 Fix Preview:

- HTTP 502/503/504: un único reintento automático tras 1.5 s, tanto en visión como en respuestas.
- Timeouts/errores de red inciertos: siguen SIN reintento para evitar duplicar gasto.
- Si llegan imágenes nuevas durante el reintento, el trabajo viejo se cancela inmediatamente.
- Estado visible durante envío/espera/reintento; el cuadro de preguntas ya no queda pegado en “Optimizando…” tras un fallo.
- Presupuesto dinámico para 1–4 imágenes: máximo total raw ~3.05 MB antes de Base64.
- Validación del tamaño REAL del JSON antes de enviar; margen bajo 4.5 MB para evitar HTTP 413.
- Compresión progresiva y reducción de resolución solo cuando hace falta para respetar el presupuesto.
- versionCode 71 / versionName 1.6.46.

No se reintrodujo OCR local, ML Kit, ONNX ni OpenCV.
