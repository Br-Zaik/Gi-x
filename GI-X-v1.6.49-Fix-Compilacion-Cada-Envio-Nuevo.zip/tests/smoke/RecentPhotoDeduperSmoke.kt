import com.gix.cameraai.RecentPhotoDeduper

fun main() {
    val d = RecentPhotoDeduper(ttlMs = 70_000L, maxEntries = 12)
    val jpeg = byteArrayOf(1, 2, 3, 4, 5)
    check(!d.isDuplicate(jpeg, "req-A", now = 1_000L))
    check(d.isDuplicate(jpeg, "req-A", now = 2_000L)) { "Mismo POST/retry debe deduplicarse" }
    check(!d.isDuplicate(jpeg, "req-B", now = 3_000L)) { "Misma imagen con request nuevo debe procesarse" }
    check(!d.isDuplicate(jpeg, null, now = 4_000L)) { "Sin requestId se prioriza tratarla como nueva" }
    check(!d.isDuplicate(jpeg, null, now = 5_000L)) { "Manual/legacy sin requestId no debe quedar bloqueado por hash" }
    println("OK: misma imagen + request nuevo = trabajo nuevo; solo retry del mismo request se deduplica")
}
