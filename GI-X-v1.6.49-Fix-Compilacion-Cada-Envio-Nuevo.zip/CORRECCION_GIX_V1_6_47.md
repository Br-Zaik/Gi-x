# GI X v1.6.47 – Consistencia de respuestas, imágenes repetidas y etiquetas técnicas

## Cambios principales

1. **Consistencia para repeticiones exactas**
   - Se agregó caché de sesión para consultas de respuesta (`fetchShortAnswer`).
   - Si se vuelve a enviar exactamente la misma pregunta/lote, GI X reutiliza la última respuesta buena en vez de gastar otra llamada y arriesgar una variante incoherente.

2. **Consistencia para imágenes repetidas**
   - Se agregó caché de sesión para lectura visual (`extractQuestionsFromImages`).
   - Si el usuario vuelve a enviar exactamente el mismo conjunto de imágenes, GI X reutiliza la misma transcripción estable anterior.

3. **Menos variación de la API**
   - Se fijó `temperature = 0.0` para consultas normales, evitando respuestas aleatorias entre intentos iguales.

4. **Símbolos químicos mejor tratados**
   - Si una pregunta pide nombres/desarrollo de símbolos químicos listados (ej. `Fe`, `Pb`, `Ag`), la canonicalización devuelve formato completo: `Fe = Hierro; Pb = Plomo; Ag = Plata`.
   - Además se valida que no falten símbolos esperados.

5. **Etiquetas tipo `Sin:` / `Epi:`**
   - Si la pregunta trae etiquetas cortas con dos puntos, GI X intenta conservarlas o reconstruirlas en la salida final.
   - También se valida que no falten esas partes etiquetadas.

6. **Prompt más estricto**
   - Se reforzaron las instrucciones para que la API responda todos los símbolos/abreviaturas/etiquetas en el mismo orden.

## Resultado esperado
- La misma imagen repetida debe dar la misma lectura estable.
- La misma consulta repetida debe dar la misma respuesta estable.
- Menos respuestas incompletas o incoherentes.
- Mejor salida en ejercicios con `Fe/Pb/Ag`, `Sin/Epi` y estructuras parecidas.
