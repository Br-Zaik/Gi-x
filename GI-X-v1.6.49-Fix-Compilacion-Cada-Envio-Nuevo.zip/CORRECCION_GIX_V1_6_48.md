# GI X v1.6.48 — cada envío vuelve a usar la API

## Cambio principal
- Se eliminaron la caché de lectura visual y la caché de respuestas agregadas en v1.6.47.
- Una misma imagen elegida otra vez en Manual se vuelve a optimizar, enviar a visión IA, organizar y responder mediante API.
- Una misma imagen recibida otra vez desde Cámara con un `requestId` nuevo también vuelve a procesarse desde cero.
- `temperature = 0.0` se mantiene para reducir variación entre consultas iguales, pero no se reutiliza la respuesta anterior.

## Protección que sí se conserva
- Si TimerCamera-X reintenta por Wi‑Fi exactamente la misma entrega con el mismo `requestId`, GI X evita cobrar dos veces esa retransmisión técnica.
- El diario de cámara ahora incluye `requestId` en la identidad persistida: la misma foto en un trabajo nuevo no colisiona con el trabajo anterior.

## Flujo de ambos modos
`Imagen(es) -> optimización -> API visual -> contexto/preguntas -> API de respuestas -> validación -> TTS`

No hay OCR local ni fallback OCR local en este flujo.

## Versión
- versionName: 1.6.48
- versionCode: 73
