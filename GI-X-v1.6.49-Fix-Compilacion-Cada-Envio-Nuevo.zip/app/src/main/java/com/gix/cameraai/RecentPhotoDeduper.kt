package com.gix.cameraai

import java.security.MessageDigest
import java.util.LinkedHashMap

/**
 * Evita facturar dos veces un reintento HTTP de la MISMA entrega de TimerCamera-X.
 * La clave incluye requestId: si el usuario vuelve a enviar la misma foto en un
 * trabajo nuevo, el nuevo requestId hace que se procese otra vez desde cero.
 */
class RecentPhotoDeduper(
    private val ttlMs: Long = 70_000L,
    private val maxEntries: Int = 24,
) {
    private val recent = LinkedHashMap<String, Long>()

    @Synchronized
    fun isDuplicate(bytes: ByteArray, requestId: String?, now: Long = System.currentTimeMillis()): Boolean {
        val iterator = recent.entries.iterator()
        while (iterator.hasNext()) {
            if (now - iterator.next().value > ttlMs) iterator.remove()
        }

        // Sin requestId no podemos distinguir con seguridad un reintento de una
        // nueva captura intencional idéntica. En ese caso se procesa como NUEVA.
        val normalizedRequestId = requestId?.trim().orEmpty()
        if (normalizedRequestId.isEmpty()) return false

        val key = normalizedRequestId + ":" + sha256(bytes)
        val previous = recent[key]
        recent[key] = now
        while (recent.size > maxEntries) {
            val first = recent.entries.firstOrNull()?.key ?: break
            recent.remove(first)
        }
        return previous != null && now - previous <= ttlMs
    }

    private fun sha256(bytes: ByteArray): String {
        return MessageDigest.getInstance("SHA-256")
            .digest(bytes)
            .joinToString("") { "%02x".format(it) }
    }
}
