# Validación GI X v1.6.46

Comprobaciones estáticas realizadas:

- v1.6.46 / versionCode 71 presentes en Gradle y UI.
- Las únicas llamadas a `extractQuestionsFromImages` usan callback de estado.
- `VisionImageOptimizer` recibe presupuesto por cantidad de imágenes.
- Reintento limitado a códigos 502/503/504.
- Timeout de red no entra en el camino de reintento.
- Validación del cuerpo JSON antes del POST visual.
- El flujo “últimas imágenes ganan” y `cancelActiveRequest()` se conserva.
- Integridad ZIP verificada tras empaquetado.

La compilación Android completa debe ejecutarse en GitHub Actions.
