# GI X v1.6.49 - corrección de compilación

Base: GI X v1.6.48 Cada Envío Nuevo API.

## Error corregido
GitHub Actions run 36327314870 / job 108642455086 fallaba en `:app:compileDebugKotlin` por referencias no resolubles dentro del `companion object` de `OnlineAnswerProvider.kt`:

- `formatChemicalNameListAnswer`
- `normalizeLabelledAnswer`

Las funciones existían como métodos de instancia, pero `canonicalizeAnswerForQuestion()` se ejecuta desde el `companion object` y no podía resolverlas.

## Solución
Se añadieron variantes auxiliares internas al `companion object` y `canonicalizeAnswerForQuestion()` usa esas variantes. No se cambia el comportamiento de las respuestas químicas ni de etiquetas.

## Se mantiene v1.6.48
- Cada selección manual se procesa como trabajo nuevo.
- Cada envío nuevo de Cámara se procesa como trabajo nuevo.
- No se reutilizan resultados de visión ni respuestas mediante caché.
- Un reintento técnico del mismo request de Cámara puede seguir deduplicándose para evitar doble gasto accidental.
- La imagen se analiza mediante la API visual; no se reintroduce OCR local.

VersionName: 1.6.49
VersionCode: 74
