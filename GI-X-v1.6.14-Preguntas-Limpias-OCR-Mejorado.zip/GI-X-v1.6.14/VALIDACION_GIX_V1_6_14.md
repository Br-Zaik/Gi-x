# GI X v1.6.14 · Pipeline de preguntas limpio

Versión:
- versionCode: 39
- versionName: 1.6.14
- applicationId/namespace: com.gix.cameraai (sin cambios)

Cambios principales:
1. La imagen se corrige/recorta primero y pasa por una preparación conservadora antes del OCR: normalización de fondo, CLAHE suave y enfoque mínimo.
2. PP-OCRv6 Small sigue como motor principal y ML Kit verifica siempre de forma independiente la hoja rectificada.
3. Las variantes fuertes (mejora adicional/adaptativa) solo entran como rescate y siguen siendo secuenciales, con límites y timeouts existentes.
4. Se muestra y se envía a la API únicamente la lista de preguntas detectadas. Se quitaron de la salida visible: contexto OCR, títulos, calidad, nitidez, cantidad de rescates y texto del escritorio.
5. El payload de API ya no incluye contexto del documento ni ruido OCR; solo preguntas normalizadas.
6. Corrección conservadora final de preguntas: tildes/capitalización conocidas, UTM/GPS/GNSS/OCR y confusiones letra/número cuando la corrección coincide con vocabulario protegido (ej. c0ordenadas -> coordenadas).
7. Tablas/títulos/contexto ya no se convierten automáticamente en preguntas para la API.

Pruebas estáticas realizadas:
- Compilación Kotlin de QuestionTextNormalizer + OcrQuestionExtractor + MultiImageDocumentMerger con stubs: OK.
- Caso de prueba con ruido externo (Ideas/Results/Examen/Core) y `c0ordenadas`: resultado final contiene solo las 6 preguntas limpias.
- Payload probado con contexto artificial: el contexto NO aparece; solo aparecen preguntas.
- Revisión de sintaxis de MainActivity/OcrProcessor/OpenCvDocumentPreprocessor: sin diagnósticos de sintaxis.
- Firmware de cámara sin cambios respecto a v1.6.13.

Nota:
La compilación Android completa debe ejecutarse en GitHub Actions porque este entorno no incluye el SDK/Gradle Android completo.
