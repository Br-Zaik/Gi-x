package com.gix.cameraai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.util.Log
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.paddle.ocr.EngineConfig
import com.paddle.ocr.PaddleOCR
import com.paddle.ocr.PaddleOCRConfig
import com.paddle.ocr.util.OpenCVUtils
import kotlinx.coroutines.runBlocking
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * OCR híbrido local y secuencial de GI-X v1.6.14.
 *
 * PP-OCRv6 Small es el motor principal para texto difícil/manuscrito y ML Kit se
 * mantiene como segunda lectura, especialmente valiosa por su geometría para tablas.
 * OpenCV hace una preparación conservadora del documento. Si Paddle/OpenCV fallan,
 * ML Kit sigue funcionando: una mejora nueva nunca debe dejar al usuario sin OCR.
 */
class OcrProcessor(context: Context) {
    data class ImageQualityReport(
        val brightness: Double,
        val contrast: Double,
        val sharpness: Double,
        val looksDark: Boolean,
        val looksLowContrast: Boolean,
        val looksBlurry: Boolean,
    ) {
        val acceptableForDocument: Boolean
            get() = !looksBlurry && !looksDark && !looksLowContrast

        /** Bonus acotado para desempatar dos lecturas de la misma pregunta. */
        fun selectionScore(): Double {
            val sharp = (sharpness.coerceIn(0.0, 400.0) / 8.0)
            val contrastPart = (contrast.coerceIn(0.0, 80.0) / 4.0)
            val penalties = (if (looksBlurry) 28.0 else 0.0) +
                (if (looksDark) 18.0 else 0.0) +
                (if (looksLowContrast) 14.0 else 0.0)
            return (sharp + contrastPart - penalties).coerceIn(-40.0, 80.0)
        }

        fun shortLabel(): String = when {
            looksBlurry -> "borrosa"
            looksDark -> "oscura"
            looksLowContrast -> "poco contraste"
            else -> "buena"
        }
    }

    private val appContext = context.applicationContext
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val prepExecutor = Executors.newSingleThreadExecutor()
    private val paddleExecutor = Executors.newSingleThreadExecutor()
    private val closed = AtomicBoolean(false)
    private val cleanupStarted = AtomicBoolean(false)
    private val activePipelines = AtomicInteger(0)
    private val paddleLock = Any()
    private val openCvLock = Any()

    @Volatile private var paddle: PaddleOCR? = null
    @Volatile private var paddleInitAttempted = false
    @Volatile private var paddleDisabledForSession = false
    @Volatile private var openCvReady = false
    @Volatile private var openCvInitAttempted = false

    private data class PaddleCandidate(
        val text: String,
        val averageConfidence: Float,
        val weakLineRatio: Float,
        val minimumConfidence: Float,
        val lineCount: Int,
    )

    fun process(bitmap: Bitmap, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        if (closed.get()) {
            onError("El motor OCR ya fue cerrado")
            return
        }

        activePipelines.incrementAndGet()
        try {
            prepExecutor.execute {
                var normalizedRef: Bitmap? = null
                var baseRef: Bitmap? = null
                var preparedRef: Bitmap? = null
                var enhancedRef: Bitmap? = null
                var rescueRef: Bitmap? = null
                val startedAt = System.nanoTime()
                var paddlePasses = 0
                var mlPasses = 0
                try {
                    pipelineLog("01_NORMALIZE", "inicio")
                    val normalizedBitmap = normalizeForOcr(bitmap)
                    normalizedRef = normalizedBitmap
                    if (closed.get()) return@execute

                    val cvReady = ensureOpenCv()
                    pipelineLog("02_DOCUMENT", "opencv=$cvReady")
                    val corrected = if (cvReady) {
                        OpenCvDocumentPreprocessor.correctPerspectiveIfSafe(normalizedBitmap)
                    } else null
                    val croppedFallback = if (cvReady && corrected == null) {
                        OpenCvDocumentPreprocessor.cropLikelyPaperIfSafe(normalizedBitmap)
                    } else null
                    val baseBitmap = corrected ?: croppedFallback ?: normalizedBitmap
                    baseRef = baseBitmap
                    if (baseBitmap !== normalizedBitmap && !normalizedBitmap.isRecycled) {
                        normalizedBitmap.recycle()
                        normalizedRef = null
                    }
                    pipelineLog(
                        "02_DOCUMENT",
                        when {
                            corrected != null -> "perspectiva corregida"
                            croppedFallback != null -> "recorte de hoja"
                            else -> "original conservado"
                        },
                    )

                    val quality = if (cvReady) {
                        OpenCvDocumentPreprocessor.quality(baseBitmap)
                    } else {
                        OpenCvDocumentPreprocessor.Quality(128.0, 64.0, 100.0)
                    }
                    pipelineLog(
                        "03_QUALITY",
                        "bright=${quality.brightness.toInt()} contrast=${quality.contrast.toInt()} sharp=${quality.sharpness.toInt()}",
                    )
                    if (closed.get()) return@execute

                    // PREPARACIÓN SIEMPRE ANTES DEL OCR: iluminación + contraste local +
                    // enfoque muy suave. Si OpenCV falla, seguimos con la hoja rectificada.
                    var primaryBitmap = baseBitmap
                    if (cvReady) {
                        OpenCvDocumentPreprocessor.prepareForOcr(baseBitmap)?.let {
                            preparedRef = it
                            primaryBitmap = it
                            pipelineLog("04_PREPARE", "fondo normalizado + CLAHE suave + enfoque mínimo")
                        }
                    }

                    // MOTOR 1: PP-OCRv6 Small es siempre el OCR principal.
                    pipelineLog("05_PADDLE_PRIMARY", "inicio")
                    paddlePasses++
                    var paddleBest = recognizePaddleTimed(primaryBitmap)
                    var hybrid = paddleBest?.text.orEmpty().trim()

                    // MOTOR 2: ML Kit actúa siempre como verificador independiente sobre
                    // la hoja rectificada ORIGINAL. Es ligero frente a Paddle y ayuda a detectar
                    // confusiones de caracteres que un único motor puede dar por válidas.
                    var mlBest: Text? = null
                    var mlText = ""
                    if (!closed.get()) {
                        pipelineLog("06_MLKIT_VERIFY", "verificación independiente")
                        mlPasses++
                        mlBest = recognizeMlBlocking(baseBitmap)
                        mlText = formatMl(mlBest, baseBitmap.width)
                        hybrid = chooseHybrid(mlText, paddleBest).trim()
                    }

                    // SEGUNDA VARIANTE VISUAL: como máximo una variante adicional. Evitamos
                    // explosión de filtros x motores x 4 fotos, que aumenta RAM y riesgo de ANR.
                    if (shouldContinuePipeline(startedAt) && shouldRunSecondVisualPass(hybrid, paddleBest, quality)) {
                        val retryBitmap = when {
                            cvReady && quality.needsExtraPass -> OpenCvDocumentPreprocessor.enhanceForText(baseBitmap)
                            primaryBitmap !== baseBitmap -> baseBitmap // contraste contra original rectificado
                            else -> enhanceFallback(baseBitmap)
                        }
                        if (retryBitmap != null) {
                            if (retryBitmap !== baseBitmap && retryBitmap !== enhancedRef) enhancedRef = retryBitmap
                            pipelineLog("07_VISUAL_RETRY", "segunda variante")
                            paddlePasses++
                            val paddleRetry = recognizePaddleTimed(retryBitmap)
                            paddleBest = chooseBestPaddle(paddleBest, paddleRetry)

                            // ML Kit entra en esta variante únicamente si el resultado aún es dudoso.
                            if (mlPasses < MAX_MLKIT_PASSES_PER_IMAGE &&
                                (shouldRunMlVerifier(paddleBest, quality) || isStructurallyWeak(hybrid))) {
                                mlPasses++
                                val mlRetry = recognizeMlBlocking(retryBitmap)
                                mlBest = chooseBestMl(mlBest, mlRetry, retryBitmap.width)
                                mlText = formatMl(mlBest, retryBitmap.width)
                            }
                            hybrid = chooseHybrid(mlText, paddleBest).trim()
                        }
                    }

                    // ÚLTIMO RESCATE: binarización adaptativa/manuscrito/sombras. Nunca corre antes
                    // de los motores normales y solo se usa si la estructura sigue débil.
                    if (cvReady && shouldContinuePipeline(startedAt) && needsHandwritingRescue(hybrid, paddleBest, quality)) {
                        OpenCvDocumentPreprocessor.enhanceForHandwriting(baseBitmap)?.let { rescueBitmap ->
                            rescueRef = rescueBitmap
                            pipelineLog("08_LAST_RESCUE", "adaptativo")
                            if (paddlePasses < MAX_PADDLE_PASSES_PER_IMAGE) {
                                paddlePasses++
                                val paddleRescue = recognizePaddleTimed(rescueBitmap)
                                paddleBest = chooseBestPaddle(paddleBest, paddleRescue)
                            }
                            if (mlPasses < MAX_MLKIT_PASSES_PER_IMAGE) {
                                mlPasses++
                                val mlRescue = recognizeMlBlocking(rescueBitmap)
                                mlBest = chooseBestMl(mlBest, mlRescue, rescueBitmap.width)
                                mlText = formatMl(mlBest, rescueBitmap.width)
                            }
                            hybrid = chooseHybrid(mlText, paddleBest).trim()
                        }
                    }

                    // Fallback final: si Paddle falló/timeout y todavía no ejecutamos ML Kit,
                    // hacemos una única lectura sobre el documento rectificado.
                    if (!closed.get() && hybrid.isBlank() && mlText.isBlank() && mlPasses < MAX_MLKIT_PASSES_PER_IMAGE) {
                        pipelineLog("09_FINAL_FALLBACK", "ML Kit")
                        mlPasses++
                        mlBest = recognizeMlBlocking(baseBitmap)
                        mlText = formatMl(mlBest, baseBitmap.width)
                        hybrid = mlText.trim()
                    }

                    val elapsedMs = (System.nanoTime() - startedAt) / 1_000_000L
                    pipelineLog(
                        "10_DONE",
                        "ms=$elapsedMs chars=${hybrid.length} ppPasses=$paddlePasses mlPasses=$mlPasses " +
                            "ppConf=${paddleBest?.averageConfidence ?: 0f} ppWeak=${paddleBest?.weakLineRatio ?: 0f}",
                    )
                    if (!closed.get()) onSuccess(hybrid)
                } catch (t: Throwable) {
                    Log.e("GIX-OCR", "OCR pipeline failed", t)
                    if (!closed.get()) onError(t.message ?: "No se pudo procesar la imagen para OCR")
                } finally {
                    // Solo liberamos bitmaps creados dentro del pipeline. El bitmap original
                    // pertenece a MainActivity y jamás se recicla aquí.
                    val rescue = rescueRef
                    val enhanced = enhancedRef
                    val prepared = preparedRef
                    val base = baseRef
                    val normalized = normalizedRef
                    if (rescue != null && rescue !== bitmap && rescue !== base && rescue !== enhanced && rescue !== prepared && !rescue.isRecycled) rescue.recycle()
                    if (enhanced != null && enhanced !== bitmap && enhanced !== base && enhanced !== prepared && !enhanced.isRecycled) enhanced.recycle()
                    if (prepared != null && prepared !== bitmap && prepared !== base && !prepared.isRecycled) prepared.recycle()
                    if (base != null && base !== bitmap && !base.isRecycled) base.recycle()
                    if (normalized != null && normalized !== bitmap && normalized !== base && !normalized.isRecycled) normalized.recycle()
                    activePipelines.decrementAndGet()
                }
            }
        } catch (t: Throwable) {
            activePipelines.decrementAndGet()
            if (!closed.get()) onError(t.message ?: "No se pudo iniciar el OCR")
        }
    }

    private fun shouldContinuePipeline(startedAtNs: Long): Boolean {
        val elapsedMs = (System.nanoTime() - startedAtNs) / 1_000_000L
        return elapsedMs < MAX_PIPELINE_BUDGET_MS && !closed.get()
    }

    private fun shouldRunMlVerifier(
        paddleCandidate: PaddleCandidate?,
        quality: OpenCvDocumentPreprocessor.Quality,
    ): Boolean {
        if (paddleCandidate == null) return true
        if (paddleCandidate.text.isBlank()) return true
        if (paddleCandidate.averageConfidence < 0.86f) return true
        if (paddleCandidate.weakLineRatio >= 0.10f) return true
        if (paddleCandidate.minimumConfidence < 0.42f) return true
        if (isStructurallyWeak(paddleCandidate.text)) return true
        if (looksLikeStructuredData(paddleCandidate.text)) return true
        return quality.needsExtraPass && paddleCandidate.averageConfidence < 0.92f
    }

    private fun shouldRunSecondVisualPass(
        hybrid: String,
        paddleCandidate: PaddleCandidate?,
        quality: OpenCvDocumentPreprocessor.Quality,
    ): Boolean {
        if (hybrid.isBlank() || isStructurallyWeak(hybrid)) return true
        if (paddleCandidate == null) return quality.needsExtraPass
        if (paddleCandidate.averageConfidence < 0.72f || paddleCandidate.weakLineRatio >= 0.22f) return true
        return quality.needsExtraPass && score(hybrid) < 520
    }

    private fun looksLikeStructuredData(text: String): Boolean {
        val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
        if (lines.size < 3) return false
        val numericLines = lines.count { line -> line.count(Char::isDigit) >= 2 }
        val shortColumns = lines.count { line ->
            line.split(Regex("\\s{2,}|\\t")).count { it.isNotBlank() } >= 3
        }
        return numericLines >= 3 || shortColumns >= 2
    }

    private fun pipelineLog(stage: String, detail: String) {
        Log.d("GIX-PIPE", "$stage · $detail")
    }

    private fun needsHandwritingRescue(
        hybrid: String,
        paddleCandidate: PaddleCandidate?,
        quality: OpenCvDocumentPreprocessor.Quality,
    ): Boolean {
        if (hybrid.isBlank() || isStructurallyWeak(hybrid)) return true
        if (paddleCandidate != null &&
            (paddleCandidate.averageConfidence < 0.67f || paddleCandidate.weakLineRatio >= 0.26f)) return true
        return quality.needsExtraPass && score(hybrid) < 300
    }


    /** Medición local y barata para comparar fotos de un mismo documento. */
    fun assessQuality(bitmap: Bitmap): ImageQualityReport {
        if (!ensureOpenCv()) {
            return ImageQualityReport(128.0, 64.0, 100.0, false, false, false)
        }
        var sample: Bitmap? = null
        var document: Bitmap? = null
        return try {
            sample = normalizeForAssessment(bitmap)
            val sampleRef = sample ?: bitmap
            document = OpenCvDocumentPreprocessor.correctPerspectiveIfSafe(sampleRef)
                ?: OpenCvDocumentPreprocessor.cropLikelyPaperIfSafe(sampleRef)
            val work = document ?: sampleRef
            val q = OpenCvDocumentPreprocessor.quality(work)
            ImageQualityReport(
                brightness = q.brightness,
                contrast = q.contrast,
                sharpness = q.sharpness,
                looksDark = q.looksDark,
                looksLowContrast = q.looksLowContrast,
                looksBlurry = q.looksBlurry,
            )
        } catch (_: Throwable) {
            ImageQualityReport(128.0, 64.0, 100.0, false, false, false)
        } finally {
            val doc = document
            val smp = sample
            if (doc != null && doc !== bitmap && doc !== smp && !doc.isRecycled) doc.recycle()
            if (smp != null && smp !== bitmap && !smp.isRecycled) smp.recycle()
        }
    }

    private fun normalizeForAssessment(source: Bitmap): Bitmap {
        val width = source.width.coerceAtLeast(1)
        val height = source.height.coerceAtLeast(1)
        val longSide = max(width, height)
        val desiredLongSide = when {
            longSide < 900 -> 900
            longSide > 1600 -> 1400
            else -> longSide
        }
        val scale = desiredLongSide.toFloat() / longSide.toFloat()
        val targetW = max(1, (width * scale).roundToInt())
        val targetH = max(1, (height * scale).roundToInt())
        return if (targetW == width && targetH == height) {
            source.copy(Bitmap.Config.ARGB_8888, false)
        } else {
            Bitmap.createScaledBitmap(source, targetW, targetH, true)
        }
    }

    private fun ensureOpenCv(): Boolean {
        if (openCvReady) return true
        synchronized(openCvLock) {
            if (openCvReady) return true
            if (openCvInitAttempted) return false
            openCvInitAttempted = true
            val ready = runCatching { OpenCVUtils.init(appContext) }
                .onFailure { Log.w("GIX-OCR", "OpenCV no disponible: ${it.message}") }
                .getOrDefault(false)
            openCvReady = ready
            return ready
        }
    }

    private fun getPaddle(): PaddleOCR? {
        paddle?.let { return it }
        synchronized(paddleLock) {
            paddle?.let { return it }
            if (paddleInitAttempted || closed.get()) return null
            paddleInitAttempted = true
            if (!ensureOpenCv()) return null
            return try {
                runBlocking {
                    PaddleOCR.create(
                        context = appContext,
                        config = PaddleOCRConfig(
                            detThresh = 0.20f,
                            detBoxThresh = 0.45f,
                            detUnclipRatio = 1.40f,
                            recScoreThresh = 0.05f,
                            recBatchSize = 1,
                        ),
                        engineConfig = EngineConfig(numThreads = 2),
                        detModelAssetPath = "models/det/inference.onnx",
                        recModelAssetPath = "models/rec/inference.onnx",
                        recConfigAssetPath = "models/rec/inference.yml",
                    )
                }.also { paddle = it }
            } catch (t: Throwable) {
                Log.e("GIX-OCR", "PP-OCRv6 no pudo inicializar; ML Kit seguirá activo", t)
                null
            }
        }
    }

    private fun recognizePaddleTimed(bitmap: Bitmap): PaddleCandidate? {
        if (closed.get() || paddleDisabledForSession) return null

        // PP-OCR usa una copia propia: si el motor nativo tarda demasiado y abandonamos
        // la espera, MainActivity/OcrProcessor puede liberar sus bitmaps sin tocar la
        // memoria que el hilo de Paddle todavía pudiera estar usando.
        val paddleBitmap = runCatching { bitmap.copy(Bitmap.Config.ARGB_8888, false) }.getOrNull()
            ?: return null
        val future = try {
            paddleExecutor.submit<PaddleCandidate?> {
                try {
                    recognizePaddleDirect(paddleBitmap)
                } finally {
                    if (!paddleBitmap.isRecycled) paddleBitmap.recycle()
                }
            }
        } catch (_: Throwable) {
            if (!paddleBitmap.isRecycled) paddleBitmap.recycle()
            return null
        }

        return try {
            future.get(PADDLE_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        } catch (_: TimeoutException) {
            paddleDisabledForSession = true
            future.cancel(true)
            Log.w("GIX-OCR", "PP-OCRv6 excedió ${PADDLE_TIMEOUT_SECONDS}s; se desactiva para esta sesión y ML Kit continúa")
            null
        } catch (t: Throwable) {
            Log.w("GIX-OCR", "PP-OCRv6 worker falló: ${t.message}")
            null
        }
    }

    private fun recognizePaddleDirect(bitmap: Bitmap): PaddleCandidate? {
        val engine = getPaddle() ?: return null
        return try {
            val result = runBlocking { engine.recognize(bitmap) }
            val items = result.results
                .filter { it.text.isNotBlank() }
            if (items.isEmpty()) return null
            val text = cleanText(items.joinToString("\n") { it.text.trim() })
            val confidences = items.map { it.confidence.coerceIn(0f, 1f) }
            val confidence = confidences.average().toFloat()
            val weakRatio = confidences.count { it < 0.58f }.toFloat() / confidences.size.coerceAtLeast(1)
            val minimum = confidences.minOrNull() ?: 0f
            PaddleCandidate(text, confidence, weakRatio, minimum, items.size)
        } catch (t: Throwable) {
            Log.w("GIX-OCR", "PP-OCRv6 pass failed: ${t.message}")
            null
        }
    }

    private fun recognizeMlBlocking(bitmap: Bitmap): Text? {
        if (closed.get()) return null
        return try {
            val image = InputImage.fromBitmap(bitmap, 0)
            Tasks.await(recognizer.process(image), MLKIT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        } catch (t: Throwable) {
            Log.w("GIX-OCR", "ML Kit pass failed: ${t.message}")
            null
        }
    }

    private fun normalizeForOcr(source: Bitmap): Bitmap {
        val width = source.width.coerceAtLeast(1)
        val height = source.height.coerceAtLeast(1)
        val longSide = max(width, height)

        // OCR de documentos: suficiente detalle sin disparar memoria en equipos modestos.
        val desiredLongSide = when {
            longSide < 1200 -> 1800
            longSide > 2600 -> 2300
            else -> longSide
        }
        val scale = desiredLongSide.toFloat() / longSide.toFloat()
        val targetW = max(1, (width * scale).roundToInt())
        val targetH = max(1, (height * scale).roundToInt())
        return if (targetW == width && targetH == height) {
            source.copy(Bitmap.Config.ARGB_8888, false)
        } else {
            Bitmap.createScaledBitmap(source, targetW, targetH, true)
        }
    }

    private fun enhanceFallback(source: Bitmap): Bitmap {
        val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val gray = ColorMatrix().apply { setSaturation(0f) }
        val contrast = 1.28f
        val translate = (-0.5f * contrast + 0.5f) * 255f
        val boost = ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, translate,
                0f, contrast, 0f, 0f, translate,
                0f, 0f, contrast, 0f, translate,
                0f, 0f, 0f, 1f, 0f,
            ),
        )
        gray.postConcat(boost)
        paint.colorFilter = ColorMatrixColorFilter(gray)
        canvas.drawBitmap(source, 0f, 0f, paint)
        return output
    }

    private fun formatMl(result: Text?, imageWidth: Int): String {
        return if (result != null && result.text.isNotBlank()) {
            cleanText(OcrTableFormatter.formatDocument(result, imageWidth))
        } else ""
    }

    private fun chooseBestMl(first: Text?, second: Text?, imageWidth: Int): Text? {
        if (first == null) return second
        if (second == null) return first
        val a = cleanText(first.text)
        val b = cleanText(second.text)
        if (a.isBlank()) return second
        if (b.isBlank()) return first
        val scoreA = score(a) + structureScoreMl(first, imageWidth)
        val scoreB = score(b) + structureScoreMl(second, imageWidth)
        return if (scoreB > scoreA + 6) second else first
    }

    private fun chooseBestPaddle(a: PaddleCandidate?, b: PaddleCandidate?): PaddleCandidate? {
        if (a == null) return b
        if (b == null) return a
        val scoreA = paddleCandidateScore(a)
        val scoreB = paddleCandidateScore(b)
        return if (scoreB > scoreA + 8) b else a
    }

    private fun paddleCandidateScore(candidate: PaddleCandidate): Int {
        val confidenceBonus = (candidate.averageConfidence * 150).toInt()
        val weakPenalty = (candidate.weakLineRatio * 180).toInt()
        val minimumPenalty = if (candidate.lineCount >= 2 && candidate.minimumConfidence < 0.30f) 35 else 0
        return score(candidate.text) + structureScoreText(candidate.text) +
            confidenceBonus - weakPenalty - minimumPenalty
    }

    private fun chooseHybrid(mlText: String, paddleCandidate: PaddleCandidate?): String {
        val paddleText = paddleCandidate?.text.orEmpty()
        if (mlText.isBlank()) return paddleText
        if (paddleText.isBlank()) return mlText

        val mlQuestions = safeQuestions(mlText)
        val paddleQuestions = safeQuestions(paddleText)
        val mlSuspiciousBeforeMerge = mlQuestions.isNotEmpty() && OcrQuestionExtractor.hasSuspiciousNumbering(mlQuestions)

        // Si ML Kit reconstruyó una tabla válida, se prioriza ANTES de fusionar
        // preguntas. En v1.6.2 la fusión podía devolver solo 1..8 y perder la tabla,
        // lectura o datos que estaban arriba de las preguntas.
        if (mlText.contains(OcrTableFormatter.TABLE_START) && !mlSuspiciousBeforeMerge) return mlText

        // Fusiona pregunta por pregunta, pero preservando también el contexto de la
        // hoja (lectura/datos/instrucciones) para que la API pueda responder preguntas
        // que dependan de ese material.
        mergeNumberedQuestions(mlText, paddleText)?.let { return it }

        val mlSuspicious = mlQuestions.isNotEmpty() && OcrQuestionExtractor.hasSuspiciousNumbering(mlQuestions)
        val paddleSuspicious = paddleQuestions.isNotEmpty() && OcrQuestionExtractor.hasSuspiciousNumbering(paddleQuestions)

        if (!paddleSuspicious && mlSuspicious && paddleQuestions.isNotEmpty()) return paddleText
        if (!mlSuspicious && paddleSuspicious && mlQuestions.isNotEmpty()) return mlText

        if (!paddleSuspicious && paddleQuestions.size > mlQuestions.size && paddleQuestions.size >= 2) return paddleText
        if (!mlSuspicious && mlQuestions.size > paddleQuestions.size && mlQuestions.size >= 2) return mlText

        val mlScore = score(mlText) + structureScoreText(mlText)
        val paddleScore = score(paddleText) + structureScoreText(paddleText) +
            ((paddleCandidate?.averageConfidence ?: 0f) * 100).toInt()
        return if (paddleScore > mlScore + 20) paddleText else mlText
    }

    private fun mergeNumberedQuestions(mlText: String, paddleText: String): String? {
        val mlQuestions = safeQuestions(mlText)
        val paddleQuestions = safeQuestions(paddleText)
        if (mlQuestions.isEmpty() || paddleQuestions.isEmpty()) return null

        val mlMap = mlQuestions.mapNotNull { q -> OcrQuestionExtractor.questionNumber(q)?.let { it to q } }.toMap()
        val paddleMap = paddleQuestions.mapNotNull { q -> OcrQuestionExtractor.questionNumber(q)?.let { it to q } }.toMap()
        if (mlMap.isEmpty() || paddleMap.isEmpty()) return null

        val ids = (mlMap.keys + paddleMap.keys).distinct().sorted()
        if (ids.size < 2 || ids.zipWithNext().any { (a, b) -> b != a + 1 }) return null

        val merged = ids.mapNotNull { id ->
            val ml = mlMap[id]
            val pp = paddleMap[id]
            when {
                ml == null -> pp
                pp == null -> ml
                ml.contains(OcrTableFormatter.TABLE_START) -> ml
                questionScore(pp) > questionScore(ml) + 35 -> pp
                else -> ml
            }
        }
        if (merged.size != ids.size) return null
        val mergedQuestions = merged.joinToString("\n\n")

        // Conserva el contexto más rico. Preferimos ML Kit porque mantiene orden
        // geométrico; si no tiene contexto útil, usamos el de Paddle.
        val mlContext = OcrQuestionExtractor.extractDocumentContext(mlText)
        val paddleContext = OcrQuestionExtractor.extractDocumentContext(paddleText)
        val context = when {
            mlContext.length >= 20 -> mlContext
            paddleContext.length >= 20 -> paddleContext
            else -> ""
        }
        return if (context.isBlank()) {
            mergedQuestions
        } else {
            "$context\n\nPreguntas:\n$mergedQuestions"
        }
    }

    private fun safeQuestions(text: String): List<String> {
        return try { OcrQuestionExtractor.extractQuestions(text) } catch (_: Throwable) { emptyList() }
    }

    private fun questionScore(question: String): Int {
        var value = score(question)
        if (Regex("(?i)\\b(?:Fe|Pb|Ag|Au|Cu|Zn|H2O|CO2|EPP|GPS|GNSS|USB)\\b").containsMatchIn(question)) value += 40
        if (question.contains(".....") || question.contains("___")) value += 20
        if (question.contains(OcrTableFormatter.TABLE_START)) value += 200
        return value
    }

    private fun isStructurallyWeak(text: String): Boolean {
        val questions = safeQuestions(text)
        if (text.length < 18) return true
        if (questions.size >= 2 && OcrQuestionExtractor.hasSuspiciousNumbering(questions)) return true
        return false
    }

    private fun structureScoreMl(result: Text, imageWidth: Int): Int {
        return try {
            structureScoreText(OcrTableFormatter.formatDocument(result, imageWidth))
        } catch (_: Throwable) {
            0
        }
    }

    private fun structureScoreText(text: String): Int {
        return try {
            val questions = OcrQuestionExtractor.extractQuestions(text)
            var value = questions.size * 90
            if (questions.size >= 3 && !OcrQuestionExtractor.hasSuspiciousNumbering(questions)) value += 180
            if (OcrQuestionExtractor.hasSuspiciousNumbering(questions)) value -= 420
            if (text.contains(OcrTableFormatter.TABLE_START)) value += 80
            val ids = questions.mapNotNull { OcrQuestionExtractor.questionNumber(it) }
            if (ids.size >= 3 && ids.zipWithNext().all { (x, y) -> y == x + 1 }) value += 220
            value
        } catch (_: Throwable) {
            0
        }
    }

    private fun score(text: String): Int {
        val trimmed = text.trim()
        if (trimmed.isBlank()) return Int.MIN_VALUE
        val chars = trimmed.length
        val useful = trimmed.count { it.isLetterOrDigit() || it in "¿?¡!.,:;()[]%-+/=_" }
        val letters = trimmed.count { it.isLetterOrDigit() }
        val weird = trimmed.count { it == '\uFFFD' || it == '�' }
        val words = trimmed.split(Regex("\\s+")).count { it.length >= 2 }
        val lines = trimmed.lines().count { it.trim().length >= 2 }
        val questionBonus = if ('?' in trimmed || '¿' in trimmed) 18 else 0
        val lineList = trimmed.lines()
        val optionBonus = lineList.count { Regex("^\\s*[A-Ha-h][\\)\\].:-]\\s+.+").matches(it) } * 4
        val numberedQuestionBonus = lineList.count {
            Regex("^\\s*\\d{1,2}\\s*[\\.)\\-:]\\s*.*$").matches(it)
        } * 10
        val shortDataBonus = lineList.count {
            val line = it.trim()
            Regex("^[A-Z][a-z]?$|^[A-Z][A-Za-z0-9₀-₉]{1,7}$").matches(line)
        } * 4
        val ratio = if (chars == 0) 0 else (useful * 100 / chars)
        val noisePenalty = max(0, 65 - ratio) * 2 + weird * 20
        return min(chars, 2600) + letters / 2 + words * 3 + min(lines, 24) * 2 +
            questionBonus + optionBonus + numberedQuestionBonus + shortDataBonus - noisePenalty
    }

    private fun cleanText(raw: String): String {
        return raw
            .replace("\r\n", "\n")
            .replace('\r', '\n')
            .lines()
            .map { line -> line.replace(Regex("[ \\t]+"), " ").trimEnd() }
            .dropWhile { it.isBlank() }
            .dropLastWhile { it.isBlank() }
            .joinToString("\n")
            .replace(Regex("\n{3,}"), "\n\n")
            .trim()
    }

    private companion object {
        const val PADDLE_TIMEOUT_SECONDS = 7L
        const val MLKIT_TIMEOUT_SECONDS = 6L
        const val MAX_PIPELINE_BUDGET_MS = 16_000L
        const val MAX_PADDLE_PASSES_PER_IMAGE = 3
        const val MAX_MLKIT_PASSES_PER_IMAGE = 2
        const val CLOSE_WAIT_SECONDS = 12L
    }

    /**
     * Cierre no destructivo: deja de aceptar trabajo nuevo, permite que el pipeline que
     * ya está dentro termine/libere sus bitmaps y recién después cierra motores. Evita
     * liberar ONNX/ML Kit mientras todavía existe una inferencia nativa en curso.
     */
    fun close() {
        if (!closed.compareAndSet(false, true)) return
        if (!cleanupStarted.compareAndSet(false, true)) return

        prepExecutor.shutdown()
        paddleExecutor.shutdown()

        Thread {
            runCatching { prepExecutor.awaitTermination(CLOSE_WAIT_SECONDS, TimeUnit.SECONDS) }
            // Si una tarea Java quedó esperando, pedimos interrupción. No liberamos Paddle
            // si previamente tuvo timeout nativo porque ese hilo podría seguir dentro de JNI.
            if (!prepExecutor.isTerminated) prepExecutor.shutdownNow()

            runCatching { paddleExecutor.awaitTermination(CLOSE_WAIT_SECONDS, TimeUnit.SECONDS) }
            if (!paddleExecutor.isTerminated) paddleExecutor.shutdownNow()

            val instance = paddle
            paddle = null
            if (instance != null && !paddleDisabledForSession && paddleExecutor.isTerminated) {
                runCatching { runBlocking { instance.release() } }
                    .onFailure { Log.w("GIX-OCR", "Paddle release omitido/seguro: ${it.message}") }
            }
            runCatching { recognizer.close() }
        }.apply {
            name = "gix-ocr-cleanup"
            isDaemon = true
            start()
        }
    }
}
