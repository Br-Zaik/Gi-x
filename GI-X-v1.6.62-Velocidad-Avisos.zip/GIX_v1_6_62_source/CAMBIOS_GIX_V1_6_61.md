# GI X 1.6.61 — voz lenta

Cambios exclusivos del selector y procesamiento de voz sobre 1.6.60.

- Eliminadas 0.05x, 0.10x, 0.15x y 0.25x.
- Añadidas 0.375x (mitad entre 0.25 y 0.50) y 0.4375x (mitad entre 0.375 y 0.50).
- Se conservan 0.50x, 0.75x, 1.00x, 1.25x, 1.50x, 1.75x y 2.00x.
- Una preferencia antigua eliminada se interpreta como 0.375x al actualizar, sin borrar ajustes.

## Corrección de sonido

Se elimina el estiramiento anterior por ventanas fijas. Las opciones lentas parten de síntesis TTS nativa a 0.50x para conservar mejor la articulación; Sonic aplica solo el ajuste restante, con detección de periodos de voz y conservación de tono.

A 0.50x no se aplica estiramiento adicional a esa síntesis. A 0.375x se aplica un factor 0.75; a 0.4375x, 0.875. Si el motor rechaza la síntesis a 0.50x, se usa 1.00x y Sonic realiza el ajuste completo. Cambiar la velocidad afecta al audio en curso dentro del pequeño búfer pendiente. No se reinicia la lectura desde el comienzo.

El aviso «Procesando» sigue a 1.00x. Se conservan la reproducción progresiva, la cancelación al llegar un documento nuevo y la confirmación de fotos solo después de terminar el sonido.

La síntesis nativa depende del motor TTS instalado: el tempo es nominal, y el ajuste por periodos puede variar unos milisegundos. No se promete voz natural perfecta a cualquier velocidad. Falta validación auditiva en el teléfono del usuario.

## Validación

- Compilación Android debug con JDK 17, Gradle 8.6 y SDK 34.
- Pruebas PCM de velocidades y tono: correctas, dentro de tolerancia del 3 % de duración para el ajuste por periodos.
- Pruebas de combinación con síntesis lenta, migración de preferencias, cancelación, cambio en reproducción y estéreo: correctas.
- 1.00x sin cambio de PCM; 0.50x con síntesis lenta también sin cambio de PCM.
- Muestra de voz sintetizada de 5.28 s: 14.136 s a 0.375x, 12.111 s a 0.4375x y 10.560 s a 0.50x al procesar desde PCM normal, sin saturación. Este ensayo no mide el TTS del Moto e30.
- Pruebas de vaciado del final del audio para 8–96 kHz: correctas.

Cámara, API, ajustes de fotografías, notificación, estados, firmware y workflows no se modifican.

Sonic se distribuye como código Java con su licencia Apache 2.0; véase THIRD_PARTY_VOICE.md. No añade bibliotecas nativas ni nuevas dependencias Gradle.
