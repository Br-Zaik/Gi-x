# GI X 1.6.60 — cambios solicitados

Base: GI-X-v1.6.59-Streaming-Recuperacion-Completa.

## Voz

- Añadido 0.05x. Se conservan las demás velocidades hasta 2.00x.
- La síntesis se realiza a velocidad normal. GI X aplica después el tempo al PCM mediante solapamiento y alineación de ondas, conservando aproximadamente el tono. Esto evita que el motor Android iguale las opciones muy lentas.
- Cambiar la velocidad afecta al audio en curso; no vuelve a leer el documento desde el principio.
- Fragmentos de texto acotados, salida por bloques pequeños y temporales eliminados tras reproducir/cancelar. No se genera una copia completa 20 veces mayor para 0.05x.
- La confirmación del lote espera el final audible, no simplemente el final de la síntesis.
- Las velocidades extremas pueden sonar menos naturales; requieren prueba auditiva en el teléfono.

## Notificación y cierre

- Notificación compacta: icono nuevo, título «GI X», sin descripción extensa ni hora.
- Quitar la app de recientes detiene recepción, solicitudes y voz, y elimina la notificación. No se reinicia sola como servicio persistente.
- Apagar la pantalla o cambiar de aplicación no ejecuta ese cierre.
- Android controla el marco y el encabezado de sus notificaciones; su aspecto exacto depende del sistema.

## Fotos

- Corrección suave de iluminación/sombras, contraste y nitidez antes del envío, tanto desde cámara como desde selección manual.
- Conserva canales de color y originales. No hay OCR local, binarización ni generación de letras.
- Si hay [ilegible] o huecos internos en la numeración, la revisión usa dos recortes solapados por fotografía en lotes de 1–2 fotos. Para 3–4 fotos manuales conserva páginas completas por el límite de cuatro imágenes de la solicitud.
- Se mantienen los límites de peso y resolución del envío. Una revisión no puede reemplazar la primera lectura si pierde preguntas o añade más marcas de ilegible.
- No se puede recuperar información ausente por desenfoque fuerte o texto fuera del encuadre. No se ha medido reconocimiento con una API real ni se han usado credenciales del usuario.

## Procesamiento

- «Procesando» por voz una vez por lote, a velocidad normal para que sea breve incluso si la respuesta está configurada a 0.05x.
- Indicador de recepción, envío, procesamiento y lectura en cámara/manual.
- El aviso de imágenes enviadas se emite después de escribir el cuerpo de la solicitud.

## Validación

- APK debug compilada con Gradle 8.6, JDK 17 y Android SDK 34: BUILD SUCCESSFUL.
- Prueba de todas las velocidades con señal PCM: 1 s de entrada produce 20 s a 0.05x, 10 s a 0.10x, 4 s a 0.25x y 0.5 s a 2x; diferencia de duración inferior a dos muestras.
- Pruebas de tono aproximado, cambio de velocidad durante reproducción, cancelación y estéreo.
- Pruebas de conservación del original y tinta negra, roja, azul y verde.
- Procesamiento y revisión visual de las dos fotografías adjuntas.
- Pruebas previas de política de lectura, lote 2/2, recuperación y streaming de voz: correctas.
- Pendiente prueba física con Moto e30, motor TTS instalado y Timer Camera X. El emulador no sustituye esa comprobación.

Se conservan firmware, modelos/proveedores, recuperación de respuestas, streaming, historial, diseño de pantalla y workflows de GitHub originales. No se agregan dependencias de producción.
