package com.gix.cameraai

/** Per-document announcements, including delayed TTS initialization and restarts.
 * Only these short messages are spoken; document context never becomes a cue.
 */
internal class DocumentVoiceCues {
    enum class Kind(val text: String, val key: String) {
        PROCESSING("Procesando", "processing"),
        CONTEXT("Contexto detectado", "context"),
    }
    data class Cue(val text: String, val id: String)
    private var workId = 0L
    private val requested = linkedSetOf<Kind>()
    private val queued = mutableSetOf<Kind>()
    private val finished = mutableSetOf<Kind>()

    fun begin(id: Long) {
        workId = id
        requested.clear(); queued.clear(); finished.clear()
    }
    fun request(id: Long, kind: Kind) {
        if (id > 0 && id == workId) requested.add(kind)
    }
    private fun id(kind: Kind) = "gix_notice_${workId}_${kind.key}"
    fun pending(id: Long): List<Cue> = if (id != workId || id <= 0) emptyList() else
        requested.filter { it !in queued && it !in finished }.map { Cue(it.text, id(it)) }
    fun markQueued(cueId: String) {
        requested.firstOrNull { id(it) == cueId }?.let { queued.add(it) }
    }
    fun finish(cueId: String?) {
        queued.firstOrNull { id(it) == cueId }?.let { finished.add(it) }
    }
    fun hasQueuedUnfinished(id: Long): Boolean = id == workId && queued.any { it !in finished }
    fun retryUnfinished() { queued.retainAll(finished) }
}
