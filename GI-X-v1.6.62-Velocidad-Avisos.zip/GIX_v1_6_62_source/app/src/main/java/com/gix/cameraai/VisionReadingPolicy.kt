package com.gix.cameraai

/** Reglas exclusivamente para la lectura visual. No altera los formatos de DeepSeek. */
internal object VisionReadingPolicy {
    fun extraInstructions(mode: AiContextMode, secondPass: Boolean): String = buildString {
        appendLine("""
            LECTURA FIEL MANUSCRITA E IMPRESA (PRIORIDAD ALTA):
            - El examen puede estar escrito a lapicero negro, azul, rojo tenue o LAPIZ GRIS, en hoja bond o cuadriculada, con manchas, sombras y tachaduras. Reconoce primero los trazos, no las respuestas imaginadas.
            - Revisa visualmente la hoja de ARRIBA HACIA ABAJO y de IZQUIERDA A DERECHA. Cada numero de ejercicio inicia un enunciado; incluye todas sus lineas y alternativas. No confundas una respuesta ya escrita bajo el enunciado con una pregunta nueva.
            - Una palabra pequeña o borrosa no autoriza a cambiar la materia, el tema ni la intención de la pregunta. Contrasta cuidadosamente cada letra y palabra con AMBAS tomas; no selecciones una frase solo porque sea más frecuente.
            - Conserva acentos, numeros, siglas, unidades, formulas, signos, negaciones y el orden tal como son visibles. No traduzcas el documento a otros temas, no resuelvas, no completes respuestas y no inventes enunciados.
            - Distingue ENUNCIADO (lo que se pide) de RESPUESTA MANUSCRITA (texto ya contestado, tachado o corregido). La respuesta del alumno no debe alterar la transcripción del enunciado.
            - Para un examen con varios incisos (V/F, alternativa multiple, completar, relacionar, calculo, pregunta abierta), recupera cada inciso sin omitir ni duplicar. Mantén intactos los formatos ya reconocidos.
            - Si algo no puede leerse, marca [ilegible] SOLO la palabra imposible de ver y conserva las demás. No rellenes huecos con suposiciones.
        """.trimIndent())
        appendLine()
        when (mode) {
            AiContextMode.MINING -> appendLine("""
                CONTEXTO DE LECTURA: el usuario seleccionó MINERÍA como ámbito general. Utilízalo SOLO para desambiguar lecturas visualmente plausibles cuando el propio documento lo respalde. No presupongas un tema minero específico ni agregues términos, siglas, preguntas o respuestas que no aparecen en la hoja.
                La transcripción debe reflejar lo escrito, incluso si el documento contiene preguntas de otra materia. Los trazos visibles tienen prioridad sobre el contexto seleccionado.
            """.trimIndent())
            AiContextMode.AUTO -> appendLine("Determina el tema exclusivamente por el CONTENIDO VISIBLE de la hoja completa. Usa ese contexto solo para resolver ambigüedades entre trazos plausibles; nunca fuerces un tema ni inventes palabras.")
            AiContextMode.GENERAL -> appendLine("No fuerces ningún tema. La forma visible de las letras tiene prioridad sobre cualquier inferencia contextual.")
        }
        if (secondPass) appendLine("""
            SEGUNDA LECTURA DE CONTROL: la primera lectura presentó zonas dudosas. Vuelve a examinar todas las fotografías como si fuera la primera vez. Las imágenes pueden ser recortes superior e inferior de cada página, en ese orden, con solapamiento: une las líneas compartidas, no dupliques preguntas y no confundas un recorte con una nueva página. Presta especial atención a palabras incompletas, número de preguntas, términos técnicos y separación entre tinta del enunciado y respuestas manuscritas. Reconstruye el documento íntegro, sin comentarios y sin inventar palabras.
        """.trimIndent())
    }.trim()

    @Suppress("UNUSED_PARAMETER")
    fun needsSecondPass(transcription: String, mode: AiContextMode): Boolean {
        if (transcription.isBlank()) return true
        val unreadable = Regex("\\[\\s*ilegible\\s*]", RegexOption.IGNORE_CASE).findAll(transcription).count()
        if (unreadable > 0) return true
        val section = transcription.substringAfter("PREGUNTAS DETECTADAS", "").trim()
        if (section.isBlank()) return true
        val numbers = Regex("(?m)^\\s*(\\d{1,2})\\s*[.):-]\\s*")
            .findAll(section).mapNotNull { it.groupValues[1].toIntOrNull() }.distinct().sorted().toList()
        // Internal gaps only: a later page may legitimately start at question 5.
        return numbers.zipWithNext().any { (a, b) -> b > a + 1 }
    }

    @Suppress("UNUSED_PARAMETER")
    fun chooseSafest(first: String, review: String, mode: AiContextMode = AiContextMode.AUTO): String {
        if (review.isBlank() || review.startsWith("[GIX_API_ERROR]")) return first
        fun numbers(text: String): Set<Int> = Regex("(?m)^\\s*(\\d{1,2})\\s*[.):-]\\s*")
            .findAll(text.substringAfter("PREGUNTAS DETECTADAS", ""))
            .mapNotNull { it.groupValues[1].toIntOrNull() }.toSet()
        val n1 = numbers(first)
        val n2 = numbers(review)
        // Nunca reemplazar por una revisión que hizo desaparecer preguntas antes identificadas.
        if (n1.isNotEmpty() && !n2.containsAll(n1)) return first
        val illegible = Regex("\\[\\s*ilegible\\s*]", RegexOption.IGNORE_CASE)
        val before = illegible.findAll(first).count()
        val after = illegible.findAll(review).count()
        if (after > before) return first
        if (after < before) return review
        if (n2.size > n1.size && review.length >= first.length / 2) return review
        return first
    }
}
