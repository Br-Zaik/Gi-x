package com.gix.cameraai

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.io.File
import java.io.RandomAccessFile
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.max

/** Use natural slow TTS at the slow settings, then pitch-synchronous tempo correction.
 * Callbacks report audible completion,
 * never file-synthesis completion, preserving the existing batch acknowledgement.
 */
internal class ControlledSpeechEngine(context: Context, onInit: TextToSpeech.OnInitListener) {
    private val cache = context.cacheDir
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val generation = AtomicLong()
    private val serial = AtomicLong()
    private val gate = Any()
    @Volatile private var speed = 1f
    @Volatile private var closed = false
    @Volatile private var listener: UtteranceProgressListener? = null
    @Volatile private var track: AudioTrack? = null
    @Volatile private var synthesis: Synthesis? = null
    private data class Synthesis(val id: String, val done: CountDownLatch = CountDownLatch(1), @Volatile var ok: Boolean = false)
    private val engine = TextToSpeech(context.applicationContext) { status ->
        // Post also avoids exposing an incompletely constructed wrapper to MainActivity.
        main.post { if (!closed) onInit.onInit(status) }
    }

    init {
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit
            override fun onDone(utteranceId: String?) {
                synthesis?.takeIf { it.id == utteranceId }?.let { it.ok = true; it.done.countDown() }
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                synthesis?.takeIf { it.id == utteranceId }?.done?.countDown()
            }
            override fun onError(utteranceId: String?, errorCode: Int) = onError(utteranceId)
        })
    }

    fun setLanguage(locale: Locale): Int = engine.setLanguage(locale)
    fun setSpeechRate(value: Float): Int {
        if (!value.isFinite() || value !in SpeechTempo.MIN_RATE..2f) return TextToSpeech.ERROR
        speed = value // Also applies to the currently playing block, without replaying text.
        return TextToSpeech.SUCCESS
    }
    fun setOnUtteranceProgressListener(value: UtteranceProgressListener): Int {
        listener = value
        return TextToSpeech.SUCCESS
    }
    fun speak(text: String, queueMode: Int, params: Bundle?, utteranceId: String): Int =
        enqueue(text, queueMode, params, utteranceId, null)

    fun announceStatus(text: String, id: String): Int =
        enqueue(text, TextToSpeech.QUEUE_ADD, null, id, null)

    private fun enqueue(text: String, queueMode: Int, params: Bundle?, id: String, fixedRate: Float?): Int {
        if (closed) return TextToSpeech.ERROR
        if (queueMode == TextToSpeech.QUEUE_FLUSH) stop()
        val token = generation.get()
        return try {
            worker.execute { if (current(token)) play(text, params, id, token, fixedRate) }
            TextToSpeech.SUCCESS
        } catch (_: java.util.concurrent.RejectedExecutionException) { TextToSpeech.ERROR }
    }

    private fun current(token: Long) = !closed && generation.get() == token && !Thread.currentThread().isInterrupted
    private fun notify(token: Long, action: (UtteranceProgressListener) -> Unit) {
        main.post { if (current(token)) listener?.let(action) }
    }

    private fun play(text: String, params: Bundle?, id: String, token: Long, fixedRate: Float?) {
        val file = File(cache, "gix_voice_${serial.incrementAndGet()}_${System.nanoTime()}.wav")
        var output: AudioTrack? = null
        try {
            val pending = Synthesis("synth_${file.name}")
            // Slow TTS supplies the articulation; Sonic applies the remaining tempo.
            // Status announcements use the same selected speed as answers.
            var sourceRate = if ((fixedRate ?: speed) <= 0.5f) 0.5f else 1f
            synchronized(gate) {
                if (!current(token)) return
                synthesis = pending
                if (engine.setSpeechRate(sourceRate) != TextToSpeech.SUCCESS) {
                    sourceRate = 1f
                    check(engine.setSpeechRate(sourceRate) == TextToSpeech.SUCCESS)
                }
                check(engine.synthesizeToFile(text, params, file, pending.id) == TextToSpeech.SUCCESS)
            }
            check(pending.done.await(60, TimeUnit.SECONDS) && pending.ok) { "No se pudo sintetizar la voz" }
            if (!current(token)) return
            val wave = readWave(file)
            val mask = if (wave.channels == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO
            val minimum = AudioTrack.getMinBufferSize(wave.sampleRate, mask, AudioFormat.ENCODING_PCM_16BIT)
            check(minimum > 0)
            val audio = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(wave.sampleRate)
                    .setChannelMask(mask).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setBufferSizeInBytes(max(minimum, wave.sampleRate * wave.channels / 5))
                .build()
            output = audio
            synchronized(gate) {
                if (!current(token)) return
                track = audio
                check(audio.state == AudioTrack.STATE_INITIALIZED)
                audio.play()
            }
            notify(token) { it.onStart(id) }
            var samplesWritten = 0L
            SpeechTempo.render(wave.samples, wave.sampleRate, wave.channels,
                { fixedRate ?: speed }, { !current(token) }, sourceRate) { block, size ->
                var offset = 0
                while (offset < size && current(token)) {
                    val written = audio.write(block, offset, size - offset, AudioTrack.WRITE_BLOCKING)
                    check(written > 0) { "No se pudo reproducir la voz" }
                    offset += written
                    samplesWritten += written
                }
            }
            // AudioTrack.write only queues sound. Wait until the device has played it.
            val framesWritten = samplesWritten / wave.channels
            var lastHead = -1L
            var lastAdvance = System.nanoTime()
            while (current(token)) {
                val head = audio.playbackHeadPosition.toLong() and 0xffffffffL
                if (head >= framesWritten) break
                if (head != lastHead) { lastHead = head; lastAdvance = System.nanoTime() }
                check(System.nanoTime() - lastAdvance < TimeUnit.SECONDS.toNanos(10)) { "Voz detenida" }
                Thread.sleep(15)
            }
            if (current(token)) notify(token) { it.onDone(id) }
        } catch (_: Exception) {
            if (current(token)) notify(token) { it.onError(id, TextToSpeech.ERROR_OUTPUT) }
        } finally {
            synchronized(gate) {
                if (track === output) track = null
                runCatching { output?.stop() }
                runCatching { output?.release() }
            }
            synthesis = null
            file.delete()
        }
    }

    fun stop(): Int {
        synchronized(gate) {
            generation.incrementAndGet()
            engine.stop()
            synthesis?.done?.countDown()
            runCatching { track?.pause(); track?.flush(); track?.stop() }
        }
        return TextToSpeech.SUCCESS
    }
    fun shutdown() {
        closed = true
        stop()
        worker.shutdownNow()
        engine.shutdown()
    }

    private data class Wave(val sampleRate: Int, val channels: Int, val samples: ShortArray)
    private fun readWave(file: File): Wave = RandomAccessFile(file, "r").use { f ->
        fun tag(): String { val b = ByteArray(4); f.readFully(b); return String(b, Charsets.US_ASCII) }
        fun intLE() = Integer.reverseBytes(f.readInt())
        fun shortLE() = java.lang.Short.reverseBytes(f.readShort()).toInt() and 0xffff
        check(tag() == "RIFF"); intLE(); check(tag() == "WAVE")
        var format = 0; var channels = 0; var rate = 0; var bits = 0
        var dataOffset = 0L; var dataSize = 0
        while (f.filePointer + 8 <= f.length()) {
            val kind = tag(); val size = intLE()
            check(size >= 0 && f.filePointer + size <= f.length())
            val end = f.filePointer + size + size % 2
            when (kind) {
                "fmt " -> { check(size >= 16); format = shortLE(); channels = shortLE(); rate = intLE(); intLE(); shortLE(); bits = shortLE() }
                "data" -> { dataOffset = f.filePointer; dataSize = size }
            }
            f.seek(end)
        }
        check(channels in 1..2 && rate in 8000..96000 && dataSize in 1..16_000_000)
        check((format == 1 && bits in listOf(8, 16)) || (format == 3 && bits == 32))
        f.seek(dataOffset)
        val samples = ShortArray(dataSize / (bits / 8)) {
            when (bits) {
                8 -> ((f.readUnsignedByte() - 128) shl 8).toShort()
                16 -> shortLE().toShort()
                else -> (Float.fromBits(intLE()).coerceIn(-1f, 1f) * 32767).toInt().toShort()
            }
        }
        Wave(rate, channels, samples)
    }
}
