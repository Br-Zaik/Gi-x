package com.gix.cameraai

import kotlin.math.*

/** Mild photographic corrections only: no OCR, thresholding or invented strokes.
 * A shared RGB gain preserves coloured ink. Bilinear illumination avoids tile seams.
 */
internal object DocumentPhotoEnhancer {
    fun enhance(pixels: IntArray, width: Int, height: Int, cancelled: () -> Boolean = { false }): IntArray {
        require(width > 0 && height > 0 && pixels.size == width * height)
        fun luma(p: Int) = (((p ushr 16) and 255) * 77 + ((p ushr 8) and 255) * 150 + (p and 255) * 29) shr 8
        val cell = 64
        val cols = (width + cell - 1) / cell
        val rows = (height + cell - 1) / cell
        val light = FloatArray(cols * rows)
        val histogram = IntArray(256)
        for (gy in 0 until rows) {
            check(!cancelled()) { "Cancelled" }
            for (gx in 0 until cols) {
                histogram.fill(0)
                var n = 0
                for (y in gy * cell until min(height, (gy + 1) * cell) step 2)
                    for (x in gx * cell until min(width, (gx + 1) * cell) step 2) {
                        histogram[luma(pixels[y * width + x])]++; n++
                    }
                var count = 0; var paper = 255
                for (v in 0..255) { count += histogram[v]; if (count >= n * 0.85f) { paper = v; break } }
                light[gy * cols + gx] = paper.coerceAtLeast(70).toFloat()
            }
        }
        val smooth = FloatArray(light.size)
        for (gy in 0 until rows) for (gx in 0 until cols) {
            var sum = 0f; var n = 0
            for (dy in -1..1) for (dx in -1..1) {
                sum += light[(gy + dy).coerceIn(0, rows - 1) * cols + (gx + dx).coerceIn(0, cols - 1)]; n++
            }
            smooth[gy * cols + gx] = sum / n
        }
        val result = IntArray(pixels.size)
        for (y in 0 until height) {
            check(!cancelled()) { "Cancelled" }
            val fy = (y.toFloat() / cell - 0.5f).coerceIn(0f, (rows - 1).toFloat())
            val y0 = fy.toInt(); val y1 = min(rows - 1, y0 + 1); val ty = fy - y0
            for (x in 0 until width) {
                val fx = (x.toFloat() / cell - 0.5f).coerceIn(0f, (cols - 1).toFloat())
                val x0 = fx.toInt(); val x1 = min(cols - 1, x0 + 1); val tx = fx - x0
                val top = smooth[y0 * cols + x0] * (1 - tx) + smooth[y0 * cols + x1] * tx
                val bottom = smooth[y1 * cols + x0] * (1 - tx) + smooth[y1 * cols + x1] * tx
                val paper = top * (1 - ty) + bottom * ty
                val gain = (235f / paper).coerceIn(1f, 1.65f)
                val i = y * width + x
                val p = pixels[i]; val lum = luma(p)
                val neighbour = (luma(pixels[y * width + max(0, x - 1)]) +
                    luma(pixels[y * width + min(width - 1, x + 1)]) +
                    luma(pixels[max(0, y - 1) * width + x]) +
                    luma(pixels[min(height - 1, y + 1) * width + x])) / 4f
                val sharp = ((lum - neighbour) * 0.25f).coerceIn(-6f, 6f)
                // Small contrast increase about the estimated paper, bounded to protect pale ink.
                val adjustment = ((lum - paper) * 0.10f).coerceIn(-10f, 0f) + sharp
                fun channel(shift: Int) = ((((p ushr shift) and 255) * gain + adjustment).roundToInt()).coerceIn(0, 255)
                result[i] = (p and -0x1000000) or (channel(16) shl 16) or (channel(8) shl 8) or channel(0)
            }
        }
        return result
    }
}
