package com.gix.cameraai

import sonic.Sonic
import java.util.Locale
import kotlin.math.abs
import kotlin.math.min

/** Speech-specific pitch-synchronous tempo. No fixed-window grain repetition.
 * Small buffers keep rate changes and cancellation responsive without storing an
 * expanded recording. Sonic's normal quality setting uses its fast pitch search.
 */
internal object SpeechTempo {
    const val MIN_RATE = 0.30f
    val rates = floatArrayOf(0.30f, 0.375f, 0.4375f, 0.50f, 0.75f, 1f, 1.25f, 1.50f, 1.75f, 2f)

    // Old values outside the available options snap to the nearest supported rate.
    fun normalizeRate(value: Float): Float = if (!value.isFinite()) 1f
        else rates.minByOrNull { abs(it - value) } ?: 1f

    fun label(value: Float): String = when (value) {
        0.375f -> "0.375x"
        0.4375f -> "0.4375x"
        else -> String.format(Locale.US, "%.2fx", value)
    }

    fun render(
        input: ShortArray, sampleRate: Int, channels: Int,
        rate: () -> Float, cancelled: () -> Boolean, sourceRate: Float = 1f,
        emit: (ShortArray, Int) -> Unit,
    ) {
        require(sampleRate in 8000..96000 && channels in 1..2)
        require(sourceRate == 0.5f || sourceRate == 1f)
        require(input.size % channels == 0)
        if (input.isEmpty() || cancelled()) return
        val frames = input.size / channels
        val blockFrames = (sampleRate / 50).coerceAtLeast(1)
        val incoming = ShortArray(blockFrames * channels)
        val outgoing = ShortArray(blockFrames * channels)
        val sonic = Sonic(sampleRate, channels).apply {
            setPitch(1f)
            setRate(1f)
            setVolume(1f)
            setQuality(0) // Downsampled search + full-rate refinement; suits Moto e30.
        }
        fun drain() {
            while (!cancelled()) {
                val n = sonic.readShortFromStream(outgoing, blockFrames)
                if (n == 0) return
                emit(outgoing, n * channels)
            }
        }
        var position = 0
        while (position < frames && !cancelled()) {
            val target = rate().takeIf { it.isFinite() }?.coerceIn(MIN_RATE, 2f) ?: 1f
            sonic.setSpeed(target / sourceRate)
            val count = min(blockFrames, frames - position)
            input.copyInto(incoming, 0, position * channels, (position + count) * channels)
            sonic.writeShortToStream(incoming, count)
            position += count
            drain()
        }
        if (!cancelled()) {
            sonic.flushStream() // Preserve final consonants and the last partial block.
            drain()
        }
    }
}
