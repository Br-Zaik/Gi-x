package com.gix.cameraai

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import java.io.ByteArrayOutputStream
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Prepara imágenes para la API visual sin reconocimiento local.
 *
 * GI X v1.6.46 limita el PESO TOTAL RAW de las imágenes antes de Base64 para que
 * el JSON final se mantenga con margen por debajo del límite del proveedor.
 */
object VisionImageOptimizer {
    private const val MAX_SIDE = 2200
    private const val MIN_SIDE = 1100
    private const val JPEG_QUALITY = 88
    private const val MIN_JPEG_QUALITY = 58

    // 3.05 MB raw -> ~4.07 MB tras Base64, dejando margen para prompt + JSON.
    private const val MAX_BATCH_RAW_BYTES = 3_050_000

    fun maxBytesPerImage(batchSize: Int): Int {
        val safeCount = batchSize.coerceIn(1, 4)
        return (MAX_BATCH_RAW_BYTES / safeCount).coerceAtLeast(650_000)
    }

    fun optimizeCameraJpeg(jpeg: ByteArray, maxBytes: Int = MAX_BATCH_RAW_BYTES): VisionImagePayload? {
        if (jpeg.isEmpty()) return null
        val target = maxBytes.coerceIn(300_000, MAX_BATCH_RAW_BYTES)
        val bitmap = CameraJpegDecoder.decodeForVision(jpeg) ?: return null
        return try {
            encodeEnhanced(bitmap, target)
        } finally {
            if (!bitmap.isRecycled) bitmap.recycle()
        }
    }

    fun optimizeUri(context: Context, uri: Uri, maxBytes: Int = MAX_BATCH_RAW_BYTES): VisionImagePayload? {
        val bitmap = ImageLoader.load(context, uri) ?: return null
        return try {
            encodeEnhanced(bitmap, maxBytes.coerceIn(300_000, MAX_BATCH_RAW_BYTES))
        } finally {
            if (!bitmap.isRecycled) bitmap.recycle()
        }
    }

    private fun encodeEnhanced(source: Bitmap, maxBytes: Int): VisionImagePayload? {
        val pixels = IntArray(source.width * source.height)
        source.getPixels(pixels, 0, source.width, 0, 0, source.width, source.height)
        val corrected = DocumentPhotoEnhancer.enhance(pixels, source.width, source.height)
        val enhanced = Bitmap.createBitmap(corrected, source.width, source.height, Bitmap.Config.ARGB_8888)
        return try { encode(enhanced, maxBytes) } finally { enhanced.recycle() }
    }

    /** Two overlapping views per page for the normal 1–2 photo batch.
     * For 3–4 manual pages retain full coverage within the existing four-image limit.
     * Input has already been corrected: never enhance or sharpen it a second time.
     */
    fun reviewViews(images: List<VisionImagePayload>, cancelled: () -> Boolean): List<VisionImagePayload> {
        if (images.size !in 1..2) return images
        val result = mutableListOf<VisionImagePayload>()
        val budget = maxBytesPerImage(images.size * 2)
        for (image in images) {
            if (cancelled()) return emptyList()
            val bitmap = CameraJpegDecoder.decodeForVision(image.bytes) ?: return images
            try {
                val bandHeight = (bitmap.height * 0.60f).roundToInt().coerceAtLeast(1)
                for (top in listOf(0, bitmap.height - bandHeight)) {
                    if (cancelled()) return emptyList()
                    val crop = Bitmap.createBitmap(bitmap, 0, top, bitmap.width, bandHeight)
                    try { result += encode(crop, budget) ?: return images }
                    finally { if (crop !== bitmap) crop.recycle() }
                }
            } finally { bitmap.recycle() }
        }
        return result
    }

    private fun encode(source: Bitmap, maxBytes: Int): VisionImagePayload? {
        var working = scaleToLongSideIfNeeded(source, MAX_SIDE)
        var ownsWorking = working !== source

        try {
            while (true) {
                var quality = JPEG_QUALITY
                var bytes = compressJpeg(working, quality)
                while (bytes.size > maxBytes && quality > MIN_JPEG_QUALITY) {
                    quality = (quality - 6).coerceAtLeast(MIN_JPEG_QUALITY)
                    bytes = compressJpeg(working, quality)
                }

                if (bytes.isNotEmpty() && bytes.size <= maxBytes) {
                    return VisionImagePayload(bytes, "image/jpeg")
                }

                val currentLongSide = max(working.width, working.height)
                if (currentLongSide <= MIN_SIDE) return null

                val nextLongSide = (currentLongSide * 0.86f).roundToInt().coerceAtLeast(MIN_SIDE)
                val next = scaleToLongSideIfNeeded(working, nextLongSide)
                if (next === working) return null
                if (ownsWorking && !working.isRecycled) working.recycle()
                working = next
                ownsWorking = true
            }
        } finally {
            if (ownsWorking && working !== source && !working.isRecycled) working.recycle()
        }
    }

    private fun scaleToLongSideIfNeeded(source: Bitmap, maxLongSide: Int): Bitmap {
        val longSide = max(source.width, source.height)
        if (longSide <= maxLongSide) return source
        val factor = maxLongSide.toFloat() / longSide.toFloat()
        val width = (source.width * factor).roundToInt().coerceAtLeast(1)
        val height = (source.height * factor).roundToInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(source, width, height, true)
    }

    private fun compressJpeg(bitmap: Bitmap, quality: Int): ByteArray {
        val out = ByteArrayOutputStream()
        if (!bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)) return ByteArray(0)
        return out.toByteArray()
    }
}
