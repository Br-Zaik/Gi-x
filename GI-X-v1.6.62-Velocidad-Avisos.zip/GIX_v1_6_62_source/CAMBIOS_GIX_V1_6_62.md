# GI X 1.6.62 — 0.30x y avisos de voz

Cambios solicitados sobre 1.6.61:

- Añadida 0.30x, punto medio entre 0.25 y 0.35. Se conservan todas las velocidades de 1.6.61.
- «Procesando» usa la velocidad seleccionada, incluido 0.30x, y sigue los cambios de velocidad durante su reproducción.
- Al terminar una lectura visual con contexto o preguntas detectadas, dice únicamente «Contexto detectado», a la velocidad seleccionada. No lee en voz alta el texto del contexto.
- Ambos avisos funcionan en cámara y manual, una vez por lote en condiciones normales.
- Los avisos pendientes se conservan si el motor de voz tarda en iniciar. Una respuesta rápida se encola después de los avisos para no cortarlos.
- Un lote nuevo o el cierre cancela los avisos anteriores. Si el motor se reinicia, solo se reintentan los avisos aún no terminados.

Se conserva Sonic y la síntesis lenta de 1.6.61. Sin cambios de cámara, procesamiento de fotos, modelos/API, notificación, firmware ni workflows.

Validación:

- Pruebas de cola de avisos: mensajes exactos, orden, inicio tardío, deduplicación, reinicio y cancelación.
- Pruebas de velocidades, incluida 0.30x, combinación con síntesis lenta, tono, estéreo, cambio en reproducción y preferencias.
- Compilación Android debug con Gradle 8.6, JDK 17 y SDK 34.

La verificación auditiva con el motor TTS instalado en el Moto e30 sigue requiriendo una prueba física.
