# Sonic

The voice tempo processor includes Sonic.java by Bill Cox, Copyright 2010, 2011,
under the Apache License 2.0.

Source: https://github.com/waywardgeek/sonic
Revision: b93885dcb70aae50c6f76b0fe4e0868f029a077e
File: https://github.com/waywardgeek/sonic/blob/b93885dcb70aae50c6f76b0fe4e0868f029a077e/Sonic.java

The Java source is included without modifications at app/src/main/java/sonic/Sonic.java.
The complete license is included in app/src/main/assets/third_party/sonic-LICENSE.txt
and packaged with the APK. The GI X integration is in SpeechTempo.kt.

No native binaries or additional Gradle dependencies are required.
