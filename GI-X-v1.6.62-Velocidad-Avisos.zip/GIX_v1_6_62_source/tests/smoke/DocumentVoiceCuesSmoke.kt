package com.gix.cameraai

fun main() {
    val cues = DocumentVoiceCues()
    cues.begin(1L)
    cues.request(1L, DocumentVoiceCues.Kind.PROCESSING)
    cues.request(1L, DocumentVoiceCues.Kind.CONTEXT)
    val waitingForEngine = cues.pending(1L)
    check(waitingForEngine.map { it.text } == listOf("Procesando", "Contexto detectado"))
    waitingForEngine.forEach { cues.markQueued(it.id) }
    check(cues.hasQueuedUnfinished(1L)) // A fast answer must QUEUE_ADD, not flush cues.
    check(cues.pending(1L).isEmpty())
    cues.request(1L, DocumentVoiceCues.Kind.CONTEXT)
    check(cues.pending(1L).isEmpty()) // A second visual pass must not repeat the cue.
    cues.finish(waitingForEngine[0].id)
    check(cues.hasQueuedUnfinished(1L))
    cues.retryUnfinished()
    check(cues.pending(1L).map { it.text } == listOf("Contexto detectado"))
    cues.markQueued(waitingForEngine[1].id)
    cues.finish(waitingForEngine[1].id)
    check(!cues.hasQueuedUnfinished(1L))
    cues.retryUnfinished()
    check(cues.pending(1L).isEmpty())
    cues.begin(2L)
    cues.request(1L, DocumentVoiceCues.Kind.CONTEXT) // Late previous-document callback.
    cues.finish(waitingForEngine[1].id)
    check(cues.pending(2L).isEmpty())
    cues.request(2L, DocumentVoiceCues.Kind.PROCESSING)
    check(cues.pending(2L).single().text == "Procesando")
    check(cues.pending(1L).isEmpty())
    cues.begin(0L) // Close/stop clears pending announcements.
    check(cues.pending(2L).isEmpty())
    check(cues.pending(0L).isEmpty())
    println("OK: exact short messages, ordering, delayed init, no repeats, restart and cancellation")
}
