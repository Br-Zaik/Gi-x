# GI X 1.6.37 — Lotes flexibles de 1 a 4 fotografías

- Las cuatro fotografías son el **máximo**, no un mínimo obligatorio. El lote de 1, 2 o 3 fotos sigue automáticamente a visión IA / OCR local / respuestas API / voz cuando dejan de llegar más capturas.
- Con cuatro JPEG recibidos, procesa de inmediato, sin esperar temporizador.
- Con `requestId`, espera hasta 6 s de inactividad después de la última foto; sin `requestId` espera hasta 4 s (antes: 1,2 s, que podía dividir una ráfaga en varios documentos).
- Tiene un límite total de 25 s por lote para evitar prolongar la espera si siguen llegando imágenes con demora.
- Si cambia el identificador entre lotes, entrega el lote anterior, aunque contenga menos de cuatro imágenes.
- El texto de estado deja claro que no es obligatorio recibir cuatro imágenes.
- No se cambia la voz, la selección de velocidad, las claves API, el código del firmware, el bloqueo, la visualización del documento ni las reglas de respuestas.

**Limitaciones:** si un firmware NO envía `requestId`, una pausa superior a cuatro segundos puede separar fotos del mismo documento. Tampoco hay manera de garantizar al 100 % el mismo documento sin un identificador por lote. No se han probado llamadas reales de API ni una APK física; completar con GitHub Actions + TimerCamera-X.

Prueba aislada de reglas:
```
kotlinc app/src/main/java/com/gix/cameraai/CameraBatchPolicy.kt tests/smoke/CameraBatchPolicySmoke.kt -include-runtime -d /tmp/gix_camera_batch_smoke.jar
java -jar /tmp/gix_camera_batch_smoke.jar
```
