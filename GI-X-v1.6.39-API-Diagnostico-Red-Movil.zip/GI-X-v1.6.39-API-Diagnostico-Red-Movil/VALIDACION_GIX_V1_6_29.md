# GI X v1.6.29 — Pantalla protegida informativa y letra manuscrita

- Base: fuente v1.6.28. versionCode 54, versionName 1.6.29.
- Bloqueo: panel de solo lectura con estado de cámara, contador de fotos recibidas durante la sesión, hora de última foto, foto previa, preguntas y respuestas en curso, estado de voz. Se actualiza desde el ticker existente sin solicitudes API nuevas.
- Desbloqueo: sin cambios: tres toques rápidos y confirmación; fijación de pantalla Android conservada.
- Visión: instrucción adicional para escritura a mano sin adivinar texto ilegible. Mismos modelos, endpoint, 1–4 fotos y OCR de respaldo.
- No se modificaron firmware, servicio de recepción, TTS, lote, firma ni otras pantallas.
- Validación: ZIP y estructura; pendiente compilación Android en Actions y prueba física de UI.
