# GI X 1.6.36 — revisión de API, respuestas y voz

Base: ZIP 1.6.35 (código fuente Android). Identificador intacto: `com.gix.cameraai`. versionCode 61 / versionName 1.6.36. No se modificó el firmware de la TimerCamera-X, la clave guardada, el icono ni el bloqueo de tres toques.

## Problemas detectados y corregidos

1. **Alternativas rechazadas aunque la API sí respondía.** Una respuesta correcta de tipo `B) La superficie terrestre` se interpretaba como paréntesis sin abrir. Se distingue un marcador de alternativa/lista de un paréntesis real en las validaciones para respuestas individuales y generales.
2. **Comprobación previa de Internet demasiado estricta.** `NET_CAPABILITY_VALIDATED` puede tardar o no describir correctamente una sesión de Zona Wi-Fi + datos móviles. El envío de visión, las respuestas, los reintentos y la prueba de API usan ahora la solicitud HTTPS real como comprobación; siguen mostrando los errores del servidor, red, saldo o clave si existen.
3. **Respuesta única con lectura descartada por formato.** Una respuesta válida de una sola pregunta con contexto podía rechazarse si el modelo no anteponía `1.`. Se permite el caso inequívoco de una pregunta, sin rebajar la validación de lotes de varias preguntas.
4. **Explicación breve rechazada sin motivo suficiente.** El límite de palabras para algunas respuestas explicativas era muy rígido; se redujo el umbral, conservando controles contra respuestas vacías y recortadas.
5. **Lotes bloqueados por numeración OCR dudosa.** En vez de cancelar todas las respuestas, se consultan de una en una y se asignan por índices internos únicos. Se conservan los números impresos y se indica la incertidumbre. La corrección de casillas `1. ____ / 2. ____` de la versión 1.6.35 permanece.
6. **La voz podía acabar antes de que acabara la API.** La reproducción de un fragmento no marca el ciclo como concluido hasta terminar también el procesamiento de la respuesta; los JPEG se confirman solo con resultado final satisfactorio y reproducción finalizada.
7. **Audio progresivo repetido o cortado.** Se recuerda el texto pronunciado de cada respuesta, se encola solo la continuación y se verbaliza una corrección si la versión final cambia la respuesta. No se relee todo el parcial por el simple hecho de que otras preguntas hayan fallado.
8. **Fallos de TTS.** Un fallo definitivo no confirma fotos como si ya se hubieran escuchado; el texto y los JPEG pendientes siguen conservados. Hasta dos reinicializaciones del motor de voz.

## Audio y modo automático

El ritmo escogido en VOZ sigue guardado en `AppPrefs.speechRate` (0.25x–2x) y se aplica al inicializar TTS y al encolar fragmentos; se intenta `es-PE` y si el motor no tiene datos, `es-ES`. El sistema emplea TTS de Android (audio reproducido), no genera un fichero de voz grabada. GI X sigue necesitando MainActivity abierta para procesar OCR, API y voz; el servicio puede conservar fotografías cuando no está abierta.

## Comprobación efectuada aquí

- Compilación JVM del extractor real de preguntas con implementaciones de prueba para sus dependencias Android.
- Hoja sintética de 10 preguntas, 4 alternativas, V/F, completar y subcasillas `1. ___` / `2. ___` debajo de la 8: números extraídos 1–10, sin dividir las subcasillas.
- Prueba JVM de expresiones regulares: una alternativa `B) ...` y una lista `1) ...` ya no se consideran paréntesis sin abrir; un paréntesis realmente abierto sí se detecta.
- Prueba JVM del algoritmo de voz progresiva: no repite textos iguales, pronuncia la parte nueva y anuncia las correcciones finales.
- Revisión estática de las rutas de API, streaming, voz, aplicación de la velocidad y diario de fotografías.

**Pendiente de validar fuera de este entorno:** compilar `:app:assembleDebug` con SDK Android/Gradle y modelos PP-OCR; probar el teléfono y la TimerCamera-X física; realizar una consulta al proveedor con clave válida y créditos, y probar el motor de voz instalado a cada velocidad. No hay una garantía de ausencia absoluta de fallos de redes o servicios externos.
