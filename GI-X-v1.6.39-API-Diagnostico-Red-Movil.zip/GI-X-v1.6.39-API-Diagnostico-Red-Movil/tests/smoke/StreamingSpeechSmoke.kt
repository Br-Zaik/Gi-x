fun main() {
    val spokenAnswers = linkedMapOf<String, String>()
    fun pick(visible: List<String>, final: Boolean): List<String> = visible.mapIndexedNotNull { index, item ->
        val normalized = item.replace(Regex("""\s+"""), " ").trim()
        if (normalized.isBlank()) return@mapIndexedNotNull null
        val printed = Regex("""^\d+[.)\-:]\s*""").find(normalized)?.value.orEmpty()
        val key = "$index:$printed"
        val spoken = spokenAnswers[key]
        val next = when {
            spoken == null -> normalized
            spoken == normalized -> ""
            normalized.startsWith(spoken) -> normalized.drop(spoken.length).trim()
            final -> "Corrección: $normalized"
            else -> ""
        }
        if (next.isNotBlank()) spokenAnswers[key] = normalized
        next.takeIf { part -> part.any { it.isLetterOrDigit() } }
    }
    require(pick(listOf("1. La topografía mide."),false)==listOf("1. La topografía mide."))
    require(pick(listOf("1. La topografía mide."),false).isEmpty())
    require(pick(listOf("1. La topografía mide. Representa el terreno."),false)==listOf("Representa el terreno."))
    require(pick(listOf("1. La topografía mide. Representa el terreno."),true).isEmpty())
    require(pick(listOf("1. La topografía representa la superficie."),true)==listOf("Corrección: 1. La topografía representa la superficie."))
    println("OK TTS: sin repetición de fragmentos, solo texto añadido y corrección final")
}
