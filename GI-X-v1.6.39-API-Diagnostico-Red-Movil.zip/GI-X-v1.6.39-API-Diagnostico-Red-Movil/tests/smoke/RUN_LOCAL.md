# Pruebas Kotlin puras (opcionales)

Estas pruebas se ejecutaron sobre el extractor real de preguntas con una implementación de prueba aislada de OcrTableFormatter (para evitar SDK Android), y sobre dos casos reproducibles de validación de respuestas y voz. No sustituyen una compilación Android ni prueban el servicio externo.

Desde la raíz del proyecto, con JDK 17 y `kotlinc` disponibles:

```bash
SRC=app/src/main/java/com/gix/cameraai
kotlinc tests/smoke/OcrTableFormatterStub.kt "$SRC"/{OcrQuestionExtractor,QuestionBoundarySplitter,QuestionTextNormalizer,VoiceQuestionNormalizer,ResponseRepository,ExamStructureDetector}.kt tests/smoke/Smoke.kt -include-runtime -d /tmp/gix_ocr_smoke.jar
java -jar /tmp/gix_ocr_smoke.jar
kotlinc tests/smoke/ProviderFormatSmoke.kt -include-runtime -d /tmp/gix_provider_smoke.jar
java -jar /tmp/gix_provider_smoke.jar
kotlinc tests/smoke/StreamingSpeechSmoke.kt -include-runtime -d /tmp/gix_speech_smoke.jar
java -jar /tmp/gix_speech_smoke.jar
```

Para la APK completa, ejecuta el workflow de GitHub Actions y prueba con TimerCamera-X y una clave API válida.
