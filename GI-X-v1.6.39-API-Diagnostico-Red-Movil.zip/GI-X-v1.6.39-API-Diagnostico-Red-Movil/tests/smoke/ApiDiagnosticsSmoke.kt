package com.gix.cameraai
fun main() {
    val p = OnlineAnswerProvider()
    val sanitize = OnlineAnswerProvider::class.java.getDeclaredMethod("safeProviderMessage", String::class.java).apply { isAccessible = true }
    val raw = "invalid: ci_live_TEST_NOT_A_REAL_KEY_12345 and ir_live_TEST_NOT_REAL_999\n HTTP 503"
    val filtered = sanitize.invoke(p, raw) as String
    check(!filtered.contains("TEST_NOT_A_REAL"))
    check(filtered.contains("[clave oculta]"))
    val method = OnlineAnswerProvider::class.java.getDeclaredMethod(
        "parseProviderError", String::class.java, Int::class.javaPrimitiveType,
        NetProvider::class.java, String::class.java, String::class.java
    ).apply { isAccessible = true }
    val transient = method.invoke(p, "upstream temporarily unavailable", 503, NetProvider.CHEAPER_INFERENCE, "deepseek-v4-flash", "req_ABC123")
    val fields = transient.javaClass.declaredFields.associate { f -> f.isAccessible = true; f.name to f.get(transient)?.toString().orEmpty() }
    check("HTTP 503" in fields.getValue("error"))
    check("req_ABC123" in fields.getValue("error"))
    check("upstream temporarily unavailable" in fields.getValue("error"))
    check(fields.getValue("failureType") == "TEMPORARY")
    val invalid = method.invoke(p, "permission denied", 403, NetProvider.CHEAPER_INFERENCE, "deepseek-v4-flash", null)
    val errField = invalid.javaClass.getDeclaredField("error").apply { isAccessible = true }
    check("HTTP 403" in (errField.get(invalid) as String))
    println("OK: HTTP 503 + request ID + error original; clave oculta; HTTP 403 diferente")
}
