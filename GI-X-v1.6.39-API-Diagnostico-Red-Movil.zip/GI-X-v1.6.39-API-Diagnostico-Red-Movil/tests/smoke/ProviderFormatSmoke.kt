fun main() {
    fun unbalanced(text: String): Boolean {
        var depth = 0
        for (c in text) {
            if (c == '(') depth++
            if (c == ')') { depth--; if (depth < 0) return true }
        }
        return depth != 0
    }
    fun listSafe(text: String): Boolean {
        val withoutMarkers = text
            .replace(Regex("""(?im)(^|[\n\r])\s*((?:pregunta\s*)?\d{1,2})\)\s+"""), "$1$2. ")
            .replace(Regex("""(?im)(^|[\n\r\t :;,-])([A-H])\)\s+"""), "$1$2. ")
        return unbalanced(withoutMarkers)
    }
    require(unbalanced("B) La superficie terrestre"))
    require(!listSafe("B) La superficie terrestre"))
    require(!listSafe("1) Verdadero\n2) Falso"))
    require(listSafe("Una oración (sin cerrar"))
    println("OK: A-H) y 1) ya no se confunden con paréntesis incompletos")
}
