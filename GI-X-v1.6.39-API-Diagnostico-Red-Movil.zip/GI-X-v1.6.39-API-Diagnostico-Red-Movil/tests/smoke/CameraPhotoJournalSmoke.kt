import android.content.Context
import com.gix.cameraai.CameraPhotoJournal
import java.io.File

fun main() {
    val dir = createTempDir(prefix = "gix_journal_")
    try {
        val journal = CameraPhotoJournal(object : Context() { override val filesDir: File = dir })
        val photo1 = byteArrayOf(1,2,3,4)
        val photo2 = byteArrayOf(1,2,3,5)
        val id1 = journal.save(photo1, " lote-1 ")
        val id2 = journal.save(photo2, "lote-1")
        check(id1 != id2)
        check(journal.pendingIds().size == 2)
        check(journal.read(id1)?.requestId == "lote-1")
        check(journal.read(id2)?.requestId == "lote-1")
        check(journal.save(photo1, "lote-X") == id1)
        check(journal.read(id1)?.requestId == "lote-1")
        File(dir, "pending_camera_jpegs/$id1.req").delete()
        journal.save(photo1, "lote-1")
        check(journal.read(id1)?.requestId == "lote-1")
        journal.acknowledge(listOf(id1, id2))
        check(journal.pendingIds().isEmpty())
        println("OK diario: JPEG, ID antes de ack HTTP, retransmisiones, reparación metadata, limpieza")
    } finally { dir.deleteRecursively() }
}
