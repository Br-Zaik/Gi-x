package com.gix.cameraai
object OcrTableFormatter {
  const val EMPTY_CELL = "[VACÍO]"
  const val TABLE_START = "[GIX_TABLE_START]"
  const val TABLE_END = "[GIX_TABLE_END]"
  const val STRUCTURED_TABLES_HEADER = "[GIX_STRUCTURED_TABLES]"
  fun parseStructuredTables(raw: String): List<String> = emptyList()
  fun removeStructuredTables(raw: String): String = raw
  fun toDisplayText(raw: String): String = raw
}
