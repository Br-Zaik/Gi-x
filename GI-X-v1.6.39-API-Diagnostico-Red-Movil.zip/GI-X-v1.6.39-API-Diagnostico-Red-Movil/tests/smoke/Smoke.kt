import com.gix.cameraai.*
fun main() {
  val sample = """
    LECTURA Y CUESTIONARIO – TOPOGRAFÍA
    Lectura
    La topografía mide y representa gráficamente la superficie terrestre. El GPS ubica coordenadas.
    Cuestionario
    1. ¿Qué es la topografía?
    A) Astronomía
    B) Ciencia de la superficie terrestre
    C) Minería
    D) Clima
    2. ¿Para qué sirve el GPS?
    3. Verdadero o falso: El nivel mide alturas.
    4. Complete: El GPS obtiene ________.
    5. ¿Qué es la brújula?
    6. ¿Qué instrumentos conoces?
    7. ¿Cómo se mide?
    8. Mencione dos áreas en las que se utiliza la topografía.
    1. ______________________    2. ______________________
    9. ¿Por qué es importante la información topográfica?
    10. ¿Qué diferencia hay entre el GPS y la brújula?
  """.trimIndent()
  val qs = OcrQuestionExtractor.extractQuestions(sample)
  val nums = qs.mapNotNull(OcrQuestionExtractor::questionNumber)
  println("OCR ids: $nums")
  require(nums == (1..10).toList()) { "OCR missed or re-numbered question ($nums)" }
  require(qs[7].contains("1. ___") && qs[7].contains("2. ___")) { "Subanswer lines lost: ${qs[7]}" }
  println("OCR context: " + OcrQuestionExtractor.extractDocumentContext(sample).take(120))
  val corrupted = listOf("1. Pregunta A", "2. Pregunta B", "1. Pregunta C", "4. Pregunta D")
  require(OcrQuestionExtractor.hasCorruptNumbering(corrupted))
  require(OcrQuestionExtractor.hasCorruptNumbering(listOf("1. Primero", "1. Segundo")))
  println("OK smoke: 10 preguntas, casillas internas, alternativas, contexto, duplicados detectados")
}
