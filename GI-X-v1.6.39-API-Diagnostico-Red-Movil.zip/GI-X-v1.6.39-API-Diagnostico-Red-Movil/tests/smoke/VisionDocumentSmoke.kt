import com.gix.cameraai.OcrQuestionExtractor

fun main() {
    val numbered = """
    CONTEXTO DETECTADO
    La topografía mide la superficie terrestre. El nivel determina alturas y el GPS ubica coordenadas.

    PREGUNTAS DETECTADAS
    1. ¿Qué es la topografía?
    A) Astronomía
    B) Ciencia que estudia la superficie terrestre
    C) Química
    D) Clima
    2. Verdadero o falso: El nivel sirve para determinar alturas.
    3. Complete: El GPS ubica __________.
    4. Mencione dos áreas.
    1. __________  2. __________
    """.trimIndent()
    val questions = OcrQuestionExtractor.extractQuestions(numbered)
    check(questions.size == 4) { "Las casillas se separaron de su pregunta: $questions" }
    check(questions[0].contains("A) Astronomía") && questions[0].contains("D) Clima"))
    check(questions.last().contains("1. ___") && questions.last().contains("2. ___"))
    val context = OcrQuestionExtractor.extractDocumentContext(numbered)
    check("topografía" in context && "nivel" in context && "GPS" in context)

    val unnumbered = """
    CONTEXTO DETECTADO
    El azimut se mide desde el norte en sentido horario. El nivel sirve para determinar diferencias de altura.

    PREGUNTAS DETECTADAS
    ¿Qué es el azimut?
    A) Ángulo horizontal desde el norte
    B) Altura absoluta
    C) Temperatura
    ¿Para qué sirve el nivel?
    Verdadero o falso: El azimut se mide en sentido horario.
    Complete: El azimut se mide desde el __________.
    """.trimIndent()
    val raw = OcrQuestionExtractor.extractQuestions(unnumbered)
    check(raw.size == 4) { "Preguntas sin numerar no conservadas: $raw" }
    check(raw.all { OcrQuestionExtractor.questionNumber(it) == null })
    check(raw[0].contains("C) Temperatura"))
    println("OK visión: contexto + alternativas + 4 numeradas con casillas + 4 sin numeración")
}
