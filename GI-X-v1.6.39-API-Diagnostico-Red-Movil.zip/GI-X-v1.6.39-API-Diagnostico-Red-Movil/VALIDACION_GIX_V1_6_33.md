# GI X v1.6.33 — Documento y preguntas visibles antes de responder

- `applicationId`/package `com.gix.cameraai` sin cambios. Versión `1.6.33`, `versionCode 58`.
- «Preguntas detectadas» muestra dos secciones cuando corresponde: CONTEXTO DETECTADO (lectura, cuadro, instrucciones) y PREGUNTAS DETECTADAS (numeración original, alternativas, V/F, completar y datos).
- Tanto el OCR local como la transcripción por visión alimentan el mismo constructor de contenido. El contexto se añade con `[GIX_DOCUMENT_CONTEXT]` a CADA bloque de preguntas enviado a la API de respuestas, incluyendo reintentos de recuperación individuales. La vista previa se construye usando el mismo contexto y preguntas de esos bloques; solo varían las cabeceras/protocolo interno e identificación técnica.
- En 1–4 capturas locales, el fusionador ahora conserva el texto de referencia leído en cualquiera de las capturas y deduplica líneas de fotos solapadas. Las tablas sin ejercicio no cuentan como preguntas adicionales; si contienen `[VACÍO]` y no hay enunciado, se tratan como ejercicios por completar.
- Preserva alternativas por estructura A) B) C), incluso si el enunciado es una pregunta simple («¿Qué...?»). Si aparece una opción sin texto legible, se indica `[ilegible]`.
- Corrección puntual en combinación ML Kit/Paddle: no descartar una lectura mucho más completa de Paddle solo porque ML Kit haya reconocido 20 caracteres.
- Opción marcada inicialmente: «Revisar antes de API: OCR local». Sin bloqueo, usa OCR local sin gastar API; prepara una revisión con «CORREGIR», «DESCARTAR» y «RESPONDER CON IA». La revisión y la corrección no consultan la API. Desmarcarla devuelve la ruta original de visión IA automática cuando hay clave.
- Cuando GI X está bloqueado, continúa el flujo automático sin interrumpir las fotos: el texto detectado es visible y desplazable, pero todos los controles permanecen deshabilitados salvo desbloquear en el mismo botón con 3 toques y confirmación. No se permite bloquear mientras se espera una revisión pendiente: primero aprobar o descartar.
- Se mantuvieron cámara, cola de fotos, streaming de respuestas, voz, historial, conexión Wi-Fi y scripts de GitHub Actions sin cambios funcionales.

## Verificación realizada

1. `kotlinc` compila las clases puras `OcrQuestionExtractor`, `MultiImageDocumentMerger`, `QuestionTextNormalizer`, `QuestionBoundarySplitter` y `ExamStructureDetector` con un stub compatible de la capa Android de tablas.
2. Pruebas ejecutadas: lectura + preguntas A/B/C, texto + V/F, lectura + cuadro, contexto recuperado de imagen distinta, tabla de referencia sin pregunta fantasma, datos presentes en payload.
3. El XML de interfaz fue analizado y sus IDs comprobados sin duplicados.

**Pendiente de validar en Android:** la compilación completa APK y las pruebas con fotos reales, API y voz deben realizarse con el flujo de GitHub Actions `Build GI X APK`; este entorno no cuenta con Android SDK/Gradle ni cámara física para probarlos. La ruta de visión IA puede consumir créditos para *leer* imágenes cuando el modo de revisión está desactivado o la app está bloqueada; el modo de revisión sin bloqueo usa OCR local primero.
