#include "M5TimerCAM.h"
#include <WiFi.h>
#include <HTTPClient.h>
#include <esp_system.h>

// GI X v1.6.15 - M5Stack TimerCamera-X U082-X
// Captura real 1600x1200 (UXGA) + exposicion corregida en el sensor.
// Flujo: PWR -> Zona Wi-Fi -> 4 fotos UXGA -> confirmar CADA JPEG -> apagado.

// ========= CONFIGURACIÓN RÁPIDA =========
const char* WIFI_NAME = "TU_ZONA_WIFI";
const char* WIFI_PASSWORD = "TU_CLAVE_WIFI";
const char* GIX_TOKEN = "GIX2026CAM";   // Déjalo así salvo que quieras usar otra clave en la app
// En la mayoría de casos, deja fija la clave GIX2026CAM y cambia solo Wi-Fi.
// ==============================================

const uint16_t GIX_PORT = 8765;
const uint32_t WIFI_TIMEOUT_MS = 30000;
const uint32_t DELIVERY_WINDOW_MS = 45000;
const uint32_t HTTP_TIMEOUT_MS = 12000;
const uint32_t RETRY_DELAY_MS = 1200;
// v1.6.27: si prefieres una foto por encendido, cambia 4 por 1 y vuelve a flashear.
const uint8_t GIX_PHOTOS_PER_POWER_ON = 4;
const uint32_t BETWEEN_PHOTOS_MS = 450;

// ===== Captura / exposición (v1.6.15) =====
// FRAMESIZE_UXGA = 1600x1200 REALES (1.92 MP). No se reescala nada en el firmware
// ni en la app: lo que sale del sensor es lo que recibe GI X.
const uint32_t WARMUP_MS = 1500;        // estabilización de AE/AGC/AWB antes de la foto útil
const uint32_t RETRY_WARMUP_MS = 700;   // estabilización extra si hubo que subir exposición
const size_t MIN_USEFUL_JPEG_BYTES = 45000;  // por debajo de esto, a 1600x1200, la hoja salió casi negra
const int AE_LEVEL_START = 1;           // +1 sobre el objetivo automático: el papel blanco engaña al AE
const int AE_LEVEL_MAX = 2;
const int BRIGHTNESS_START = 1;
const int BRIGHTNESS_MAX = 2;

int aeLevelApplied = AE_LEVEL_START;
int brightnessApplied = BRIGHTNESS_START;

String phoneBaseUrl() {
  // En una Zona Wi-Fi del celular, el gateway de la cámara es el propio celular.
  IPAddress gateway = WiFi.gatewayIP();
  return String("http://") + gateway.toString() + ":" + String(GIX_PORT);
}

bool connectWifi() {
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(WIFI_NAME, WIFI_PASSWORD);

  Serial.print("Conectando a la Zona Wi-Fi");
  unsigned long started = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - started < WIFI_TIMEOUT_MS) {
    delay(400);
    Serial.print(".");
  }
  Serial.println();

  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("No se pudo conectar a la Zona Wi-Fi.");
    return false;
  }

  Serial.print("Conectada. IP camara: ");
  Serial.println(WiFi.localIP());
  Serial.print("Celular/gateway: ");
  Serial.println(WiFi.gatewayIP());
  return true;
}

String getPendingRequestId() {
  if (WiFi.status() != WL_CONNECTED) return "";

  HTTPClient http;
  http.setTimeout(4500);
  String url = phoneBaseUrl() + "/camera/poll?token=" + String(GIX_TOKEN);
  http.begin(url);
  int code = http.GET();
  String result = "";
  if (code == 200) {
    String body = http.getString();
    body.trim();
    if (body.startsWith("CAPTURE|")) {
      result = body.substring(8);
      result.trim();
    }
  }
  http.end();
  return result;
}

void warmUpCamera() {
  // Descarta tomas iniciales solo para estabilizar autoexposición, ganancia y
  // balance de blancos. Estas NO se envían a GI X.
  // v1.6.15: el calentamiento dura ~WARMUP_MS reales (antes ~0.7 s), porque con
  // poca luz el OV3660 necesita varios frames para subir la exposición.
  unsigned long started = millis();
  while (millis() - started < WARMUP_MS) {
    if (TimerCAM.Camera.get()) {
      TimerCAM.Camera.free();
    }
    delay(120);
  }
}

// Sube la exposición un paso y vuelve a estabilizar. Se usa solo si la primera
// captura salió claramente subexpuesta (JPEG demasiado pequeño para 1600x1200).
void raiseExposureOneStep() {
  if (aeLevelApplied < AE_LEVEL_MAX) {
    aeLevelApplied++;
    TimerCAM.Camera.sensor->set_ae_level(TimerCAM.Camera.sensor, aeLevelApplied);
  }
  if (brightnessApplied < BRIGHTNESS_MAX) {
    brightnessApplied++;
    TimerCAM.Camera.sensor->set_brightness(TimerCAM.Camera.sensor, brightnessApplied);
  }
  Serial.printf("Reintento de exposicion: ae_level=%d brightness=%d\n",
                aeLevelApplied, brightnessApplied);
  unsigned long started = millis();
  while (millis() - started < RETRY_WARMUP_MS) {
    if (TimerCAM.Camera.get()) {
      TimerCAM.Camera.free();
    }
    delay(120);
  }
}

bool captureAndDeliverOnePhoto(const String& requestId) {
  if (WiFi.status() != WL_CONNECTED) return false;

  // Una foto útil por iteración: 4 iteraciones por encendido.
  // El reintento por subexposición sustituye una captura, no crea otra entrega.
  if (!TimerCAM.Camera.get()) {
    Serial.println("No se pudo capturar la foto util");
    return false;
  }

  if (TimerCAM.Camera.fb->len < MIN_USEFUL_JPEG_BYTES &&
      (aeLevelApplied < AE_LEVEL_MAX || brightnessApplied < BRIGHTNESS_MAX)) {
    Serial.printf("Captura subexpuesta (%u bytes). Subiendo exposicion y repitiendo.\n",
                  (unsigned int)TimerCAM.Camera.fb->len);
    TimerCAM.Camera.free();
    raiseExposureOneStep();
    if (!TimerCAM.Camera.get()) {
      Serial.println("No se pudo capturar la foto util tras subir exposicion");
      return false;
    }
  }

  Serial.printf("Resolucion real entregada: %u x %u\n",
                (unsigned int)TimerCAM.Camera.fb->width,
                (unsigned int)TimerCAM.Camera.fb->height);

  String url = phoneBaseUrl() + "/camera/photo?token=" + String(GIX_TOKEN);
  if (requestId.length() > 0) {
    url += "&requestId=" + requestId;
  }

  const uint8_t* jpegData = TimerCAM.Camera.fb->buf;
  const size_t jpegSize = TimerCAM.Camera.fb->len;
  Serial.printf("Foto capturada una vez: %u bytes\n", (unsigned int)jpegSize);

  bool sent = false;
  unsigned long started = millis();
  int attempt = 0;

  // Si GI X aún está arrancando, reintentamos EL MISMO JPEG. No volvemos a tomar otra foto.
  while (!sent && millis() - started < DELIVERY_WINDOW_MS) {
    attempt++;
    if (WiFi.status() != WL_CONNECTED) {
      // Reintentar el MISMO JPEG mientras el hotspot se recupera.
      Serial.println("Wi-Fi se desconecto; reintentando enlace sin recapturar.");
      WiFi.reconnect();
      delay(RETRY_DELAY_MS);
      continue;
    }

    HTTPClient http;
    http.setTimeout(HTTP_TIMEOUT_MS);
    http.begin(url);
    http.addHeader("Content-Type", "image/jpeg");
    int code = http.POST(jpegData, jpegSize);
    String response = code > 0 ? http.getString() : "";
    http.end();

    if (code == 200) {
      sent = true;
      Serial.printf("Foto enviada a GI X en intento %d\n", attempt);
    } else {
      Serial.printf("Fallo enviando la misma foto. Intento %d, HTTP %d %s\n",
                    attempt, code, response.c_str());
      delay(RETRY_DELAY_MS);
    }
  }

  TimerCAM.Camera.free();
  return sent;
}

void powerDown() {
  Serial.println("Apagando Timer Camera X...");
  TimerCAM.Power.setLed(0);
  WiFi.disconnect(true);
  WiFi.mode(WIFI_OFF);
  delay(250);
  TimerCAM.Power.powerOff();

  // Con batería debería apagarse. Si está alimentada por USB externo,
  // puede seguir energizada físicamente; este bucle impide tomar otra foto.
  while (true) delay(1000);
}

void setup() {
  Serial.begin(115200);
  delay(250);

  TimerCAM.begin();
  TimerCAM.Power.begin();
  TimerCAM.Power.setLed(40);

  if (!TimerCAM.Camera.begin()) {
    Serial.println("ERROR: no se pudo iniciar OV3660");
    delay(2500);
    powerDown();
  }

  TimerCAM.Camera.sensor->set_pixformat(TimerCAM.Camera.sensor, PIXFORMAT_JPEG);
  // 1600x1200 REALES: prioriza detalle para OCR y aprovecha la PSRAM de la U082-X.
  TimerCAM.Camera.sensor->set_framesize(TimerCAM.Camera.sensor, FRAMESIZE_UXGA);
  TimerCAM.Camera.sensor->set_quality(TimerCAM.Camera.sensor, 8);
  TimerCAM.Camera.sensor->set_vflip(TimerCAM.Camera.sensor, 1);
  TimerCAM.Camera.sensor->set_hmirror(TimerCAM.Camera.sensor, 0);

  // ===== Exposición real del sensor (v1.6.15) =====
  // Las fotos anteriores llegaban oscuras, con sombra y contraste irregular. Se
  // corrige en el SENSOR, no con filtros digitales posteriores.
  TimerCAM.Camera.sensor->set_exposure_ctrl(TimerCAM.Camera.sensor, 1);   // autoexposición activa
  TimerCAM.Camera.sensor->set_aec2(TimerCAM.Camera.sensor, 1);            // AE del DSP: mejor con texto fino
  TimerCAM.Camera.sensor->set_ae_level(TimerCAM.Camera.sensor, aeLevelApplied);
  TimerCAM.Camera.sensor->set_gain_ctrl(TimerCAM.Camera.sensor, 1);       // ganancia automática
  TimerCAM.Camera.sensor->set_gainceiling(TimerCAM.Camera.sensor, GAINCEILING_16X);
  TimerCAM.Camera.sensor->set_whitebal(TimerCAM.Camera.sensor, 1);
  TimerCAM.Camera.sensor->set_awb_gain(TimerCAM.Camera.sensor, 1);
  TimerCAM.Camera.sensor->set_wb_mode(TimerCAM.Camera.sensor, 0);         // AWB automático
  TimerCAM.Camera.sensor->set_lenc(TimerCAM.Camera.sensor, 1);            // corrige esquinas oscuras
  TimerCAM.Camera.sensor->set_bpc(TimerCAM.Camera.sensor, 1);
  TimerCAM.Camera.sensor->set_wpc(TimerCAM.Camera.sensor, 1);
  TimerCAM.Camera.sensor->set_raw_gma(TimerCAM.Camera.sensor, 1);         // gamma: recupera grises del texto
  TimerCAM.Camera.sensor->set_brightness(TimerCAM.Camera.sensor, brightnessApplied);
  TimerCAM.Camera.sensor->set_contrast(TimerCAM.Camera.sensor, 1);
  TimerCAM.Camera.sensor->set_saturation(TimerCAM.Camera.sensor, -1);     // menos ruido de color en papel

  if (!connectWifi()) {
    delay(1500);
    powerDown();
  }

  // Una pulsación manda hasta CUATRO JPEG originales del mismo documento.
  // ID único por encendido: el celular no mezcla hojas de encendidos distintos.
  warmUpCamera();
  String requestId = getPendingRequestId();
  if (requestId.length() == 0) requestId = String((unsigned long)esp_random(), HEX);
  for (uint8_t i = 0; i < GIX_PHOTOS_PER_POWER_ON; i++) {
    Serial.printf("Foto %u de %u\n", (unsigned)(i + 1), (unsigned)GIX_PHOTOS_PER_POWER_ON);
    bool sent = captureAndDeliverOnePhoto(requestId);
    if (!sent) {
      Serial.println("Entrega no confirmada; se cancela el resto para ahorrar batería.");
      break;
    }
    if (i + 1 < GIX_PHOTOS_PER_POWER_ON) delay(BETWEEN_PHOTOS_MS);
  }
  powerDown();
}

void loop() {
  // Nunca se toman fotos desde loop(). Un encendido = hasta cuatro fotos útiles.
  delay(1000);
}
