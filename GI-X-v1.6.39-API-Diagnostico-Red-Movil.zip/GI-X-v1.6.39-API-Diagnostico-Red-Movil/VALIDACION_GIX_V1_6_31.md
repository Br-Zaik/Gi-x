# GI X v1.6.31 - Bloqueo limpio + respuesta y voz en vivo

- Version subida a `versionCode 56` y `versionName 1.6.31`.
- Bloqueo sin capa encima: la interfaz original queda visible y el scroll sigue funcionando.
- El mismo boton cambia entre `BLOQUEAR GI X` y `DESBLOQUEAR GI X`.
- Mientras GI X esta bloqueado se desactivan API, voz, camara, imagen manual, vista previa y acciones de historial.
- Las respuestas parciales estables se publican en el cuadro de respuesta mientras llega la API.
- Las respuestas nuevas visibles entran a una cola de voz una sola vez para evitar repetir todo desde el inicio.
- Los textos superiores de API se dejaron mas cortos para limpiar la pantalla principal.

Nota: este entorno no tiene Gradle instalado, por eso la compilacion final debe correr en GitHub Actions.
