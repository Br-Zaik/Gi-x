# GI X v1.6.38 — Recepción, visión, API y voz (refuerzo focalizado)

Base: v1.6.37. `applicationId=com.gix.cameraai`, versionCode=63.

## Funcionamiento conservado
- La TimerCamera-X envía **hasta cuatro** JPEG originales **uno a uno**. En el firmware incluido las cuatro capturas comparten `requestId`. **No** existe `part` o `total` en las peticiones actuales. La captura configurada en ese firmware es **UXGA 1600 × 1200**, no 2048 × 1536. No se ha modificado firmware.
- Al completar 4, visión IA recibe las 4 imágenes juntas de inmediato. Si llegan 1–3, el lote se cierra por inactividad y envía las disponibles; jamás se requiere la cuarta. Con identificador se esperan 6 s sin nuevas fotos; sin identificador, 4 s. Si cambia el ID, el lote anterior se cierra. **No puede garantizarse contra pausas superiores a esa espera sin una señal explícita de fin de lote del firmware.**
- Visión IA lee las fotos directamente, devuelve CONTEXTO DETECTADO y PREGUNTAS DETECTADAS, y la app usa esa reconstrucción en la API de respuestas y voz; OCR local solo si falla visión. Manual sigue envío automático.

## Correcciones reales de esta versión
1. Ampliado de 25 s a 90 s el techo absoluto de agrupación para no dividir entregas secuenciales lentas por el antiguo corte arbitrario. **La espera normal de lotes 1–3 sigue siendo 6 s / 4 s**, no 90 s.
2. El diario de imágenes persiste el `requestId` antes de publicar el JPEG; si no puede guardarlo no confirma la recepción. Impide mezclar tras reiniciar la actividad JPEG de dos encendidos distintos porque desapareció el archivo de ID.
3. Un JPEG reenviado puede reparar un ID faltante de versiones anteriores sin duplicar el documento; el ID ya existente nunca se sobreescribe.
4. Prioridad a lotes de cámara almacenados/en cola antes de imágenes manuales pendientes.
5. Historial de JPEG confirmados acotado a 64 SHA y limpieza de IDs observados al completar audio; evita crecimiento ilimitado de esos conjuntos durante una sesión larga.
6. Un callback final de voz no confirma el lote si hubo un fallo de TTS.

## Comprobaciones y límites
- Test aislado de la política de lotes 1, 2, 3 y 4, ID nuevo e imágenes secuenciales lentas. Prueba aislada de reconocimiento/estructuración de preguntas si hay compilador Kotlin.
- No ejecutadas llamadas reales a Cheaper Inference, ni compilación APK Android integral en este entorno, ni prueba de enlace físico/TTS del Motorola. No prometer cero fallos.
- Si Android destruye la Activity, el servicio guarda JPEG, pero IA/voz se reanudan al abrir GI X.
