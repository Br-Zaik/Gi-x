# GI X v1.6.32 - Correccion de desbloqueo seguro

- Version subida a `versionCode 57` y `versionName 1.6.32`.
- Mantiene el bloqueo limpio sin capa encima: la interfaz original queda visible y el scroll funciona.
- Restaura el desbloqueo seguro: 3 toques rapidos en el mismo boton y luego confirmacion.
- El boton ya no desbloquea con un solo toque.
- Conserva los cambios de respuesta progresiva y voz en cola de v1.6.31.

Nota: este entorno no tiene Gradle instalado, por eso la compilacion final debe correr en GitHub Actions.
