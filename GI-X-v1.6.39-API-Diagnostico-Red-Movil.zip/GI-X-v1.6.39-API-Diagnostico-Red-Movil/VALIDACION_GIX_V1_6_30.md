# GI X 1.6.30 — Bloqueo sobre la interfaz original

- Basado en el código fuente v1.6.29; versión 1.6.30 / code 55.
- BLOQUEAR GI X superpone una capa transparente: se sigue viendo la misma pantalla de cámara, imagen, preguntas y respuestas en tiempo real.
- No se recrea pantalla GI X PROTEGIDO ni se duplican consultas OCR/API.
- La capa intercepta los toques; botón inferior DESBLOQUEAR tres veces rápido y confirmación, con cancelación.
- Se mantiene fijación de pantalla de Android; su propio mecanismo de desfijar sigue bajo control del sistema.
- No se modificaron cámara, firmware, API, OCR, voz ni servicio Wi-Fi.
- Validación del archivo ZIP y revisión estática; pendiente compilación real de APK y prueba en dispositivo.
