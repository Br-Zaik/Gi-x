package com.gix.cameraai

import android.content.Context
import java.io.File
import java.security.MessageDigest

/** Cola duradera de JPEG originales. Confirmar HTTP solo después de escribir la foto. */
class CameraPhotoJournal(context: Context) {
    data class Entry(val id: String, val jpeg: ByteArray, val requestId: String?)
    private val dir = File(context.filesDir, "pending_camera_jpegs").apply { mkdirs() }

    fun idFor(jpeg: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(jpeg).joinToString("") { "%02x".format(it) }

    @Synchronized fun save(jpeg: ByteArray, requestId: String?): String {
        val id = idFor(jpeg)
        val target = File(dir, "$id.jpg")
        val normalizedRequestId = requestId?.trim().orEmpty()
        val metadata = File(dir, "$id.req")
        if (target.isFile) {
            // El mismo JPEG reenviado se confirma sin duplicar. Reparar metadata
            // ausente de versiones previas, pero no reemplazar el ID ya guardado.
            if (!metadata.isFile && normalizedRequestId.isNotEmpty()) {
                metadata.writeText(normalizedRequestId)
            }
            return id
        }
        val files = dir.listFiles { file -> file.extension == "jpg" }.orEmpty()
        val used = files.sumOf { it.length() }
        if (files.size >= MAX_PHOTOS || used + jpeg.size > MAX_DISK_BYTES) {
            throw IllegalStateException("Cola de imágenes llena: no se confirmó la foto")
        }
        val tmp = File(dir, "$id.tmp")
        val tmpMetadata = File(dir, "$id.req.tmp")
        try {
            tmp.outputStream().use { out ->
                out.write(jpeg)
                out.flush()
                out.fd.sync()
            }
            // Guardar primero el identificador y después publicar el JPEG. Así
            // pendingIds() jamás ve una fotografía sin su requestId por una
            // terminación inesperada entre ambos archivos.
            if (normalizedRequestId.isNotEmpty()) {
                tmpMetadata.outputStream().use { out ->
                    out.write(normalizedRequestId.toByteArray(Charsets.UTF_8))
                    out.flush()
                    out.fd.sync()
                }
                if (!tmpMetadata.renameTo(metadata)) {
                    throw IllegalStateException("No se pudo guardar identificador del lote")
                }
            }
            if (!tmp.renameTo(target)) {
                throw IllegalStateException("No se pudo guardar fotografía recibida")
            }
        } finally {
            tmp.delete()
            tmpMetadata.delete()
        }
        return id
    }

    @Synchronized fun read(id: String): Entry? {
        if (!id.matches(Regex("[0-9a-f]{64}"))) return null
        val jpegFile = File(dir, "$id.jpg")
        if (!jpegFile.isFile) return null
        return runCatching {
            Entry(id, jpegFile.readBytes(), File(dir, "$id.req").takeIf { it.exists() }
                ?.readText()?.takeIf { it.isNotBlank() })
        }.getOrNull()
    }

    @Synchronized fun pendingIds(): List<String> = dir.listFiles { file -> file.extension == "jpg" }
        .orEmpty().sortedBy { it.lastModified() }.map { it.nameWithoutExtension }

    @Synchronized fun acknowledge(ids: Collection<String>) {
        for (id in ids) {
            if (!id.matches(Regex("[0-9a-f]{64}"))) continue
            File(dir, "$id.jpg").delete()
            File(dir, "$id.req").delete()
        }
    }

    companion object {
        private const val MAX_PHOTOS = 80
        private const val MAX_DISK_BYTES = 150L * 1024L * 1024L
    }
}
