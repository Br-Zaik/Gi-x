package com.gix.cameraai

/** Reglas de agrupación: 4 fotos es el máximo, NUNCA un mínimo para responder. */
internal object CameraBatchPolicy {
    const val MAX_IMAGES = 4
    // El firmware de 4 fotos envía el mismo requestId en toda la ráfaga.
    private const val IDENTIFIED_IDLE_MS = 6_000L
    // Firmware sin id: permitir breves demoras Wi-Fi entre capturas.
    private const val UNIDENTIFIED_IDLE_MS = 4_000L
    // Respaldo amplio: el firmware envía cada JPEG SECUENCIALMENTE y reintenta hasta 45 s.
    // La inactividad cierra 1-3 imágenes pronto; este techo no debe partir 4 entregas lentas.
    private const val MAX_BATCH_LIFETIME_MS = 90_000L

    fun mustSplit(currentRequestId: String?, incomingRequestId: String?): Boolean {
        val current = currentRequestId?.trim().orEmpty()
        val incoming = incomingRequestId?.trim().orEmpty()
        // Mantener conservador: un cambio entre con/sin id también marca lote nuevo.
        return (current.isNotEmpty() || incoming.isNotEmpty()) && current != incoming
    }

    fun idleDelayMs(requestId: String?, elapsedMs: Long): Long {
        val idle = if (requestId.isNullOrBlank()) UNIDENTIFIED_IDLE_MS else IDENTIFIED_IDLE_MS
        val remaining = (MAX_BATCH_LIFETIME_MS - elapsedMs.coerceAtLeast(0L)).coerceAtLeast(0L)
        return minOf(idle, remaining)
    }
}
