# GI X 1.6.35 — reparación de casillas numeradas dentro de preguntas

## Error reproducido

Un cuestionario con preguntas 1–10 y con espacios de respuesta bajo la pregunta 8 (`1. ______`, `2. ______`) era segmentado como 1,2,3,4,5,6,7,8,1,2,9,10. El control `hasCorruptNumbering` detenía la consulta de respuestas antes de `fetchShortAnswer`. Si el OCR de visión IA estaba activo, la imagen sí podía haber llegado a la API de *lectura*, pero la consulta de *respuestas* no se ejecutaba.

## Corrección localizada

- Conservar casillas de subrespuesta numeradas dentro del enunciado padre sin contarlas como preguntas independientes.
- Preservar las líneas originales para mostrarlas en «Preguntas detectadas» y enviarlas como parte de la pregunta.
- No borrar ni saltarse controles de numeración cuando aparecen preguntas numeradas verdaderamente duplicadas o fuera de orden.
- Sin cambios en cámara, envío automático, voz, bloqueo ni configuración de la API.
- `versionCode 60`, `versionName 1.6.35`.

La compilación final de APK y la prueba física de cámara/voz deben realizarse por GitHub Actions y Android.
