# VALIDACIÓN GI X v1.6.25

1. Base: GI X v1.6.24.
2. package/applicationId sin cambios: `com.gix.cameraai`.
3. versionCode 50 / versionName 1.6.25.
4. No se cambió cámara, resolución, flujo de 1-4 imágenes, OCR local ni interfaz general.
5. Respuestas por lote de Cheaper Inference usan streaming SSE (`stream: true`).
6. La pantalla publica respuestas completas de forma progresiva mientras siguen llegando las demás.
7. El prompt exige una respuesta por línea para permitir actualización progresiva segura.
8. Si el stream se corta, las líneas completas ya recibidas se conservan y solo se recuperan las faltantes.
9. Cheaper Inference usa `ranking: speed` y conserva `X-CI-Concise: 1` + razonamiento mínimo.
10. Se mantienen respuestas cortas y numeración original; no se inventan números en preguntas sin numeración.
