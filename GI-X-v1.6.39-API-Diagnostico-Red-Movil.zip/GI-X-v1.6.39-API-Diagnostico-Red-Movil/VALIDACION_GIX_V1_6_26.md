# GI X v1.6.26 — cámara automática y protección táctil

Base: v1.6.25; applicationId `com.gix.cameraai`; versionCode 51.

- Modo CÁMARA está a la escucha del servidor local desde el inicio; firmware actual envía JPEG al encender aunque no se emita CAPTURE.
- Retirados del modo cámara los botones redundantes de captura y AUTO: OFF. La recepción, cola de lotes, API streaming y voz permanecen activos.
- BLOQUEAR TOQUES instala una capa completa que consume toques sobre la UI. En esa capa, DESBLOQUEAR requiere tres pulsaciones dentro de cuatro segundos.
- SALIR separado: tras desbloquear, abre confirmación antes de cerrar la Activity.
- ATRÁS no puede salir mientras la capa está activa. Fuera de ella conserva los tres ATRÁS históricos.
- Se solicita anclaje de pantalla de Android mediante startLockTask; la confirmación del sistema y los gestos de desanclaje dependen de la configuración del teléfono. No se afirma bloqueo absoluto de Inicio, botón de encendido ni panel de notificaciones.
- No se cambian firmware, API, OCR, cámara ni el modelo de respuestas.

Compilar con GitHub Actions (`:app:assembleDebug`) y probar físicamente el anclaje y la recepción Wi-Fi en el teléfono antes del uso real. No se ejecutó compilación Android en este entorno.
