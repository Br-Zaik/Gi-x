# VALIDACIÓN GI X v1.6.24

1. 1-4 imágenes originales se envían juntas a visión IA.
2. La IA compara las tomas por zona y prioriza la más nítida/legible de cada parte.
3. Preguntas detectadas conserva los enunciados completos.
4. Respuestas no repite las preguntas.
5. Con número impreso: `7. S 60° W.`
6. Sin número impreso: solo la respuesta, sin inventar numeración visible.
7. TTS usa la misma salida corta.
8. OCR local sigue como respaldo.
9. versionCode 49 / versionName 1.6.24.
10. Se conserva `com.gix.cameraai`, cámara, API y corrección de instalación Android 11 de v1.6.23.
