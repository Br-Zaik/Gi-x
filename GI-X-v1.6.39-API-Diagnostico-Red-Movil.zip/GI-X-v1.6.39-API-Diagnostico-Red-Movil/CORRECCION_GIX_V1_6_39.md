# GI X v1.6.39 — Conectividad API y diagnóstico verificable

## Hallazgos reales
- La etiqueta v1.6.33 era fija en el XML aunque el APK fuera más nuevo.
- El proveedor transformaba todos los HTTP 5xx y varios temporales en «servidor ocupado», ocultando el código y el mensaje original. No hay evidencia de que el servidor y no la ruta de red fuera el culpable.
- La versión anterior había quitado `VALIDATED` sin comprobar si HTTPS seguía saliendo por una Wi-Fi local SIN Internet. Ahora cada solicitud API puede abrir HTTPS por la red celular validada cuando la ruta predeterminada no tiene Internet, sin sacar de Wi-Fi al servidor de la cámara.
- Se retiró el header X-CI-Concise no documentado, sin cambiar la clave, URL, proveedor, modelo o voz.
- Se oculta por defecto la clave al pegarla y no se incluye la clave en los errores, que ahora indican HTTP e ID del request de CheaperInference si viene en la respuesta.
- No se reintentan automáticamente pruebas con error de clave, saldo, 429 o sin red. Los fallos temporales todavía pueden reintentarse hasta dos veces.

## Verificación pendiente
Compilar APK en Actions y comprobar tanto los datos móviles con hotspot como la prueba API guardada; no disponemos de la clave privada del usuario ni de la cámara real.

## Datos que NO deben exponerse
No publique capturas con claves API. Si se compartió una clave, debe rotarse en el panel del proveedor.
