# GI X v1.6.27 · Estabilidad prolongada (fuente)

- `versionCode 52`, `versionName 1.6.27`; mismo package, API, OCR y respuestas.
- La pantalla SIGUE encendida con `FLAG_KEEP_SCREEN_ON` mientras está en modo cámara.
- Servicio foreground `connectedDevice`: el socket Wi-Fi ya NO depende de la vida de MainActivity.
- Reconexión del socket en watchdog cada 5 s con intervalos crecientes hasta 60 s; no reinicia la zona Wi-Fi del sistema.
- WakeLock CPU parcial temporal con límite y limpieza al salir; NO impide cierres forzosos del fabricante ni Doze por completo.
- El servidor inspecciona y escribe JPEG originales en archivos internos ANTES de responder HTTP 200. Cola máximo 80 fotos / 150 MB: si se llena NO confirma HTTP 200. En caso de cierre inesperado, se recupera al abrir la UI. El servicio solo guarda; la IA/TTS dependen de la actividad visible.
- Los lotes desplazados de RAM se guardan como IDs para reconstruirse desde el disco y evitar borrado silencioso de fotos pendientes.
- Al concluir una respuesta válida, se quitan las fotos correspondientes del diario; ante error, permanecen pendientes para otro inicio.
- Temperatura severa API >=29: pospone tareas nuevas hasta que el sistema se enfríe. No enfría físicamente el teléfono.
- Firmware INCLUIDO actualizado opcional (requiere reflashear M5Stack): 4 fotos UXGA por encendido con un mismo id y confirmación HTTP de cada JPEG; sin reflashear la cámara seguirá enviando 1 foto por encendido. La app espera hasta 7 s después de la primera para agrupar.
- NO verificado mediante APK instalado en hardware. Compilar por GitHub Actions y probar durante varias horas con hotspot, voz, zona Wi-Fi y fotos reales. Nunca puede prometerse funcionamiento 100% ante apagado/force-stop, corte de batería/datos o cierres del sistema.
