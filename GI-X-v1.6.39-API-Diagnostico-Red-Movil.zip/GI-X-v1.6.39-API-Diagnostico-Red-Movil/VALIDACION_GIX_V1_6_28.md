# GI X 1.6.28 — Protección de modo CÁMARA

Base: v1.6.27. Solo cambios de pantalla de bloqueo/salida.

- El modo cámara tiene un único control en su fila: BLOQUEAR GI X. Se oculta SALIR de esa fila.
- Las fotografías, servidor, firmware, OCR, vision, API y TTS se conservan intactos.
- Se mantiene encendida la pantalla. Se inicia `startLockTask()` al bloquear: Android puede pedir permiso de fijar pantalla y su propio gesto de desfijado sigue teniendo prioridad sobre la aplicación.
- Pantalla bloqueada absorbe toques de la app y desbloquea únicamente tras tres pulsaciones del control dentro de 1,8 segundos y confirmación. Cancelar conserva el bloqueo.
- Al desbloquear, la cámara sigue trabajando. ATRÁS 3 veces + confirmación sigue siendo la salida de la app.

Limitación Android: una aplicación convencional no puede deshabilitar por sí misma físicamente Inicio/Recientes o impedir desfijar pantalla mediante el gesto del sistema. Para protección completa tipo kiosco se requiere administración del dispositivo/Device Owner, que NO se configura en este ZIP.

Pendiente: ejecutar build GitHub Actions y prueba física en el teléfono; no se declara probado en un Android real.
