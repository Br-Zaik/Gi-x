# GI X v1.6.34 · Ciclo automático de cámara y manual

- Ambos modos continúan de imagen → OCR/visión → vista previa íntegra → API → TTS sin botón de aprobación.
- La casilla de revisión y el panel RESPONDER CON IA permanecen ocultos (IDs conservados por compatibilidad con ViewBinding).
- Cámara: recibe y agrupa hasta cuatro JPEG con ventana de silencio de 6 s solo cuando llegan menos de cuatro fotos del mismo lote; con cuatro imágenes, procesa inmediatamente; nuevas fotos durante API o voz permanecen en cola y diario persistente.
- Tras el último fragmento de voz, confirma los JPEG usados y procesa el siguiente lote. Si Android destruye el proceso antes del último audio, el diario permite recuperar las fotos al abrir la app.
- Revisión periódica del diario cuando la cámara está ociosa; reenvíos JPEG ya finalizados no vuelven a llenar el diario.
- Errores tardíos de un TTS anterior no cancelan la narración de un nuevo ciclo.
- Si se eligen imágenes manuales durante una narración, se ponen en cola y no cortan el audio de la cámara.
- Si la API responde parcialmente o la voz no termina, las fotos de cámara no se borran del diario (se recuperan al reabrir GI X).
- No se tocó el bloqueo de tres toques, el paquete, la API configurada ni el firmware de cámara.

**Limitación Android:** CameraLinkService puede continuar recibiendo y guardando fotos aun si se destruye MainActivity; el OCR, la consulta API y la reproducción TTS todavía residen en MainActivity. La pantalla debe permanecer abierta (puede estar bloqueada dentro de GI X). Android o el fabricante pueden matar el proceso y no se promete funcionamiento ininterrumpido durante horas sin prueba física.

**Verificación pendiente:** Compilar APK en GitHub Actions y probar dispositivo real / TimerCamera-X; pruebas locales estáticas no sustituyen esta integración.

## Comprobaciones realizadas en este entorno

- XML y AndroidManifest validados sintácticamente.
- Código puro de extracción / fusión / normalización compilado con Kotlin y probado: lectura, alternativas, V/F, completar, respuesta abierta, fusión de dos capturas, duplicados SHA-256.
- Diario de imágenes compilado con un stub de Context y probado: guardar, leer, evitar duplicados y confirmar borrado.
- El código Android completo no se pudo compilar aquí porque no hay Android SDK/Gradle; ejecutar el workflow de GitHub Actions y verificar recepción + API + voz en el Motorola.
