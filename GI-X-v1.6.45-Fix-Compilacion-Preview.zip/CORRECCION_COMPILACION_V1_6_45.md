# GI X v1.6.45 — corrección de compilación

Se corrigió el fallo observado en GitHub Actions (job 108496407684) dentro de `MainActivity.kt`.

La limpieza de OCR local de v1.6.45 eliminó por error tres helpers de interfaz que NO pertenecían al OCR:

- `makePreviewThumbnail(Bitmap)`
- `clearAllPreviews()`
- `dropPreviewReferencesForDestroy()`

Esas funciones son necesarias para crear/liberar miniaturas de vista previa y soltar referencias al destruir la Activity. Se restauraron sin reintroducir ML Kit, ONNX, OpenCV ni PP-OCR.

Los errores secundarios `isRecycled` / `recycle` del log eran consecuencia de que Kotlin no podía resolver el tipo correcto de la lista de miniaturas al faltar `makePreviewThumbnail`.

La arquitectura sigue siendo solo online:

1–4 imágenes -> optimización -> API visual -> preguntas/contexto -> API de respuestas -> TTS.
