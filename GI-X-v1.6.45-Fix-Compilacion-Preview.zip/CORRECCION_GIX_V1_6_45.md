# GI X v1.6.45 — limpieza y robustez online

Cambios principales:

- Eliminados motores/modelos OCR locales: PP-OCR, ML Kit Text Recognition, ONNX Runtime y OpenCV.
- Flujo único online: imagen optimizada → visión IA → preguntas/contexto → respuestas → TTS.
- Últimas imágenes ganan: nueva entrada cancela API/TTS/trabajo anterior; no hay cola de documentos.
- Corregido el caso en que visión devuelve un examen V/F o similar como texto: ahora pasa al rescate de estructura antes de decidir que no hay preguntas.
- Sin reintentos automáticos tras timeout o fallo temporal incierto.
- Recuperación por división solo cuando el proveedor declara explícitamente límite de salida.
- Detección de truncamiento visual por `finish_reason`.
- Diagnóstico acumulado de tokens/llamadas/tiempo cuando `usage` está disponible.
- Optimización de imágenes manuales/cámara antes de Base64 y control de tamaño.
- Clasificación HTTP separada para auth, 400/modelo, 413, 429, 5xx y timeout.
- API Key cifrada con Android Keystore AES-GCM y migración de claves antiguas en texto plano.
- Respuesta final de cámara persistida antes de TTS para evitar una segunda llamada si Android cierra la app durante la voz.
- Historial fuera de SharedPreferences, con límites y sin backup.
- Workflows limpiados de PP-OCR y nombre de APK dinámico.
- `versionCode 70` / `versionName 1.6.45`.

No se modificó el firmware ni el protocolo de TimerCamera-X.
