# Validación GI X v1.6.44

- Base confirmada: v1.6.43.
- `applicationId com.gix.cameraai` intacto.
- `versionName 1.6.44`, `versionCode 69`.
- Regla de completar actualizada en prompt de lote y prompt individual.
- Respuesta objetivo: normalmente 2–4 palabras; 1 palabra sigue permitida si es inequívoca.
- Sin cambios en cámara, bloqueo, TTS, firmware o configuración de API.
