# Validación GI X v1.6.45

## Estado

Versión revisada: `1.6.45` (`versionCode 70`).

## Comprobaciones realizadas

- Pruebas puras de extracción de preguntas: correctas.
  - Numeración y alternativas.
  - Casillas/subrespuestas internas sin crear preguntas falsas.
  - Rescate de examen V/F cuando la visión lo entrega como contexto/texto.
- Pruebas de delimitadores/formato del proveedor: correctas.
- Pruebas del TTS progresivo: correctas; no repite fragmentos ya hablados.
- Pruebas de agrupación de cámara: correctas para 1, 2, 3 y 4 fotos y separación por nuevo request ID.
- XML Android (`AndroidManifest`, reglas de backup y extracción): parseo correcto.
- Workflows YAML de GitHub Actions: parseo correcto.
- Escaneo sintáctico Kotlin sin Android classpath: no se detectaron errores de sintaxis (`expecting`, `unexpected tokens`, redeclaraciones).
- No quedan referencias activas a PP-OCR, ML Kit Text Recognition, ONNX Runtime, OpenCV ni scripts de preparación de OCR local.
- No quedan artefactos `.onnx`, `.so` o `.aar` del OCR local dentro de `app`.
- No quedan referencias activas a versiones antiguas v1.6.23/v1.6.40 en la app o workflows.
- `app/build.gradle` confirma `versionCode 70` y `versionName 1.6.45`.

## Cambios de robustez verificados por código

- Flujo online-only: imagen → visión IA → estructura de documento → respuesta IA → TTS.
- Entrada nueva invalida el trabajo anterior; no existe cola de documentos.
- Respuestas tardías se descartan mediante generación/work ID.
- La conexión activa y TTS se cancelan al iniciar un documento nuevo.
- No hay reintento automático tras timeout incierto.
- La recuperación por división solo se permite ante límite explícito de salida.
- La visión detecta truncamiento por `finish_reason` y no continúa con una transcripción incompleta.
- Diagnóstico de llamadas/tokens/tiempo cuando el proveedor devuelve `usage`.
- Preparación de imagen con reducción de tamaño antes de Base64 para limitar memoria/payload.
- Clasificación separada de 401/403, 400/404/405/422, 413, 429, 5xx y timeout.
- API Key almacenada mediante Android Keystore AES-GCM, con migración de la clave antigua.
- Respuesta de cámara persistida antes del TTS para poder reanudar voz sin repetir una llamada pagada.
- Historial movido fuera de SharedPreferences y fuera de backup.
- Workflows sin descarga de OCR y con nombre de APK basado en `versionName`.

## Limitación de esta validación

Este entorno no dispone de Android SDK/Gradle ni acceso de red utilizable para instalar el toolchain, por lo que **no se realizó una compilación APK Android completa local**. La compilación final debe validarse con GitHub Actions, que sí prepara el entorno Android del repositorio.
