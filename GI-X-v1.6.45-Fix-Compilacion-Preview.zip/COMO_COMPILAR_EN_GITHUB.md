# Compilar GI X v1.6.45 en GitHub desde el celular

La v1.6.45 ya no necesita descargar modelos OCR ni ejecutar scripts antes de compilar.

1. Sube el ZIP al repositorio como haces normalmente.
2. Abre **Actions**.
3. Ejecuta **Compilar GI X APK desde ZIP** si no arrancó solo.
4. El workflow valida el ZIP, encuentra `settings.gradle`, compila `:app:assembleDebug`, verifica firma/alineación y publica la APK.
5. El nombre de salida se genera desde `versionName`; para esta versión será `GI-X-v1.6.45-debug.apk`.

El workflow alternativo **Build GI X APK** también compila directamente el contenido del repositorio.

No hace falta tocar el firmware de la TimerCamera-X para esta actualización.
