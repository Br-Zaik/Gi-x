# GI X v1.6.44 — Completar frases con respuestas más claras

Base: GI X v1.6.43. Package/applicationId sin cambios: `com.gix.cameraai`.

## Cambio solicitado

Las preguntas de completar ya no fuerzan una respuesta excesivamente mínima de una sola palabra cuando eso hace que el resultado se vea pobre o ambiguo.

Nueva regla de respuesta:
- normalmente 2 a 4 palabras para completar de forma clara y natural;
- puede usar 1 sola palabra, símbolo o término técnico cuando sea inequívoco;
- no añade explicaciones ni definiciones innecesarias;
- se aplica tanto a preguntas individuales como a lotes de varias preguntas.

Ejemplos esperados:
- `Preparación` -> `Etapa de preparación` cuando el contexto lo pida;
- `minables` -> `Reservas minables`;
- `meteorización` -> `Proceso de meteorización`;
- `Au` permanece `Au` cuando se pide símbolo químico.

No se modificó la política v1.6.43 de prioridad de imágenes nuevas, el bloqueo, cámara, TTS, firmware ni credenciales/API guardadas.

Versión Android: `1.6.44` (`versionCode 69`).
