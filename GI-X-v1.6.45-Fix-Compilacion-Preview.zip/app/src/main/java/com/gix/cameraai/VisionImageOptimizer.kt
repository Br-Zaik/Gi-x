package com.gix.cameraai

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import java.io.ByteArrayOutputStream
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Prepara imágenes para la API visual sin reconocimiento local.
 *
 * Evita cargar y convertir a Base64 fotografías enormes del selector manual.
 * Conserva suficiente resolución para texto pequeño y normaliza la salida a JPEG.
 */
object VisionImageOptimizer {
    private const val MAX_SIDE = 2200
    private const val JPEG_QUALITY = 90
    private const val MAX_BYTES = 4_700_000

    fun optimizeCameraJpeg(jpeg: ByteArray): VisionImagePayload? {
        if (jpeg.isEmpty()) return null
        val info = CameraJpegDecoder.inspect(jpeg) ?: return null
        val longSide = max(info.width, info.height)
        if (longSide <= MAX_SIDE && jpeg.size <= MAX_BYTES) {
            return VisionImagePayload(jpeg, "image/jpeg")
        }
        val bitmap = CameraJpegDecoder.decodeForVision(jpeg) ?: return null
        return try {
            encode(bitmap)
        } finally {
            if (!bitmap.isRecycled) bitmap.recycle()
        }
    }

    fun optimizeUri(context: Context, uri: Uri): VisionImagePayload? {
        val bitmap = ImageLoader.load(context, uri) ?: return null
        return try {
            encode(bitmap)
        } finally {
            if (!bitmap.isRecycled) bitmap.recycle()
        }
    }

    private fun encode(source: Bitmap): VisionImagePayload? {
        val scaled = scaleIfNeeded(source)
        return try {
            var quality = JPEG_QUALITY
            var bytes = compressJpeg(scaled, quality)
            while (bytes.size > MAX_BYTES && quality > 70) {
                quality -= 8
                bytes = compressJpeg(scaled, quality)
            }
            if (bytes.isEmpty() || bytes.size > 5 * 1024 * 1024) null
            else VisionImagePayload(bytes, "image/jpeg")
        } finally {
            if (scaled !== source && !scaled.isRecycled) scaled.recycle()
        }
    }

    private fun scaleIfNeeded(source: Bitmap): Bitmap {
        val longSide = max(source.width, source.height)
        if (longSide <= MAX_SIDE) return source
        val factor = MAX_SIDE.toFloat() / longSide.toFloat()
        val width = (source.width * factor).roundToInt().coerceAtLeast(1)
        val height = (source.height * factor).roundToInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(source, width, height, true)
    }

    private fun compressJpeg(bitmap: Bitmap, quality: Int): ByteArray {
        val out = ByteArrayOutputStream()
        if (!bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)) return ByteArray(0)
        return out.toByteArray()
    }
}
