package com.gix.cameraai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class HistoryEntry(
    val id: String,
    val timestamp: Long,
    val source: String,
    val questionCount: Int,
    val ocrText: String,
    val answerText: String
)

/**
 * Historial liviano fuera de SharedPreferences para evitar leer/regrabar un JSON grande
 * cada vez que se abre la app. Se guarda en noBackupFilesDir.
 */
class HistoryRepository(context: Context) {
    private val file = File(context.noBackupFilesDir, "gix_history_v1645.json")
    private val oldPrefs = context.getSharedPreferences("gix_history", Context.MODE_PRIVATE)

    init {
        migrateLegacyIfNeeded()
    }

    @Synchronized
    fun getAll(): List<HistoryEntry> = parse(file.takeIf { it.isFile }?.readText().orEmpty())

    @Synchronized
    fun add(entry: HistoryEntry) {
        val safe = entry.copy(
            ocrText = entry.ocrText.take(MAX_DOCUMENT_CHARS),
            answerText = entry.answerText.take(MAX_ANSWER_CHARS),
        )
        val list = getAll().toMutableList()
        list.removeAll { it.id == safe.id }
        list.add(0, safe)
        save(list.take(MAX_ITEMS))
    }

    @Synchronized
    fun delete(id: String) {
        save(getAll().filterNot { it.id == id })
    }

    @Synchronized
    fun clear() {
        file.delete()
        oldPrefs.edit().remove(OLD_KEY_HISTORY).apply()
    }

    private fun migrateLegacyIfNeeded() {
        if (file.isFile) return
        val legacy = oldPrefs.getString(OLD_KEY_HISTORY, null).orEmpty()
        if (legacy.isBlank()) return
        val parsed = parse(legacy)
        if (parsed.isNotEmpty()) save(parsed.take(MAX_ITEMS))
        oldPrefs.edit().remove(OLD_KEY_HISTORY).apply()
    }

    private fun parse(raw: String): List<HistoryEntry> {
        if (raw.isBlank()) return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val obj = array.optJSONObject(i) ?: continue
                    add(
                        HistoryEntry(
                            id = obj.optString("id", System.currentTimeMillis().toString()),
                            timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                            source = obj.optString("source", "desconocido"),
                            questionCount = obj.optInt("questionCount", 0),
                            ocrText = obj.optString("ocrText").take(MAX_DOCUMENT_CHARS),
                            answerText = obj.optString("answerText").take(MAX_ANSWER_CHARS),
                        )
                    )
                }
            }.sortedByDescending { it.timestamp }
        }.getOrElse { emptyList() }
    }

    private fun save(entries: List<HistoryEntry>) {
        val array = JSONArray()
        entries.forEach { entry ->
            array.put(
                JSONObject().apply {
                    put("id", entry.id)
                    put("timestamp", entry.timestamp)
                    put("source", entry.source)
                    put("questionCount", entry.questionCount)
                    put("ocrText", entry.ocrText.take(MAX_DOCUMENT_CHARS))
                    put("answerText", entry.answerText.take(MAX_ANSWER_CHARS))
                }
            )
        }
        file.parentFile?.mkdirs()
        val tmp = File(file.parentFile, file.name + ".tmp")
        tmp.writeText(array.toString())
        if (!tmp.renameTo(file)) {
            file.writeText(array.toString())
            tmp.delete()
        }
    }

    companion object {
        private const val OLD_KEY_HISTORY = "history_entries"
        private const val MAX_ITEMS = 30
        private const val MAX_DOCUMENT_CHARS = 12_000
        private const val MAX_ANSWER_CHARS = 8_000
    }
}
