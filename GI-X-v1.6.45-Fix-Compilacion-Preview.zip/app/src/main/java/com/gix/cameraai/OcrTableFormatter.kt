package com.gix.cameraai

/**
 * Utilidades de texto para tablas que devuelve la IA.
 *
 * GI X v1.6.45 usa visión online. Se conservan
 * únicamente estos marcadores porque el extractor y el prompt de respuestas
 * todavía pueden recibir tablas estructuradas desde la API visual.
 */
object OcrTableFormatter {
    const val STRUCTURED_TABLES_HEADER = "[GIX_STRUCTURED_TABLES]"
    const val TABLE_START = "[GIX_TABLE_START]"
    const val TABLE_END = "[GIX_TABLE_END]"
    const val EMPTY_CELL = "[VACÍO]"

    data class TableData(
        val headers: List<String>,
        val rows: List<List<String>>
    ) {
        fun toPromptText(): String = buildString {
            append(TABLE_START).append('\n')
            append("Columnas: ").append(headers.joinToString(" | ")).append('\n')
            rows.forEachIndexed { index, row ->
                append("Fila ").append(index + 1).append(": ")
                append(row.map { it.ifBlank { EMPTY_CELL } }.joinToString(" | "))
                append('\n')
            }
            append(TABLE_END)
        }
    }

    fun parseStructuredTables(raw: String): List<String> {
        val metadata = raw.substringAfter(STRUCTURED_TABLES_HEADER, "")
        if (metadata.isBlank()) return emptyList()
        val regex = Regex(
            Regex.escape(TABLE_START) + "(.*?)" + Regex.escape(TABLE_END),
            setOf(RegexOption.DOT_MATCHES_ALL)
        )
        return regex.findAll(metadata)
            .map { match -> TABLE_START + "\n" + match.groupValues[1].trim() + "\n" + TABLE_END }
            .toList()
    }

    fun removeStructuredTables(raw: String): String =
        raw.substringBefore(STRUCTURED_TABLES_HEADER).trim()

    fun toDisplayText(raw: String): String {
        val base = removeStructuredTables(raw)
        val tables = parseStructuredTables(raw)
        if (tables.isEmpty()) return base.trim()

        val prettyTables = tables.mapIndexed { index, block ->
            val body = block
                .replace(TABLE_START, "")
                .replace(TABLE_END, "")
                .replace(EMPTY_CELL, "(vacío)")
                .trim()
            "Tabla ${index + 1}:\n$body"
        }.joinToString("\n\n")

        return buildString {
            if (base.isNotBlank()) append(base.trim()).append("\n\n")
            append(prettyTables)
        }.trim()
    }
}
